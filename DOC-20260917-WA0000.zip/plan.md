# Plan — NFT Mint Bot → Web Platform with Auto Copy-Trading

## Context (carried over from last chat)
Existing deliverable at `/mnt/agents/output/nft-mint-bot/`: CLI Node.js EVM auto-mint bot
(`bot.js`, `src/config.js`, `src/minter.js`, `src/monitor.js`, `src/utils.js`,
`scripts/precheck.js`, `.env.example`). Features: time/poll/event triggers, EIP-1559
gas-bump replacement retries, multi-wallet, dry-run mode.

## New requirements (this chat)
1. Turn the bot into a **website**: browser dashboard to configure/run/monitor the mint bot.
2. Add **auto copy-trading**: track user-listed "profitable sniper/trader" wallets, detect
   their on-chain NFT activity (mints / buys), auto-mirror with configurable sizing, spend
   caps, and per-wallet toggles.
3. Safety posture: simulation/paper mode by default, keys stay server-side (never in the
   frontend bundle), no profit guarantees anywhere in copy, live-execution gated behind
   explicit user config (RPC + keys) — delivered preview runs in simulation mode.

## Stage 1 — Foundation & skill loading
- Load `vibecoding-webapp-swarm` (orchestration, design-first workflow, delivery model).
- Load `swarm-workspace` for worktree setup.
- Load `webapp-building-swarm` (React frontend artifact) + `backend-building-swarm`
  (tRPC + Drizzle + Hono graft) per the full-stack composition rule.
- Output: shared repo + worktree ready.

## Stage 2 — Design brief
- Define product: "MintPilot" style dashboard — dark trading-terminal aesthetic,
  low-saturation palette per default standards.
- Pages: Overview (live status, PnL sim), Mint Bot (config form + trigger status + logs),
  Copy Trading (watched wallets table, signal feed, mirror settings), Wallets, Activity log,
  Settings (RPC, mode toggle, caps).
- Output: design brief + page inventory passed to builders.

## Stage 3 — Frontend build (subagent: webapp builder)
- React + TS + Tailwind + shadcn/ui dashboard implementing Stage 2 pages.
- Consumes backend via tRPC; live updates via subscription/polling.
- Output: built frontend in worktree, committed on frontend branch.

## Stage 4 — Backend graft (subagent: backend builder)
- tRPC + Drizzle + Hono on the same repo: routers for mint-config, bot control
  (start/stop/status), watched wallets CRUD, signals, activity log, settings.
- Bot engine integration: port `src/monitor.js` + `src/minter.js` into a server-side
  `MintEngine`; new `CopyTrader` engine (wallet watcher → signal → mirror execution) with
  simulation-mode execution path (no keys required in preview).
- Output: backend branch committed; merged by lead.

## Stage 5 — Validation (verifier subagent)
- npm install, build frontend, boot server, smoke-test routers + pages, confirm no private
  keys reachable from client bundle, confirm simulation mode default.
- Output: pass/fail report; iterate on failures.

## Stage 6 — Delivery
- `website_version_manager build_version` (type: dynamic if Dockerfile/server-backed,
  else static) and final summary to user.

## File propagation
- Stage 2 brief → Stage 3/4 prompts; existing bot source paths handed to Stage 4;
  Stage 3+4 branches merged before Stage 5; Stage 5 report gates Stage 6.

## Iteration 2 (post-launch features)
1. **Smart RPC manager** — `contracts/rpc.ts` endpoint pools per chain (multiple public HTTPS endpoints each), server-side latency race (eth_chainId timing, parallel, 3.5s timeout, chainId-validated), cached best-endpoint per chain (5min TTL), `user_settings.rpcAuto` toggle (default true) — engine resolves RPC via manager (custom URL when rpcAuto=false). Settings UI: auto/custom toggle + "Race now" ranked latency list.
2. **NFT link import** — pure parser `contracts/nftLinks.ts`: OpenSea /assets/:chain/:addr/:id, Blur, MagicEden, Zora, Rarible, explorer /address links, bare 0x → {chainId, contractAddress, tokenId, source}. Used in TaskWizard (prefill chain+contract) and CopyTrading (OpenSea profile links → watched wallet).
3. **Contract auto-inspect** — `tasks.inspect({chainId, contractAddress})`: probe common view fns (saleActive variants, mintPrice/cost/price, maxPerWallet) + estimateGas on candidate mint fns → prefill mintFunction/value/sale state chips in wizard.
4. Schema: add `rpcAuto` to user_settings (schema.ts + ensureSchema.ts COLUMN_ADDS + CREATE — journal migrator unreliable in runtime, embedded ensure is source of truth).
5. Gates: check + build → build_version.

## Iteration 3 (on-chain trader discovery)
1. **ChainScanner engine** (`api/engine/chainScanner.ts`): fetch Seaport OrderFulfilled logs (topic0 0x9d9af8e3..., addresses 1.1/1.5/1.6 canonical) over recent block window via rpcManager best endpoint; adaptive chunking (500→250→100→50 on range errors), 90s budget; decode via ethers Interface; aggregate per wallet: buys/sells/volume/collections + realized PnL for single-NFT buy→sell pairs seen in window; NATIVE + chain WETH counted, other tokens excluded (noted).
2. **Schema**: `discovered_traders` table (global per-chain results, upsert on rescan) — schema.ts + ensureSchema.ts (runtime source of truth).
3. **tRPC `discover` router**: `scan({chainId})` (10-min per-chain cooldown, returns window summary), `list({chainId, limit})` ranked by realizedPnl; copy via existing copy.add.
4. **UI**: CopyTrading "Discover (on-chain)" tab — chain chips, scan button w/ progress, methodology disclosure, ranked results table, per-row Copy button.
5. Gates: check + build → build_version.

## Iteration 4 (orderbook fix + unrealized PnL + charts + cleanup)
0. VERIFIED: Seaport 1.6 live on Ink + Robinhood (getCode + OrderFulfilled logs); OpenSea supports both chains; Reservoir NFT API sunset 2025-10-15 → replace with OpenSea API v2 (api key, free).
1. Sweeper: Reservoir client → opensea.ts (floor via /v2/orders/{chain}/seaport/listings, fulfill via /v2/listings/fulfillment_data); openseaApiKey setting; unlock Robinhood+Ink; graceful no-key state.
2. Scanner: unrealized PnL — open positions (bought/minted in window, unsold) marked at latest in-window collection sale price; flips status/mark/unrealized; trader totals.
3. Charts/deep detail: recharts — drawer cumulative PnL curve, win/loss histogram, mint-vs-secondary split; discover aggregate stat cards + top-10 bar; watchlist signal equity sparkline.
4. UI cleanup + error sweep (verifier): eslint/tsc/build clean, server smoke test, consistency fixes.

## Iteration 5 — All-time PnL via OpenSea profiles (user: "search unrealized and realized pnl through opensea profiles transaction. Also Not latest pnl, all time pnl")
1. New api/engine/openseaProfiler.ts: fetch full account event history via OpenSea v2 (`GET /v2/events/accounts/{address}` paginated, event_type=sale, buyer/seller attribution, ETH/WETH only), FIFO pair per collection+chain → ALL-TIME realized PnL; open positions marked at CURRENT collection floor (`/v2/collections/{slug}/stats` floor_price) → unrealized PnL. Events carry closing_date timestamps → true all-time cumulative PnL curve.
2. Cache: wallet_profiles table (address-keyed JSON payload + fetchedAt, 30-min TTL, force-refresh param) in schema.ts + ensureSchema.ts.
3. Router: discover.walletProfile(address) — needs openseaApiKey, graceful no-key error.
4. UI: WalletProfile drawer from Discover rows + Watchlist rows — all-time realized/unrealized/total PnL, win rate, volume, per-chain split, cumulative PnL area chart over real timestamps, best/worst flips, open positions w/ floor marks. Disclosure: OpenSea trade history only (Seaport venues).
5. Gates: check/build/vitest, then version.

## Iteration 6 — Non-ETH/WETH payments + period PnL windows (user: "Add non eth/weth support, and add checking all time pnl/unrealized pnl of 1week, 3 weeks")
1. Price oracle layer (api/engine/priceOracle.ts): DefiLlama coins API (free, no key) — historical prices at sale timestamp (`/prices/historical/{ts}/{chain}:{token}` batched, hour-rounded, in-memory cache); convert ERC-20 token payments → USD → ETH via historical ETH price (coingecko:ethereum). Unavailable price → sale flagged `unpriced`, excluded from PnL (never zero).
2. Profiler: accept ALL ERC-20 payments (drop ETH/WETH-only filter), tag flips pricedWith native|oracle|unpriced; add period windows — compute aggregates for 1w / 3w / all-time server-side from the same event set (realized from flips sold in window; unrealized from positions entered in window, floor-marked; per-window equity curve).
3. contracts/profile.ts payload += periods {week1, week3} + oracle pricing stats; disclosure line.
4. UI: WalletProfileDrawer period chips (All time / 3W / 1W) switching stat strip + equity chart + flips + open positions; "oracle-priced" badge + unpriced count.
5. Gates: check/build/vitest, then version.

## Iteration 7 — Top-3 holdings in wallet profile (user: "add more details like the top 3 nft collection the wallet is holding")
1. Profiler: fetch current holdings via OpenSea `GET /v2/chain/{chain}/account/{address}/nfts` (6 chains, capped pages), aggregate per collection (count), floor-value via collection stats (reuse floor fetch), rank by est. value (count × floor, fallback count) → payload `holdings` top 3 + totals; graceful degrade on failure.
2. UI: "TOP HOLDINGS" section in WalletProfileDrawer — 3 cards (image, name, chain, count, floor, est. value).
3. Gates + version.

## Iteration 8 — Robinhood price coverage + payment plans (user request)
A. [agent: robinhood-coverage] priceOracle fallback chain: DefiLlama historical → DefiLlama current (nearest, flagged approx) → unpriced; sweep app for remaining 4663 gaps; disclosure copy.
B. [agent: plans-entitlements] FREE/PRO plans:
   - FREE: snipe bot only, 7-day trial from signup, max 3 pending snipe orders, max 2 wallets per multi-snipe; copy/discover/sweep/profiler PRO-gated.
   - PRO $15/mo: everything. users.plan/planExpiresAt/createdAt; site_settings kv (payment link); admin router (grant/revoke, user list) gated by ADMIN_EMAIL=dioruhanan@gmail.com (auto-PRO on register/login).
   - UI: plan badge + trial countdown, paywall lock cards, Upgrade section (payment link / contact admin), Admin section (users + grants + payment link).
   - Gates: check + vitest per agent (no concurrent build); lead runs build + version.

## Iteration 9 — Remove all simulation/mock, real on-chain everywhere (user: "remove all simulation data and put real on chain data for all")
1. Engines live-only: mintEngine/copyTrader/floorSweeper drop sim branches + "SIMULATED" logs; execute via user's managed vault wallet + resolveRpcForUser; no key/insufficient funds → honest error status, never fake success.
2. Mode removal: contracts/bot.ts mode constants, schema mode columns kept but ignored (always live), UI selectors/toggles/badges/copy removed (TaskWizard, Tasks, CopyTrading/CopySettings, Sweeper, Settings, Overview, shell, Upgrade feature list).
3. Mock data eradication: src/data/leaderboard.ts + snipers.ts (mulberry32 PRNG mocks) → Leaderboard page wired to REAL public endpoint over discovered_traders (empty state when no scans); MintEngineTerminal/MirroredFeed/LeaderboardPreview → real public recent-signals feed or honest empty; ChainStrip/FeeCalculator → static facts only, no fabricated stats; docs.ts scrub.
4. Live-mode risk copy: "executes real transactions with real funds from your bot vault".
5. Gates: check/build/vitest; grep proof zero simulat/mock residue (tests excluded); lead verifies + version.

## Iteration 10 — Crypto payments, EVM-only, hardening (user: remove Stripe, pay-to-address 0x300e…975e, "do the rest stuff", EVM only, shared OpenSea key)
A. [payments+legal] Remove Stripe; PRO payment = send $15 of native token on any of the 6 EVM chains to 0x300ef926e05a9891e9e3f575e6ba43d55c9a975e (hardcoded default, admin-overridable). payment_claims table: user submits chain+txHash → Admin verifies on explorer → approve grants PRO 30d / reject. EVM-only sweep (grep solana etc). Legal pages: Terms, Risk Disclosure, Privacy + footer links.
B. [hardening] Engine loops re-check entitlement each cycle (downgrade/expiry stops execution); shared server-side OpenSea key (site_settings, admin-set, per-user key overrides); Wallets vault funding guidance (per-chain balance + low-balance warn via resolveRpcForUser); Settings change-password; Admin password reset for locked-out users; creds login rate limiting (in-memory lockout).

## Iteration 11 — Competitor feature batch (user: "Add everything except discord/telegram alerts")
Schema pre-applied by lead: bot_positions table, discovered_traders.labels, user_settings.mevProtection.
- Wave 1 (parallel): B[intelligence] wallet labels (sniper/smart-money/fresh/whale/flipper/holder) in chainScanner + discover UI + contract guard (bytecode/proxy/mint-selector/OpenSea safelist) in taskRouter+TaskWizard. C[execution+UX] MEV Protect routing (chain 1), gas guard at fire time (maxGasGwei), vault portfolio in Wallets (reuse profile.get), CSV bulk wallet import (backend copy.bulkAdd; UI by B — contract fixed).
- Wave 2: A[sell-side] bot_positions recording (copy/sweep/snipe), sellEngine (best-offer lookup, TP/SL triggers, mirror-sell on watched-wallet sales, Seaport approval, sell-into-offer), positionsRouter + Positions dashboard section.

## Iteration 12 — Mint-bot parity batch (user: features 1-5 + research 7)
Schema pre-applied: mint_tasks.mintPhase/merkleProofs/simulateFirst.
- D[mint upgrades]: whitelist/merkle-proof minting (per-wallet proofs, phase detection via common sale-state getters, whitelistSaleActive flag option) + pre-flight eth_call simulation (skip fire on would-revert). Files: mintEngine, mintPhase.ts(new), taskRouter, TaskWizard.
- E[trending+progress]: mintWatch engine (recent-blocks Transfer-from-zero aggregation, rolling 1m/5m/15m windows, unique minters) → public.trendingMints + Trending landing page; per-contract mint progress (totalSupply eth_call + velocity) → task detail widget. Files: mintWatch.ts(new), publicRouter, Trending.tsx(new), App.tsx, Navbar, Tasks.tsx, engineManager.
- R[rarity feasibility]: thorough research — post-Reservoir rarity sources (NFTScan API free tier, OpenSea v2 traits, tokenURI metadata self-compute à la TraitSniper). Verdict → build only if viable (wave 2: G).

## Iteration 13 — Arc chain support + RPC pool repair (2026-09-17)
- **Arc (chain id 5042, Circle USDC-gas L1, mainnet launched 2026-09-16)** added across every chain enumeration: contracts/bot.ts Chains, contracts/rpc.ts (ChainKeyToId, RpcEndpoints pool of 5 curl-verified endpoints: rpc.mainnet.arc.io, rpc.drpc.mainnet.arc.io, rpc.blockdaemon.mainnet.arc.io, rpc.quicknode.mainnet.arc.io, 5042.rpc.thirdweb.com; ExplorerBaseUrls → arcexplorer.io since explorer.arc.io is Cloudflare-Access-gated), contracts/nftLinks.ts (slug + explorer host), contracts/plans.ts PAYMENT_CHAIN_IDS, mintWatch MINT_WATCH_CHAINS, chainScanner SECONDS_PER_BLOCK (1s), src/lib/chains.ts, shared.tsx CHAINS, CopyTrading SECONDS_PER_BLOCK, new public/chain-arc.svg.
- **Arc is mint/snipe + payments only**: OpenSea has no Arc coverage (verified: API empty, Seaport conduit bytecode 0x on-chain) → `isSweepSupportedChain` stays false; new `MARKET_CHAINS` (CHAINS minus arc) drives Sweeper + CopyTrading discover/watch pickers. Docs/FAQ, Upgrade, Trending, ChainStrip copy updated to seven chains.
- **RPC pool repair ("fix the rpc error")**: audited every pooled endpoint live — removed eth.llamarpc.com (Cloudflare 525), robinhood.rpc.blxrbdn.com (403 on eth_getLogs), robinhood-rpc.publicnode.com (token-gated archive/getLogs), rpc-gel.inkonchain.com (dead). Added eth.rpc.blxrbdn.com + rpc.mevblocker.io (chain 1), robinhood.drpc.org (4663, getLogs OK ≤10k range), ink-rpc.publicnode.com + 57073.rpc.thirdweb.com (57073). Fixed stale frontend rpc fields in shared.tsx (eth/polygon/ink).
- Gates: tsc clean, 216/216 vitest, build OK.

## Iteration 14 — Arc FULL market support (user challenged "no OpenSea on Arc") (2026-09-17)
User pushback was correct — deeper research proved OpenSea supports Arc from mainnet day one (announced on X, opensea.io/discover/chain/arc live with real volume: AKARII $200K+, OnchainSharc $130K+, Arclings $104K+). My earlier "no Seaport" claim checked the conduit address, not Seaport itself.
**Verified on-chain (live OrderFulfilled logs, 191 sales in last 100 blocks):** Seaport 1.6 deployed at canonical 0x0000…eB395; listings paid in NATIVE USDC (18dp, 1e18=$1); offers paid in ERC20 USDC 0x3600000000000000000000000000000000000000 (6dp, verified decimals()=6 symbol()=USDC); conduit + conduit controller NOT deployed → orders use conduitKey 0 (operator = Seaport itself). DefiLlama arc: prefix live (historical + current).
**Changes:** opensea.ts CHAIN_SLUGS + 5042:"arc" + OFFER_PAYMENT_DECIMALS/OFFER_PAYMENT_TOKEN + paymentToWei scaling in getBestOffer; chainScanner WETH_BY_CHAIN + PAYMENT_TOKEN_DECIMALS with ×10^12 scaling in aggregation; openseaProfiler WETH map + 5042; priceOracle LLAMA_PREFIX + 5042:"arc"; sellEngine approval operator now probed on-chain (conduit if deployed else Seaport protocol address) — sells on Arc would have failed with the hardcoded conduit; MARKET_CHAINS exclusion removed (sweep/copy/discover pickers include Arc again); docs FAQ updated; 2 new scanner tests (218 total). Sandbox DNS to api.opensea.io is poisoned (resolves to bogus IPs) — noted; production server unaffected.

## Iteration 15 — Per-chain currency symbols + kill switch + gas widget (2026-09-17)
- **Per-chain currency symbol** (user-ordered): nativeSymbol(chainId) in contracts/rpc.ts (5042→USDC, default ETH) + formatSignedNative in src/lib/chains.ts. Applied to per-chain value displays: Positions rows (entry/sell/PnL), Sweeper floors (rule + floor-now toast), Tasks list price, TaskWizard (price label, inspect, review, est. cost). Cross-chain aggregates (Overview/CopyTrading/Wallets totals) keep "ETH" label honestly (mixed units).
- **Emergency kill switch**: user_settings.halted (schema.ts + ensureSchema CREATE+COLUMN_ADDS); api/lib/halt.ts (10s cached isHalted, fail-open); gates in all four engines — mintEngine cancels armed tasks with clear log, floorSweeper/copyTrader pause cycles (throttled warn), sellEngine pauses exits AND mirror sells; settings.update accepts halted + logs the toggle; UI: red STOP/green RESUME button in top bar (window.confirm) + global alarm banner while halted.
- **Live gas widget**: public.gasNow (eth_gasPrice ×7 chains via getBestRpc, 15s server cache, per-chain null-tolerant) + Overview "Network gas · live" chip row (green <50 / amber <200 / red ≥200 gwei).
- Competitor check: scheduled mints (time/poll/event triggers), multi-wallet snipe, merkle whitelist, sim-first, gas guard, MEV, rarity sweeps, TP/SL, trending — all already shipped. Remaining gaps reported to user: mass bidding (needs Seaport order signing), reveal sniping, Discord/Telegram (user-deferred).
- contracts/rpc.test.ts added (arc constants, ≥2 endpoints/chain, dead-endpoint guard); vitest include now covers contracts/. 222/222 tests, tsc clean, build OK.
