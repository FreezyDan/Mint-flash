'use strict';
/**
 * NFT auto-mint bot
 *
 * Usage:
 *   cp .env.example .env   # fill it in
 *   npm install
 *   node scripts/precheck.js   # sanity check (dry run recommended first)
 *   DRY_RUN=true npm start     # rehearsal
 *   npm start                  # live
 */
const { ethers } = require('ethers');
const { config, validate } = require('./src/config');
const { waitForTrigger } = require('./src/monitor');
const { mintWithWallet } = require('./src/minter');
const { log, short } = require('./src/utils');

// Generic ABI - covers common mint shapes. Replace abi/contract.json with the
// project's real ABI for full type safety and reliable function encoding.
const GENERIC_ABI = [
  'function saleActive() view returns (bool)',
  'function isSaleActive() view returns (bool)',
  'function publicSaleActive() view returns (bool)',
  'function mint(uint256 quantity) payable',
  'function mint(uint256 quantity)',
  'function mint(address to, uint256 quantity) payable',
  'function publicMint(uint256 quantity) payable',
  'function whitelistMint(uint256 quantity, bytes32[] proof) payable',
  'event SaleOpened()',
];

async function main() {
  validate(config);
  log(`Bot starting | chain=${config.chainId} mode=${config.trigger.mode} dryRun=${config.safety.dryRun}`);
  log(`Target contract: ${config.contractAddress}`);
  log(`Wallets: ${config.privateKeys.length}`);

  const provider = new ethers.JsonRpcProvider(config.rpcUrl, config.chainId);
  const contract = new ethers.Contract(config.contractAddress, GENERIC_ABI, provider);

  // Pre-flight: connectivity + balances
  const network = await provider.getNetwork();
  log(`Connected: ${network.name} (chain ${network.chainId})`);
  for (const [i, key] of config.privateKeys.entries()) {
    const w = new ethers.Wallet(key);
    const bal = await provider.getBalance(w.address);
    log(`  wallet ${i} ${short(w.address)} balance=${ethers.formatEther(bal)} ETH`);
    if (bal < config.mint.valueWei) {
      log(`  WARNING: wallet ${i} cannot afford mint value ${ethers.formatEther(config.mint.valueWei)} ETH + gas`);
    }
  }

  log('Arming trigger…');
  await waitForTrigger(config, provider, contract);
  log('TRIGGER FIRED - executing mints');

  // Fire all wallets concurrently. Each manages its own nonce independently.
  const results = await Promise.all(
    config.privateKeys.map((key, i) =>
      mintWithWallet(config, provider, contract, key, `w${i}`).catch((e) => ({
        ok: false, reason: 'exception', error: e.message,
      }))
    )
  );

  const ok = results.filter((r) => r.ok).length;
  log(`Done. ${ok}/${config.privateKeys.length} wallets succeeded.`);
  results.forEach((r, i) => {
    if (!r.ok) log(`  w${i} failed: ${r.reason}${r.error ? ' - ' + r.error.slice(0, 120) : ''}`);
  });
  process.exit(ok > 0 || results.every((r) => r.dryRun) ? 0 : 1);
}

main().catch((e) => {
  console.error('Fatal:', e);
  process.exit(1);
});
