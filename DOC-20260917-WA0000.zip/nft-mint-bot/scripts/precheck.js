'use strict';
/**
 * Pre-flight check: validates config, connects to RPC, checks wallet
 * balances, verifies the mint function exists on the target contract and
 * (if poll mode) reports the current sale-flag state.
 */
const { ethers } = require('ethers');
const { config, validate } = require('../src/config');
const { log, short } = require('../src/utils');

const GENERIC_ABI = [
  'function saleActive() view returns (bool)',
  'function isSaleActive() view returns (bool)',
  'function publicSaleActive() view returns (bool)',
  'function mint(uint256 quantity) payable',
  'function mint(uint256 quantity)',
  'function mint(address to, uint256 quantity) payable',
  'function publicMint(uint256 quantity) payable',
  'event SaleOpened()',
];

async function main() {
  validate(config);
  const provider = new ethers.JsonRpcProvider(config.rpcUrl, config.chainId);
  const net = await provider.getNetwork();
  log(`RPC OK - ${net.name} chain ${net.chainId}`);

  const code = await provider.getCode(config.contractAddress);
  if (code === '0x') throw new Error(`No contract at ${config.contractAddress}`);

  const contract = new ethers.Contract(config.contractAddress, GENERIC_ABI, provider);
  const fn = contract.getFunction(config.mint.functionName);
  if (!fn) {
    log(`WARNING: "${config.mint.functionName}" not in generic ABI - make sure abi/contract.json has the real one`);
  } else {
    log(`Mint function "${config.mint.functionName}" found`);
  }

  for (const [i, key] of config.privateKeys.entries()) {
    const w = new ethers.Wallet(key);
    const bal = await provider.getBalance(w.address);
    const enough = bal >= config.mint.valueWei;
    log(`wallet ${i} ${short(w.address)}: ${ethers.formatEther(bal)} ETH ${enough ? 'OK' : '(INSUFFICIENT for mint value)'}`);
  }

  for (const flag of ['saleActive', 'isSaleActive', 'publicSaleActive']) {
    if (typeof contract[flag] !== 'function') continue;
    try {
      log(`${flag}() = ${await contract[flag]()}`);
    } catch { /* not present */ }
  }

  try {
    const fee = await provider.getFeeData();
    log(`current baseFee=${ethers.formatUnits(fee.maxFeePerGas || 0n, 'gwei')} gwei`);
  } catch { /* non-EIP1559 chain */ }

  log('Pre-check complete.');
}

main().catch((e) => { console.error('Pre-check failed:', e.message); process.exit(1); });
