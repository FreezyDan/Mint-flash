'use strict';
const { ethers } = require('ethers');
const { log, sleep } = require('./utils');

/**
 * Resolves when the sale opens, according to the configured trigger mode.
 * - time : resolves at the given ISO timestamp (sends a few ms early to beat
 *          the public, tweak LEAD_MS if your node is slow)
 * - poll : calls contract[flagMethod]() until it returns true
 * - event: subscribes to eventName on the contract over websocket
 */
async function waitForTrigger(cfg, provider, contract) {
  const { mode } = cfg.trigger;

  if (mode === 'time') {
    const openAt = Date.parse(cfg.trigger.openTime);
    const LEAD_MS = 150; // land the tx right as the block opens
    const waitMs = openAt - Date.now() - LEAD_MS;
    if (waitMs > 0) {
      log(`Time trigger: sale opens ${cfg.trigger.openTime}, waiting ${(waitMs / 1000).toFixed(1)}s…`);
      await sleep(waitMs);
    } else {
      log(`Time trigger: open time already passed, firing immediately`);
    }
    return;
  }

  if (mode === 'poll') {
    const method = cfg.trigger.flagMethod;
    if (typeof contract[method] !== 'function') {
      throw new Error(`Contract has no view method "${method}" - set FLAG_METHOD correctly or use a full ABI`);
    }
    log(`Poll trigger: watching ${method}() every ${cfg.trigger.pollIntervalMs}ms…`);
    for (;;) {
      try {
        const open = await contract[method]();
        if (open) {
          log(`${method}() returned true - sale is OPEN`);
          return;
        }
      } catch (e) {
        log(`poll error (will retry): ${e.message}`);
      }
      await sleep(cfg.trigger.pollIntervalMs);
    }
  }

  if (mode === 'event') {
    if (!cfg.wsUrl) throw new Error('WS_URL required for event trigger');
    const wsProvider = new ethers.WebSocketProvider(cfg.wsUrl, cfg.chainId);
    const wsContract = new ethers.Contract(cfg.contractAddress, contract.interface, wsProvider);
    log(`Event trigger: waiting for "${cfg.trigger.eventName}" on ${cfg.contractAddress}…`);
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Event trigger timed out after 24h')), 24 * 3600e3);
      wsContract.once(cfg.trigger.eventName, (...args) => {
        clearTimeout(timer);
        const ev = args[args.length - 1];
        log(`Caught event ${ev.eventName} in tx ${ev.transactionHash}`);
        resolve();
      });
      wsContract.once('error', (e) => {
        clearTimeout(timer);
        reject(e);
      });
    });
    wsProvider.destroy();
    return;
  }

  throw new Error(`Unknown trigger mode: ${mode}`);
}

module.exports = { waitForTrigger };
