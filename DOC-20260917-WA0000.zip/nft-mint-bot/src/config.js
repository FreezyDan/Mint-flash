'use strict';
require('dotenv').config();
const { ethers } = require('ethers');

const gwei = (v) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) throw new Error(`Invalid gwei value: ${v}`);
  return BigInt(Math.round(n * 1e9));
};

function parseArgs(raw) {
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) throw new Error('MINT_ARGS must be a JSON array');
    return parsed;
  } catch (e) {
    throw new Error(`MINT_ARGS is not valid JSON: ${e.message}`);
  }
}

const privateKeys = (process.env.PRIVATE_KEYS || '')
  .split(',')
  .map((k) => k.trim())
  .filter(Boolean);

const config = {
  rpcUrl: process.env.RPC_URL,
  wsUrl: process.env.WS_URL || null,
  chainId: Number(process.env.CHAIN_ID || 1),
  privateKeys,

  contractAddress: process.env.CONTRACT_ADDRESS,

  mint: {
    functionName: process.env.MINT_FUNCTION || 'mint',
    args: parseArgs(process.env.MINT_ARGS || '[1]'),
    valueWei: (() => {
      const eth = process.env.MINT_VALUE_ETH || '0';
      if (!/^\d+(\.\d+)?$/.test(eth)) throw new Error(`MINT_VALUE_ETH invalid: ${eth}`);
      return ethers.parseUnits(eth, 'ether');
    })(),
    gasLimit: BigInt(process.env.MINT_GAS_LIMIT || 200000),
  },

  trigger: {
    mode: (process.env.TRIGGER_MODE || 'time').toLowerCase(),
    openTime: process.env.OPEN_TIME || null,
    flagMethod: process.env.FLAG_METHOD || 'saleActive',
    pollIntervalMs: Number(process.env.POLL_INTERVAL_MS || 1000),
    eventName: process.env.EVENT_NAME || null,
  },

  gas: {
    startMaxFee: gwei(process.env.START_MAX_FEE_GWEI || '60'),
    startPriority: gwei(process.env.START_PRIORITY_GWEI || '3'),
    bump: gwei(process.env.GAS_BUMP_GWEI || '10'),
    maxMaxFee: gwei(process.env.MAX_MAX_FEE_GWEI || '500'),
    maxRetries: Number(process.env.MAX_RETRIES || 8),
  },

  safety: {
    dryRun: process.env.DRY_RUN === 'true',
    maxWallets: Number(process.env.MAX_WALLETS || 5),
  },
};

// ---------- validation ----------
function validate(cfg) {
  const problems = [];
  if (!cfg.rpcUrl) problems.push('RPC_URL is required');
  if (cfg.privateKeys.length === 0) problems.push('PRIVATE_KEYS is required');
  if (!cfg.contractAddress || !/^0x[0-9a-fA-F]{40}$/.test(cfg.contractAddress))
    problems.push('CONTRACT_ADDRESS must be a valid address');
  if (!['time', 'poll', 'event'].includes(cfg.trigger.mode))
    problems.push(`TRIGGER_MODE must be time|poll|event, got "${cfg.trigger.mode}"`);
  if (cfg.trigger.mode === 'time') {
    if (!cfg.trigger.openTime || isNaN(Date.parse(cfg.trigger.openTime)))
      problems.push('OPEN_TIME must be a valid ISO timestamp for TRIGGER_MODE=time');
  }
  if (cfg.trigger.mode === 'event' && !cfg.wsUrl)
    problems.push('WS_URL is required for TRIGGER_MODE=event');
  if (cfg.privateKeys.length > cfg.safety.maxWallets)
    problems.push(`${cfg.privateKeys.length} keys exceeds MAX_WALLETS=${cfg.safety.maxWallets}`);
  for (const k of cfg.privateKeys) {
    if (!/^0x[0-9a-fA-F]{64}$/.test(k)) problems.push(`Bad private key format: ${k.slice(0, 8)}...`);
  }
  if (problems.length) {
    console.error('Config validation failed:');
    problems.forEach((p) => console.error('  - ' + p));
    process.exit(1);
  }
}

module.exports = { config, validate };
