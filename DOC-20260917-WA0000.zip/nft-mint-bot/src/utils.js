'use strict';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const fmtGwei = (wei) => (Number(wei) / 1e9).toFixed(2) + ' gwei';

const now = () => new Date().toISOString();

function log(...args) {
  console.log(`[${now()}]`, ...args);
}

function short(addr) {
  return addr.slice(0, 6) + '…' + addr.slice(-4);
}

module.exports = { sleep, fmtGwei, log, short, now };
