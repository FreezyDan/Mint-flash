'use strict';
const { ethers } = require('ethers');
const { log, fmtGwei, short } = require('./utils');

const RECEIPT_TIMEOUT_MS = 3 * 60 * 1000; // give up waiting after 3 min

/**
 * Sends the mint tx for one wallet with fee-bump replacements.
 *
 * Strategy:
 *  1. Grab the wallet's pending nonce ONCE (all retries reuse it -> tx
 *     replacements, never double-spend with a bumped nonce).
 *  2. Send with starting EIP-1559 fees.
 *  3. On any failure that looks like "not mined / underpriced / dropped",
 *     resubmit the SAME tx with higher fees, until MAX_MAX_FEE_GWEI.
 *  4. Once a txHash is accepted by the mempool, keep replacing on underprice
 *     errors until it mines or we hit the retry ceiling.
 */
async function mintWithWallet(cfg, provider, contract, privateKey, label) {
  const wallet = new ethers.Wallet(privateKey, provider);
  const { functionName, args, valueWei, gasLimit } = cfg.mint;
  const g = cfg.gas;

  const data = contract.interface.encodeFunctionData(functionName, args);
  const to = await contract.getAddress();
  const nonce = await provider.getTransactionCount(wallet.address, 'pending');
  log(`[${label}] nonce=${nonce} value=${ethers.formatEther(valueWei)} ETH gasLimit=${gasLimit}`);

  let maxFee = g.startMaxFee;
  let priority = g.startPriority;

  for (let attempt = 1; attempt <= g.maxRetries; attempt++) {
    if (maxFee > g.maxMaxFee) {
      log(`[${label}] fee ceiling ${fmtGwei(g.maxMaxFee)} reached, aborting`);
      return { ok: false, reason: 'fee-ceiling' };
    }

    const txRequest = {
      to,
      data,
      value: valueWei,
      gasLimit,
      nonce,
      maxFeePerGas: maxFee,
      maxPriorityFeePerGas: priority,
      chainId: cfg.chainId,
      type: 2,
    };

    if (cfg.safety.dryRun) {
      log(`[${label}] DRY_RUN - would send:`, {
        to, data: data.slice(0, 10) + '…', value: ethers.formatEther(valueWei),
        maxFee: fmtGwei(maxFee), priority: fmtGwei(priority),
      });
      return { ok: true, dryRun: true };
    }

    try {
      const tx = await wallet.sendTransaction(txRequest);
      log(`[${label}] attempt ${attempt}: submitted ${tx.hash} (maxFee=${fmtGwei(maxFee)})`);

      try {
        const receipt = await tx.wait(1, RECEIPT_TIMEOUT_MS);
        if (receipt && receipt.status === 1) {
          log(`[${label}] MINTED in block ${receipt.blockNumber} - ${tx.hash}`);
          return { ok: true, hash: tx.hash, receipt };
        }
        log(`[${label}] tx reverted on-chain: ${tx.hash}`);
        return { ok: false, reason: 'reverted', hash: tx.hash };
      } catch (waitErr) {
        // ethers v6 throws on revert / timeout; receipt may be attached
        const receipt = waitErr.receipt;
        if (receipt && receipt.status === 1) return { ok: true, hash: tx.hash, receipt };
        if (receipt && receipt.status === 0) {
          log(`[${label}] tx reverted on-chain: ${tx.hash}`);
          return { ok: false, reason: 'reverted', hash: tx.hash };
        }
        log(`[${label}] not mined within timeout, bumping fees and replacing`);
        // fall through to bump
      }
    } catch (sendErr) {
      const msg = sendErr.message || String(sendErr);
      if (msg.includes('nonce too low')) {
        log(`[${label}] nonce already consumed - a previous tx from this wallet mined`);
        return { ok: false, reason: 'nonce-consumed', error: msg };
      }
      if (msg.includes('underpriced') || msg.includes('replacement transaction underpriced')) {
        log(`[${label}] underpriced, bumping fees`);
      } else if (msg.includes('execution reverted') || msg.includes('CALL_EXCEPTION')) {
        log(`[${label}] mint call reverted: ${msg.slice(0, 200)}`);
        return { ok: false, reason: 'call-reverted', error: msg };
      } else {
        log(`[${label}] send error (${msg.slice(0, 140)}), bumping and retrying`);
      }
    }

    maxFee += g.bump;
    priority += g.bump;
    if (maxFee > g.maxMaxFee) {
      log(`[${label}] next fee ${fmtGwei(maxFee)} would exceed ceiling, stopping`);
      return { ok: false, reason: 'fee-ceiling' };
    }
  }

  return { ok: false, reason: 'retries-exhausted' };
}

module.exports = { mintWithWallet };
