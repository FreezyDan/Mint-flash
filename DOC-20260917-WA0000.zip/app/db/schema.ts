import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  int,
  boolean,
  decimal,
  varchar,
  text,
  json,
  timestamp,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  // Nullable — OAuth users never have a password hash. Format: "saltHex:hashHex" (scrypt).
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Subscription plan: 'free' (7-day snipe-bot trial, capped) or 'pro'
  // ($15/mo, everything). planExpiresAt null = no expiry (e.g. admin grant).
  plan: varchar("plan", { length: 8 }).notNull().default("free"),
  planExpiresAt: timestamp("planExpiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ---------------------------------------------------------------------------
// MintDash: NFT auto-mint bot + copy-trading tables
// ---------------------------------------------------------------------------

export const mintTasks = mysqlTable("mint_tasks", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  name: varchar("name", { length: 255 }).notNull(),
  contractAddress: varchar("contractAddress", { length: 42 }).notNull(),
  chainId: int("chainId").notNull().default(1),
  mintFunction: varchar("mintFunction", { length: 128 }).notNull().default("mint"),
  mintArgs: json("mintArgs").notNull(),
  mintValueEth: varchar("mintValueEth", { length: 64 }).notNull().default("0"),
  gasLimit: int("gasLimit").notNull().default(200000),
  triggerMode: varchar("triggerMode", { length: 16 }).notNull().default("time"), // 'time'|'poll'|'event'
  openTime: timestamp("openTime"),
  flagMethod: varchar("flagMethod", { length: 128 }).notNull().default("saleActive"),
  pollIntervalMs: int("pollIntervalMs").notNull().default(1000),
  eventName: varchar("eventName", { length: 128 }),
  startMaxFeeGwei: int("startMaxFeeGwei").notNull().default(60),
  startPriorityGwei: int("startPriorityGwei").notNull().default(3),
  gasBumpGwei: int("gasBumpGwei").notNull().default(10),
  // Whitelist/allowlist minting: 'auto' (detect) | 'public' | 'whitelist'.
  mintPhase: varchar("mintPhase", { length: 16 }),
  // Map of lowercase wallet address → merkle proof (bytes32[]) for whitelist
  // mints; null for public mints.
  merkleProofs: json("merkleProofs"),
  // Pre-flight eth_call simulation before every live broadcast; reverts skip
  // the fire instead of burning gas on a failed transaction.
  simulateFirst: boolean("simulateFirst").notNull().default(true),
  maxMaxFeeGwei: int("maxMaxFeeGwei").notNull().default(500),
  maxRetries: int("maxRetries").notNull().default(8),
  status: varchar("status", { length: 16 }).notNull().default("draft"), // 'draft'|'armed'|'firing'|'done'|'failed'|'cancelled'
  dryRun: boolean("dryRun").notNull().default(true),
  // How many bot wallets this task snipes with (multi-snipe). Free plan is
  // capped at FREE_LIMITS.maxSnipeWallets; the engine slices its key list.
  walletCount: int("walletCount").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type MintTask = typeof mintTasks.$inferSelect;
export type InsertMintTask = typeof mintTasks.$inferInsert;

// Public wallet addresses used by the bot. Manually-added wallets store public
// addresses only — their keys come from the BOT_PRIVATE_KEYS server env var at
// execution time. Managed rows ("Auto vault") are auto-created on sign-up and
// carry an AES-256-GCM encrypted private key (encryptedKey) so the bot can
// sign with them in live mode.
export const botWallets = mysqlTable("bot_wallets", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  label: varchar("label", { length: 255 }).notNull(),
  address: varchar("address", { length: 42 }).notNull(),
  managed: boolean("managed").default(false).notNull(),
  // Only managed rows carry a key. Format: "iv:tag:ciphertext" (base64url).
  encryptedKey: text("encryptedKey"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BotWallet = typeof botWallets.$inferSelect;
export type InsertBotWallet = typeof botWallets.$inferInsert;

export const watchedWallets = mysqlTable("watched_wallets", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  address: varchar("address", { length: 42 }).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  chain: varchar("chain", { length: 32 }).notNull().default("ethereum"),
  enabled: boolean("enabled").notNull().default(true),
  copyMints: boolean("copyMints").notNull().default(true),
  copyBuys: boolean("copyBuys").notNull().default(false),
  maxPerTradeEth: varchar("maxPerTradeEth", { length: 64 }).notNull().default("0.1"),
  maxDailyEth: varchar("maxDailyEth", { length: 64 }).notNull().default("1"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WatchedWallet = typeof watchedWallets.$inferSelect;
export type InsertWatchedWallet = typeof watchedWallets.$inferInsert;

export const signals = mysqlTable("signals", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  watchedWalletId: bigint("watchedWalletId", { mode: "number", unsigned: true })
    .references(() => watchedWallets.id),
  type: varchar("type", { length: 16 }).notNull(), // 'mint'|'buy'
  contractAddress: varchar("contractAddress", { length: 42 }).notNull(),
  tokenId: varchar("tokenId", { length: 78 }),
  collectionName: varchar("collectionName", { length: 255 }),
  priceEth: varchar("priceEth", { length: 64 }),
  txHash: varchar("txHash", { length: 66 }),
  status: varchar("status", { length: 16 }).notNull().default("detected"), // 'detected'|'mirrored'|'skipped'|'failed'
  pnlEth: varchar("pnlEth", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Signal = typeof signals.$inferSelect;
export type InsertSignal = typeof signals.$inferInsert;

export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  taskId: bigint("taskId", { mode: "number", unsigned: true })
    .references(() => mintTasks.id),
  level: varchar("level", { length: 16 }).notNull().default("info"), // 'info'|'warn'|'error'|'success'
  source: varchar("source", { length: 16 }).notNull(), // 'mint'|'copy'|'system'
  message: text("message").notNull(),
  meta: json("meta"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;

export const userSettings = mysqlTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique()
    .references(() => users.id),
  rpcUrl: varchar("rpcUrl", { length: 512 }),
  // When true, the smart RPC manager races public endpoints and ignores rpcUrl.
  rpcAuto: boolean("rpcAuto").notNull().default(true),
  chainId: int("chainId").notNull().default(1),
  // Legacy column — every engine executes real on-chain transactions; this is
  // no longer read. Kept for schema compatibility (ensureSchema is additive-only).
  executionMode: varchar("executionMode", { length: 16 }).notNull().default("live"),
  maxGasGwei: int("maxGasGwei").notNull().default(500),
  // Legacy column — the Reservoir API was sunset; kept for schema
  // compatibility. New deployments use openseaApiKey below.
  reservoirApiKey: varchar("reservoirApiKey", { length: 128 }),
  // Optional OpenSea API key (v2) — REQUIRED for the floor sweeper.
  openseaApiKey: varchar("openseaApiKey", { length: 128 }),
  // Route Ethereum-mainnet executions through a private mempool (Flashbots
  // Protect) instead of the public mempool.
  mevProtection: boolean("mevProtection").notNull().default(true),
  // Emergency kill switch — when true, every engine (snipe, copy, sweep,
  // sell) refuses to broadcast transactions for this user.
  halted: boolean("halted").notNull().default(false),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = typeof userSettings.$inferInsert;

// Chain-global snapshot of profitable OpenSea/Seaport traders found by the
// on-chain scanner (api/engine/chainScanner.ts). No userId — rows are shared
// across users and fully replaced per chain on every scan.
export const discoveredTraders = mysqlTable(
  "discovered_traders",
  {
    id: serial("id").primaryKey(),
    chainId: int("chainId").notNull(),
    address: varchar("address", { length: 42 }).notNull(),
    buys: int("buys").notNull().default(0),
    sells: int("sells").notNull().default(0),
    trades: int("trades").notNull().default(0),
    spendEth: varchar("spendEth", { length: 64 }).notNull().default("0"),
    proceedsEth: varchar("proceedsEth", { length: 64 }).notNull().default("0"),
    realizedPnlEth: varchar("realizedPnlEth", { length: 64 }).notNull().default("0"),
    // Flip detail stats across ALL flips (mint + secondary) in the window.
    flips: int("flips").notNull().default(0),
    wins: int("wins").notNull().default(0),
    winRatePct: varchar("winRatePct", { length: 16 }).notNull().default("0"),
    avgPnlEth: varchar("avgPnlEth", { length: 64 }).notNull().default("0"),
    bestFlipEth: varchar("bestFlipEth", { length: 64 }).notNull().default("0"),
    // Aggregate ROI = sum(pnl)/sum(cost)*100; null when all flips were free mints.
    roiPct: varchar("roiPct", { length: 16 }),
    mintPnlEth: varchar("mintPnlEth", { length: 64 }).notNull().default("0"),
    mintFlips: int("mintFlips").notNull().default(0),
    // Mean hold time across flips, in hours (null when no flips).
    avgHoldHours: varchar("avgHoldHours", { length: 16 }),
    // Sum of unrealized PnL over open positions with a known in-window mark;
    // null when the wallet has no marked open positions.
    unrealizedPnlEth: decimal("unrealizedPnlEth", { precision: 20, scale: 10 }),
    // Unsold in-window acquisitions (buys + mints) still held at scan end.
    openPositions: int("openPositions").notNull().default(0),
    collections: int("collections").notNull().default(0),
    fromBlock: bigint("fromBlock", { mode: "number", unsigned: true }).notNull(),
    toBlock: bigint("toBlock", { mode: "number", unsigned: true }).notNull(),
    scannedAt: timestamp("scannedAt").defaultNow().notNull(),
  },
  (table) => [index("discovered_traders_chainId_idx").on(table.chainId)],
);

export type DiscoveredTrader = typeof discoveredTraders.$inferSelect;
export type InsertDiscoveredTrader = typeof discoveredTraders.$inferInsert;

// Per-flip P&L detail backing the discovered_traders aggregates. Replaced
// alongside discovered_traders on every rescan (delete by chainId + insert).
export const discoveredFlips = mysqlTable(
  "discovered_flips",
  {
    id: serial("id").primaryKey(),
    chainId: int("chainId").notNull(),
    address: varchar("address", { length: 42 }).notNull(),
    contractAddress: varchar("contractAddress", { length: 42 }).notNull(),
    tokenId: varchar("tokenId", { length: 78 }),
    kind: varchar("kind", { length: 16 }).notNull().default("secondary"), // 'mint'|'secondary'
    // 'closed' = mint→sell / buy→sell pair; 'open' = unsold holding marked at
    // the collection's latest in-window sale price (null mark when unknown).
    status: varchar("status", { length: 16 }).notNull().default("closed"), // 'closed'|'open'
    markPriceEth: decimal("markPriceEth", { precision: 20, scale: 10 }),
    unrealizedPnlEth: decimal("unrealizedPnlEth", { precision: 20, scale: 10 }),
    buyPriceEth: varchar("buyPriceEth", { length: 64 }),
    sellPriceEth: varchar("sellPriceEth", { length: 64 }),
    pnlEth: varchar("pnlEth", { length: 64 }),
    roiPct: varchar("roiPct", { length: 16 }), // null on free mints
    holdBlocks: bigint("holdBlocks", { mode: "number", unsigned: true }),
    buyTxHash: varchar("buyTxHash", { length: 66 }),
    sellTxHash: varchar("sellTxHash", { length: 66 }),
    scannedAt: timestamp("scannedAt").defaultNow().notNull(),
  },
  (table) => [
    index("discovered_flips_chainId_address_idx").on(table.chainId, table.address),
  ],
);

export type DiscoveredFlip = typeof discoveredFlips.$inferSelect;
export type InsertDiscoveredFlip = typeof discoveredFlips.$inferInsert;

// All-time wallet PnL profiles (api/engine/openseaProfiler.ts) cached by
// wallet address. Chain-global, shared across users; the router serves rows
// fresher than 30 minutes and re-fetches otherwise. `payload` is the full
// WalletProfile JSON (@contracts/profile).
export const walletProfiles = mysqlTable("wallet_profiles", {
  id: serial("id").primaryKey(),
  walletAddress: varchar("walletAddress", { length: 42 }).notNull().unique(),
  payload: json("payload").notNull(),
  fetchedAt: timestamp("fetchedAt").defaultNow().notNull(),
});

export type WalletProfileRow = typeof walletProfiles.$inferSelect;
export type InsertWalletProfile = typeof walletProfiles.$inferInsert;

// Floor-sweeper rules: watch a collection's orderbook floor
// (OpenSea API v2) and buy the cheapest listing when the floor crosses the
// user's threshold. ETH amounts are decimal strings. boughtCount/spentEth
// track cumulative progress toward the caps; the engine auto-disables the
// rule when either cap is reached.
export const sweepRules = mysqlTable("sweep_rules", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  chainId: int("chainId").notNull(),
  contractAddress: varchar("contractAddress", { length: 42 }).notNull(),
  collectionName: varchar("collectionName", { length: 255 }),
  mode: varchar("mode", { length: 8 }).notNull().default("below"), // 'below'|'above'
  thresholdEth: varchar("thresholdEth", { length: 64 }).notNull(),
  maxBuys: int("maxBuys").notNull().default(1),
  maxSpendEth: varchar("maxSpendEth", { length: 64 }).notNull().default("1"),
  // Rarity sniping: when set, only buy floor listings whose OpenRarity
  // rank is at most this value (unknown rank proceeds with a log line).
  maxRarityRank: int("maxRarityRank"),
  enabled: boolean("enabled").notNull().default(true),
  boughtCount: int("boughtCount").notNull().default(0),
  spentEth: varchar("spentEth", { length: 64 }).notNull().default("0"),
  lastFloorEth: varchar("lastFloorEth", { length: 64 }),
  lastCheckedAt: timestamp("lastCheckedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SweepRule = typeof sweepRules.$inferSelect;
export type InsertSweepRule = typeof sweepRules.$inferInsert;

// Site-wide key/value settings owned by the admin (e.g. the PRO checkout
// payment link shown on the Upgrade page).
export const siteSettings = mysqlTable("site_settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: text("value"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;

// PRO pay-to-address claims: a user sends payment to the payment address on a
// supported EVM chain, submits the tx hash here, and the admin approves or
// rejects it after confirming the transfer on-chain. Approving a claim grants
// that user PRO for 30 days (see api/adminRouter billing.reviewClaim).
export const paymentClaims = mysqlTable(
  "payment_claims",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    chainId: int("chainId").notNull(),
    txHash: varchar("txHash", { length: 66 }).notNull(),
    status: varchar("status", { length: 12 }).notNull().default("pending"), // 'pending'|'approved'|'rejected'
    adminNote: varchar("adminNote", { length: 256 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    reviewedAt: timestamp("reviewedAt"),
  },
  (table) => [index("payment_claims_userId_idx").on(table.userId)],
);

export type PaymentClaim = typeof paymentClaims.$inferSelect;
export type InsertPaymentClaim = typeof paymentClaims.$inferInsert;

// Bot-acquired NFT positions (sniped mints, mirrored copy buys, swept floors).
// The sell engine manages TP/SL and mirror-sell exits against these rows.
export const botPositions = mysqlTable(
  "bot_positions",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    source: varchar("source", { length: 8 }).notNull(), // 'snipe'|'copy'|'sweep'
    refId: int("refId"), // originating task/rule/signal id
    chainId: int("chainId").notNull(),
    contractAddress: varchar("contractAddress", { length: 42 }).notNull(),
    tokenId: varchar("tokenId", { length: 80 }),
    qty: int("qty").notNull().default(1),
    entryEth: decimal("entryEth", { precision: 20, scale: 10 }),
    status: varchar("status", { length: 8 }).notNull().default("open"), // 'open'|'sold'|'closed'
    tpPct: int("tpPct"), // take-profit % over entry; null = disabled
    slPct: int("slPct"), // stop-loss % under entry; null = disabled
    sellReason: varchar("sellReason", { length: 16 }), // 'take_profit'|'stop_loss'|'mirror_sell'|'manual'
    sellTxHash: varchar("sellTxHash", { length: 66 }),
    sellEth: decimal("sellEth", { precision: 20, scale: 10 }),
    realizedPnlEth: decimal("realizedPnlEth", { precision: 20, scale: 10 }),
    openedAt: timestamp("openedAt").defaultNow().notNull(),
    soldAt: timestamp("soldAt"),
  },
  (table) => [
    index("bot_positions_userId_idx").on(table.userId),
    index("bot_positions_status_idx").on(table.status),
  ],
);

export type BotPosition = typeof botPositions.$inferSelect;
export type InsertBotPosition = typeof botPositions.$inferInsert;
