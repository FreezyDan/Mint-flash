ALTER TABLE `bot_wallets` ADD `managed` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `bot_wallets` ADD `encryptedKey` text;--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);