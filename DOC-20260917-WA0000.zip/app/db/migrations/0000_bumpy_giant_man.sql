CREATE TABLE `activity_logs` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`taskId` bigint unsigned,
	`level` varchar(16) NOT NULL DEFAULT 'info',
	`source` varchar(16) NOT NULL,
	`message` text NOT NULL,
	`meta` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bot_wallets` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`label` varchar(255) NOT NULL,
	`address` varchar(42) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `bot_wallets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mint_tasks` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`name` varchar(255) NOT NULL,
	`contractAddress` varchar(42) NOT NULL,
	`chainId` int NOT NULL DEFAULT 1,
	`mintFunction` varchar(128) NOT NULL DEFAULT 'mint',
	`mintArgs` json NOT NULL,
	`mintValueEth` varchar(64) NOT NULL DEFAULT '0',
	`gasLimit` int NOT NULL DEFAULT 200000,
	`triggerMode` varchar(16) NOT NULL DEFAULT 'time',
	`openTime` timestamp,
	`flagMethod` varchar(128) NOT NULL DEFAULT 'saleActive',
	`pollIntervalMs` int NOT NULL DEFAULT 1000,
	`eventName` varchar(128),
	`startMaxFeeGwei` int NOT NULL DEFAULT 60,
	`startPriorityGwei` int NOT NULL DEFAULT 3,
	`gasBumpGwei` int NOT NULL DEFAULT 10,
	`maxMaxFeeGwei` int NOT NULL DEFAULT 500,
	`maxRetries` int NOT NULL DEFAULT 8,
	`status` varchar(16) NOT NULL DEFAULT 'draft',
	`dryRun` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mint_tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `signals` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`watchedWalletId` bigint unsigned,
	`type` varchar(16) NOT NULL,
	`contractAddress` varchar(42) NOT NULL,
	`tokenId` varchar(78),
	`collectionName` varchar(255),
	`priceEth` varchar(64),
	`txHash` varchar(66),
	`status` varchar(16) NOT NULL DEFAULT 'detected',
	`pnlEth` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `signals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_settings` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`rpcUrl` varchar(512),
	`chainId` int NOT NULL DEFAULT 1,
	`executionMode` varchar(16) NOT NULL DEFAULT 'simulation',
	`maxGasGwei` int NOT NULL DEFAULT 500,
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_settings_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`unionId` varchar(255) NOT NULL,
	`name` varchar(255),
	`email` varchar(320),
	`avatar` text,
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	`lastSignInAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_unionId_unique` UNIQUE(`unionId`)
);
--> statement-breakpoint
CREATE TABLE `watched_wallets` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`userId` bigint unsigned NOT NULL,
	`address` varchar(42) NOT NULL,
	`label` varchar(255) NOT NULL,
	`chain` varchar(32) NOT NULL DEFAULT 'ethereum',
	`enabled` boolean NOT NULL DEFAULT true,
	`copyMints` boolean NOT NULL DEFAULT true,
	`copyBuys` boolean NOT NULL DEFAULT false,
	`maxPerTradeEth` varchar(64) NOT NULL DEFAULT '0.1',
	`maxDailyEth` varchar(64) NOT NULL DEFAULT '1',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `watched_wallets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `activity_logs` ADD CONSTRAINT `activity_logs_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `activity_logs` ADD CONSTRAINT `activity_logs_taskId_mint_tasks_id_fk` FOREIGN KEY (`taskId`) REFERENCES `mint_tasks`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `bot_wallets` ADD CONSTRAINT `bot_wallets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `mint_tasks` ADD CONSTRAINT `mint_tasks_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `signals` ADD CONSTRAINT `signals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `signals` ADD CONSTRAINT `signals_watchedWalletId_watched_wallets_id_fk` FOREIGN KEY (`watchedWalletId`) REFERENCES `watched_wallets`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_settings` ADD CONSTRAINT `user_settings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `watched_wallets` ADD CONSTRAINT `watched_wallets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;