/**
 * Offline tests for the DefiLlama price oracle — the fetcher is injected,
 * so no network is touched. URL capture also verifies batching (multiple
 * coins per historical call, ETH's own price riding along), caching, and
 * the current-price fallback for historical misses (Robinhood coverage).
 */
import { describe, expect, it } from "vitest";
import {
  convertToEth,
  createPriceResolver,
  currentCoinCandidates,
  hourFloor,
  llamaCoinKey,
  type PriceFetcher,
} from "./priceOracle";

const USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48";
const WETH_INK = "0x4200000000000000000000000000000000000006";
/** Canonical Paxos USDG on Robinhood Chain (4663) and its Ethereum twin. */
const USDG_ROBINHOOD = "0x5fc5360d0400a0fd4f2af552add042d716f1d168";
const USDG_ETHEREUM = "0xe343167631d89b6ffc58b88d6b7fb0228795491d";
const TS = 1_700_000_123; // not hour-aligned on purpose
const HOUR = hourFloor(TS);

type CoinEntry = { price: number; decimals?: number; symbol?: string };

/**
 * Mock coins.llama.fi: serves `hist` prices on /prices/historical and `cur`
 * prices on /prices/current (defaults to the same map — a coin that has
 * history usually has a current price too; pass `{}` to simulate a
 * current-endpoint miss).
 */
function mockFetcher(
  hist: Record<string, CoinEntry>,
  cur: Record<string, CoinEntry> = hist,
) {
  const calls: string[] = [];
  const fetcher: PriceFetcher = async (url) => {
    calls.push(url);
    const m = url.match(/\/prices\/historical\/(\d+)\/(.+)$/);
    const c = url.match(/\/prices\/current\/(.+)$/);
    const coins: Record<string, unknown> = {};
    if (m) {
      for (const key of decodeURIComponent(m[2]).split(",")) {
        if (hist[key]) coins[key] = { timestamp: Number(m[1]), ...hist[key] };
      }
    } else if (c) {
      for (const key of decodeURIComponent(c[1]).split(",")) {
        if (cur[key]) coins[key] = { timestamp: 1_800_000_000, ...cur[key] };
      }
    }
    return { coins };
  };
  return { fetcher, calls };
}

describe("priceOracle — batching, caching, conversion", () => {
  it("batches token + ETH prices into one hourly historical call and converts", async () => {
    const { fetcher, calls } = mockFetcher({
      [`ethereum:${USDC}`]: { price: 1.0, decimals: 6, symbol: "USDC" },
      "coingecko:ethereum": { price: 2000, symbol: "ETH" },
    });
    const oracle = createPriceResolver({ fetcher });
    oracle.request(1, USDC, TS);
    await oracle.resolve();

    // One call, hour-floored, both coins comma-batched.
    expect(calls).toHaveLength(1);
    expect(calls[0]).toContain(`/prices/historical/${HOUR}/`);
    expect(calls[0]).toContain(`ethereum:${USDC}`);
    expect(calls[0]).toContain("coingecko:ethereum");

    // 2000 USDC (18dp token amount) at $1 with ETH at $2000 → exactly 1 ETH.
    const conv = oracle.get(1, USDC, 2000n * 10n ** 18n, TS);
    expect(conv).not.toBeNull();
    expect(conv!.ethWei).toBe(10n ** 18n);
    expect(conv!.eth).toBe("1.0000000000");
    expect(conv!.usd).toBe("2000.00");
    expect(conv!.approx).toBe(false); // exact historical rate, no fallback
  });

  it("converts fractional rates with bigint fixed-point math", async () => {
    const { fetcher } = mockFetcher({
      [`base:${WETH_INK}`]: { price: 0.5, decimals: 18 },
      "coingecko:ethereum": { price: 2500 },
    });
    const oracle = createPriceResolver({ fetcher });
    oracle.request(8453, WETH_INK, TS);
    await oracle.resolve();
    // 3 tokens @ $0.50 = $1.50 ÷ $2500 = 0.0006 ETH
    const conv = oracle.get(8453, WETH_INK, 3n * 10n ** 18n, TS);
    expect(conv!.ethWei).toBe(6n * 10n ** 14n);
    expect(conv!.usd).toBe("1.50");
  });

  it("returns null when the oracle has no price and negative-caches the miss", async () => {
    const { fetcher, calls } = mockFetcher({}); // nothing priced
    const oracle = createPriceResolver({ fetcher });
    oracle.request(1, USDC, TS);
    await oracle.resolve();
    expect(oracle.get(1, USDC, 10n ** 18n, TS)).toBeNull();
    expect(oracle.decimals(1, USDC, TS)).toBeNull();

    // Two calls: one historical batch, one current-price fallback batch.
    expect(calls).toHaveLength(2);
    expect(calls.some((u) => u.includes("/prices/historical/"))).toBe(true);
    expect(calls.some((u) => u.includes(`/prices/current/ethereum:${USDC}`))).toBe(true);

    // A second resolve of the same pair must not re-hit the network (1h
    // negative cache on BOTH endpoints).
    oracle.request(1, USDC, TS);
    await oracle.resolve();
    expect(calls).toHaveLength(2);
  });

  it("survives a dead oracle: resolve() never throws, everything unpriced", async () => {
    const fetcher: PriceFetcher = async () => {
      throw new Error("network down");
    };
    const oracle = createPriceResolver({ fetcher, budgetMs: 5_000 });
    oracle.request(1, USDC, TS);
    await expect(oracle.resolve()).resolves.toBeUndefined();
    expect(oracle.get(1, USDC, 10n ** 18n, TS)).toBeNull();
  });

  it("robinhood token with no coverage anywhere → current fallback misses, unpriced", async () => {
    const { fetcher, calls } = mockFetcher({});
    const oracle = createPriceResolver({ fetcher });
    oracle.request(4663, USDC, TS); // no historical prefix; current candidate exists
    await oracle.resolve();
    // Historical call carries only ETH's price (robinhood has no historical
    // prefix); the current call tries the chain's own `robinhood:` prefix.
    const hist = calls.filter((u) => u.includes("/prices/historical/"));
    const cur = calls.filter((u) => u.includes("/prices/current/"));
    expect(hist).toHaveLength(1);
    expect(hist[0]).toContain("coingecko:ethereum");
    expect(hist[0]).not.toContain(USDC);
    expect(cur).toHaveLength(1);
    expect(cur[0]).toContain(`robinhood:${USDC}`);
    // No coverage on either endpoint → null (profiler marks it unpriced).
    expect(oracle.get(4663, USDC, 10n ** 18n, TS)).toBeNull();
    expect(llamaCoinKey(4663, USDC)).toBeNull();
    expect(llamaCoinKey(57073, WETH_INK)).toBe(`ink:${WETH_INK}`);
  });

  it("rejects non-finite / non-positive prices", async () => {
    const { fetcher } = mockFetcher({
      [`ethereum:${USDC}`]: { price: -5, decimals: 6 },
      "coingecko:ethereum": { price: 2000 },
    });
    const oracle = createPriceResolver({ fetcher });
    oracle.request(1, USDC, TS);
    await oracle.resolve();
    expect(oracle.get(1, USDC, 10n ** 18n, TS)).toBeNull();
  });

  it("convertToEth one-shot helper normalizes smallest-unit quantities by decimals", async () => {
    const { fetcher } = mockFetcher({
      [`ethereum:${USDC}`]: { price: 1.0, decimals: 6 },
      "coingecko:ethereum": { price: 2000 },
    });
    // 500 USDC as a 6-decimals smallest-unit string → 0.25 ETH, $500.
    const conv = await convertToEth(1, USDC, "500000000", 6, TS, { fetcher });
    expect(conv).toEqual({ eth: "0.2500000000", usd: "500.00", approx: false });
  });
});

describe("priceOracle — current-price fallback (approx pricing)", () => {
  it("historical hit → no current-endpoint call, approx:false", async () => {
    const { fetcher, calls } = mockFetcher({
      [`ethereum:${USDC}`]: { price: 1.0, decimals: 6 },
      "coingecko:ethereum": { price: 2000 },
    });
    const oracle = createPriceResolver({ fetcher });
    oracle.request(1, USDC, TS);
    await oracle.resolve();
    expect(calls.every((u) => u.includes("/prices/historical/"))).toBe(true);
    expect(oracle.get(1, USDC, 10n ** 18n, TS)!.approx).toBe(false);
  });

  it("historical miss → current price used, approx:true, exact fallback math", async () => {
    // Historical knows ONLY ETH ($2500 at the sale hour); the current
    // endpoint prices the token at $0.50 now.
    const { fetcher, calls } = mockFetcher(
      { "coingecko:ethereum": { price: 2500 } },
      { [`ethereum:${USDC}`]: { price: 0.5, decimals: 6, symbol: "USDC" } },
    );
    const oracle = createPriceResolver({ fetcher });
    oracle.request(1, USDC, TS);
    await oracle.resolve();
    expect(calls.some((u) => u.includes(`/prices/current/ethereum:${USDC}`))).toBe(true);
    // 3 tokens × $0.50 (CURRENT) = $1.50 ÷ $2500 (HISTORICAL ETH) = 0.0006 ETH.
    const conv = oracle.get(1, USDC, 3n * 10n ** 18n, TS);
    expect(conv).not.toBeNull();
    expect(conv!.approx).toBe(true);
    expect(conv!.ethWei).toBe(6n * 10n ** 14n);
    expect(conv!.usd).toBe("1.50");
    // Fallback decimals are available too.
    expect(oracle.decimals(1, USDC, TS)).toBe(6);
  });

  it("prices a Robinhood USDG sale via the robinhood: current fallback", async () => {
    const { fetcher, calls } = mockFetcher(
      { "coingecko:ethereum": { price: 2000 } }, // history: ETH only
      { [`robinhood:${USDG_ROBINHOOD}`]: { price: 1.0, decimals: 6, symbol: "USDG" } },
    );
    const oracle = createPriceResolver({ fetcher });
    oracle.request(4663, USDG_ROBINHOOD, TS);
    await oracle.resolve();
    // Historical call: ETH rider only (robinhood has no historical prefix).
    const hist = calls.filter((u) => u.includes("/prices/historical/"));
    expect(hist).toHaveLength(1);
    expect(hist[0]).toContain("coingecko:ethereum");
    // Current call: own prefix first + canonical ethereum: twin, one batch.
    const cur = calls.filter((u) => u.includes("/prices/current/"));
    expect(cur).toHaveLength(1);
    expect(cur[0]).toContain(`robinhood:${USDG_ROBINHOOD}`);
    expect(cur[0]).toContain(`ethereum:${USDG_ETHEREUM}`);
    // 2000 USDG @ $1 with ETH at $2000 → exactly 1 ETH, flagged approx.
    const conv = oracle.get(4663, USDG_ROBINHOOD, 2000n * 10n ** 18n, TS);
    expect(conv).not.toBeNull();
    expect(conv!.approx).toBe(true);
    expect(conv!.ethWei).toBe(10n ** 18n);
    expect(conv!.usd).toBe("2000.00");
  });

  it("tries the canonical ethereum: twin when the robinhood: prefix misses", async () => {
    const { fetcher } = mockFetcher(
      { "coingecko:ethereum": { price: 2000 } },
      { [`ethereum:${USDG_ETHEREUM}`]: { price: 1.0, decimals: 6, symbol: "USDG" } },
    );
    const oracle = createPriceResolver({ fetcher });
    oracle.request(4663, USDG_ROBINHOOD, TS);
    await oracle.resolve();
    const conv = oracle.get(4663, USDG_ROBINHOOD, 500n * 10n ** 18n, TS);
    expect(conv).not.toBeNull();
    expect(conv!.approx).toBe(true);
    expect(conv!.ethWei).toBe(25n * 10n ** 16n); // 0.25 ETH
    expect(currentCoinCandidates(4663, USDG_ROBINHOOD)).toEqual([
      `robinhood:${USDG_ROBINHOOD}`,
      `ethereum:${USDG_ETHEREUM}`,
    ]);
  });

  it("batches current-price fallback calls at ≤25 coins and sends an AbortSignal", async () => {
    // 30 distinct Robinhood tokens → two current calls (25 + 5).
    const tokens = Array.from(
      { length: 30 },
      (_, i) => `0x${String(i + 1).padStart(40, "0")}`,
    );
    const signals: unknown[] = [];
    const calls: string[] = [];
    const fetcher: PriceFetcher = async (url, signal) => {
      calls.push(url);
      signals.push(signal);
      return { coins: {} };
    };
    const oracle = createPriceResolver({ fetcher });
    for (const t of tokens) oracle.request(4663, t, TS);
    await oracle.resolve();
    const cur = calls.filter((u) => u.includes("/prices/current/"));
    expect(cur).toHaveLength(2);
    for (const u of cur) {
      const list = decodeURIComponent(u.split("/prices/current/")[1]).split(",");
      expect(list.length).toBeLessThanOrEqual(25);
    }
    // 30 unique robinhood: coins across the two calls (no canonical twins —
    // none of these addresses are in the built-in map).
    const all = cur.flatMap((u) => decodeURIComponent(u.split("/prices/current/")[1]).split(","));
    expect(new Set(all).size).toBe(30);
    expect(all.every((c) => c.startsWith("robinhood:"))).toBe(true);
    expect(signals.length).toBeGreaterThan(0);
    expect(signals.every((s) => s instanceof AbortSignal)).toBe(true);
  });

  it("current-price call retries on failure, then prices approx", async () => {
    let curAttempts = 0;
    const fetcher: PriceFetcher = async (url) => {
      if (url.includes("/prices/current/")) {
        curAttempts += 1;
        if (curAttempts < 3) throw new Error("flaky"); // 2 fails, then success
        return {
          coins: {
            [`robinhood:${USDG_ROBINHOOD}`]: { price: 1.0, decimals: 6, symbol: "USDG" },
          },
        };
      }
      return { coins: { "coingecko:ethereum": { price: 2000 } } };
    };
    const oracle = createPriceResolver({ fetcher });
    oracle.request(4663, USDG_ROBINHOOD, TS);
    await expect(oracle.resolve()).resolves.toBeUndefined();
    expect(curAttempts).toBe(3); // initial + MAX_RETRIES
    const conv = oracle.get(4663, USDG_ROBINHOOD, 2000n * 10n ** 18n, TS);
    expect(conv!.approx).toBe(true);
    expect(conv!.ethWei).toBe(10n ** 18n);
  });

  it("dead current endpoint after historical miss → null, never throws", async () => {
    const fetcher: PriceFetcher = async (url) => {
      if (url.includes("/prices/current/")) throw new Error("down");
      return { coins: { "coingecko:ethereum": { price: 2000 } } };
    };
    const oracle = createPriceResolver({ fetcher, budgetMs: 10_000 });
    oracle.request(4663, USDG_ROBINHOOD, TS);
    await expect(oracle.resolve()).resolves.toBeUndefined();
    expect(oracle.get(4663, USDG_ROBINHOOD, 10n ** 18n, TS)).toBeNull();
  });
});
