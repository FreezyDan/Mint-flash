/**
 * Smart RPC manager — races the public endpoint pool per chain and caches
 * the fastest healthy endpoint. When a user has `rpcAuto` enabled (the
 * default), engines use this instead of a hand-configured rpcUrl.
 */
import { RpcEndpoints, type ResolvedRpc, type RpcRaceResult } from "@contracts/rpc";
import { getOrCreateSettings } from "../queries/settings";
import { healthyEndpoints, markUnhealthy } from "./rpcHealth";

const RACE_TIMEOUT_MS = 3_500;
const BEST_CACHE_TTL_MS = 5 * 60 * 1000;
/** Two consecutive probe timeouts mark an endpoint unhealthy for 10 min. */
const TIMEOUT_STREAK_LIMIT = 2;

const bestCache = new Map<number, { url: string; expiresAt: number }>();
/** Consecutive probe timeouts per endpoint (reset on any successful probe). */
const timeoutStreaks = new Map<string, number>();

async function probeEndpoint(url: string, chainId: number): Promise<RpcRaceResult> {
  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), RACE_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_chainId", params: [] }),
      signal: controller.signal,
    });
    const latencyMs = Date.now() - started;
    // HTTP errors (403/5xx) — the endpoint is blocking or broken; skip it.
    if (!res.ok) {
      markUnhealthy(url);
      return { url, latencyMs, ok: false };
    }
    const body = (await res.json()) as {
      result?: string;
      error?: { code?: number; message?: string };
    };
    // A JSON-RPC error response (code present) means the endpoint rejects our
    // calls — mark it unhealthy so it is not raced again for 10 minutes.
    if (body.error && body.error.code !== undefined) {
      markUnhealthy(url);
      return { url, latencyMs, ok: false };
    }
    const reported = body.result ? Number.parseInt(body.result, 16) : NaN;
    const ok = reported === chainId;
    if (ok) timeoutStreaks.delete(url);
    return { url, latencyMs, ok };
  } catch {
    if (controller.signal.aborted) {
      const streak = (timeoutStreaks.get(url) ?? 0) + 1;
      timeoutStreaks.set(url, streak);
      if (streak >= TIMEOUT_STREAK_LIMIT) {
        markUnhealthy(url);
        timeoutStreaks.delete(url);
      }
    }
    return { url, latencyMs: null, ok: false };
  } finally {
    clearTimeout(timer);
  }
}

/** Race every healthy pool endpoint for a chain; sorted ok-first, latency asc. */
export async function raceEndpoints(chainId: number): Promise<RpcRaceResult[]> {
  const pool = healthyEndpoints(RpcEndpoints[chainId] ?? []);
  const results = await Promise.all(pool.map((url) => probeEndpoint(url, chainId)));
  return results.sort((a, b) => {
    if (a.ok !== b.ok) return a.ok ? -1 : 1;
    return (a.latencyMs ?? Number.POSITIVE_INFINITY) - (b.latencyMs ?? Number.POSITIVE_INFINITY);
  });
}

/** Fastest healthy endpoint for a chain, cached for 5 minutes. */
export async function getBestRpc(chainId: number): Promise<string> {
  const pool = healthyEndpoints(RpcEndpoints[chainId] ?? []);
  const fallback = pool[0] ?? "";
  const cached = bestCache.get(chainId);
  // A cached winner that has since been marked unhealthy is re-raced.
  if (cached && cached.expiresAt > Date.now() && pool.includes(cached.url)) {
    return cached.url;
  }

  const results = await raceEndpoints(chainId);
  const best = results.find((r) => r.ok)?.url ?? fallback;
  bestCache.set(chainId, { url: best, expiresAt: Date.now() + BEST_CACHE_TTL_MS });
  return best;
}

/**
 * Resolve the RPC endpoint for a user + chain.
 * Custom rpcUrl wins only when rpcAuto is off; otherwise the auto-raced
 * public endpoint is used.
 */
export async function resolveRpcForUser(userId: number, chainId: number): Promise<ResolvedRpc> {
  const settings = await getOrCreateSettings(userId);
  if (!settings.rpcAuto && settings.rpcUrl) {
    return { url: settings.rpcUrl, source: "custom" };
  }
  const url = await getBestRpc(chainId);
  return { url, source: "auto" };
}
