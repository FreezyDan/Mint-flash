/**
 * Offline tests for rarity sniping: pure local-score math, the rarity
 * gate, and the v2 endpoint parsing behind a mocked global fetch (wire
 * shapes mimic the OpenSea API v2 nft / traits responses).
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  clearRarityCaches,
  computeLocalRarity,
  getTokenRarity,
  getTraitFrequencies,
  passesRarityGate,
  resolveRarity,
  topRarestTraits,
  traitKey,
  type ResolvedRarity,
  type TokenTrait,
} from "./rarity";

const CONTRACT = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

/** Queue of mocked fetch responses (OpenSea v2 wire shapes). */
let responses: Array<{ status?: number; body: unknown }>;
let requestedUrls: string[];

function queue(body: unknown, status = 200) {
  responses.push({ status, body });
}

beforeEach(() => {
  responses = [];
  requestedUrls = [];
  clearRarityCaches();
  vi.stubGlobal(
    "fetch",
    vi.fn(async (url: string | URL | Request) => {
      requestedUrls.push(String(url));
      const next = responses.shift();
      if (!next) throw new Error("unexpected fetch");
      return {
        ok: (next.status ?? 200) >= 200 && (next.status ?? 200) < 300,
        status: next.status ?? 200,
        json: async () => next.body,
      } as Response;
    }),
  );
});

afterEach(() => {
  vi.unstubAllGlobals();
});

const nftBody = (args: {
  rank?: number | null;
  collection?: string | null;
  traits?: Array<{ trait_type: string; value: string | number }>;
}) => ({
  nft: {
    collection: args.collection === undefined ? "test-collection" : args.collection,
    traits: args.traits ?? [
      { trait_type: "Background", value: "Blue" },
      { trait_type: "Eyes", value: "Laser" },
    ],
    ...(args.rank !== undefined && args.rank !== null
      ? { rarity: { strategy_id: "openrarity", rank: args.rank } }
      : {}),
  },
});

const traitsBody = {
  categories: { Background: "string", Eyes: "string" },
  counts: {
    Background: { Blue: 5000, Gold: 100 },
    Eyes: { Laser: 250, Normal: 8000 },
  },
};

describe("computeLocalRarity — pure information-theoretic score", () => {
  const traits: TokenTrait[] = [
    { type: "Background", value: "Blue" },
    { type: "Eyes", value: "Laser" },
  ];

  it("sums −log2(frequency) over all traits", () => {
    const freq = new Map([
      [traitKey("Background", "Blue"), 5000],
      [traitKey("Eyes", "Laser"), 250],
    ]);
    // freqs: 0.5 and 0.025 → scores 1 and ~5.3219
    const { score, traits: per } = computeLocalRarity(traits, freq, 10_000);
    expect(score).toBeCloseTo(1 + -Math.log2(0.025), 6);
    expect(per[0].frequency).toBeCloseTo(0.5, 9);
    expect(per[1].score).toBeCloseTo(-Math.log2(0.025), 6);
  });

  it("is case-insensitive when matching trait keys", () => {
    const freq = new Map([[traitKey("background", "blue"), 100]]);
    const { score } = computeLocalRarity(
      [{ type: "Background", value: "BLUE" }],
      freq,
      1000,
    );
    expect(score).toBeCloseTo(-Math.log2(0.1), 6);
  });

  it("skips a missing trait with a note instead of scoring it", () => {
    const freq = new Map([[traitKey("Background", "Blue"), 5000]]);
    const { score, traits: per } = computeLocalRarity(traits, freq, 10_000);
    expect(score).toBeCloseTo(1, 9); // only the known trait contributes
    expect(per[1].note).toMatch(/not in frequency table/);
    expect(per[1].score).toBe(0);
  });

  it("scores an empty trait list as 0", () => {
    const { score, traits: per } = computeLocalRarity([], new Map(), 10_000);
    expect(score).toBe(0);
    expect(per).toEqual([]);
  });

  it("skips zero-count traits (would be +∞) and non-positive supply", () => {
    const freq = new Map([[traitKey("Background", "Blue"), 0]]);
    const zero = computeLocalRarity(traits.slice(0, 1), freq, 10_000);
    expect(zero.traits[0].note).toMatch(/zero holders/);
    expect(zero.score).toBe(0);

    const noSupply = computeLocalRarity(traits.slice(0, 1), freq, 0);
    expect(noSupply.traits[0].note).toMatch(/unknown total supply/);
    expect(noSupply.score).toBe(0);
  });

  it("clamps frequency at 1 when the count exceeds the estimated supply", () => {
    const freq = new Map([[traitKey("Background", "Blue"), 20_000]]);
    const { score } = computeLocalRarity(traits.slice(0, 1), freq, 10_000);
    expect(score).toBe(0); // -log2(1), not negative
  });
});

describe("passesRarityGate — rank-only comparison", () => {
  it("passes when rank ≤ max, skips when rank > max", () => {
    const rare: ResolvedRarity = {
      kind: "rank",
      rank: 42,
      traits: [],
      collectionSlug: "x",
    };
    const common: ResolvedRarity = { ...rare, rank: 9000 };
    expect(passesRarityGate(rare, 100)).toBe("pass");
    expect(passesRarityGate(common, 100)).toBe("skip");
  });

  it("returns 'unknown' for score-only and unknown rarity (never blocks)", () => {
    expect(
      passesRarityGate(
        { kind: "score", score: 12.5, traits: [], collectionSlug: "x" },
        100,
      ),
    ).toBe("unknown");
    expect(passesRarityGate({ kind: "unknown" }, 100)).toBe("unknown");
  });
});

describe("getTokenRarity / getTraitFrequencies — v2 wire shapes", () => {
  it("parses rank, traits and collection slug from the nft endpoint", async () => {
    queue(nftBody({ rank: 42 }));
    const res = await getTokenRarity(1, CONTRACT, "7", "key");
    expect(requestedUrls[0]).toContain("/v2/chain/ethereum/contract/");
    expect(requestedUrls[0]).toContain("/nfts/7");
    expect(res?.rank).toBe(42);
    expect(res?.collectionSlug).toBe("test-collection");
    expect(res?.traits).toEqual([
      { type: "Background", value: "Blue" },
      { type: "Eyes", value: "Laser" },
    ]);
  });

  it("returns null rank when OpenSea hasn't computed rarity yet", async () => {
    queue(nftBody({}));
    const res = await getTokenRarity(8453, CONTRACT, "7", "key");
    expect(requestedUrls[0]).toContain("/v2/chain/base/");
    expect(res?.rank).toBeNull();
    expect(res?.collectionSlug).toBe("test-collection");
  });

  it("returns null on chains without OpenSea coverage", async () => {
    const res = await getTokenRarity(999_999, CONTRACT, "7", "key");
    expect(res).toBeNull();
    expect(requestedUrls).toHaveLength(0);
  });

  it("builds the frequency map and estimates supply as the max count", async () => {
    queue(traitsBody);
    const res = await getTraitFrequencies(1, "test-collection", "key");
    expect(requestedUrls[0]).toContain("/v2/traits/test-collection");
    expect(res?.totalSupply).toBe(8000);
    expect(res?.freq.get("background:blue")).toBe(5000);
    expect(res?.freq.get("eyes:laser")).toBe(250);
  });

  it("returns null for an empty frequency table", async () => {
    queue({ categories: {}, counts: {} });
    const res = await getTraitFrequencies(1, "test-collection", "key");
    expect(res).toBeNull();
  });
});

describe("resolveRarity — rank first, local-score fallback, caching", () => {
  it("resolves to a rank when OpenRarity is available", async () => {
    queue(nftBody({ rank: 7 }));
    const res = await resolveRarity(1, CONTRACT, "7", "key");
    expect(res).toMatchObject({ kind: "rank", rank: 7 });
    expect(requestedUrls).toHaveLength(1); // no traits call needed
  });

  it("falls back to a local score when the rank is absent", async () => {
    queue(nftBody({}));
    queue(traitsBody);
    const res = await resolveRarity(1, CONTRACT, "7", "key");
    expect(res.kind).toBe("score");
    if (res.kind === "score") {
      // Blue 5000/8000 → 0.6781; Laser 250/8000 → 5
      expect(res.score).toBeCloseTo(-Math.log2(5000 / 8000) + 5, 4);
    }
    expect(requestedUrls).toHaveLength(2);
  });

  it("resolves to unknown when neither rank nor slug is available", async () => {
    queue(nftBody({ collection: null }));
    const res = await resolveRarity(1, CONTRACT, "7", "key");
    expect(res).toEqual({ kind: "unknown" });
  });

  it("degrades to unknown (not a throw) when the nft endpoint fails", async () => {
    queue({}, 500);
    const res = await resolveRarity(1, CONTRACT, "7", "key");
    expect(res).toEqual({ kind: "unknown" });
  });

  it("caches token results and collection frequencies", async () => {
    queue(nftBody({}));
    queue(traitsBody);
    queue(nftBody({})); // second token: nft fetch only — frequencies cached
    const first = await resolveRarity(1, CONTRACT, "7", "key");
    const second = await resolveRarity(1, CONTRACT, "8", "key");
    const again = await resolveRarity(1, CONTRACT, "7", "key"); // token cache
    expect(first.kind).toBe("score");
    expect(second.kind).toBe("score");
    expect(again).toEqual(first);
    expect(requestedUrls).toHaveLength(3);
  });
});

describe("topRarestTraits — tooltip data", () => {
  it("returns the 2 rarest traits with collection %", async () => {
    queue(nftBody({}));
    queue(traitsBody);
    const token = await getTokenRarity(1, CONTRACT, "7", "key");
    const top = await topRarestTraits(1, "test-collection", token!.traits, "key");
    expect(top).toEqual([
      { type: "Eyes", value: "Laser", pct: 3.13 },
      { type: "Background", value: "Blue", pct: 62.5 },
    ]);
  });
});
