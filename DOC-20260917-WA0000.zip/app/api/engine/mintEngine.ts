import { ethers } from "ethers";
import type { MintTask, UserSettings } from "@db/schema";
import { explorerTxUrl } from "@contracts/rpc";
import { logActivity } from "../queries/activity";
import { entryEth10, insertPosition } from "../queries/positions";
import { getMeProtection, getOrCreateSettings } from "../queries/settings";
import { updateTask } from "../queries/tasks";
import { findUserById } from "../queries/users";
import { canExecute, computeEntitlement } from "../lib/entitlements";
import { isHalted } from "../lib/halt";
import { MEV_PROTECT_RPC } from "../lib/mev";
import { cleanRpcError, ErrorThrottle } from "../lib/rpcError";
import { getLiveExecutionKeys } from "./managedWallet";
import { evaluateGas, effectiveCapGwei, formatGwei } from "./gasGuard";
import {
  detectMintPhase,
  injectProofArgs,
  resolvePhase,
  type MintPhaseName,
} from "./mintPhase";
import { simulateMint, shouldSendAfterSim } from "./mintSimulate";
import { resolveRpcForUser } from "./rpcManager";

/**
 * TypeScript port of the CLI bot (monitor.js + minter.js) as a long-lived,
 * per-task engine. Keyed by taskId via the engine manager.
 *
 * Trigger modes (monitor.js):
 *  - time : wait until openTime (150ms lead)
 *  - poll : call flagMethod() on the contract until it returns true
 *  - event: wait for eventName on the contract (WS provider required)
 *
 * Execution (minter.js) — LIVE ONLY:
 *  - fixed pending nonce, EIP-1559 type-2 txs
 *  - bump both fees by gasBumpGwei on underpriced/timeout
 *  - abort when fees would exceed the maxMaxFeeGwei ceiling
 *
 * Every task executes REAL on-chain transactions signed by the user's managed
 * vault wallet (plus any BOT_PRIVATE_KEYS env extras). There is no dry-run
 * path: no usable signing key or RPC endpoint fails the task honestly with a
 * clear activity log; reverted/failed transactions log the real reason and
 * tx hash; successes log the real tx hash + explorer link.
 */

const GENERIC_ABI = [
  "function saleActive() view returns (bool)",
  "function isSaleActive() view returns (bool)",
  "function publicSaleActive() view returns (bool)",
  "function mint(uint256 quantity) payable",
  "function mint(uint256 quantity)",
  "function mint(address to, uint256 quantity) payable",
  "function publicMint(uint256 quantity) payable",
  "function whitelistMint(uint256 quantity, bytes32[] proof) payable",
  "event SaleOpened()",
];

const RECEIPT_TIMEOUT_MS = 3 * 60 * 1000;
const TIME_LEAD_MS = 150;
/** Re-check network gas this often while the gas guard is holding fire. */
const GAS_RECHECK_MS = 15_000;
/** Throttle "holding fire" activity logs to one per task per 5 minutes. */
const GAS_HOLD_LOG_INTERVAL_MS = 5 * 60 * 1000;
/** Mint-phase detection result is reused for this long at fire time. */
const PHASE_CACHE_MS = 20_000;

type LogLevel = "info" | "warn" | "error" | "success";
type Logger = (level: LogLevel, message: string, meta?: unknown) => Promise<void>;

function gweiToWei(v: number): bigint {
  return ethers.parseUnits(String(v), "gwei");
}

function fmtGwei(wei: bigint): string {
  return `${ethers.formatUnits(wei, "gwei")} gwei`;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export class MintEngine {
  private stopped = false;
  private readonly task: MintTask;
  /** Repeat-error throttle (1 log per 15 min per cleaned message). */
  private errorThrottle = new ErrorThrottle();
  constructor(task: MintTask, _settings?: UserSettings) {
    this.task = task;
    // Settings are re-resolved live at run time; the constructor arg is kept
    // for call-site compatibility (engineManager passes the cached row).
    void _settings;
  }

  stop() {
    this.stopped = true;
  }

  get taskId() {
    return this.task.id;
  }

  private log: Logger = async (level, message, meta) => {
    if (level !== "info") console[level === "success" ? "log" : level]?.(`[mint#${this.task.id}]`, message);
    await logActivity({
      userId: this.task.userId,
      taskId: this.task.id,
      level,
      source: "mint",
      message,
      meta,
    });
  };

  /** Sleep that returns early (false) when the engine is stopped. */
  private async wait(ms: number): Promise<boolean> {
    const end = Date.now() + ms;
    while (!this.stopped && Date.now() < end) {
      await sleep(Math.min(500, end - Date.now()));
    }
    return !this.stopped;
  }

  /** The endpoint chosen by the smart RPC manager (set by makeProvider). */
  private resolvedRpc: { url: string; source: "custom" | "auto" } | null = null;
  /** Global gas ceiling from user_settings.maxGasGwei (null = unknown). */
  private globalMaxGasGwei: number | null = null;
  /** Flashbots Protect broadcast URL when MEV protection applies, else null. */
  private mevProtectUrl: string | null = null;
  /** Last time a "holding fire" gas log was written (throttle). */
  private lastGasHoldLogAt = 0;
  /** Cached resolved mint phase (whitelist/public/closed/unknown), 20s TTL. */
  private phaseCache: { at: number; phase: MintPhaseName } | null = null;
  /** Last time a phase-hold log was written (throttle). */
  private lastPhaseHoldLogAt = 0;
  /** Last time a simulation-hold log was written (throttle). */
  private lastSimHoldLogAt = 0;
  /** Wallets already told about a missing merkle proof (log once each). */
  private readonly noProofLogged = new Set<string>();

  /**
   * Resolved mint phase for this task: on-chain detection folded with the
   * task's mintPhase override ('auto' follows detection). Detection failures
   * degrade to 'unknown' — they must never block execution. Cached 20s.
   */
  private async getResolvedPhase(provider: ethers.JsonRpcProvider): Promise<MintPhaseName> {
    const now = Date.now();
    if (this.phaseCache && now - this.phaseCache.at < PHASE_CACHE_MS) {
      return this.phaseCache.phase;
    }
    try {
      const detected = await detectMintPhase(provider, this.task.contractAddress);
      const resolved = resolvePhase(detected.phase, this.task.mintPhase);
      if (resolved.note) await this.log("warn", `mint phase: ${resolved.note}`);
      this.phaseCache = { at: now, phase: resolved.phase };
      return resolved.phase;
    } catch {
      return "unknown";
    }
  }

  /**
   * Phase gate inside the fire loop. Returns "fire", or holds with the same
   * wait-and-retry semantics as the gas guard ("hold"), or skips this wallet
   * entirely when the whitelist phase demands a proof the wallet lacks.
   */
  private async phaseGate(
    provider: ethers.JsonRpcProvider,
    label: string,
    walletAddress: string,
    hasProof: boolean,
  ): Promise<{ verdict: "fire" | "skip"; phase: MintPhaseName } | { verdict: "hold"; phase: MintPhaseName }> {
    const phase = await this.getResolvedPhase(provider);
    if (phase === "whitelist" && !hasProof) {
      const key = walletAddress.toLowerCase();
      if (!this.noProofLogged.has(key)) {
        this.noProofLogged.add(key);
        await this.log("warn", `[${label}] no merkle proof for ${walletAddress} — skipped`);
      }
      return { verdict: "skip", phase };
    }
    if (phase === "closed" || (phase === "unknown" && this.task.mintPhase === "whitelist")) {
      const now = Date.now();
      if (now - this.lastPhaseHoldLogAt >= GAS_HOLD_LOG_INTERVAL_MS) {
        this.lastPhaseHoldLogAt = now;
        await this.log(
          "info",
          phase === "closed"
            ? `[${label}] mint not live — phase: closed`
            : `[${label}] whitelist phase required but undetectable on this contract — holding fire`,
        );
      }
      return { verdict: "hold", phase };
    }
    return { verdict: "fire", phase };
  }

  private async makeProvider(): Promise<ethers.JsonRpcProvider | null> {
    try {
      const rpc = await resolveRpcForUser(this.task.userId, this.task.chainId);
      this.resolvedRpc = rpc;
      if (!rpc.url) return null;
      return new ethers.JsonRpcProvider(rpc.url, this.task.chainId);
    } catch {
      return null;
    }
  }

  /**
   * Load the execution-affecting settings that live outside the task row:
   * the global gas ceiling and the MEV-protection flag. Failures degrade to
   * "no global cap, no MEV rerouting" — reads/sends stay on the normal RPC.
   */
  private async loadExecutionSettings(): Promise<void> {
    try {
      const settings = await getOrCreateSettings(this.task.userId);
      this.globalMaxGasGwei = settings.maxGasGwei ?? null;
    } catch {
      this.globalMaxGasGwei = null;
    }
    try {
      const mevEnabled = await getMeProtection(this.task.userId);
      this.mevProtectUrl = mevEnabled ? (MEV_PROTECT_RPC[this.task.chainId] ?? null) : null;
    } catch {
      this.mevProtectUrl = null;
    }
  }

  /**
   * Gas guard: is the network cheap enough to broadcast right now?
   * Holds fire (never fails the task) when over the effective cap.
   */
  private async gasAllowsBroadcast(
    provider: ethers.JsonRpcProvider,
    label: string,
  ): Promise<boolean> {
    const cap = effectiveCapGwei(this.task.maxMaxFeeGwei ?? null, this.globalMaxGasGwei);
    if (cap === null) return true;
    let feeData: ethers.FeeData;
    try {
      feeData = await provider.getFeeData();
    } catch {
      return true; // can't evaluate — don't block execution on a fee-oracle hiccup
    }
    if (feeData.maxFeePerGas === null) return true;
    const maxFeeGwei = Number(ethers.formatUnits(feeData.maxFeePerGas, "gwei"));
    const priorityGwei =
      feeData.maxPriorityFeePerGas === null
        ? 0
        : Number(ethers.formatUnits(feeData.maxPriorityFeePerGas, "gwei"));
    const verdict = evaluateGas({
      maxFeeGwei,
      priorityGwei,
      taskMaxMaxFeeGwei: this.task.maxMaxFeeGwei ?? null,
      globalMaxGasGwei: this.globalMaxGasGwei,
    });
    if (verdict.ok) return true;
    const now = Date.now();
    if (now - this.lastGasHoldLogAt >= GAS_HOLD_LOG_INTERVAL_MS) {
      this.lastGasHoldLogAt = now;
      await this.log(
        "info",
        `[${label}] gas ${formatGwei(maxFeeGwei)} gwei > cap ${formatGwei(cap)} — holding fire`,
      );
    }
    return false;
  }

  // ---------- trigger (port of monitor.js) ----------

  private async waitForTrigger(provider: ethers.JsonRpcProvider | null) {
    const t = this.task;

    if (t.triggerMode === "time") {
      if (!t.openTime) throw new Error("openTime is required for time trigger");
      const waitMs = t.openTime.getTime() - Date.now() - TIME_LEAD_MS;
      if (waitMs > 0) {
        await this.log(
          "info",
          `Time trigger: sale opens ${t.openTime.toISOString()}, waiting ${(waitMs / 1000).toFixed(1)}s…`,
        );
        await this.wait(waitMs);
      } else {
        await this.log("info", "Time trigger: open time already passed, firing immediately");
      }
      return;
    }

    if (t.triggerMode === "poll") {
      await this.log(
        "info",
        `Poll trigger: watching ${t.flagMethod}() every ${t.pollIntervalMs}ms…`,
      );
      if (provider) {
        const contract = new ethers.Contract(t.contractAddress, GENERIC_ABI, provider);
        const fn = contract.getFunction(t.flagMethod);
        while (!this.stopped) {
          try {
            const open = (await fn()) as boolean;
            if (open) {
              await this.log("success", `${t.flagMethod}() returned true — sale is OPEN`);
              return;
            }
          } catch (e) {
            // Cleaned + throttled: a failing flag poll runs every
            // pollIntervalMs — the same error logs at most once per 15 min.
            const cleaned = cleanRpcError(e);
            if (this.errorThrottle.shouldLog(`poll:${cleaned}`)) {
              await this.log("warn", `poll error (will retry): ${cleaned}`);
            }
          }
          if (!(await this.wait(t.pollIntervalMs))) return;
        }
      }
      return;
    }

    if (t.triggerMode === "event") {
      const eventName = t.eventName ?? "SaleOpened";
      const rpcUrl = this.resolvedRpc?.url ?? "";
      if (rpcUrl.startsWith("ws")) {
        await this.log("info", `Event trigger: waiting for "${eventName}" on ${t.contractAddress}…`);
        const wsProvider = new ethers.WebSocketProvider(rpcUrl, t.chainId);
        try {
          const wsContract = new ethers.Contract(t.contractAddress, GENERIC_ABI, wsProvider);
          await new Promise<void>((resolve, reject) => {
            const timer = setTimeout(
              () => reject(new Error("Event trigger timed out after 24h")),
              24 * 3600e3,
            );
            wsContract.once(eventName, (...args: unknown[]) => {
              clearTimeout(timer);
              const ev = args[args.length - 1] as { transactionHash?: string };
              void this.log("success", `Caught event ${eventName} in tx ${ev?.transactionHash ?? "?"}`);
              resolve();
            });
            wsContract.once("error", (e: Error) => {
              clearTimeout(timer);
              reject(e);
            });
            // Poll the stopped flag so stop() can break the wait.
            void (async () => {
              while (!this.stopped) await sleep(500);
              clearTimeout(timer);
              resolve();
            })();
          });
        } finally {
          wsProvider.destroy();
        }
      } else {
        throw new Error(
          `Event trigger needs a ws:// RPC URL to subscribe to "${eventName}" — ` +
            "the resolved endpoint is HTTPS. Set a websocket RPC in Settings.",
        );
      }
      return;
    }

    throw new Error(`Unknown trigger mode: ${t.triggerMode}`);
  }

  // ---------- execution (port of minter.js) ----------

  private async liveExecution(provider: ethers.JsonRpcProvider, keys: string[]) {
    const t = this.task;
    const contract = new ethers.Contract(t.contractAddress, GENERIC_ABI, provider);
    const valueWei = ethers.parseEther(t.mintValueEth || "0");
    // MEV protection: only the broadcast is rerouted to the Flashbots
    // Protect private mempool (standard eth_sendRawTransaction, no auth).
    // Reads/polling (nonce, fee data, receipts) stay on the normal RPC.
    const broadcastProvider = this.mevProtectUrl
      ? new ethers.JsonRpcProvider(this.mevProtectUrl, t.chainId)
      : provider;
    if (this.mevProtectUrl) {
      await this.log("info", "MEV protection: private mempool routing (Flashbots Protect)");
    }
    // Mint-phase snapshot at fire time (whitelist/public/closed/unknown);
    // the per-wallet fire loop re-checks it through the 20s cache.
    const phase = await this.getResolvedPhase(provider);
    await this.log(
      "info",
      `mint phase: ${phase}${t.mintPhase && t.mintPhase !== "auto" ? ` (task override: ${t.mintPhase})` : ""}`,
    );
    const results = await Promise.all(
      keys.map((key, i) =>
        this.mintWithWallet(provider, broadcastProvider, contract, key, `w${i}`, valueWei).catch(
          (e: Error) => ({
            ok: false as const,
            reason: "exception",
            error: cleanRpcError(e),
          }),
        ),
      ),
    );
    const ok = results.filter((r) => r.ok).length;
    await this.log(
      ok > 0 ? "success" : "error",
      `Execution finished: ${ok}/${keys.length} wallets succeeded`,
      { results: results.map((r) => ({ ok: r.ok, ...("reason" in r ? { reason: r.reason } : {}) })) },
    );
    const firstOk = results.find((r) => r.ok && "hash" in r) as { hash?: string } | undefined;
    if (ok === 0) throw new Error("All wallet executions failed");
    // Track the minted NFTs as an open position for the sell engine (TP/SL,
    // manual sell). Token ids are unknown here — the sell engine resolves
    // them from the vault's holdings. Best-effort — never break the task.
    try {
      await insertPosition({
        userId: t.userId,
        source: "snipe",
        refId: t.id,
        chainId: t.chainId,
        contractAddress: t.contractAddress,
        tokenId: null,
        qty: Math.max(1, ok),
        entryEth: entryEth10(t.mintValueEth || "0"),
      });
    } catch (err) {
      console.warn(`[mint#${t.id}] failed to record position:`, err);
    }
    return firstOk?.hash ?? null;
  }

  private async mintWithWallet(
    provider: ethers.JsonRpcProvider,
    broadcastProvider: ethers.JsonRpcProvider,
    contract: ethers.Contract,
    privateKey: string,
    label: string,
    valueWei: bigint,
  ): Promise<{ ok: boolean; reason?: string; hash?: string; error?: string }> {
    const t = this.task;
    // The wallet signs + broadcasts via the (possibly MEV-protected)
    // broadcast provider; nonce reads stay on the normal RPC.
    const wallet = new ethers.Wallet(privateKey, broadcastProvider);
    const to = t.contractAddress;
    const baseArgs = (t.mintArgs as unknown[]) ?? [];
    // Whitelist minting: this wallet's merkle proof (if the task carries one).
    const proofs = (t.merkleProofs as Record<string, string[]> | null) ?? null;
    const proof = proofs?.[wallet.address.toLowerCase()] ?? null;
    let proofAnnounced = false;
    const nonce = await provider.getTransactionCount(wallet.address, "pending");
    await this.log(
      "info",
      `[${label}] nonce=${nonce} value=${ethers.formatEther(valueWei)} ETH gasLimit=${t.gasLimit}`,
    );

    let maxFee = gweiToWei(t.startMaxFeeGwei);
    let priority = gweiToWei(t.startPriorityGwei);
    const bump = gweiToWei(t.gasBumpGwei);
    const ceiling = gweiToWei(t.maxMaxFeeGwei);

    for (let attempt = 1; attempt <= t.maxRetries; attempt++) {
      if (this.stopped) return { ok: false, reason: "stopped" };
      if (maxFee > ceiling) {
        await this.log("warn", `[${label}] fee ceiling ${fmtGwei(ceiling)} reached, aborting`);
        return { ok: false, reason: "fee-ceiling" };
      }

      // Gas guard: when the network is pricier than the effective cap,
      // skip this attempt and keep polling — do NOT fail the task, gas
      // may drop. Doesn't consume an attempt (attempt-- before continue).
      if (!(await this.gasAllowsBroadcast(provider, label))) {
        if (!(await this.wait(GAS_RECHECK_MS))) return { ok: false, reason: "stopped" };
        attempt--;
        continue;
      }

      // Phase gate: closed holds fire (the mint may go live any second);
      // whitelist without a proof for this wallet skips it outright.
      const gate = await this.phaseGate(provider, label, wallet.address, proof !== null);
      if (gate.verdict === "skip") return { ok: false, reason: "no-merkle-proof" };
      if (gate.verdict === "hold") {
        if (!(await this.wait(GAS_RECHECK_MS))) return { ok: false, reason: "stopped" };
        attempt--;
        continue;
      }

      // Merkle-proof injection: appended as the final mint arg, or swapped
      // into a "$proof" placeholder element when the user pinned its position.
      const args = gate.phase === "whitelist" && proof ? injectProofArgs(baseArgs, proof) : baseArgs;
      let data: string;
      try {
        data = contract.interface.encodeFunctionData(t.mintFunction, args);
      } catch (encErr) {
        const msg = cleanRpcError(encErr);
        await this.log("error", `[${label}] cannot encode ${t.mintFunction} args: ${msg}`);
        return { ok: false, reason: "encode-failed", error: msg };
      }
      if (gate.phase === "whitelist" && proof && !proofAnnounced) {
        proofAnnounced = true;
        await this.log("info", `[${label}] firing whitelist mint with merkle proof (phase: whitelist)`);
      }

      // Pre-flight simulation (eth_call): the exact tx — same calldata incl.
      // injected proof, same value, same from. A revert holds fire with the
      // gas guard's wait-and-retry semantics; infra errors never block.
      if (t.simulateFirst) {
        const sim = await simulateMint(provider, {
          from: wallet.address,
          contractAddress: to,
          data,
          valueWei,
        });
        if (!sim.ok && !shouldSendAfterSim(sim)) {
          const now = Date.now();
          if (now - this.lastSimHoldLogAt >= GAS_HOLD_LOG_INTERVAL_MS) {
            this.lastSimHoldLogAt = now;
            await this.log(
              "info",
              `[${label}] pre-flight simulation reverted: ${sim.reason} — holding fire`,
            );
          }
          if (!(await this.wait(GAS_RECHECK_MS))) return { ok: false, reason: "stopped" };
          attempt--;
          continue;
        }
      }

      const txRequest = {
        to,
        data,
        value: valueWei,
        gasLimit: BigInt(t.gasLimit),
        nonce,
        maxFeePerGas: maxFee,
        maxPriorityFeePerGas: priority,
        chainId: t.chainId,
        type: 2,
      };

      try {
        const tx = await wallet.sendTransaction(txRequest);
        await this.log("info", `[${label}] attempt ${attempt}: submitted ${tx.hash} (maxFee=${fmtGwei(maxFee)})`);

        try {
          const receipt = await tx.wait(1, RECEIPT_TIMEOUT_MS);
          if (receipt && receipt.status === 1) {
            await this.log("success", `[${label}] MINTED in block ${receipt.blockNumber} — ${tx.hash}`, {
              txHash: tx.hash,
            });
            return { ok: true, hash: tx.hash };
          }
          await this.log("error", `[${label}] tx reverted on-chain: ${tx.hash}`);
          return { ok: false, reason: "reverted", hash: tx.hash };
        } catch (waitErr) {
          const receipt = (waitErr as { receipt?: { status: number } }).receipt;
          if (receipt && receipt.status === 1) return { ok: true, hash: tx.hash };
          if (receipt && receipt.status === 0) {
            await this.log("error", `[${label}] tx reverted on-chain: ${tx.hash}`);
            return { ok: false, reason: "reverted", hash: tx.hash };
          }
          await this.log("warn", `[${label}] not mined within timeout, bumping fees and replacing`);
        }
      } catch (sendErr) {
        const msg = (sendErr as Error).message || String(sendErr);
        if (msg.includes("nonce too low")) {
          await this.log("warn", `[${label}] nonce already consumed — a previous tx from this wallet mined`);
          return { ok: false, reason: "nonce-consumed", error: msg };
        }
        if (msg.includes("underpriced")) {
          await this.log("warn", `[${label}] underpriced, bumping fees`);
        } else if (msg.includes("execution reverted") || msg.includes("CALL_EXCEPTION")) {
          await this.log("error", `[${label}] mint call reverted: ${msg}`);
          return { ok: false, reason: "call-reverted", error: msg };
        } else {
          await this.log("warn", `[${label}] send error (${msg}), bumping and retrying`);
        }
      }

      maxFee += bump;
      priority += bump;
      if (maxFee > ceiling) {
        await this.log("warn", `[${label}] next fee ${fmtGwei(maxFee)} would exceed ceiling, stopping`);
        return { ok: false, reason: "fee-ceiling" };
      }
    }

    return { ok: false, reason: "retries-exhausted" };
  }

  // ---------- main loop ----------

  async run(): Promise<void> {
    const t = this.task;

    // Plan gate at start time: routers gate arming, but the trial can expire
    // while a task sits armed — a free user whose trial ended must not fire
    // transactions. Fail honestly with a clear log.
    try {
      const owner = await findUserById(t.userId);
      const ent = computeEntitlement(owner ?? {});
      if (!canExecute(ent, "snipe")) {
        await updateTask(t.userId, t.id, { status: "failed" });
        await this.log(
          "error",
          "TRIAL_EXPIRED — your 7-day free trial has ended. Upgrade to PRO ($15/mo) from the Upgrade tab to keep sniping.",
        );
        return;
      }
      // Emergency kill switch: refuse to fire while the user has halted all
      // execution. The task is cancelled (not failed) — re-arm after resuming.
      if (await isHalted(t.userId)) {
        await updateTask(t.userId, t.id, { status: "cancelled" });
        await this.log(
          "warn",
          "EMERGENCY STOP is active — task cancelled without firing. Release the stop (top bar) and re-arm to snipe.",
        );
        return;
      }
    } catch (err) {
      console.error(`[mint#${t.id}] entitlement check failed:`, err);
    }

    // Live-only: the task owner's managed vault key is the primary signer,
    // BOT_PRIVATE_KEYS env keys remain as extra wallets. Multi-snipe: the
    // task's walletCount caps how many keys fire (free plan is limited to
    // FREE_LIMITS.maxSnipeWallets at the router layer). No key → honest
    // failure, never a fake success.
    const allKeys = await getLiveExecutionKeys(t.userId);
    const keys = allKeys.slice(0, Math.max(1, t.walletCount ?? 1));
    const provider = await this.makeProvider();
    await this.loadExecutionSettings();

    try {
      if (keys.length === 0) {
        await updateTask(t.userId, t.id, { status: "failed" });
        await this.log(
          "error",
          "No execution wallet — create/fund your bot vault (Wallets tab) before starting a task",
        );
        return;
      }
      if (!provider) {
        await updateTask(t.userId, t.id, { status: "failed" });
        await this.log(
          "error",
          "No RPC endpoint available for this chain — set a custom RPC in Settings or enable auto-select",
        );
        return;
      }

      await updateTask(t.userId, t.id, { status: "firing" });
      await this.log(
        "info",
        `Engine started | mode=live trigger=${t.triggerMode} target=${t.contractAddress} wallets=${keys.length}`,
      );
      if (this.resolvedRpc) {
        await this.log(
          "info",
          `RPC endpoint: ${this.resolvedRpc.url} (${this.resolvedRpc.source})`,
        );
      }

      await this.waitForTrigger(provider);
      if (this.stopped) {
        await updateTask(t.userId, t.id, { status: "cancelled" });
        await this.log("warn", "Engine stopped during trigger wait — task cancelled");
        return;
      }
      await this.log("info", "TRIGGER FIRED — executing mints");

      const txHash = await this.liveExecution(provider, keys);
      if (this.stopped) {
        await updateTask(t.userId, t.id, { status: "cancelled" });
        return;
      }

      await updateTask(t.userId, t.id, { status: "done" });
      const explorer = txHash ? explorerTxUrl(t.chainId, txHash) : null;
      await this.log(
        "success",
        `Task "${t.name}" done${txHash ? ` — tx ${txHash}` : ""}`,
        txHash ? { txHash, ...(explorer ? { explorerUrl: explorer } : {}) } : undefined,
      );
    } catch (err) {
      const msg = cleanRpcError(err);
      console.error(`[mint#${t.id}] engine error:`, msg);
      await updateTask(t.userId, t.id, { status: "failed" }).catch(() => undefined);
      await this.log("error", `Engine failed: ${msg}`);
    }
  }
}
