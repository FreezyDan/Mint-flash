/**
 * Offline tests for the Minting-Now watcher: window bucketing, unique
 * minters, ring-buffer eviction, per-chain contract-cap eviction, trending
 * ranking, and the ABI/eth_call decoders used by enrichment + mint progress.
 */
import { describe, expect, it } from "vitest";
import { ethers } from "ethers";
import {
  computeWindows,
  decodeAbiString,
  decodeAbiUint,
  decodeMintLog,
  MAX_CONTRACTS_PER_CHAIN,
  MAX_EVENTS_PER_CONTRACT,
  MAX_SUPPLY_SELECTORS,
  rankTrending,
  recordContractMint,
  recordMint,
  RETENTION_MS,
  TRANSFER_TOPIC,
  ZERO_ADDRESS_TOPIC,
  type ContractActivity,
  type MintEvent,
} from "./mintWatch";

const NOW = 1_800_000_000_000;
const CONTRACT_A = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const CONTRACT_B = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
const MINTER_1 = "0x1111111111111111111111111111111111111111";
const MINTER_2 = "0x2222222222222222222222222222222222222222";

const ev = (ts: number, minter = MINTER_1): MintEvent => ({ ts, minter });

function activity(chainId: number, contract: string, events: MintEvent[]): ContractActivity {
  return {
    chainId,
    contract,
    events: [...events],
    lastMintTs: events.reduce((m, e) => Math.max(m, e.ts), 0),
  };
}

describe("computeWindows", () => {
  it("buckets mints into 1m / 5m / 15m / 1h windows", () => {
    const events = [
      ev(NOW - 10_000), // 10s ago → all windows
      ev(NOW - 2 * 60_000), // 2m ago → 5m/15m/1h
      ev(NOW - 10 * 60_000), // 10m ago → 15m/1h
      ev(NOW - 45 * 60_000), // 45m ago → 1h only
      ev(NOW - 2 * 60 * 60_000), // 2h ago → outside retention, ignored
    ];
    const w = computeWindows(events, NOW);
    expect(w).toEqual({
      m1: 1,
      m5: 2,
      m15: 3,
      h1: 4,
      uniqueMinters15m: 1,
      lastMintTs: NOW - 10_000,
    });
  });

  it("counts unique minters within the 15m window only", () => {
    const events = [
      ev(NOW - 60_000, MINTER_1),
      ev(NOW - 120_000, MINTER_1), // same minter again
      ev(NOW - 180_000, MINTER_2),
      ev(NOW - 30 * 60_000, "0x3333333333333333333333333333333333333333"), // 30m ago — outside 15m
    ];
    const w = computeWindows(events, NOW);
    expect(w.m15).toBe(3);
    expect(w.uniqueMinters15m).toBe(2);
    expect(w.h1).toBe(4);
  });

  it("returns zeros and lastMintTs 0 for an empty buffer", () => {
    expect(computeWindows([], NOW)).toEqual({
      m1: 0,
      m5: 0,
      m15: 0,
      h1: 0,
      uniqueMinters15m: 0,
      lastMintTs: 0,
    });
  });
});

describe("recordMint ring buffer", () => {
  it("evicts events older than the 1h retention window", () => {
    const a = activity(1, CONTRACT_A, [
      ev(NOW - 3 * 60 * 60_000), // 3h old — evicted on next record
      ev(NOW - 30 * 60_000),
    ]);
    recordMint(a, ev(NOW));
    expect(a.events).toHaveLength(2);
    expect(a.events[0].ts).toBe(NOW - 30 * 60_000);
    expect(a.lastMintTs).toBe(NOW);
  });

  it(`caps the buffer at ${MAX_EVENTS_PER_CONTRACT} events (drops oldest)`, () => {
    const a = activity(1, CONTRACT_A, []);
    for (let i = 0; i < MAX_EVENTS_PER_CONTRACT + 25; i += 1) {
      recordMint(a, ev(NOW - (MAX_EVENTS_PER_CONTRACT + 25 - i) * 1000));
    }
    expect(a.events).toHaveLength(MAX_EVENTS_PER_CONTRACT);
    // Newest event is the last one recorded.
    expect(a.events.at(-1)!.ts).toBe(NOW - 1000);
  });
});

describe("recordContractMint contract cap", () => {
  it("evicts the contract with the oldest lastMintTs when the chain map is full", () => {
    const map = new Map<string, ContractActivity>();
    for (let i = 0; i < MAX_CONTRACTS_PER_CHAIN; i += 1) {
      const contract = `0x${i.toString(16).padStart(40, "0")}`;
      recordContractMint(map, 1, contract, ev(NOW - (MAX_CONTRACTS_PER_CHAIN - i) * 60_000));
    }
    expect(map.size).toBe(MAX_CONTRACTS_PER_CHAIN);
    const stalest = `0x${(0).toString(16).padStart(40, "0")}`;
    expect(map.has(stalest)).toBe(true);

    recordContractMint(map, 1, CONTRACT_A, ev(NOW));
    expect(map.size).toBe(MAX_CONTRACTS_PER_CHAIN);
    expect(map.has(CONTRACT_A)).toBe(true);
    expect(map.has(stalest)).toBe(false); // oldest lastMintTs evicted
  });
});

describe("rankTrending", () => {
  it("sorts by 15m mints desc and tiebreaks on 5m mints", () => {
    const low = activity(1, CONTRACT_A, [ev(NOW - 14 * 60_000)]); // m15=1, m5=0
    const tieOlder = activity(1, CONTRACT_B, [
      ev(NOW - 14 * 60_000),
      ev(NOW - 10 * 60_000),
    ]); // m15=2, m5=0
    const tieHotter = activity(8453, CONTRACT_A, [
      ev(NOW - 14 * 60_000),
      ev(NOW - 60_000),
    ]); // m15=2, m5=1 → wins the tiebreak

    const ranked = rankTrending([low, tieHotter, tieOlder], NOW);
    expect(ranked.map((r) => r.chainId)).toEqual([8453, 1, 1]);
    expect(ranked[0].contract).toBe(CONTRACT_A);
    expect(ranked[0].m15).toBe(2);
    expect(ranked[0].m5).toBe(1);
    expect(ranked[2].m15).toBe(1);
  });

  it("excludes contracts with no mints inside the retention window", () => {
    const stale = activity(1, CONTRACT_A, [ev(NOW - RETENTION_MS - 1)]);
    const fresh = activity(1, CONTRACT_B, [ev(NOW - 30_000)]);
    const ranked = rankTrending([stale, fresh], NOW);
    expect(ranked).toHaveLength(1);
    expect(ranked[0].contract).toBe(CONTRACT_B);
  });

  it("leaves enrichment metadata null (snapshot accessor overlays it)", () => {
    const ranked = rankTrending([activity(1, CONTRACT_A, [ev(NOW - 5_000)])], NOW);
    expect(ranked[0]).toMatchObject({ name: null, symbol: null, totalSupply: null });
  });
});

describe("decodeMintLog", () => {
  const topic = (addr: string) => ethers.zeroPadValue(addr, 32);

  it("decodes a Transfer-from-zero mint (minter from topics[2])", () => {
    const mint = decodeMintLog({
      address: CONTRACT_A.toUpperCase().replace("0X", "0x"),
      topics: [TRANSFER_TOPIC, ZERO_ADDRESS_TOPIC, topic(MINTER_1), ethers.toBeHex(5, 32)],
    });
    expect(mint).toEqual({ contract: CONTRACT_A, minter: MINTER_1 });
  });

  it("rejects non-mint transfers and malformed logs", () => {
    expect(
      decodeMintLog({
        address: CONTRACT_A,
        topics: [TRANSFER_TOPIC, topic(MINTER_1), topic(MINTER_2), ethers.toBeHex(5, 32)],
      }),
    ).toBeNull();
    expect(decodeMintLog({ address: CONTRACT_A, topics: [TRANSFER_TOPIC] })).toBeNull();
    expect(decodeMintLog({ address: CONTRACT_A, topics: [] })).toBeNull();
  });
});

describe("ABI decoders", () => {
  const coder = ethers.AbiCoder.defaultAbiCoder();

  it("decodes a standard dynamic-string return (name()/symbol())", () => {
    const hex = coder.encode(["string"], ["Degen Apes S2"]);
    expect(decodeAbiString(hex)).toBe("Degen Apes S2");
  });

  it("decodes a legacy bytes32 string return", () => {
    const hex = ethers.encodeBytes32String("BAYC");
    expect(decodeAbiString(hex)).toBe("BAYC");
  });

  it("returns null for reverts / empty / garbage", () => {
    expect(decodeAbiString("0x")).toBeNull();
    expect(decodeAbiString("0x1234")).toBeNull();
    expect(decodeAbiString(`0x${"ff".repeat(64)}`)).toBeNull();
    expect(decodeAbiUint("0x")).toBeNull();
    expect(decodeAbiUint("0x1234")).toBeNull();
  });

  it("decodes uint256 totals and rejects values beyond safe integers", () => {
    expect(decodeAbiUint(coder.encode(["uint256"], [10_000n]))).toBe(10_000);
    expect(decodeAbiUint(coder.encode(["uint256"], [2n ** 60n]))).toBeNull();
  });
});

describe("max-supply selectors", () => {
  it("covers the four getter candidates in order", () => {
    expect(MAX_SUPPLY_SELECTORS).toHaveLength(4);
    expect(MAX_SUPPLY_SELECTORS[0]).toBe(ethers.id("maxSupply()").slice(0, 10));
    expect(MAX_SUPPLY_SELECTORS[1]).toBe(ethers.id("MAX_SUPPLY()").slice(0, 10));
    expect(MAX_SUPPLY_SELECTORS[2]).toBe(ethers.id("maxTokens()").slice(0, 10));
    expect(MAX_SUPPLY_SELECTORS[3]).toBe(ethers.id("collectionSize()").slice(0, 10));
  });
});
