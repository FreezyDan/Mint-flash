/**
 * Offline tests for the contract safety guard: pure helpers on fixture
 * bytecode plus guardContract behavior with a stubbed fetch (EOA, tiny
 * bytecode, selector hit/miss, transport failure).
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import { ethers } from "ethers";
import {
  MIN_BYTECODE_BYTES,
  MINT_SELECTORS,
  bytecodeBytes,
  detectProxy,
  findMintSelectors,
  guardContract,
  hasBytecode,
} from "./contractGuard";

const ADDR = "0x3333333333333333333333333333333333333333";
const RPC = "https://rpc.example.test";

const EIP1967_LOGIC_SLOT =
  "360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc";
const EIP1967_BEACON_SLOT =
  "a3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50";

/** Fixture bytecode of exactly `bytes` runtime bytes (hex, no 0x). */
const fixtureCode = (bytes: number) => "60".repeat(bytes);
/** Realistic ERC-721-ish bytecode with the mint(address,uint256) selector. */
const ERC721_CODE = `0x60806040${"52".repeat(600)}40c10f19${"00".repeat(400)}`;

/** Stub global fetch to answer eth_getCode with the given bytecode. */
function stubRpc(bytecode: string) {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => ({
      ok: true,
      json: async () => ({ jsonrpc: "2.0", id: 1, result: bytecode }),
    })),
  );
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("selector constants", () => {
  it("match the spec'd 4-byte selectors", () => {
    expect(MINT_SELECTORS["40c10f19"]).toBe("mint(address,uint256)");
    expect(MINT_SELECTORS["a0712d68"]).toBe("mint(uint256)");
    expect(MINT_SELECTORS["6a627842"]).toBe("mint(address)");
    expect(MINT_SELECTORS["a1448194"]).toBe("safeMint(address)");
    expect(MINT_SELECTORS[ethers.id("publicMint(uint256)").slice(2, 10)]).toBe(
      "publicMint(uint256)",
    );
  });
});

describe("pure bytecode helpers", () => {
  it("hasBytecode/bytecodeBytes handle EOA and real code", () => {
    expect(hasBytecode("")).toBe(false);
    expect(hasBytecode("0x")).toBe(false);
    expect(hasBytecode("0x6000")).toBe(true);
    expect(bytecodeBytes("0x")).toBe(0);
    expect(bytecodeBytes("0x600052")).toBe(3);
  });

  it("detectProxy flags EIP-1967 slot patterns (logic + beacon)", () => {
    expect(detectProxy(`0x6080${EIP1967_LOGIC_SLOT}601d`)).toBe(true);
    expect(detectProxy(`0x6080${EIP1967_BEACON_SLOT}601d`)).toBe(true);
    expect(detectProxy(`0x6080${EIP1967_LOGIC_SLOT.toUpperCase()}601D`)).toBe(true);
    expect(detectProxy(ERC721_CODE)).toBe(false);
    expect(detectProxy("0x")).toBe(false);
  });

  it("findMintSelectors hits and misses", () => {
    expect(findMintSelectors(ERC721_CODE)).toEqual(["mint(address,uint256)"]);
    const publicMint = `0x6080${"52".repeat(300)}${ethers.id("publicMint(uint256)").slice(2, 10)}`;
    expect(findMintSelectors(publicMint)).toEqual(["publicMint(uint256)"]);
    expect(findMintSelectors(`0x${fixtureCode(500)}`)).toEqual([]);
    expect(findMintSelectors("0x")).toEqual([]);
  });
});

describe("guardContract", () => {
  it("EOA (empty bytecode) → danger 'not a contract', no other checks", async () => {
    stubRpc("0x");
    const report = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(report.level).toBe("danger");
    expect(report.checks).toHaveLength(1);
    expect(report.checks[0].name).toBe("bytecode");
    expect(report.checks[0].detail).toMatch(/not a contract/);
  });

  it("tiny bytecode → danger 'suspiciously small bytecode'", async () => {
    stubRpc(`0x${fixtureCode(MIN_BYTECODE_BYTES - 1)}`);
    const report = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(report.level).toBe("danger");
    const sizeCheck = report.checks.find((c) => c.name === "bytecode-size");
    expect(sizeCheck?.level).toBe("danger");
    expect(sizeCheck?.detail).toMatch(/suspiciously small bytecode/);
  });

  it("proxy bytecode → warn 'upgradeable proxy'", async () => {
    stubRpc(`0x${"60".repeat(300)}${EIP1967_LOGIC_SLOT}${"40c10f19"}`);
    const report = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(report.level).toBe("warn");
    const proxyCheck = report.checks.find((c) => c.name === "proxy");
    expect(proxyCheck?.level).toBe("warn");
    expect(proxyCheck?.detail).toMatch(/upgradeable proxy/);
  });

  it("no standard mint selector → warn; selector present → ok overall", async () => {
    stubRpc(`0x${fixtureCode(500)}`);
    const miss = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(miss.level).toBe("warn");
    expect(miss.checks.find((c) => c.name === "mint-selector")?.detail).toMatch(
      /no standard mint selector/,
    );

    stubRpc(ERC721_CODE);
    const hit = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(hit.level).toBe("ok");
    expect(hit.checks.find((c) => c.name === "mint-selector")?.detail).toMatch(
      /mint\(address,uint256\)/,
    );
  });

  it("transport failure NEVER throws — yields a warn-level report", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        throw new Error("network down");
      }),
    );
    const report = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(report.level).toBe("warn");
    expect(report.checks[0].detail).toMatch(/guard unavailable/);
  });

  it("RPC JSON error → warn-level report, not a throw", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: true,
        json: async () => ({ jsonrpc: "2.0", id: 1, error: { message: "rate limited" } }),
      })),
    );
    const report = await guardContract({ chainId: 1, contractAddress: ADDR, rpcUrl: RPC });
    expect(report.level).toBe("warn");
    expect(report.checks[0].detail).toMatch(/rate limited/);
  });
});
