import { ethers } from "ethers";
import type { BotPosition, WatchedWallet } from "@db/schema";
import { explorerTxUrl } from "@contracts/rpc";
import { logActivity } from "../queries/activity";
import { findUserById } from "../queries/users";
import { findEnabledWatchedWallets } from "../queries/copy";
import {
  findOpenCopyPositionsIn,
  findOpenPositionsByUser,
  findUsersWithOpenPositions,
  updatePosition,
} from "../queries/positions";
import { canExecute, computeEntitlement, type ExecutableFeature } from "../lib/entitlements";
import { isHalted } from "../lib/halt";
import { cleanRpcError, ErrorThrottle } from "../lib/rpcError";
import { resolveOpenseaKey } from "../lib/openseaKey";
import { getManagedPrivateKey } from "./managedWallet";
import { resolveRpcForUser } from "./rpcManager";
import {
  getBestOffer,
  getOwnedTokenId,
  getSellCalldata,
  openseaChainIdFromSlug,
  openseaFetch,
} from "./opensea";

/**
 * Sell-side engine — the exit half of the trading loop (GMGN/BullX parity).
 *
 * Every NFT the bot acquires is tracked as a bot_positions row (source
 * 'snipe' | 'copy' | 'sweep'). This engine sells them into the best OpenSea
 * collection offer (fulfilling a Seaport bid is a plain on-chain tx — no
 * order signing needed) when:
 *  a) take-profit / stop-loss triggers vs the live best offer,
 *  b) a copied wallet sells the same collection (mirror sell),
 *  c) the user hits "Sell now" (manual — same executeSell path).
 *
 * Exit semantics (evaluateExit):
 *  - take_profit: bestOffer ≥ entry × (1 + tpPct/100)
 *  - stop_loss:   bestOffer ≤ entry × (1 − slPct/100)
 *  - entry null → null (can't compute a % return — position is skipped
 *    silently; manual + mirror sells still work).
 *
 * Offers go stale fast, so the best offer is re-fetched immediately before
 * building fulfillment calldata. Approvals: the vault must approve the
 * OpenSea conduit (0x1E0049783F008A0085193E00003D00cd54003c71) once per
 * contract — remembered in-process; the order's protocolAddress is checked
 * as a fallback operator. Failures (no offers, revert, RPC) log an error and
 * leave the position OPEN so the next cycle retries.
 *
 * Plan enforcement mirrors the buy engines: copy/sweep-sourced exits are
 * PRO-only (free users get one throttled info log per hour); snipe exits
 * are allowed while the 7-day trial is live.
 */

const TICK_MS = 75_000;
const RECEIPT_WAIT_MS = 60_000;
const MAX_GROUPS_PER_CYCLE = 20;
const MAX_SELLS_PER_CYCLE = 5;
const MAX_WALLETS_PER_CYCLE = 15;
const EVENTS_LIMIT = 10;
/** Min interval between "PRO plan required — exits paused" logs per user. */
const PLAN_PAUSED_LOG_INTERVAL_MS = 60 * 60_000;

/** OpenSea's canonical Seaport conduit — the approval operator for sales. */
export const OPENSEA_CONDUIT = "0x1E0049783F008A0085193E00003D00cd54003c71";

const ERC721_ABI = [
  "function isApprovedForAll(address owner, address operator) view returns (bool)",
  "function setApprovalForAll(address operator, bool approved)",
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const rand = (min: number, max: number) => min + Math.random() * (max - min);

/** Contracts the vault already approved this process (never re-send). */
const approvedContracts = new Set<string>();

/**
 * Per-(position, cleaned message) throttle for sell-failure logs: a failing
 * position retries every cycle — the same error logs at most once per 15 min.
 */
const sellErrorThrottle = new ErrorThrottle();

export type SellReason = "take_profit" | "stop_loss" | "mirror_sell" | "manual";

export type SellResult =
  | { ok: true; txHash: string; sellEth: string }
  | { ok: false; error: string };

/**
 * Pure TP/SL evaluation against the current best offer. Exported for
 * offline unit testing.
 */
export function evaluateExit(
  position: { entryEth: string | null; tpPct: number | null; slPct: number | null },
  bestOfferEth: number,
): "take_profit" | "stop_loss" | null {
  if (position.entryEth === null || position.entryEth === undefined) return null;
  const entry = Number(position.entryEth);
  if (!Number.isFinite(entry) || entry <= 0) return null;
  if (position.tpPct !== null && position.tpPct !== undefined) {
    if (bestOfferEth >= entry * (1 + position.tpPct / 100)) return "take_profit";
  }
  if (position.slPct !== null && position.slPct !== undefined) {
    if (bestOfferEth <= entry * (1 - position.slPct / 100)) return "stop_loss";
  }
  return null;
}

/** Subtract decimal ETH strings with fixed 10dp (schema scale). */
function subEth(a: string, b: string): string {
  return (Number(a) - Number(b)).toFixed(10);
}

function positionLabel(position: BotPosition): string {
  return `${position.contractAddress.slice(0, 6)}…${position.contractAddress.slice(-4)}${
    position.tokenId ? ` #${position.tokenId}` : ""
  }`;
}

/**
 * Sell one open position into the best OpenSea collection offer.
 * Self-contained (resolves vault key + RPC itself) so routers can call it
 * outside the engine loop. On failure the position stays open.
 */
export async function executeSell(ctx: {
  userId: number;
  position: BotPosition;
  apiKey: string;
  reason: SellReason;
}): Promise<SellResult> {
  const { userId, position, apiKey, reason } = ctx;
  const label = positionLabel(position);

  try {
    if (position.status !== "open") {
      return { ok: false, error: `position ${position.id} is not open` };
    }

    // 1. Signer: the user's managed vault key (server-side only, never logged).
    const privateKey = await getManagedPrivateKey(userId);
    if (!privateKey) {
      await logActivity({
        userId,
        level: "warn",
        source: "sweep",
        message: `Sell skipped for ${label}: no managed vault key — check the Wallets tab`,
      });
      return { ok: false, error: "no managed vault key" };
    }
    const wallet = new ethers.Wallet(privateKey);

    // 2. Token id: recorded at buy time, else look up what the vault holds.
    let tokenId = position.tokenId;
    if (!tokenId) {
      tokenId = await getOwnedTokenId(
        position.chainId,
        position.contractAddress,
        wallet.address,
        apiKey,
      );
    }
    if (!tokenId) {
      // Nothing to sell — the vault holds no token in this collection.
      await updatePosition(userId, position.id, { status: "closed" });
      await logActivity({
        userId,
        level: "warn",
        source: "sweep",
        message: `Position ${label} closed: no owned token found in the vault`,
      });
      return { ok: false, error: "no owned token found" };
    }

    // 3. Offer staleness: re-fetch the best offer immediately before calldata.
    const offer = await getBestOffer(position.chainId, position.contractAddress, apiKey);
    if (!offer) {
      throw new Error("no active offers for this collection");
    }

    // 4. Approval: the vault must approve the OpenSea conduit once per
    // contract (in-process memory). The order's protocol address is checked
    // as a fallback operator in case fulfillment routes through it directly.
    const rpc = await resolveRpcForUser(userId, position.chainId);
    const provider = new ethers.JsonRpcProvider(rpc.url, position.chainId);
    const signer = wallet.connect(provider);
    const nft = new ethers.Contract(position.contractAddress, ERC721_ABI, provider);

    const approvalKey =
      `${position.chainId}:${position.contractAddress.toLowerCase()}:${wallet.address.toLowerCase()}`;
    if (!approvedContracts.has(approvalKey)) {
      // Approval operator: OpenSea's canonical conduit where it is actually
      // deployed; otherwise the Seaport protocol address itself. Arc launched
      // without the conduit (eth_getCode → 0x, verified 2026-09-17) so its
      // orders use conduitKey 0 — operator = Seaport 1.6. Probing on-chain
      // keeps this correct for any future chain with the same layout.
      const conduitCode = await provider.getCode(OPENSEA_CONDUIT).catch(() => "0x");
      const operator =
        conduitCode && conduitCode !== "0x" ? OPENSEA_CONDUIT : offer.protocolAddress;
      const approved = await (nft.isApprovedForAll(wallet.address, operator) as Promise<boolean>).catch(
        () => false,
      );
      if (!approved) {
        const approvalTx = await signer.sendTransaction({
          to: position.contractAddress,
          data: nft.interface.encodeFunctionData("setApprovalForAll", [
            operator,
            true,
          ]),
        });
        const approvalReceipt = await approvalTx.wait(1, RECEIPT_WAIT_MS);
        if (!approvalReceipt || approvalReceipt.status !== 1) {
          throw new Error(`setApprovalForAll tx ${approvalTx.hash} reverted`);
        }
        await logActivity({
          userId,
          level: "info",
          source: "sweep",
          message: `Approved ${operator === OPENSEA_CONDUIT ? "OpenSea conduit" : "Seaport protocol"} for ${label} — tx ${approvalTx.hash}`,
        });
      }
      approvedContracts.add(approvalKey);
    }

    // 5. Fulfillment calldata (criteria offers need the exact token id).
    const calldata = await getSellCalldata(
      position.chainId,
      offer.orderHash,
      offer.protocolAddress,
      wallet.address,
      apiKey,
      tokenId,
      position.contractAddress,
    );
    if (!calldata) {
      throw new Error("OpenSea returned no executable sell path");
    }

    const fee = await provider.getFeeData();
    const tx = await signer.sendTransaction({
      to: calldata.to,
      data: calldata.data,
      value: BigInt(calldata.value),
      ...(fee.maxFeePerGas ? { maxFeePerGas: fee.maxFeePerGas } : {}),
      ...(fee.maxPriorityFeePerGas
        ? { maxPriorityFeePerGas: fee.maxPriorityFeePerGas }
        : {}),
    });
    const receipt = await tx.wait(1, RECEIPT_WAIT_MS);
    if (!receipt || receipt.status !== 1) {
      throw new Error(`sell tx ${tx.hash} reverted`);
    }

    // 6. Record the exit: realized PnL = proceeds − entry (null entry → null).
    const realizedPnlEth = position.entryEth !== null
      ? subEth(offer.priceEth, position.entryEth)
      : null;
    await updatePosition(userId, position.id, {
      status: "sold",
      sellReason: reason,
      sellTxHash: tx.hash,
      sellEth: offer.priceEth,
      realizedPnlEth,
      soldAt: new Date(),
    });

    const explorer = explorerTxUrl(position.chainId, tx.hash);
    await logActivity({
      userId,
      level: "success",
      source: "sweep",
      message:
        `Sold ${label} @ ${offer.priceEth} ETH (${reason})` +
        `${realizedPnlEth !== null ? ` — PnL ${realizedPnlEth} ETH` : ""} — tx ${tx.hash}`,
      meta: {
        positionId: position.id,
        reason,
        txHash: tx.hash,
        sellEth: offer.priceEth,
        realizedPnlEth,
        live: true,
        ...(explorer ? { explorerUrl: explorer } : {}),
      },
    });
    // Successful sell — reset any throttled error keys for this position.
    sellErrorThrottle.clearPrefix(`${position.id}:`);
    return { ok: true, txHash: tx.hash, sellEth: offer.priceEth };
  } catch (err) {
    const msg = cleanRpcError(err);
    if (sellErrorThrottle.shouldLog(`${position.id}:${msg}`)) {
      await logActivity({
        userId,
        level: "error",
        source: "sweep",
        message: `Sell failed for ${label} (${reason}): ${msg} — will retry next cycle`,
      });
    }
    return { ok: false, error: msg };
  }
}

/* ---------------------------------------------------------------------- */
/* Mirror-sell event parsing (v2 account events)                           */
/* ---------------------------------------------------------------------- */

type SaleEvent = {
  key: string;
  chainId: number;
  contract: string;
  seller: string;
  collection: string | null;
};

/** Parse one raw v2 asset_event into the bits mirror-sell needs. */
function parseMirrorSaleEvent(raw: unknown): SaleEvent | null {
  const ev = raw as Record<string, unknown> | null;
  if (!ev || ev.event_type !== "sale") return null;
  const chainId = typeof ev.chain === "string" ? openseaChainIdFromSlug(ev.chain) : null;
  const nft = ev.nft as Record<string, unknown> | undefined;
  const contract = typeof nft?.contract === "string" ? nft.contract.toLowerCase() : null;
  const seller = typeof ev.seller === "string" ? ev.seller.toLowerCase() : "";
  if (chainId === null || !contract || !seller) return null;
  const orderHash = typeof ev.order_hash === "string" ? ev.order_hash : null;
  const txHash = typeof ev.transaction === "string" ? ev.transaction : null;
  const tokenId =
    nft?.identifier !== undefined && nft?.identifier !== null ? String(nft.identifier) : "?";
  const key =
    orderHash ??
    txHash ??
    `${chainId}:${contract}:${tokenId}:${String(ev.closing_date ?? "")}`;
  return {
    key,
    chainId,
    contract,
    seller,
    collection: typeof nft?.collection === "string" ? nft.collection : null,
  };
}

/* ---------------------------------------------------------------------- */
/* Engine loop                                                             */
/* ---------------------------------------------------------------------- */

export class SellEngine {
  private stopped = false;
  private running = false;
  /** Users paused by plan enforcement: last info-log timestamp (throttled). */
  private planPausedLoggedAt = new Map<number, number>();
  /** Watched wallets seen at least once — first poll seeds history only. */
  private seenWallets = new Set<number>();
  /** Processed sale events: `${walletId}:${eventKey}` (in-memory dedupe). */
  private processedEvents = new Set<string>();

  stop() {
    this.stopped = true;
  }

  async start() {
    if (this.running) return;
    this.running = true;
    this.stopped = false;
    void this.loop();
  }

  private async loop() {
    while (!this.stopped) {
      try {
        await this.tick();
      } catch (err) {
        console.error("[sell] tick error:", err);
      }
      await sleep(TICK_MS);
    }
    this.running = false;
  }

  private async tick() {
    const sellsThisCycle = new Map<number, number>();
    await this.exitPass(sellsThisCycle);
    await this.mirrorSellPass(sellsThisCycle);
  }

  private sellCount(map: Map<number, number>, userId: number): number {
    return map.get(userId) ?? 0;
  }

  private bumpSellCount(map: Map<number, number>, userId: number) {
    map.set(userId, this.sellCount(map, userId) + 1);
  }

  /** Throttled "PRO plan required — exits paused" log, once per user per hour. */
  private async logPlanPaused(userId: number) {
    const last = this.planPausedLoggedAt.get(userId) ?? 0;
    if (Date.now() - last < PLAN_PAUSED_LOG_INTERVAL_MS) return;
    this.planPausedLoggedAt.set(userId, Date.now());
    await logActivity({
      userId,
      level: "info",
      source: "sweep",
      message: "PRO plan required — exits paused (Upgrade tab)",
    });
  }

  private async logHaltPaused(userId: number) {
    const last = this.planPausedLoggedAt.get(userId) ?? 0;
    if (Date.now() - last < PLAN_PAUSED_LOG_INTERVAL_MS) return;
    this.planPausedLoggedAt.set(userId, Date.now());
    await logActivity({
      userId,
      level: "warn",
      source: "sweep",
      message: "EMERGENCY STOP active — exits paused (release it from the top bar)",
    });
  }

  // ---------- TP/SL exit pass ----------

  private async exitPass(sellsThisCycle: Map<number, number>) {
    const userIds = await findUsersWithOpenPositions();
    for (const userId of userIds) {
      try {
        const user = await findUserById(userId);
        const ent = computeEntitlement(user ?? {});

        // Emergency kill switch — no exits (or mirror sells) while halted.
        if (await isHalted(userId)) {
          await this.logHaltPaused(userId);
          continue;
        }

        const positions = await findOpenPositionsByUser(userId);
        // Plan gate by source: snipe exits during trial; copy/sweep PRO-only.
        const allowed: BotPosition[] = [];
        let paused = false;
        for (const p of positions) {
          if (canExecute(ent, p.source as ExecutableFeature)) allowed.push(p);
          else paused = true;
        }
        if (paused) await this.logPlanPaused(userId);
        if (allowed.length === 0) continue;

        const { key: apiKey } = await resolveOpenseaKey(userId);

        // One getBestOffer per (chain, contract) group, capped per cycle.
        const groups = new Map<string, BotPosition[]>();
        for (const p of allowed) {
          const key = `${p.chainId}:${p.contractAddress.toLowerCase()}`;
          const list = groups.get(key) ?? [];
          list.push(p);
          groups.set(key, list);
        }
        let groupsChecked = 0;
        for (const group of groups.values()) {
          if (groupsChecked >= MAX_GROUPS_PER_CYCLE) break;
          if (this.sellCount(sellsThisCycle, userId) >= MAX_SELLS_PER_CYCLE) break;
          groupsChecked++;
          const first = group[0];
          const offer = await getBestOffer(first.chainId, first.contractAddress, apiKey);
          if (!offer) continue;
          const offerEth = Number(offer.priceEth);
          for (const position of group) {
            if (this.sellCount(sellsThisCycle, userId) >= MAX_SELLS_PER_CYCLE) break;
            const trigger = evaluateExit(position, offerEth);
            if (!trigger) continue;
            const result = await executeSell({ userId, position, apiKey, reason: trigger });
            if (result.ok) this.bumpSellCount(sellsThisCycle, userId);
          }
        }
      } catch (err) {
        console.error(`[sell] user ${userId} exit pass error:`, err);
      }
    }
  }

  // ---------- mirror-sell pass ----------

  private async mirrorSellPass(sellsThisCycle: Map<number, number>) {
    let wallets: WatchedWallet[];
    try {
      wallets = await findEnabledWatchedWallets();
    } catch (err) {
      console.error("[sell] failed to load watched wallets:", err);
      return;
    }

    // Only PRO users mirror exits; group wallets by owner and gate once.
    const byUser = new Map<number, WatchedWallet[]>();
    for (const w of wallets) {
      const list = byUser.get(w.userId) ?? [];
      list.push(w);
      byUser.set(w.userId, list);
    }

    let checked = 0;
    for (const [userId, userWallets] of byUser) {
      if (checked >= MAX_WALLETS_PER_CYCLE) break;
      try {
        const user = await findUserById(userId);
        const ent = computeEntitlement(user ?? {});
        if (!canExecute(ent, "copy")) continue;
        if (await isHalted(userId)) continue; // emergency stop
        const { key: apiKey } = await resolveOpenseaKey(userId);

        for (const wallet of userWallets) {
          if (checked >= MAX_WALLETS_PER_CYCLE) break;
          checked++;
          await this.checkWalletSales(userId, wallet, apiKey, sellsThisCycle);
          if (checked < MAX_WALLETS_PER_CYCLE) await sleep(rand(1_000, 2_500));
        }
      } catch (err) {
        console.error(`[sell] user ${userId} mirror pass error:`, err);
      }
    }
  }

  /**
   * Poll one watched wallet's recent sales. On the very first sight of a
   * wallet the returned events are marked processed WITHOUT selling — the
   * bot never replays history that predates it.
   */
  private async checkWalletSales(
    userId: number,
    wallet: WatchedWallet,
    apiKey: string,
    sellsThisCycle: Map<number, number>,
  ) {
    const body = (await openseaFetch(
      `/v2/events/accounts/${encodeURIComponent(wallet.address)}` +
        `?event_type=sale&limit=${EVENTS_LIMIT}`,
      apiKey,
    )) as { asset_events?: unknown[] };
    const events = (body.asset_events ?? [])
      .map(parseMirrorSaleEvent)
      .filter((e): e is SaleEvent => e !== null);

    if (!this.seenWallets.has(wallet.id)) {
      this.seenWallets.add(wallet.id);
      for (const e of events) this.processedEvents.add(`${wallet.id}:${e.key}`);
      return;
    }

    const target = wallet.address.toLowerCase();
    for (const event of events) {
      const dedupeKey = `${wallet.id}:${event.key}`;
      if (this.processedEvents.has(dedupeKey)) continue;
      this.processedEvents.add(dedupeKey);
      if (event.seller !== target) continue;
      if (this.sellCount(sellsThisCycle, userId) >= MAX_SELLS_PER_CYCLE) break;

      // The copied wallet sold this collection — exit matching copy positions.
      const matches = await findOpenCopyPositionsIn(userId, [
        { chainId: event.chainId, contractAddress: event.contract },
      ]);
      if (matches.length === 0) continue;

      await logActivity({
        userId,
        level: "info",
        source: "copy",
        message:
          `mirrored exit: ${wallet.label} sold ${event.collection ?? event.contract}` +
          ` — exiting ${matches.length} copied position(s)`,
      });
      for (const position of matches) {
        if (this.sellCount(sellsThisCycle, userId) >= MAX_SELLS_PER_CYCLE) break;
        const result = await executeSell({
          userId,
          position,
          apiKey,
          reason: "mirror_sell",
        });
        if (result.ok) this.bumpSellCount(sellsThisCycle, userId);
      }
    }
  }
}
