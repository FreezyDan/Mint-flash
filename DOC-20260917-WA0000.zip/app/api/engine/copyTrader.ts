import { ethers } from "ethers";
import type { UserSettings, WatchedWallet } from "@db/schema";
import type { Chain } from "@contracts/bot";
import { ChainKeyToId, explorerTxUrl } from "@contracts/rpc";
import { logActivity } from "../queries/activity";
import {
  findEnabledWatchedWallets,
  insertSignal,
} from "../queries/copy";
import { entryEth10, insertPosition } from "../queries/positions";
import { getOrCreateSettings } from "../queries/settings";
import { findUserById } from "../queries/users";
import { canExecute, computeEntitlement } from "../lib/entitlements";
import { isHalted } from "../lib/halt";
import { cleanRpcError, ErrorThrottle } from "../lib/rpcError";
import { getLiveExecutionKeys } from "./managedWallet";
import { resolveRpcForUser } from "./rpcManager";

/**
 * Copy-trading watcher — live on-chain only.
 *
 * Every ~15–45s (randomized to spread RPC load) each enabled watched wallet
 * is checked against the latest block on its chain: transactions the watched
 * address initiated are classified as mint/buy by value heuristic and
 * recorded as real signals with the actual tx hash. Nothing is fabricated —
 * no blocks involving the wallet, no signals.
 *
 * Signing keys (managed vault + BOT_PRIVATE_KEYS env extras) are resolved per
 * tick so execution-capable users are logged; key material is NEVER logged —
 * only the primary signer address is.
 */

const TICK_MIN_MS = 15_000;
const TICK_MAX_MS = 45_000;
/** Min interval between "PRO plan required" info logs per user. */
const PLAN_PAUSED_LOG_INTERVAL_MS = 60 * 60_000;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function rand(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

export class CopyTrader {
  private stopped = false;
  private running = false;
  private lastSeenBlock = new Map<number, number>();
  private liveKeysLogged = new Set<number>();
  private rpcLogged = new Set<number>();
  /** Per-(wallet, cleaned message) error throttle: 1 log per 15 min. */
  private errorThrottle = new ErrorThrottle();
  /** Users paused by plan enforcement: last info-log timestamp (throttled). */
  private planPausedLoggedAt = new Map<number, number>();

  stop() {
    this.stopped = true;
  }

  async start() {
    if (this.running) return;
    this.running = true;
    this.stopped = false;
    void this.loop();
  }

  private async loop() {
    while (!this.stopped) {
      try {
        await this.tick();
      } catch (err) {
        console.error("[copy] tick error:", err);
      }
      await sleep(rand(TICK_MIN_MS, TICK_MAX_MS));
    }
    this.running = false;
  }

  /**
   * Plan gate: re-check the wallet owner's entitlement every cycle so a
   * downgraded/expired user stops executing. Skips with one throttled info
   * log per user per hour. Returns true when execution may proceed.
   */
  private async assertPlanAllows(userId: number): Promise<boolean> {
    // Emergency kill switch — checked before the plan gate.
    if (await isHalted(userId)) {
      const last = this.planPausedLoggedAt.get(userId) ?? 0;
      if (Date.now() - last >= PLAN_PAUSED_LOG_INTERVAL_MS) {
        this.planPausedLoggedAt.set(userId, Date.now());
        await logActivity({
          userId,
          level: "warn",
          source: "copy",
          message: "EMERGENCY STOP active — copy trading paused (release it from the top bar)",
        });
      }
      return false;
    }
    const user = await findUserById(userId);
    const ent = computeEntitlement(user ?? {});
    if (canExecute(ent, "copy")) return true;
    const last = this.planPausedLoggedAt.get(userId) ?? 0;
    if (Date.now() - last >= PLAN_PAUSED_LOG_INTERVAL_MS) {
      this.planPausedLoggedAt.set(userId, Date.now());
      await logActivity({
        userId,
        level: "info",
        source: "copy",
        message: "PRO plan required — execution paused (Upgrade tab)",
      });
    }
    return false;
  }

  private async tick() {
    const wallets = await findEnabledWatchedWallets();
    for (const wallet of wallets) {
      try {
        if (!(await this.assertPlanAllows(wallet.userId))) continue;
        const settings = await getOrCreateSettings(wallet.userId);
        await this.liveTick(wallet, settings);
        // Successful poll — if this wallet had throttled errors, log one
        // recovery line and reset its throttle keys.
        const recovered = this.errorThrottle.clearPrefix(`${wallet.id}:`);
        if (recovered.cleared > 0) {
          await logActivity({
            userId: wallet.userId,
            level: "info",
            source: "copy",
            message:
              `Copy watcher recovered for ${wallet.label}` +
              ` (${recovered.suppressed} repeat(s) suppressed while failing)`,
          });
        }
      } catch (err) {
        // Clean the raw ethers noise, then throttle: the same error for the
        // same wallet logs at most once per 15 min (repeats are counted).
        const cleaned = cleanRpcError(err);
        console.error(`[copy] wallet ${wallet.id} tick error:`, cleaned);
        if (!this.errorThrottle.shouldLog(`${wallet.id}:${cleaned}`)) continue;
        await logActivity({
          userId: wallet.userId,
          level: "error",
          source: "copy",
          message: `Copy watcher error for ${wallet.label}: ${cleaned}`,
        });
      }
    }
  }

  // ---------- live on-chain detection ----------

  private async liveTick(wallet: WatchedWallet, settings: UserSettings) {
    // Watched wallets carry a chain KEY — map it to the chain id and resolve
    // the endpoint via the smart RPC manager (custom rpcUrl or auto-raced).
    const chainId = ChainKeyToId[wallet.chain as Chain] ?? settings.chainId;
    const rpc = await resolveRpcForUser(wallet.userId, chainId);
    const provider = new ethers.JsonRpcProvider(rpc.url, chainId);
    if (!this.rpcLogged.has(wallet.userId)) {
      this.rpcLogged.add(wallet.userId);
      await logActivity({
        userId: wallet.userId,
        level: "info",
        source: "copy",
        message: `Copy watcher RPC endpoint for chain ${chainId}: ${rpc.url} (${rpc.source})`,
      });
    }

    // Resolve the live execution key set for this user: the managed vault key
    // is the primary signer, BOT_PRIVATE_KEYS env keys are extras. Keys stay
    // server-side and are NEVER logged — only the primary signer address is.
    const execKeys = await getLiveExecutionKeys(wallet.userId);
    if (!this.liveKeysLogged.has(wallet.userId)) {
      this.liveKeysLogged.add(wallet.userId);
      if (execKeys.length > 0) {
        const primary = new ethers.Wallet(execKeys[0]).address;
        await logActivity({
          userId: wallet.userId,
          level: "info",
          source: "copy",
          message:
            `Live copy-trading: ${execKeys.length} signing key(s) loaded, ` +
            `primary execution wallet ${primary}`,
        });
      } else {
        await logActivity({
          userId: wallet.userId,
          level: "warn",
          source: "copy",
          message:
            "No execution wallet — create/fund your bot vault (Wallets tab) to mirror detections on-chain",
        });
      }
    }

    const latest = await provider.getBlockNumber();
    const fromBlock = this.lastSeenBlock.get(wallet.id) ?? latest;
    if (latest <= fromBlock) return;
    // Only inspect the newest block per tick to stay conservative.
    const block = await provider.getBlock(latest, true);
    this.lastSeenBlock.set(wallet.id, latest);
    if (!block) return;

    const target = wallet.address.toLowerCase();
    for (const tx of block.prefetchedTransactions) {
      const involves =
        tx.from.toLowerCase() === target || tx.to?.toLowerCase() === target;
      if (!involves || tx.from.toLowerCase() !== target) continue; // only trades the wallet initiated

      const isMint = tx.value === 0n && tx.to !== null; // heuristic: 0-value contract call
      const type = isMint ? "mint" : "buy";
      if ((type === "mint" && !wallet.copyMints) || (type === "buy" && !wallet.copyBuys)) {
        continue;
      }
      const priceEth = ethers.formatEther(tx.value);

      await insertSignal({
        userId: wallet.userId,
        watchedWalletId: wallet.id,
        type,
        contractAddress: tx.to ?? tx.from,
        collectionName: null,
        priceEth,
        txHash: tx.hash,
        status: "detected",
        pnlEth: null,
      });
      // Track mirrored BUYs as open positions for the sell engine (TP/SL,
      // mirror-sell, manual). Best-effort — never break detection.
      if (type === "buy") {
        try {
          await insertPosition({
            userId: wallet.userId,
            source: "copy",
            refId: wallet.id,
            chainId,
            contractAddress: tx.to ?? tx.from,
            tokenId: null,
            qty: 1,
            entryEth: entryEth10(priceEth),
            // Watched wallets carry no TP/SL settings — the user sets them
            // later from the Positions tab.
            tpPct: null,
            slPct: null,
          });
        } catch (err) {
          console.warn(`[copy] failed to record position for wallet ${wallet.id}:`, err);
        }
      }
      await logActivity({
        userId: wallet.userId,
        level: "info",
        source: "copy",
        message: `Detected ${type} by ${wallet.label} in tx ${tx.hash} (value ${priceEth} ETH)`,
        meta: {
          txHash: tx.hash,
          live: true,
          ...(explorerTxUrl(chainId, tx.hash)
            ? { explorerUrl: explorerTxUrl(chainId, tx.hash) }
            : {}),
        },
      });
    }
  }
}
