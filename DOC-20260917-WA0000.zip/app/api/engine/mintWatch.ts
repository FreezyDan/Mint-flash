/**
 * "Minting Now" watcher — a rolling, in-memory view of live ERC-721 mint
 * activity across all seven supported chains (Icy Tools / Moby parity).
 *
 * Every ~20s per chain (chains staggered to spread RPC load) it scans
 * `Transfer` logs whose topics[1] is the zero address (mints) from the
 * last-seen block to head, using adaptive chunking (≤2000 blocks, halving
 * on RPC errors) over the shared auto-raced public endpoints
 * (`getBestRpc` in rpcManager).
 *
 * Per (chainId, contract) it keeps a 1-hour ring buffer of mint events and
 * derives velocity windows (1m / 5m / 15m / 1h + unique minters in 15m).
 * Collection metadata (name / symbol / totalSupply) is enriched via cheap
 * eth_call reads, cached 10 minutes per contract, reverts tolerated.
 *
 * Memory discipline: at most 500 contracts per chain (oldest lastMintTs
 * evicted first) and 1000 events per contract.
 *
 * Everything is best-effort — the watcher must never crash the server, and
 * snapshot accessors return honest empty data while it warms up.
 */
import { id as keccak } from "ethers";
import { cleanRpcError } from "../lib/rpcError";
import { getBestRpc } from "./rpcManager";

/** ERC-721 Transfer(address,address,uint256) — all indexed. */
export const TRANSFER_TOPIC =
  "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
/** topics[1] (from) of a mint: the zero address, left-padded to 32 bytes. */
export const ZERO_ADDRESS_TOPIC =
  "0x0000000000000000000000000000000000000000000000000000000000000000";

/** All seven chains the watcher covers. */
export const MINT_WATCH_CHAINS = [1, 8453, 42161, 137, 4663, 57073, 5042] as const;

const LOOP_MS = 20_000;
const CHAIN_STAGGER_MS = 3_000;
const RPC_TIMEOUT_MS = 8_000;
const BASE_CHUNK = 2_000;
const MIN_CHUNK = 50;

export const RETENTION_MS = 60 * 60 * 1_000; // ring buffer keeps 1h
export const MAX_CONTRACTS_PER_CHAIN = 500;
export const MAX_EVENTS_PER_CONTRACT = 1_000;
const ENRICH_TTL_MS = 10 * 60 * 1_000;
const ENRICH_PER_TICK_CAP = 8;
const SNAPSHOT_TOP = 30;

const WINDOW_1M = 60_000;
const WINDOW_5M = 5 * 60_000;
const WINDOW_15M = 15 * 60_000;

/* eth_call selectors (given / keccak-derived) */
const SEL_NAME = "0x06fdde03"; // name()
const SEL_SYMBOL = "0x95d89b41"; // symbol()
const SEL_TOTAL_SUPPLY = "0x18160ddd"; // totalSupply()
/** Max-supply getter candidates, tried in order — first answer wins. */
export const MAX_SUPPLY_SELECTORS = [
  keccak("maxSupply()").slice(0, 10),
  keccak("MAX_SUPPLY()").slice(0, 10),
  keccak("maxTokens()").slice(0, 10),
  keccak("collectionSize()").slice(0, 10),
] as const;

const toHex = (n: number) => `0x${n.toString(16)}`;

/* ------------------------------------------------------------------------- */
/* Types                                                                      */
/* ------------------------------------------------------------------------- */

export type MintEvent = {
  ts: number;
  minter: string;
};

/** Per-contract rolling mint activity (1h ring buffer). */
export type ContractActivity = {
  chainId: number;
  contract: string;
  /** Ascending by ts. */
  events: MintEvent[];
  lastMintTs: number;
};

export type TrendingWindows = {
  m1: number;
  m5: number;
  m15: number;
  h1: number;
  uniqueMinters15m: number;
  lastMintTs: number;
};

export type TrendingEntry = TrendingWindows & {
  chainId: number;
  contract: string;
  name: string | null;
  symbol: string | null;
  totalSupply: number | null;
};

type RawLog = {
  address: string;
  topics: string[];
};

/* ------------------------------------------------------------------------- */
/* Pure helpers (exported for offline testing)                                */
/* ------------------------------------------------------------------------- */

/**
 * Append a mint event to a contract's ring buffer: drops events older than
 * the retention window and caps the buffer length.
 */
export function recordMint(activity: ContractActivity, ev: MintEvent): ContractActivity {
  activity.events.push(ev);
  activity.lastMintTs = Math.max(activity.lastMintTs, ev.ts);
  const cutoff = ev.ts - RETENTION_MS;
  let drop = 0;
  while (drop < activity.events.length && activity.events[drop].ts < cutoff) drop += 1;
  if (drop > 0) activity.events.splice(0, drop);
  if (activity.events.length > MAX_EVENTS_PER_CONTRACT) {
    activity.events.splice(0, activity.events.length - MAX_EVENTS_PER_CONTRACT);
  }
  return activity;
}

/**
 * Record a mint on a per-chain contract map, enforcing the per-chain
 * contract cap — when full, the contract with the oldest lastMintTs is
 * evicted to make room for the new one.
 */
export function recordContractMint(
  map: Map<string, ContractActivity>,
  chainId: number,
  contract: string,
  ev: MintEvent,
): ContractActivity {
  let activity = map.get(contract);
  if (!activity) {
    if (map.size >= MAX_CONTRACTS_PER_CHAIN) {
      let oldestKey: string | null = null;
      let oldestTs = Number.POSITIVE_INFINITY;
      for (const [key, value] of map) {
        if (value.lastMintTs < oldestTs) {
          oldestTs = value.lastMintTs;
          oldestKey = key;
        }
      }
      if (oldestKey !== null && oldestTs < ev.ts) map.delete(oldestKey);
    }
    activity = { chainId, contract, events: [], lastMintTs: 0 };
    map.set(contract, activity);
  }
  return recordMint(activity, ev);
}

/** Window counters over a contract's event ring buffer at `now`. */
export function computeWindows(events: readonly MintEvent[], now: number): TrendingWindows {
  let m1 = 0;
  let m5 = 0;
  let m15 = 0;
  let h1 = 0;
  let lastMintTs = 0;
  const minters15 = new Set<string>();
  for (const ev of events) {
    const age = now - ev.ts;
    if (age < 0 || age >= RETENTION_MS) continue;
    h1 += 1;
    if (age < WINDOW_1M) m1 += 1;
    if (age < WINDOW_5M) m5 += 1;
    if (age < WINDOW_15M) {
      m15 += 1;
      minters15.add(ev.minter);
    }
    if (ev.ts > lastMintTs) lastMintTs = ev.ts;
  }
  return { m1, m5, m15, h1, uniqueMinters15m: minters15.size, lastMintTs };
}

/**
 * Rank contract activities: only contracts with at least one mint in the
 * retention window qualify. Sorted by 15m mints desc, tiebreak 5m desc,
 * then 1h desc, then most recent mint. Metadata fields are left null —
 * the snapshot accessor overlays cached enrichment.
 */
export function rankTrending(
  activities: Iterable<ContractActivity>,
  now: number,
): TrendingEntry[] {
  const ranked: TrendingEntry[] = [];
  for (const activity of activities) {
    const windows = computeWindows(activity.events, now);
    if (windows.h1 === 0) continue;
    ranked.push({
      chainId: activity.chainId,
      contract: activity.contract,
      name: null,
      symbol: null,
      totalSupply: null,
      ...windows,
    });
  }
  ranked.sort(
    (a, b) =>
      b.m15 - a.m15 || b.m5 - a.m5 || b.h1 - a.h1 || b.lastMintTs - a.lastMintTs,
  );
  return ranked;
}

/** Decode an ERC-721 mint log (Transfer from zero address). */
export function decodeMintLog(log: RawLog): { contract: string; minter: string } | null {
  if (log.topics.length < 3) return null;
  if (log.topics[0]?.toLowerCase() !== TRANSFER_TOPIC) return null;
  if (log.topics[1]?.toLowerCase() !== ZERO_ADDRESS_TOPIC) return null;
  return {
    contract: log.address.toLowerCase(),
    minter: `0x${log.topics[2].slice(26).toLowerCase()}`,
  };
}

/**
 * Decode an ABI-encoded `string` return value (name/symbol). Handles the
 * standard dynamic-string layout and the legacy bytes32 variant some old
 * collections use. Returns null on anything else.
 */
export function decodeAbiString(hex: string): string | null {
  if (!hex || hex === "0x") return null;
  const clean = hex.startsWith("0x") ? hex.slice(2) : hex;
  try {
    if (clean.length >= 128) {
      // Dynamic string: [offset][length][data]
      const len = Number(BigInt(`0x${clean.slice(64, 128)}`));
      if (!Number.isSafeInteger(len) || len < 0 || 128 + len * 2 > clean.length) return null;
      const bytes = Buffer.from(clean.slice(128, 128 + len * 2), "hex");
      const out = bytes.toString("utf8").replace(/\0+$/g, "");
      return out.length > 0 ? out : null;
    }
    if (clean.length === 64) {
      // Legacy bytes32 string.
      const out = Buffer.from(clean, "hex").toString("utf8").replace(/\0+$/g, "");
      return out.length > 0 ? out : null;
    }
    return null;
  } catch {
    return null;
  }
}

/** Decode a uint256 return value to a safe integer; null on revert/empty/overflow. */
export function decodeAbiUint(hex: string): number | null {
  if (!hex || hex === "0x") return null;
  const clean = hex.startsWith("0x") ? hex.slice(2) : hex;
  if (clean.length !== 64) return null;
  try {
    const value = BigInt(`0x${clean}`);
    if (value > BigInt(Number.MAX_SAFE_INTEGER)) return null;
    return Number(value);
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------------- */
/* RPC plumbing                                                               */
/* ------------------------------------------------------------------------- */

async function rpcCall(
  url: string,
  method: string,
  params: unknown[],
  timeoutMs = RPC_TIMEOUT_MS,
): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`RPC HTTP ${res.status}`);
    const body = (await res.json()) as {
      result?: unknown;
      error?: { code?: number; message?: string };
    };
    if (body.error) {
      throw new Error(`RPC ${body.error.code ?? ""}: ${body.error.message ?? "unknown"}`);
    }
    return body.result;
  } finally {
    clearTimeout(timer);
  }
}

/** eth_call returning raw hex, or null on revert/error (never throws). */
async function ethCallString(
  url: string,
  contract: string,
  data: string,
  timeoutMs = RPC_TIMEOUT_MS,
): Promise<string | null> {
  try {
    const result = (await rpcCall(
      url,
      "eth_call",
      [{ to: contract, data }, "latest"],
      timeoutMs,
    )) as string;
    return typeof result === "string" ? result : null;
  } catch {
    return null;
  }
}

/**
 * Read totalSupply() plus the first max-supply getter that answers, within
 * the given budget. All nulls tolerated — never throws.
 */
export async function fetchSupplyInfo(
  url: string,
  contract: string,
  budgetMs = 5_000,
): Promise<{ total: number | null; max: number | null; pct: number | null }> {
  const deadline = Date.now() + budgetMs;
  const remaining = () => Math.max(500, deadline - Date.now());

  const totalHex =
    Date.now() < deadline
      ? await ethCallString(url, contract, SEL_TOTAL_SUPPLY, remaining())
      : null;
  const total = totalHex !== null ? decodeAbiUint(totalHex) : null;

  let max: number | null = null;
  for (const sel of MAX_SUPPLY_SELECTORS) {
    if (Date.now() >= deadline) break;
    const hex = await ethCallString(url, contract, sel, remaining());
    const value = hex !== null ? decodeAbiUint(hex) : null;
    if (value !== null && value > 0) {
      max = value;
      break;
    }
  }

  const pct =
    total !== null && max !== null && max > 0
      ? Math.min(100, Math.round((total / max) * 10_000) / 100)
      : null;
  return { total, max, pct };
}

/* ------------------------------------------------------------------------- */
/* Enrichment                                                                 */
/* ------------------------------------------------------------------------- */

type Enrichment = {
  name: string | null;
  symbol: string | null;
  totalSupply: number | null;
  fetchedAt: number;
};

/* ------------------------------------------------------------------------- */
/* Watcher                                                                    */
/* ------------------------------------------------------------------------- */

export class MintWatch {
  /** chainId → contract → activity. */
  private chains = new Map<number, Map<string, ContractActivity>>();
  private enrichCache = new Map<string, Enrichment>();
  private lastSeenBlock = new Map<number, number>();
  private stopped = false;
  private bootedChains = false;
  private timers = new Set<ReturnType<typeof setTimeout>>();

  async start() {
    if (this.bootedChains) return;
    this.bootedChains = true;
    this.stopped = false;
    MINT_WATCH_CHAINS.forEach((chainId, i) => {
      const timer = setTimeout(() => {
        void this.chainLoop(chainId);
      }, i * CHAIN_STAGGER_MS);
      this.timers.add(timer);
    });
    console.log("[mintwatch] watching mints on", MINT_WATCH_CHAINS.length, "chains");
  }

  stop() {
    this.stopped = true;
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear();
  }

  private schedule(fn: () => void, ms: number) {
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      fn();
    }, ms);
    this.timers.add(timer);
  }

  private async chainLoop(chainId: number) {
    while (!this.stopped) {
      try {
        await this.scanChainOnce(chainId);
      } catch (err) {
        console.error(`[mintwatch] chain ${chainId} scan error:`, cleanRpcError(err));
      }
      if (this.stopped) break;
      await new Promise<void>((resolve) => this.schedule(resolve, LOOP_MS));
    }
  }

  private chainMap(chainId: number): Map<string, ContractActivity> {
    let map = this.chains.get(chainId);
    if (!map) {
      map = new Map();
      this.chains.set(chainId, map);
    }
    return map;
  }

  /**
   * One scan pass for a chain: fetch mint Transfer logs from the last-seen
   * block to head in adaptive chunks (≤2000 blocks, halving on error).
   * The first pass seeds the cursor one chunk behind head so the feed has
   * data immediately without a deep catch-up scan.
   */
  private async scanChainOnce(chainId: number) {
    const url = await getBestRpc(chainId);
    if (!url) return;
    const headHex = (await rpcCall(url, "eth_blockNumber", [])) as string;
    const head = Number.parseInt(headHex, 16);
    if (!Number.isFinite(head)) return;

    const last = this.lastSeenBlock.get(chainId);
    const from = last === undefined ? Math.max(0, head - BASE_CHUNK + 1) : last + 1;
    if (from > head) {
      this.lastSeenBlock.set(chainId, head);
      return;
    }

    const now = Date.now();
    const map = this.chainMap(chainId);
    let chunk = BASE_CHUNK;
    let cursor = from;
    while (cursor <= head && !this.stopped) {
      const end = Math.min(cursor + chunk - 1, head);
      try {
        const logs = (await rpcCall(url, "eth_getLogs", [
          {
            topics: [TRANSFER_TOPIC, ZERO_ADDRESS_TOPIC],
            fromBlock: toHex(cursor),
            toBlock: toHex(end),
          },
        ])) as RawLog[];
        for (const log of logs) {
          const mint = decodeMintLog(log);
          if (!mint) continue;
          recordContractMint(map, chainId, mint.contract, { ts: now, minter: mint.minter });
        }
        cursor = end + 1;
        // Restore chunk size after a success (bounded by the base chunk).
        chunk = Math.min(BASE_CHUNK, chunk * 2);
      } catch {
        if (chunk <= MIN_CHUNK) {
          // Even a tiny chunk fails — skip this range rather than stall.
          cursor = end + 1;
          chunk = BASE_CHUNK;
        } else {
          chunk = Math.max(MIN_CHUNK, Math.floor(chunk / 2));
        }
      }
    }
    this.lastSeenBlock.set(chainId, head);

    // Kick off enrichment for recently active contracts (fire-and-forget).
    this.enrichActiveContracts(chainId, url, map).catch(() => {});
  }

  /** Enrich (name/symbol/totalSupply) contracts with recent mints, cached 10 min. */
  private async enrichActiveContracts(
    chainId: number,
    url: string,
    map: Map<string, ContractActivity>,
  ) {
    const cutoff = Date.now() - WINDOW_15M;
    const candidates = [...map.values()]
      .filter((a) => a.lastMintTs >= cutoff)
      .sort((a, b) => b.lastMintTs - a.lastMintTs)
      .slice(0, ENRICH_PER_TICK_CAP);
    for (const activity of candidates) {
      const key = `${chainId}:${activity.contract}`;
      const cached = this.enrichCache.get(key);
      if (cached && cached.fetchedAt > Date.now() - ENRICH_TTL_MS) continue;
      const [nameHex, symbolHex, supply] = await Promise.all([
        ethCallString(url, activity.contract, SEL_NAME),
        ethCallString(url, activity.contract, SEL_SYMBOL),
        fetchSupplyInfo(url, activity.contract, 3_000),
      ]);
      this.enrichCache.set(key, {
        name: nameHex !== null ? decodeAbiString(nameHex) : null,
        symbol: symbolHex !== null ? decodeAbiString(symbolHex) : null,
        totalSupply: supply.total,
        fetchedAt: Date.now(),
      });
    }
  }

  private enrichment(chainId: number, contract: string): Enrichment | null {
    return this.enrichCache.get(`${chainId}:${contract}`) ?? null;
  }

  /** Top trending contracts across all chains (default top 30). */
  getTrendingSnapshot(limit = SNAPSHOT_TOP): TrendingEntry[] {
    const all: ContractActivity[] = [];
    for (const map of this.chains.values()) all.push(...map.values());
    const ranked = rankTrending(all, Date.now()).slice(0, limit);
    for (const entry of ranked) {
      const meta = this.enrichment(entry.chainId, entry.contract);
      if (meta) {
        entry.name = meta.name;
        entry.symbol = meta.symbol;
        entry.totalSupply = meta.totalSupply;
      }
    }
    return ranked;
  }

  /** Velocity windows for a single contract, or null when unseen. */
  getContractActivity(chainId: number, contract: string): TrendingWindows | null {
    const activity = this.chains.get(chainId)?.get(contract.toLowerCase());
    if (!activity) return null;
    return computeWindows(activity.events, Date.now());
  }
}

/** Process-wide singleton — booted by the engine manager. */
export const mintWatch = new MintWatch();

/** Snapshot accessor: top 30 trending contracts with enrichment overlaid. */
export function getTrendingSnapshot(): TrendingEntry[] {
  return mintWatch.getTrendingSnapshot(SNAPSHOT_TOP);
}

/** Single-contract velocity windows for the mint-progress monitor. */
export function getContractActivity(chainId: number, contract: string): TrendingWindows | null {
  return mintWatch.getContractActivity(chainId, contract);
}
