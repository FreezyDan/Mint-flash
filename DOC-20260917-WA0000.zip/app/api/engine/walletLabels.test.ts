/**
 * Offline tests for wallet behavior label rules: each rule's boundary,
 * importance ordering, and the 3-label cap.
 */
import { describe, expect, it } from "vitest";
import {
  computeLabels,
  parseLabels,
  serializeLabels,
  LABEL_THRESHOLDS,
  MAX_LABELS,
  type LabelAggregate,
} from "./walletLabels";

/** Baseline: an aggregate that matches NO rule. */
const QUIET: LabelAggregate = {
  winRatePct: null,
  flips: 0,
  mintFlips: 0,
  realizedPnlEth: 0,
  volumeEth: 0,
  avgHoldHours: null,
  firstActivityAgeHours: null,
  openPositions: 0,
  unrealizedPnlEth: null,
};

const agg = (over: Partial<LabelAggregate>): LabelAggregate => ({ ...QUIET, ...over });

describe("computeLabels — individual rules", () => {
  it("labels nothing for a quiet wallet", () => {
    expect(computeLabels(QUIET)).toEqual([]);
  });

  it("smart-money: win rate ≥60% AND ≥10 flips AND positive realized PnL", () => {
    expect(
      computeLabels(agg({ winRatePct: 60, flips: 10, realizedPnlEth: 0.5 })),
    ).toEqual(["smart-money"]);
    // Boundary: exactly at thresholds passes.
    expect(
      computeLabels(
        agg({
          winRatePct: LABEL_THRESHOLDS.smartMoneyWinRatePct,
          flips: LABEL_THRESHOLDS.smartMoneyMinFlips,
          realizedPnlEth: 0.0001,
        }),
      ),
    ).toContain("smart-money");
  });

  it("smart-money: fails when any leg is unmet", () => {
    expect(
      computeLabels(agg({ winRatePct: 59.9, flips: 12, realizedPnlEth: 1 })),
    ).toEqual([]);
    expect(
      computeLabels(agg({ winRatePct: 80, flips: 9, realizedPnlEth: 1 })),
    ).toEqual([]);
    expect(
      computeLabels(agg({ winRatePct: 80, flips: 12, realizedPnlEth: 0 })),
    ).toEqual([]);
  });

  it("sniper: mint flips ≥60% of ≥5 flips (boundary inclusive)", () => {
    expect(computeLabels(agg({ flips: 5, mintFlips: 3 }))).toEqual(["sniper"]);
    expect(computeLabels(agg({ flips: 5, mintFlips: 2 }))).toEqual([]);
    expect(computeLabels(agg({ flips: 4, mintFlips: 4 }))).toEqual([]);
  });

  it("whale: volume (spend + proceeds) ≥ 25 ETH", () => {
    expect(computeLabels(agg({ volumeEth: 25 }))).toEqual(["whale"]);
    expect(computeLabels(agg({ volumeEth: 24.999 }))).toEqual([]);
  });

  it("fresh: first observed activity < 30 days before scan end", () => {
    expect(computeLabels(agg({ firstActivityAgeHours: 719 }))).toEqual(["fresh"]);
    expect(computeLabels(agg({ firstActivityAgeHours: 720 }))).toEqual([]);
    expect(computeLabels(agg({ firstActivityAgeHours: null }))).toEqual([]);
  });

  it("flipper: avg hold < 24h across ≥3 flips", () => {
    expect(computeLabels(agg({ avgHoldHours: 2.5, flips: 3 }))).toEqual(["flipper"]);
    expect(computeLabels(agg({ avgHoldHours: 24, flips: 3 }))).toEqual([]);
    expect(computeLabels(agg({ avgHoldHours: 2.5, flips: 2 }))).toEqual([]);
  });

  it("diamond: avg hold > 720h across ≥2 flips (excludes flipper)", () => {
    expect(computeLabels(agg({ avgHoldHours: 721, flips: 2 }))).toEqual(["diamond"]);
    expect(computeLabels(agg({ avgHoldHours: 720, flips: 2 }))).toEqual([]);
    expect(computeLabels(agg({ avgHoldHours: 2000, flips: 1 }))).toEqual([]);
  });

  it("bagholder: ≥5 open positions AND negative unrealized PnL", () => {
    expect(computeLabels(agg({ openPositions: 5, unrealizedPnlEth: -0.1 }))).toEqual([
      "bagholder",
    ]);
    expect(computeLabels(agg({ openPositions: 4, unrealizedPnlEth: -0.1 }))).toEqual([]);
    expect(computeLabels(agg({ openPositions: 6, unrealizedPnlEth: 0.3 }))).toEqual([]);
    // Null unrealized (unmarked positions) must not label bagholder.
    expect(computeLabels(agg({ openPositions: 8, unrealizedPnlEth: null }))).toEqual([]);
  });
});

describe("computeLabels — precedence and cap", () => {
  it("orders by importance (smart-money first) and caps at MAX_LABELS", () => {
    const labels = computeLabels(
      agg({
        winRatePct: 90,
        flips: 20,
        mintFlips: 20,
        realizedPnlEth: 10,
        volumeEth: 500,
        firstActivityAgeHours: 1,
        avgHoldHours: 1,
        openPositions: 9,
        unrealizedPnlEth: -3,
      }),
    );
    expect(labels).toEqual(["smart-money", "sniper", "whale"]);
    expect(labels.length).toBe(MAX_LABELS);
  });

  it("drops fresh before later rules when the cap binds", () => {
    // smart-money + whale + fresh + flipper → fresh wins the third slot over
    // flipper because it ranks higher in importance order.
    const labels = computeLabels(
      agg({
        winRatePct: 70,
        flips: 15,
        mintFlips: 0,
        realizedPnlEth: 1,
        volumeEth: 30,
        firstActivityAgeHours: 5,
        avgHoldHours: 2,
      }),
    );
    expect(labels).toEqual(["smart-money", "whale", "fresh"]);
  });
});

describe("label storage serialization", () => {
  it("round-trips through serializeLabels/parseLabels", () => {
    const labels = computeLabels(agg({ volumeEth: 100 }));
    const raw = serializeLabels(labels);
    expect(raw).toBe('["whale"]');
    expect(parseLabels(raw)).toEqual(["whale"]);
  });

  it("serializes an empty label set as null and parses tolerantly", () => {
    expect(serializeLabels([])).toBeNull();
    expect(parseLabels(null)).toEqual([]);
    expect(parseLabels(undefined)).toEqual([]);
    expect(parseLabels("not json")).toEqual([]);
    expect(parseLabels('{"a":1}')).toEqual([]);
    expect(parseLabels('[1, "whale", null]')).toEqual(["whale"]);
  });
});
