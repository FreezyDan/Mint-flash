import { describe, expect, it } from "vitest";
import { effectiveCapGwei, evaluateGas, formatGwei } from "./gasGuard";

describe("evaluateGas", () => {
  it("is ok when network gas is under the cap", () => {
    const v = evaluateGas({
      maxFeeGwei: 40,
      priorityGwei: 2,
      taskMaxMaxFeeGwei: null,
      globalMaxGasGwei: 500,
    });
    expect(v).toEqual({ ok: true });
  });

  it("is ok when network gas is exactly at the cap", () => {
    const v = evaluateGas({
      maxFeeGwei: 500,
      priorityGwei: 5,
      taskMaxMaxFeeGwei: null,
      globalMaxGasGwei: 500,
    });
    expect(v.ok).toBe(true);
  });

  it("is not ok when network gas exceeds the cap, with a clear reason", () => {
    const v = evaluateGas({
      maxFeeGwei: 612.55,
      priorityGwei: 5,
      taskMaxMaxFeeGwei: null,
      globalMaxGasGwei: 500,
    });
    expect(v.ok).toBe(false);
    expect(v.reason).toBe("gas 612.55 gwei above cap 500 gwei");
  });

  it("task cap takes precedence over the global cap", () => {
    // Over the global 500 but under the task's own 800 → ok.
    const under = evaluateGas({
      maxFeeGwei: 650,
      priorityGwei: 5,
      taskMaxMaxFeeGwei: 800,
      globalMaxGasGwei: 500,
    });
    expect(under.ok).toBe(true);

    // Over the task's 200 even though the global 500 would allow it → hold.
    const over = evaluateGas({
      maxFeeGwei: 250,
      priorityGwei: 5,
      taskMaxMaxFeeGwei: 200,
      globalMaxGasGwei: 500,
    });
    expect(over.ok).toBe(false);
    expect(over.reason).toBe("gas 250 gwei above cap 200 gwei");
  });

  it("is always ok when both caps are null (guard disabled)", () => {
    const v = evaluateGas({
      maxFeeGwei: 9999,
      priorityGwei: 500,
      taskMaxMaxFeeGwei: null,
      globalMaxGasGwei: null,
    });
    expect(v).toEqual({ ok: true });
  });

  it("fractional gwei values compare and format correctly", () => {
    const v = evaluateGas({
      maxFeeGwei: 0.5,
      priorityGwei: 0.1,
      taskMaxMaxFeeGwei: null,
      globalMaxGasGwei: 0.4,
    });
    expect(v.ok).toBe(false);
    expect(v.reason).toBe("gas 0.5 gwei above cap 0.4 gwei");
  });
});

describe("effectiveCapGwei", () => {
  it("prefers the task cap, falls back to global, else null", () => {
    expect(effectiveCapGwei(100, 500)).toBe(100);
    expect(effectiveCapGwei(null, 500)).toBe(500);
    expect(effectiveCapGwei(null, null)).toBeNull();
  });
});

describe("formatGwei", () => {
  it("trims to ≤2 decimals and drops trailing zeros", () => {
    expect(formatGwei(500)).toBe("500");
    expect(formatGwei(612.5)).toBe("612.5");
    expect(formatGwei(612.567)).toBe("612.57");
    expect(formatGwei(0.1)).toBe("0.1");
  });
});
