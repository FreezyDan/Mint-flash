import type { MintTask } from "@db/schema";
import { logActivity } from "../queries/activity";
import { findArmedTasks, updateTask } from "../queries/tasks";
import { findUserById } from "../queries/users";
import { computeEntitlement } from "../lib/entitlements";
import { getOrCreateSettings } from "../queries/settings";
import { CopyTrader } from "./copyTrader";
import { FloorSweeper } from "./floorSweeper";
import { MintEngine } from "./mintEngine";
import { mintWatch as mintWatchSingleton, MintWatch } from "./mintWatch";
import { SellEngine } from "./sellEngine";

/**
 * Singleton that owns all running engines.
 * - boots on server start (called from api/boot.ts)
 * - restores 'armed' tasks from the DB on boot
 * - runs one CopyTrader watcher loop for all users
 *
 * Everything is wrapped in try/catch — engines must never crash the server.
 */
class EngineManager {
  private mintEngines = new Map<number, MintEngine>();
  private copyTrader: CopyTrader | null = null;
  private floorSweeper: FloorSweeper | null = null;
  private sellEngine: SellEngine | null = null;
  private mintWatch: MintWatch | null = null;
  private booted = false;

  isTaskRunning(taskId: number): boolean {
    return this.mintEngines.has(taskId);
  }

  runningTaskIds(): number[] {
    return [...this.mintEngines.keys()];
  }

  async boot() {
    if (this.booted) return;
    this.booted = true;
    try {
      console.log("[engine] booting engine manager");
      this.copyTrader = new CopyTrader();
      await this.copyTrader.start();

      this.floorSweeper = new FloorSweeper();
      await this.floorSweeper.start();

      this.sellEngine = new SellEngine();
      await this.sellEngine.start();

      // "Minting Now" trending watcher — module singleton so publicRouter
      // reads the same in-memory snapshot the boot loop fills.
      this.mintWatch = mintWatchSingleton;
      await this.mintWatch.start();

      const armed = await findArmedTasks();
      for (const task of armed) {
        // Plan guard: never restore a snipe for a free user whose 7-day
        // trial ended while the server was down.
        try {
          const owner = await findUserById(task.userId);
          const ent = computeEntitlement(owner ?? {});
          if (ent.plan === "free" && ent.trialExpired) {
            await updateTask(task.userId, task.id, { status: "cancelled" });
            await logActivity({
              userId: task.userId,
              taskId: task.id,
              level: "warn",
              source: "system",
              message: `Task "${task.name}" cancelled — free trial expired`,
            });
            continue;
          }
        } catch (err) {
          console.error(`[engine] entitlement check failed for task ${task.id}:`, err);
        }
        await this.startTask(task).catch((err) =>
          console.error(`[engine] failed to restore task ${task.id}:`, err),
        );
      }
      if (armed.length > 0) {
        console.log(`[engine] restored ${armed.length} armed task(s)`);
      }
    } catch (err) {
      console.error("[engine] boot failed:", err);
    }
  }

  /** Start the mint engine for a task row the caller has already loaded. */
  async startTask(task: MintTask) {
    this.stopTask(task.id);
    const settings = await getOrCreateSettings(task.userId);
    const engine = new MintEngine(task, settings);
    this.mintEngines.set(task.id, engine);
    void engine
      .run()
      .catch((err) => console.error(`[engine] task ${task.id} crashed:`, err))
      .finally(() => {
        if (this.mintEngines.get(task.id) === engine) {
          this.mintEngines.delete(task.id);
        }
      });
  }

  stopTask(taskId: number): boolean {
    const engine = this.mintEngines.get(taskId);
    if (!engine) return false;
    engine.stop();
    this.mintEngines.delete(taskId);
    return true;
  }

  stopAll() {
    for (const id of [...this.mintEngines.keys()]) this.stopTask(id);
    this.copyTrader?.stop();
    this.floorSweeper?.stop();
    this.sellEngine?.stop();
    this.mintWatch?.stop();
  }

  /** System-level log helper. */
  async logSystem(userId: number, message: string) {
    await logActivity({ userId, level: "info", source: "system", message });
  }
}

export const engineManager = new EngineManager();
