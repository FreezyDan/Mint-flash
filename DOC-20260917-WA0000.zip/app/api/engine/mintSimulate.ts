/**
 * Pre-flight mint simulation (eth_call) — run the exact transaction
 * (same calldata incl. any injected merkle proof, same value, same from)
 * against the node before broadcasting. A would-be revert holds fire
 * instead of burning gas on a guaranteed-failed transaction; infra
 * failures (timeout/node error, NOT a revert) never block the send.
 */

export type SimulateResult =
  | { ok: true }
  | { ok: false; kind: "revert"; reason: string }
  | { ok: false; kind: "infra"; reason: string };

export type SimulateProvider = {
  call: (tx: {
    to: string;
    data: string;
    value: bigint;
    from: string;
  }) => Promise<string>;
};

const SIM_TIMEOUT_MS = 4_000;

/**
 * Pure send/hold decision over a simulation result:
 *  - ok          → send
 *  - revert      → hold (the mint may not be live yet — retry later)
 *  - infra error → send anyway (never block execution on node hiccups)
 */
export function shouldSendAfterSim(result: SimulateResult): boolean {
  if (result.ok) return true;
  return result.kind === "infra";
}

/** Extract a human revert reason from an ethers v6 CALL_EXCEPTION error. */
export function extractRevertReason(err: unknown): string {
  const e = err as {
    reason?: unknown;
    shortMessage?: unknown;
    message?: unknown;
    info?: { error?: { message?: unknown } };
  };
  let raw =
    (typeof e?.reason === "string" && e.reason) ||
    (typeof e?.info?.error?.message === "string" && e.info.error.message) ||
    (typeof e?.shortMessage === "string" && e.shortMessage) ||
    (typeof e?.message === "string" && e.message) ||
    "execution reverted";
  // Strip the "execution reverted: " wrapper nodes add around the reason
  // and trailing noise like "(data=…)".
  raw = raw.replace(/^execution reverted:?\s*/i, "").replace(/\s*\((?:data|reason)=.*$/s, "").trim();
  if (!raw) raw = "execution reverted";
  return raw.length > 120 ? `${raw.slice(0, 117)}...` : raw;
}

function isRevertError(err: unknown): boolean {
  const code = (err as { code?: unknown })?.code;
  return code === "CALL_EXCEPTION";
}

/**
 * Simulate the exact mint tx via eth_call. 4s timeout; a timeout or any
 * non-revert error degrades to an "infra" result (send proceeds).
 */
export async function simulateMint(
  provider: SimulateProvider,
  tx: { from: string; contractAddress: string; data: string; valueWei: bigint },
): Promise<SimulateResult> {
  try {
    await Promise.race([
      provider.call({
        to: tx.contractAddress,
        data: tx.data,
        value: tx.valueWei,
        from: tx.from,
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("simulation timeout")), SIM_TIMEOUT_MS),
      ),
    ]);
    return { ok: true };
  } catch (err) {
    if (isRevertError(err)) {
      return { ok: false, kind: "revert", reason: extractRevertReason(err) };
    }
    const msg = (err as Error)?.message ?? String(err);
    return { ok: false, kind: "infra", reason: msg.slice(0, 120) || "simulation rpc failure" };
  }
}
