/**
 * Offline unit tests for the pure TP/SL exit evaluation — no DB, no network.
 */
import { describe, expect, it } from "vitest";
import { evaluateExit } from "./sellEngine";

describe("evaluateExit", () => {
  it("triggers take_profit when the offer reaches entry × (1 + tp%)", () => {
    // entry 1.0, tp 50% → trigger at 1.5
    expect(
      evaluateExit({ entryEth: "1.0000000000", tpPct: 50, slPct: null }, 1.5),
    ).toBe("take_profit");
    expect(
      evaluateExit({ entryEth: "1.0000000000", tpPct: 50, slPct: null }, 1.6),
    ).toBe("take_profit");
  });

  it("does not trigger take_profit below the threshold", () => {
    expect(
      evaluateExit({ entryEth: "1.0000000000", tpPct: 50, slPct: null }, 1.49),
    ).toBeNull();
  });

  it("triggers stop_loss when the offer drops to entry × (1 − sl%)", () => {
    // entry 2.0, sl 25% → trigger at 1.5
    expect(
      evaluateExit({ entryEth: "2.0000000000", tpPct: null, slPct: 25 }, 1.5),
    ).toBe("stop_loss");
    expect(
      evaluateExit({ entryEth: "2.0000000000", tpPct: null, slPct: 25 }, 1.2),
    ).toBe("stop_loss");
  });

  it("does not trigger stop_loss above the threshold", () => {
    expect(
      evaluateExit({ entryEth: "2.0000000000", tpPct: null, slPct: 25 }, 1.51),
    ).toBeNull();
  });

  it("returns null when entryEth is null (cannot compute %)", () => {
    expect(evaluateExit({ entryEth: null, tpPct: 50, slPct: 25 }, 999)).toBeNull();
    expect(evaluateExit({ entryEth: null, tpPct: 50, slPct: 25 }, 0.0001)).toBeNull();
  });

  it("returns null when both tpPct and slPct are disabled", () => {
    expect(
      evaluateExit({ entryEth: "1.0000000000", tpPct: null, slPct: null }, 100),
    ).toBeNull();
    expect(
      evaluateExit({ entryEth: "1.0000000000", tpPct: null, slPct: null }, 0.001),
    ).toBeNull();
  });

  it("prefers take_profit when both thresholds are crossed (offer above tp)", () => {
    // offer way above entry: tp wins; sl condition cannot also hold here
    expect(
      evaluateExit({ entryEth: "1.0000000000", tpPct: 10, slPct: 90 }, 1.11),
    ).toBe("take_profit");
  });

  it("treats a zero/invalid entry as uncomputable (no trigger)", () => {
    expect(evaluateExit({ entryEth: "0", tpPct: 50, slPct: 50 }, 100)).toBeNull();
    expect(
      evaluateExit({ entryEth: "not-a-number", tpPct: 50, slPct: 50 }, 100),
    ).toBeNull();
  });

  it("handles small entries with high tp percentages", () => {
    // entry 0.05, tp 200% → trigger at 0.15
    expect(
      evaluateExit({ entryEth: "0.0500000000", tpPct: 200, slPct: null }, 0.149),
    ).toBeNull();
    expect(
      evaluateExit({ entryEth: "0.0500000000", tpPct: 200, slPct: null }, 0.151),
    ).toBe("take_profit");
  });
});
