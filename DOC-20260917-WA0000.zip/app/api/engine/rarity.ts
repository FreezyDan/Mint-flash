/**
 * Rarity sniping — OpenSea API v2 rarity data + local trait-frequency
 * scoring.
 *
 * Two data sources (both via the shared openseaFetch client, 8s abort):
 *  1. GET /v2/chain/{slug}/contract/{addr}/nfts/{tokenId} — the token's
 *     traits plus `nft.rarity.rank` (OpenRarity). The rank is OPTIONAL:
 *     OpenSea only computes it after reveal/indexing, so pre-reveal and
 *     freshly revealed tokens come back without it.
 *  2. GET /v2/traits/{collection_slug} — the full trait-frequency table
 *     (`counts: { [category]: { [value]: count } }`), which enables LOCAL
 *     rarity scoring when the rank is absent.
 *
 * Local score (information-theoretic, the standard "rarity score" sum):
 *     score = Σ over traits of −log2(count / totalSupply)
 * Rarer traits contribute more; a token of perfectly common traits
 * (every trait held by the whole supply) scores 0.
 *
 * Gate semantics (passesRarityGate): a local score is NOT comparable to an
 * OpenRarity rank, so score-only / unknown results return 'unknown' and
 * callers must decide their own policy — the sweeper proceeds (never block
 * buys on missing data).
 */

import { openseaChainSlug, openseaFetch } from "./opensea";

export type TokenTrait = { type: string; value: string };

export type TokenRarity = {
  /** OpenRarity rank, or null when OpenSea hasn't computed it yet. */
  rank: number | null;
  traits: TokenTrait[];
  /** Collection slug (needed for the traits-frequency endpoint), if known. */
  collectionSlug: string | null;
};

type RawTrait = { trait_type?: string | number; value?: string | number };

type NftResponse = {
  nft?: {
    collection?: string;
    traits?: RawTrait[];
    rarity?: { strategy_id?: string; rank?: string | number };
  };
};

/**
 * Traits + OpenRarity rank for one token. Returns null when the chain has
 * no OpenSea coverage or the response carries no nft payload; transport
 * failures throw (same contract as openseaFetch).
 */
export async function getTokenRarity(
  chainId: number,
  contractAddress: string,
  tokenId: string,
  apiKey?: string | null,
): Promise<TokenRarity | null> {
  const slug = openseaChainSlug(chainId);
  if (!slug) return null;
  const path =
    `/v2/chain/${encodeURIComponent(slug)}` +
    `/contract/${encodeURIComponent(contractAddress)}` +
    `/nfts/${encodeURIComponent(tokenId)}`;
  const body = (await openseaFetch(path, apiKey)) as NftResponse;
  const nft = body.nft;
  if (!nft) return null;

  const traits: TokenTrait[] = (nft.traits ?? [])
    .filter((t) => t?.trait_type !== undefined && t?.trait_type !== null)
    .map((t) => ({
      type: String(t.trait_type),
      value: t.value === undefined || t.value === null ? "" : String(t.value),
    }));

  const rawRank = nft.rarity?.rank;
  const rank =
    rawRank !== undefined && rawRank !== null && Number.isFinite(Number(rawRank))
      ? Number(rawRank)
      : null;

  return { rank, traits, collectionSlug: nft.collection ?? null };
}

export type TraitFrequencies = {
  /** Estimated collection size — see note in getTraitFrequencies. */
  totalSupply: number;
  /** "type:value" (lowercased) → holder count. */
  freq: Map<string, number>;
};

type TraitsResponse = {
  categories?: Record<string, string>;
  counts?: Record<string, Record<string, string | number>>;
};

/** Frequency-table key — case-insensitive on both halves. */
export function traitKey(type: string, value: string): string {
  return `${type.toLowerCase()}:${value.toLowerCase()}`;
}

/**
 * Full trait-frequency table for a collection. Returns null when the chain
 * is unsupported or no counts are returned; transport failures throw.
 *
 * totalSupply choice: the traits endpoint has no explicit supply field, so
 * we take the MAX count seen across all category values — the most-common
 * trait value is held by (approximately) every token, making its count a
 * solid supply estimate without a second request to the collection
 * endpoint.
 */
export async function getTraitFrequencies(
  chainId: number,
  collectionSlug: string,
  apiKey?: string | null,
): Promise<TraitFrequencies | null> {
  if (!openseaChainSlug(chainId)) return null;
  const body = (await openseaFetch(
    `/v2/traits/${encodeURIComponent(collectionSlug)}`,
    apiKey,
  )) as TraitsResponse;

  const freq = new Map<string, number>();
  let totalSupply = 0;
  for (const [category, values] of Object.entries(body.counts ?? {})) {
    for (const [value, rawCount] of Object.entries(values ?? {})) {
      const count = Number(rawCount);
      if (!Number.isFinite(count) || count < 0) continue;
      freq.set(traitKey(category, value), count);
      if (count > totalSupply) totalSupply = count;
    }
  }
  if (freq.size === 0 || totalSupply <= 0) return null;
  return { totalSupply, freq };
}

export type TraitRarity = {
  type: string;
  value: string;
  /** Holder count from the frequency table — null when not listed. */
  count: number | null;
  /** count / totalSupply in (0, 1] — null when not computable. */
  frequency: number | null;
  /** −log2(frequency); 0 for skipped traits. */
  score: number;
  note?: string;
};

export type LocalRarity = {
  /** Σ −log2(frequency) over traits present in the frequency table. */
  score: number;
  traits: TraitRarity[];
};

/**
 * Pure local rarity score. Traits missing from the frequency table (or
 * with a zero count, which would score +∞) are skipped with a note; an
 * empty trait list scores 0.
 */
export function computeLocalRarity(
  traits: TokenTrait[],
  freq: Map<string, number>,
  totalSupply: number,
): LocalRarity {
  const out: TraitRarity[] = [];
  let score = 0;
  for (const t of traits) {
    if (totalSupply <= 0) {
      out.push({
        ...t,
        count: null,
        frequency: null,
        score: 0,
        note: "unknown total supply — skipped",
      });
      continue;
    }
    const count = freq.get(traitKey(t.type, t.value));
    if (count === undefined) {
      out.push({
        ...t,
        count: null,
        frequency: null,
        score: 0,
        note: "not in frequency table — skipped",
      });
      continue;
    }
    if (count <= 0) {
      out.push({
        ...t,
        count,
        frequency: null,
        score: 0,
        note: "zero holders in frequency table — skipped",
      });
      continue;
    }
    // Clamp at 1: a count above the estimated supply must not score < 0.
    const frequency = Math.min(1, count / totalSupply);
    const traitScore = -Math.log2(frequency);
    score += traitScore;
    out.push({ ...t, count, frequency, score: traitScore });
  }
  return { score, traits: out };
}

export type ResolvedRarity =
  | { kind: "rank"; rank: number; traits: TokenTrait[]; collectionSlug: string | null }
  | { kind: "score"; score: number; traits: TraitRarity[]; collectionSlug: string }
  | { kind: "unknown" };

const TOKEN_CACHE_TTL_MS = 10 * 60_000;
const FREQ_CACHE_TTL_MS = 30 * 60_000;

const tokenCache = new Map<string, { at: number; value: ResolvedRarity }>();
const freqCache = new Map<string, { at: number; value: TraitFrequencies | null }>();

/** Test hook — drop both in-memory caches. */
export function clearRarityCaches(): void {
  tokenCache.clear();
  freqCache.clear();
}

/**
 * Best rarity answer for one token: the OpenRarity rank when OpenSea has
 * computed it, else a local trait-frequency score when the collection slug
 * and frequency table are available, else 'unknown'. Rarity is advisory
 * data — transport/parse failures degrade to 'unknown' rather than
 * throwing, so callers never lose a buy/sell path over it.
 *
 * Results are cached in memory: 10 min per token, 30 min per collection
 * frequency table.
 */
export async function resolveRarity(
  chainId: number,
  contractAddress: string,
  tokenId: string,
  apiKey?: string | null,
): Promise<ResolvedRarity> {
  const cacheKey = `${chainId}:${contractAddress.toLowerCase()}:${tokenId}`;
  const hit = tokenCache.get(cacheKey);
  if (hit && Date.now() - hit.at < TOKEN_CACHE_TTL_MS) return hit.value;

  const value = await resolveRarityUncached(chainId, contractAddress, tokenId, apiKey);
  tokenCache.set(cacheKey, { at: Date.now(), value });
  return value;
}

async function resolveRarityUncached(
  chainId: number,
  contractAddress: string,
  tokenId: string,
  apiKey?: string | null,
): Promise<ResolvedRarity> {
  let token: TokenRarity | null = null;
  try {
    token = await getTokenRarity(chainId, contractAddress, tokenId, apiKey);
  } catch (err) {
    console.warn(`[rarity] token lookup failed for ${contractAddress}#${tokenId}:`, err);
    return { kind: "unknown" };
  }
  if (!token) return { kind: "unknown" };
  if (token.rank !== null) {
    return {
      kind: "rank",
      rank: token.rank,
      traits: token.traits,
      collectionSlug: token.collectionSlug,
    };
  }
  if (!token.collectionSlug) return { kind: "unknown" };

  const frequencies = await cachedTraitFrequencies(chainId, token.collectionSlug, apiKey);
  if (!frequencies) return { kind: "unknown" };
  const local = computeLocalRarity(token.traits, frequencies.freq, frequencies.totalSupply);
  return {
    kind: "score",
    score: local.score,
    traits: local.traits,
    collectionSlug: token.collectionSlug,
  };
}

export type TopTrait = {
  type: string;
  value: string;
  /** % of the collection holding this trait value. */
  pct: number;
};

/**
 * The 2 rarest traits of a token with their collection-wide %, derived from
 * the (30-min cached) frequency table. Returns null when no frequency data
 * is available — best-effort for tooltips, never throws.
 */
export async function topRarestTraits(
  chainId: number,
  collectionSlug: string,
  traits: TokenTrait[],
  apiKey?: string | null,
): Promise<TopTrait[] | null> {
  const frequencies = await cachedTraitFrequencies(chainId, collectionSlug, apiKey);
  if (!frequencies) return null;
  const local = computeLocalRarity(traits, frequencies.freq, frequencies.totalSupply);
  const known = local.traits.filter((t) => t.frequency !== null);
  if (known.length === 0) return null;
  known.sort((a, b) => b.score - a.score);
  return known.slice(0, 2).map((t) => ({
    type: t.type,
    value: t.value,
    pct: Number(((t.frequency ?? 0) * 100).toFixed(2)),
  }));
}

async function cachedTraitFrequencies(
  chainId: number,
  collectionSlug: string,
  apiKey?: string | null,
): Promise<TraitFrequencies | null> {
  const cacheKey = `${chainId}:${collectionSlug}`;
  const hit = freqCache.get(cacheKey);
  if (hit && Date.now() - hit.at < FREQ_CACHE_TTL_MS) return hit.value;
  let value: TraitFrequencies | null = null;
  try {
    value = await getTraitFrequencies(chainId, collectionSlug, apiKey);
  } catch (err) {
    console.warn(`[rarity] trait frequencies failed for ${collectionSlug}:`, err);
  }
  freqCache.set(cacheKey, { at: Date.now(), value });
  return value;
}

export type RarityGateResult = "pass" | "skip" | "unknown";

/**
 * Pure gate check. A local score is NOT comparable to an OpenRarity rank,
 * so score-only and unknown rarity both return 'unknown' — the caller
 * decides (the sweeper treats 'unknown' as proceed-with-log, never block).
 */
export function passesRarityGate(
  resolved: ResolvedRarity,
  maxRarityRank: number,
): RarityGateResult {
  if (resolved.kind !== "rank") return "unknown";
  return resolved.rank <= maxRarityRank ? "pass" : "skip";
}
