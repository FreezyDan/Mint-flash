import { ethers } from "ethers";
import type { SweepRule } from "@db/schema";
import { logActivity } from "../queries/activity";
import { findEnabledSweepRules, updateSweepRule } from "../queries/sweep";
import { entryEth10, insertPosition } from "../queries/positions";
import { findUserById } from "../queries/users";
import { canExecute, computeEntitlement } from "../lib/entitlements";
import { isHalted } from "../lib/halt";
import { cleanRpcError, ErrorThrottle } from "../lib/rpcError";
import { resolveOpenseaKey } from "../lib/openseaKey";
import { getManagedPrivateKey } from "./managedWallet";
import { resolveRpcForUser } from "./rpcManager";
import {
  getBuyCalldata,
  getFloorAsk,
  type FloorAsk,
} from "./opensea";
import { passesRarityGate, resolveRarity } from "./rarity";
import { explorerTxUrl } from "@contracts/rpc";

/**
 * Floor-sweeper engine.
 *
 * Every ~45s all enabled sweep_rules are polled (staggered a few seconds
 * apart to spread OpenSea load). Per rule the floor ask comes from the
 * OpenSea API v2 Seaport orderbook — listings are off-chain orders, so there
 * is nothing to watch on-chain. lastFloorEth/lastCheckedAt are stamped on
 * every successful check.
 *
 * OpenSea requires an API key — one ALWAYS resolves via resolveOpenseaKey
 * (user key → admin shared override → built-in shared key), so there is no
 * "no key" idle path anymore.
 *
 * Plan enforcement: the sweep loop re-checks the owner's entitlement every
 * cycle. Non-PRO users (downgraded / expired) are skipped with a single
 * throttled info log per user per hour — closing the downgrade hole.
 *
 * Trigger: mode 'below' buys when floor ≤ threshold; mode 'above' buys when
 * floor ≥ threshold (momentum entry). Caps: the rule auto-disables (with a
 * warn log) when maxBuys is reached or the next buy would exceed maxSpendEth.
 *
 * Execution is LIVE ONLY: when a rule triggers, the engine signs the OpenSea
 * fulfillment calldata with the user's managed vault key (never logged) and
 * submits it via the user's resolved RPC. No vault key → one clear warn log
 * and the buy is skipped — nothing is ever faked. Failed transactions surface
 * the real revert reason/tx hash; successes log the real tx hash + explorer
 * link.
 *
 * Every rule check is try/catch'd — engine failures never crash the server.
 */

const TICK_MS = 45_000;
/** Min interval between "PRO plan required" info logs per user. */
const PLAN_PAUSED_LOG_INTERVAL_MS = 60 * 60_000;
/** Min interval between rarity-gate skip logs per rule. */
const RARITY_SKIP_LOG_INTERVAL_MS = 10 * 60_000;
const RECEIPT_WAIT_MS = 60_000;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const rand = (min: number, max: number) => min + Math.random() * (max - min);

/** Add two decimal ETH strings, avoiding float noise in stored counters. */
export function addEth(a: string, b: string | number): string {
  const sum = Number(a) + Number(b);
  return String(Number(sum.toFixed(8)));
}

export type SweepDecision =
  | { kind: "skip"; triggered: boolean }
  | { kind: "auto-disable"; reason: string }
  | { kind: "buy" };

/**
 * Pure trigger + cap evaluation for a rule at a given floor price.
 * Exported for offline unit testing.
 */
export function evaluateSweep(
  rule: Pick<
    SweepRule,
    "mode" | "thresholdEth" | "maxBuys" | "maxSpendEth" | "boughtCount" | "spentEth"
  >,
  floorEth: number,
): SweepDecision {
  const threshold = Number(rule.thresholdEth);
  const triggered =
    rule.mode === "above" ? floorEth >= threshold : floorEth <= threshold;
  if (!triggered) return { kind: "skip", triggered: false };

  if (rule.boughtCount >= rule.maxBuys) {
    return {
      kind: "auto-disable",
      reason: `buy count cap reached (${rule.boughtCount}/${rule.maxBuys})`,
    };
  }
  const spent = Number(rule.spentEth);
  const maxSpend = Number(rule.maxSpendEth);
  if (spent + floorEth > maxSpend) {
    return {
      kind: "auto-disable",
      reason:
        `spend cap reached (${addEth(rule.spentEth, floorEth)} ETH would exceed ` +
        `${rule.maxSpendEth} ETH)`,
    };
  }
  return { kind: "buy" };
}

/** Display token id — null for collection-wide/criteria listings. */
function tokenLabel(floor: FloorAsk): string {
  return floor.tokenId !== null ? `#${floor.tokenId}` : "floor listing";
}

function ruleLabel(rule: SweepRule): string {
  return (
    rule.collectionName ??
    `${rule.contractAddress.slice(0, 6)}…${rule.contractAddress.slice(-4)}`
  );
}

export class FloorSweeper {
  private stopped = false;
  private running = false;
  /** Users paused by plan enforcement: last info-log timestamp (throttled). */
  private planPausedLoggedAt = new Map<number, number>();
  /** Rules whose rarity gate skipped a floor: last info-log timestamp. */
  private raritySkipLoggedAt = new Map<number, number>();
  /** Live-mode users without a vault key are logged once. */
  private noKeyLogged = new Set<number>();
  /** Per-(rule, cleaned message) error throttle: 1 log per 15 min. */
  private errorThrottle = new ErrorThrottle();

  stop() {
    this.stopped = true;
  }

  async start() {
    if (this.running) return;
    this.running = true;
    this.stopped = false;
    void this.loop();
  }

  private async loop() {
    while (!this.stopped) {
      try {
        await this.tick();
      } catch (err) {
        console.error("[sweep] tick error:", err);
      }
      await sleep(TICK_MS);
    }
    this.running = false;
  }

  private async tick() {
    const rules = await findEnabledSweepRules();
    for (const rule of rules) {
      try {
        await this.checkRule(rule);
        // Successful check — reset any throttled error keys for this rule.
        const recovered = this.errorThrottle.clearPrefix(`${rule.id}:`);
        if (recovered.cleared > 0) {
          await logActivity({
            userId: rule.userId,
            level: "info",
            source: "sweep",
            message: `Sweep watcher recovered for ${ruleLabel(rule)}`,
          });
        }
      } catch (err) {
        // Clean raw ethers noise; identical errors log at most once/15 min.
        const cleaned = cleanRpcError(err);
        console.error(`[sweep] rule ${rule.id} check error:`, cleaned);
        if (!this.errorThrottle.shouldLog(`${rule.id}:${cleaned}`)) continue;
        await logActivity({
          userId: rule.userId,
          level: "error",
          source: "sweep",
          message: `Sweep rule ${ruleLabel(rule)} error: ${cleaned}`,
        });
      }
      // Stagger rules by a few seconds to spread OpenSea requests.
      if (rules.length > 1) await sleep(rand(2_000, 4_000));
    }
  }

  /**
   * Plan gate: re-check the rule owner's entitlement every cycle so a
   * downgraded/expired user stops executing. Skips with one throttled info
   * log per user per hour. Returns true when execution may proceed.
   */
  private async assertPlanAllows(userId: number): Promise<boolean> {
    // Emergency kill switch — checked before the plan gate.
    if (await isHalted(userId)) {
      const last = this.planPausedLoggedAt.get(userId) ?? 0;
      if (Date.now() - last >= PLAN_PAUSED_LOG_INTERVAL_MS) {
        this.planPausedLoggedAt.set(userId, Date.now());
        await logActivity({
          userId,
          level: "warn",
          source: "sweep",
          message: "EMERGENCY STOP active — sweeper paused (release it from the top bar)",
        });
      }
      return false;
    }
    const user = await findUserById(userId);
    const ent = computeEntitlement(user ?? {});
    if (canExecute(ent, "sweep")) return true;
    const last = this.planPausedLoggedAt.get(userId) ?? 0;
    if (Date.now() - last >= PLAN_PAUSED_LOG_INTERVAL_MS) {
      this.planPausedLoggedAt.set(userId, Date.now());
      await logActivity({
        userId,
        level: "info",
        source: "sweep",
        message: "PRO plan required — execution paused (Upgrade tab)",
      });
    }
    return false;
  }

  private async checkRule(rule: SweepRule) {
    if (!(await this.assertPlanAllows(rule.userId))) return;

    // A key always resolves (user key → shared override → built-in shared).
    const { key: openseaKey } = await resolveOpenseaKey(rule.userId);

    const floor = await getFloorAsk(
      rule.chainId,
      rule.contractAddress,
      openseaKey,
    );

    if (!floor) {
      // No asks right now (or none returned) — still stamp the check time.
      await updateSweepRule(rule.userId, rule.id, { lastCheckedAt: new Date() });
      return;
    }

    const floorEth = Number(floor.priceEth);
    await updateSweepRule(rule.userId, rule.id, {
      lastFloorEth: floor.priceEth,
      lastCheckedAt: new Date(),
    });

    const decision = evaluateSweep(rule, floorEth);
    if (decision.kind === "skip") return;

    if (decision.kind === "auto-disable") {
      await updateSweepRule(rule.userId, rule.id, { enabled: false });
      await logActivity({
        userId: rule.userId,
        level: "warn",
        source: "sweep",
        message: `Sweep rule ${ruleLabel(rule)} auto-disabled: caps reached — ${decision.reason}`,
      });
      return;
    }

    if (!(await this.checkRarityGate(rule, openseaKey, floor))) return;

    await this.liveBuy(rule, openseaKey, floor);
  }

  /**
   * Rarity sniping (TraitSniper-style: only buy rare-at-floor). Runs after
   * the floor ask passes evaluateSweep and before buying. Only enforced
   * when the rule sets maxRarityRank AND the floor listing carries a token
   * id (criteria/collection-wide listings skip the check entirely).
   *
   * Semantics: rank known and > max → skip this listing (throttled info
   * log, 1/rule/10min); rank ≤ max → proceed. Rarity UNKNOWN (OpenSea
   * hasn't computed the rank yet, or only a local score is available —
   * scores aren't comparable to ranks) → proceed with a log line; missing
   * data must NEVER block a buy.
   */
  private async checkRarityGate(
    rule: SweepRule,
    openseaKey: string,
    floor: FloorAsk,
  ): Promise<boolean> {
    const max = rule.maxRarityRank;
    if (max === null || max === undefined || floor.tokenId === null) return true;

    const resolved = await resolveRarity(
      rule.chainId,
      rule.contractAddress,
      floor.tokenId,
      openseaKey,
    );
    const gate = passesRarityGate(resolved, max);

    if (gate === "skip" && resolved.kind === "rank") {
      const last = this.raritySkipLoggedAt.get(rule.id) ?? 0;
      if (Date.now() - last >= RARITY_SKIP_LOG_INTERVAL_MS) {
        this.raritySkipLoggedAt.set(rule.id, Date.now());
        await logActivity({
          userId: rule.userId,
          level: "info",
          source: "sweep",
          message:
            `Sweep rule ${ruleLabel(rule)}: floor #${floor.tokenId} rank ` +
            `${resolved.rank} > max ${max} — skipped (rarity gate)`,
        });
      }
      return false;
    }

    if (gate === "pass" && resolved.kind === "rank") {
      await logActivity({
        userId: rule.userId,
        level: "info",
        source: "sweep",
        message: `Sweep rule ${ruleLabel(rule)}: rarity gate passed: rank ${resolved.rank}`,
      });
    } else {
      // 'unknown' — rank not computed yet (pre/post-reveal) or only a
      // local trait score exists. Proceed; never block on missing data.
      await logActivity({
        userId: rule.userId,
        level: "info",
        source: "sweep",
        message: `Sweep rule ${ruleLabel(rule)}: rarity unknown for #${floor.tokenId} — proceeding`,
      });
    }
    return true;
  }

  // ---------- live execution ----------

  private async liveBuy(rule: SweepRule, openseaKey: string, floor: FloorAsk) {
    // The user's managed vault key is the signer for live sweeps. The key is
    // used server-side only and is NEVER logged — the address is.
    const privateKey = await getManagedPrivateKey(rule.userId);
    if (!privateKey) {
      if (!this.noKeyLogged.has(rule.userId)) {
        this.noKeyLogged.add(rule.userId);
        await logActivity({
          userId: rule.userId,
          level: "warn",
          source: "sweep",
          message:
            "Live sweep skipped: no managed vault key — check the Wallets tab",
        });
      }
      return;
    }

    const wallet = new ethers.Wallet(privateKey);
    const calldata = await getBuyCalldata(
      rule.chainId,
      floor.orderHash,
      floor.protocolAddress,
      wallet.address,
      openseaKey,
    );
    if (!calldata) {
      await logActivity({
        userId: rule.userId,
        level: "warn",
        source: "sweep",
        message: `Live sweep skipped for ${ruleLabel(rule)}: OpenSea returned no executable buy path`,
      });
      return;
    }

    const rpc = await resolveRpcForUser(rule.userId, rule.chainId);
    const provider = new ethers.JsonRpcProvider(rpc.url, rule.chainId);
    const signer = wallet.connect(provider);

    const fee = await provider.getFeeData();
    const tx = await signer.sendTransaction({
      to: calldata.to,
      data: calldata.data,
      value: BigInt(calldata.value),
      ...(fee.maxFeePerGas ? { maxFeePerGas: fee.maxFeePerGas } : {}),
      ...(fee.maxPriorityFeePerGas
        ? { maxPriorityFeePerGas: fee.maxPriorityFeePerGas }
        : {}),
    });
    const receipt = await tx.wait(1, RECEIPT_WAIT_MS);
    if (!receipt || receipt.status !== 1) {
      throw new Error(`sweep buy tx ${tx.hash} reverted`);
    }

    await this.recordBuy(rule, floor);
    const explorer = explorerTxUrl(rule.chainId, tx.hash);
    await logActivity({
      userId: rule.userId,
      level: "success",
      source: "sweep",
      message:
        `Swept ${ruleLabel(rule)} ${tokenLabel(floor)} @ ${floor.priceEth} ETH ` +
        `from vault ${wallet.address} — tx ${tx.hash}`,
      meta: {
        ruleId: rule.id,
        tokenId: floor.tokenId,
        txHash: tx.hash,
        live: true,
        ...(explorer ? { explorerUrl: explorer } : {}),
      },
    });
  }

  private async recordBuy(rule: SweepRule, floor: FloorAsk) {
    await updateSweepRule(rule.userId, rule.id, {
      boughtCount: rule.boughtCount + 1,
      spentEth: addEth(rule.spentEth, floor.priceEth),
    });
    // Track the swept NFT as an open position for the sell engine (TP/SL,
    // manual sell). Best-effort — never break the buy path.
    try {
      await insertPosition({
        userId: rule.userId,
        source: "sweep",
        refId: rule.id,
        chainId: rule.chainId,
        contractAddress: rule.contractAddress,
        tokenId: floor.tokenId,
        qty: 1,
        entryEth: entryEth10(floor.priceEth),
      });
    } catch (err) {
      console.warn(`[sweep] failed to record position for rule ${rule.id}:`, err);
    }
  }
}
