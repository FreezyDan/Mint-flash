/**
 * Endpoint health tracking for the RPC manager — pure, in-memory, no I/O.
 *
 * An endpoint is marked unhealthy when a raced probe gets a JSON-RPC error
 * response (code present), an HTTP error, or times out twice in a row.
 * Unhealthy endpoints are skipped by raceEndpoints/getBestRpc for 10 minutes;
 * entries simply expire (no background re-probe needed).
 */

export const UNHEALTHY_TTL_MS = 10 * 60_000;

const unhealthyUntil = new Map<string, number>();

/** Mark an endpoint unhealthy for `ttlMs` (default 10 min) from `now`. */
export function markUnhealthy(url: string, now = Date.now(), ttlMs = UNHEALTHY_TTL_MS): void {
  unhealthyUntil.set(url, now + ttlMs);
}

/** True when the endpoint is not currently marked unhealthy. */
export function isHealthy(url: string, now = Date.now()): boolean {
  const until = unhealthyUntil.get(url);
  if (until === undefined) return true;
  if (until <= now) {
    unhealthyUntil.delete(url);
    return true;
  }
  return false;
}

/**
 * Filter a pool down to healthy endpoints. When EVERY endpoint is unhealthy
 * the full pool is returned — a degraded endpoint beats no endpoint at all.
 */
export function healthyEndpoints(urls: readonly string[], now = Date.now()): string[] {
  const healthy = urls.filter((url) => isHealthy(url, now));
  return healthy.length > 0 ? healthy : [...urls];
}

/** Test helper: forget all health marks. */
export function resetEndpointHealth(): void {
  unhealthyUntil.clear();
}
