/**
 * Contract safety guard (competitor: Maestro anti-rug checks).
 *
 * Runs a battery of cheap static/on-chain probes against a mint contract
 * before a task is created or previewed:
 *   1. bytecode presence   — an EOA at the target address is a hard block
 *   2. bytecode size       — <200 bytes of runtime code is a hard block
 *   3. EIP-1967 proxy      — upgradeable proxies can swap logic later (warn)
 *   4. mint selectors      — no standard mint fn selector in bytecode (warn)
 *   5. OpenSea safelist    — disabled/unsafe/verified collection status
 *
 * Everything is best-effort: 8s aborts on all network calls and the guard
 * NEVER throws — a transport failure yields a warn-level report so task
 * creation degrades gracefully instead of breaking.
 */
import { ethers } from "ethers";
import { worstGuardLevel, type GuardCheck, type GuardReport } from "@contracts/guard";
import { openseaChainSlug, openseaFetch } from "./opensea";

const RPC_TIMEOUT_MS = 8_000;

/** Runtime bytecode below this size can't be a real NFT contract. */
export const MIN_BYTECODE_BYTES = 200;

/**
 * EIP-1967 storage slots. A proxy's runtime bytecode embeds these constants
 * (the fallback loads the implementation/beacon address from the slot), so
 * their presence in bytecode is a reliable proxy heuristic.
 */
const EIP1967_LOGIC_SLOT =
  "360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc";
const EIP1967_BEACON_SLOT =
  "a3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50";

/** Common mint function selectors (4-byte hex, no 0x) → human signature.
 *  Note: 6a627842 is the canonical mint(address) selector (often listed as
 *  the bare "mint" entry in selector tables). */
export const MINT_SELECTORS: Record<string, string> = {
  "40c10f19": "mint(address,uint256)",
  "a0712d68": "mint(uint256)",
  [ethers.id("publicMint(uint256)").slice(2, 10)]: "publicMint(uint256)",
  "6a627842": "mint(address)",
  "a1448194": "safeMint(address)",
};

export type GuardOpts = {
  chainId: number;
  contractAddress: string;
  rpcUrl: string;
  /** When provided, the OpenSea safelist check runs. */
  openseaKey?: string;
};

/** Lowercase hex without the 0x prefix; tolerates odd input. */
function codeHex(bytecode: string): string {
  return bytecode.toLowerCase().replace(/^0x/, "");
}

/** True when the address has any runtime code (empty/"0x" → EOA). */
export function hasBytecode(bytecode: string): boolean {
  return codeHex(bytecode).length > 0;
}

/** Runtime bytecode length in bytes. */
export function bytecodeBytes(bytecode: string): number {
  return codeHex(bytecode).length / 2;
}

/**
 * EIP-1967 proxy detection: true when the runtime bytecode embeds the logic
 * (implementation) or beacon storage-slot constant.
 */
export function detectProxy(bytecode: string): boolean {
  const code = codeHex(bytecode);
  if (code.length === 0) return false;
  return code.includes(EIP1967_LOGIC_SLOT) || code.includes(EIP1967_BEACON_SLOT);
}

/** Standard mint function signatures whose selectors appear in the bytecode. */
export function findMintSelectors(bytecode: string): string[] {
  const code = codeHex(bytecode);
  if (code.length === 0) return [];
  return Object.entries(MINT_SELECTORS)
    .filter(([selector]) => code.includes(selector))
    .map(([, signature]) => signature);
}

/* ------------------------------------------------------------------------- */
/* Network probes (all best-effort, 8s aborts)                               */
/* ------------------------------------------------------------------------- */

async function ethGetCode(rpcUrl: string, address: string): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), RPC_TIMEOUT_MS);
  try {
    const res = await fetch(rpcUrl, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_getCode",
        params: [address, "latest"],
      }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`RPC HTTP ${res.status}`);
    const body = (await res.json()) as { result?: string; error?: { message?: string } };
    if (body.error) throw new Error(body.error.message ?? "RPC error");
    return typeof body.result === "string" ? body.result : "0x";
  } finally {
    clearTimeout(timer);
  }
}

type OpenseaContractResponse = { collection?: string };
type OpenseaCollectionResponse = {
  safelist_status?: string;
  is_disabled?: boolean;
  is_nsfw?: boolean;
};

/** OpenSea safelist probe; any failure degrades to an ok "unavailable" check. */
async function openseaCheck(opts: GuardOpts): Promise<GuardCheck> {
  const name = "opensea";
  const chainSlug = openseaChainSlug(opts.chainId);
  if (!chainSlug) {
    return { name, level: "ok", detail: "chain not indexed by OpenSea — safelist check skipped" };
  }
  try {
    const contract = (await openseaFetch(
      `/v2/chain/${encodeURIComponent(chainSlug)}/contract/${encodeURIComponent(opts.contractAddress)}`,
      opts.openseaKey,
    )) as OpenseaContractResponse | null;
    const collectionSlug = contract?.collection;
    if (!collectionSlug) {
      return { name, level: "ok", detail: "no OpenSea collection found for this contract" };
    }
    const collection = (await openseaFetch(
      `/v2/collections/${encodeURIComponent(collectionSlug)}`,
      opts.openseaKey,
    )) as OpenseaCollectionResponse | null;
    if (collection?.is_disabled === true) {
      return {
        name,
        level: "danger",
        detail: `OpenSea disabled this collection (${collectionSlug}) — likely a scam or takedown`,
      };
    }
    if (collection?.is_nsfw === true) {
      return { name, level: "warn", detail: `OpenSea flags ${collectionSlug} as NSFW` };
    }
    const status = collection?.safelist_status;
    if (status === "verified" || status === "approved") {
      return { name, level: "ok", detail: `OpenSea safelisted (${status}) — ${collectionSlug}` };
    }
    if (status === "not_requested" || status === "unsafe") {
      return {
        name,
        level: "warn",
        detail: `OpenSea safelist status "${status}" for ${collectionSlug} — unvetted collection`,
      };
    }
    return {
      name,
      level: "ok",
      detail: `OpenSea collection ${collectionSlug} (safelist: ${status ?? "unknown"})`,
    };
  } catch {
    return { name, level: "ok", detail: "OpenSea lookup unavailable" };
  }
}

/**
 * Run the full guard battery. NEVER throws — a transport failure yields a
 * warn-level report so callers can decide how to degrade.
 */
export async function guardContract(opts: GuardOpts): Promise<GuardReport> {
  let bytecode: string;
  try {
    bytecode = await ethGetCode(opts.rpcUrl, opts.contractAddress);
  } catch (e) {
    return {
      level: "warn",
      checks: [
        {
          name: "rpc",
          level: "warn",
          detail: `contract guard unavailable — RPC error: ${(e as Error).message.slice(0, 160)}`,
        },
      ],
    };
  }

  // EOA at the target address: hard block, remaining checks are meaningless.
  if (!hasBytecode(bytecode)) {
    return {
      level: "danger",
      checks: [
        {
          name: "bytecode",
          level: "danger",
          detail: "not a contract — no code at this address on the selected chain",
        },
      ],
    };
  }

  const checks: GuardCheck[] = [];

  const bytes = bytecodeBytes(bytecode);
  checks.push(
    bytes < MIN_BYTECODE_BYTES
      ? {
          name: "bytecode-size",
          level: "danger",
          detail: `suspiciously small bytecode (${bytes} bytes) — likely a fake or bare forwarder`,
        }
      : { name: "bytecode-size", level: "ok", detail: `${bytes} bytes of runtime code` },
  );

  checks.push(
    detectProxy(bytecode)
      ? {
          name: "proxy",
          level: "warn",
          detail: "upgradeable proxy — logic can change after you snipe",
        }
      : { name: "proxy", level: "ok", detail: "no EIP-1967 proxy pattern in bytecode" },
  );

  const mintFns = findMintSelectors(bytecode);
  checks.push(
    mintFns.length === 0
      ? {
          name: "mint-selector",
          level: "warn",
          detail: "no standard mint selector in bytecode — verify the mint function manually",
        }
      : { name: "mint-selector", level: "ok", detail: `mint entry points: ${mintFns.join(", ")}` },
  );

  if (opts.openseaKey) {
    checks.push(await openseaCheck(opts));
  }

  return { level: worstGuardLevel(checks), checks };
}
