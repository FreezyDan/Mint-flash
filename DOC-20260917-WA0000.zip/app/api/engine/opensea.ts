/**
 * OpenSea API v2 client — Seaport orderbook floor data + buy execution
 * calldata. Listings live off-chain (Seaport orders) until filled; OpenSea
 * indexes them into a REST API. An API key is REQUIRED (free tier covers
 * ~45s polling) — callers pass the user's key from settings.
 *
 * All fetches use an 8s abort timeout and throw clear errors:
 *  - 401/403 → "Invalid or missing OpenSea API key — add one in Settings"
 *  - 429     → "OpenSea rate-limited — the sweeper will retry next cycle"
 * Callers that treat missing data as non-fatal get `null` returns; hard
 * transport failures throw.
 */

const BASE_URL = "https://api.opensea.io";

const CHAIN_SLUGS: Record<number, string> = {
  1: "ethereum",
  8453: "base",
  42161: "arbitrum",
  137: "polygon",
  4663: "robinhood",
  57073: "ink",
  // OpenSea supports Arc from mainnet day one (2026-09-16).
  5042: "arc",
};

/**
 * Decimals of the ERC20 token Seaport OFFERS are paid in, per chain id
 * (default 18 — WETH). On Arc, offers are paid in USDC
 * (0x3600…0000, 6 decimals — verified against live OrderFulfilled logs),
 * while native listings are 18-decimal like everywhere else. Offer prices
 * must be scaled ×10^12 to sit on the same 18dp scale as entry prices.
 */
const OFFER_PAYMENT_DECIMALS: Record<number, number> = {
  5042: 6,
};

/** ERC20 payment-token address for offers, per chain id (Arc USDC). */
const OFFER_PAYMENT_TOKEN: Record<number, string> = {
  5042: "0x3600000000000000000000000000000000000000",
};

/** Scale a raw payment amount (smallest unit) to 18dp wei-equivalent. */
function paymentToWei(amount: bigint, decimals: number): bigint {
  if (decimals > 18) return amount / 10n ** BigInt(decimals - 18);
  if (decimals < 18) return amount * 10n ** BigInt(18 - decimals);
  return amount;
}

const REQUEST_TIMEOUT_MS = 8_000;

/** OpenSea chain slug for a chain id, or null when OpenSea has no coverage. */
export function openseaChainSlug(chainId: number): string | null {
  return CHAIN_SLUGS[chainId] ?? null;
}

/** Chain id for an OpenSea chain slug (events API), or null when unknown. */
export function openseaChainIdFromSlug(slug: string): number | null {
  for (const [id, s] of Object.entries(CHAIN_SLUGS)) {
    if (s === slug) return Number(id);
  }
  // Legacy "matic" slug is kept alive for older integrations.
  if (slug === "matic") return 137;
  return null;
}

/** True when floor sweeping is supported on this chain id. */
export function isSweepSupportedChain(chainId: number): boolean {
  return openseaChainSlug(chainId) !== null;
}

export async function openseaFetch(
  path: string,
  apiKey: string | null | undefined,
  init?: RequestInit,
): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const headers: Record<string, string> = { accept: "application/json" };
    if (apiKey) headers["x-api-key"] = apiKey;
    const res = await fetch(`${BASE_URL}${path}`, {
      ...init,
      headers: { ...headers, ...(init?.headers as Record<string, string> | undefined) },
      signal: controller.signal,
    });
    if (res.status === 401 || res.status === 403) {
      throw new Error("Invalid or missing OpenSea API key — add one in Settings");
    }
    if (res.status === 429) {
      throw new Error("OpenSea rate-limited — the sweeper will retry next cycle");
    }
    if (!res.ok) {
      throw new Error(`OpenSea request failed (${res.status})`);
    }
    return await res.json();
  } catch (err) {
    if (err instanceof Error && err.name === "AbortError") {
      throw new Error("OpenSea request timed out");
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

export type FloorAsk = {
  /** Token id of the cheapest listing, or null for collection-wide offers. */
  tokenId: string | null;
  /** Total listing price in ETH, decimal string. */
  priceEth: string;
  /** Seaport order hash — identifies the listing for fulfillment. */
  orderHash: string;
  /** Seaport protocol contract address for the listing's chain. */
  protocolAddress: string;
};

type OfferItem = { identifierOrCriteria?: string | number };
type ConsiderationItem = {
  token?: string;
  startAmount?: string | number;
  endAmount?: string | number;
  recipient?: string;
};
type SeaportOrder = {
  order_hash?: string;
  protocol_address?: string;
  current_price?: string | number;
  maker?: { address?: string };
  protocol_data?: {
    parameters?: {
      offerer?: string;
      offer?: OfferItem[];
      consideration?: ConsiderationItem[];
    };
  };
};

/** Cheapest listing for a slug; throws on hard failures. */
async function fetchFloorOrder(
  slug: string,
  contractAddress: string,
  apiKey?: string | null,
): Promise<SeaportOrder | null> {
  const path =
    `/v2/orders/${encodeURIComponent(slug)}/seaport/listings` +
    `?asset_contract_address=${encodeURIComponent(contractAddress)}` +
    `&order_by=eth_price&order_direction=asc&limit=1`;
  const body = (await openseaFetch(path, apiKey)) as { orders?: SeaportOrder[] };
  return body.orders?.[0] ?? null;
}

/**
 * Cheapest active listing for a contract on a chain. Returns null when the
 * chain is unsupported or the collection has no listings.
 */
export async function getFloorAsk(
  chainId: number,
  contractAddress: string,
  apiKey?: string | null,
): Promise<FloorAsk | null> {
  let slug = openseaChainSlug(chainId);
  if (!slug) return null;

  let order: SeaportOrder | null;
  try {
    order = await fetchFloorOrder(slug, contractAddress, apiKey);
  } catch (err) {
    // The legacy "matic" slug is kept alive for older integrations — retry
    // once when the canonical "polygon" slug is rejected as unknown.
    if (
      slug === "polygon" &&
      err instanceof Error &&
      /\((404|400)\)/.test(err.message)
    ) {
      slug = "matic";
      order = await fetchFloorOrder(slug, contractAddress, apiKey);
    } else {
      throw err;
    }
  }
  if (!order?.order_hash || !order.protocol_address) return null;

  // Prefer the documented current_price field (wei); fall back to summing
  // native-currency consideration items paying the offerer.
  let priceWei: bigint | null = null;
  if (order.current_price !== undefined && order.current_price !== null) {
    try {
      priceWei = BigInt(order.current_price);
    } catch {
      priceWei = null;
    }
  }
  if (priceWei === null) {
    const params = order.protocol_data?.parameters;
    const offerer = params?.offerer?.toLowerCase();
    priceWei = (params?.consideration ?? [])
      .filter((c) => {
        const recipient = c.recipient?.toLowerCase();
        return (
          c.token === "0x0000000000000000000000000000000000000000" &&
          !!offerer &&
          recipient === offerer
        );
      })
      .reduce((sum, c) => {
        try {
          return sum + BigInt(c.endAmount ?? c.startAmount ?? 0);
        } catch {
          return sum;
        }
      }, 0n);
  }
  if (priceWei <= 0n) return null;

  const offer = order.protocol_data?.parameters?.offer;
  const identifier = offer?.[0]?.identifierOrCriteria;
  const tokenId = identifier !== undefined && identifier !== null ? String(identifier) : null;

  return {
    tokenId,
    priceEth: weiToEth(priceWei),
    orderHash: order.order_hash,
    protocolAddress: order.protocol_address,
  };
}

/** wei (bigint) → ETH decimal string with full precision, no trailing zeros. */
function weiToEth(wei: bigint): string {
  const whole = wei / 1_000_000_000_000_000_000n;
  const frac = (wei % 1_000_000_000_000_000_000n).toString().padStart(18, "0").replace(/0+$/, "");
  return frac ? `${whole}.${frac}` : whole.toString();
}

export type BuyCalldata = {
  to: string;
  data: string;
  /** Native value in wei (decimal string). */
  value: string;
};

type FulfillmentResponse = {
  fulfillment_data?: {
    transaction?: {
      to?: string;
      data?: string;
      value?: string | number;
    };
  };
};

/**
 * Execution calldata for fulfilling the Seaport listing `orderHash` as
 * `fulfillerAddress`. Extracts the transaction from
 * POST /v2/listings/fulfillment_data. Returns null when the chain is
 * unsupported or no fulfillment data is returned; transport failures throw.
 */
export async function getBuyCalldata(
  chainId: number,
  orderHash: string,
  protocolAddress: string,
  fulfillerAddress: string,
  apiKey?: string | null,
): Promise<BuyCalldata | null> {
  const slug = openseaChainSlug(chainId);
  if (!slug) return null;

  const body = (await openseaFetch("/v2/listings/fulfillment_data", apiKey, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      listing: { hash: orderHash, chain: slug, protocol_address: protocolAddress },
      fulfiller: { address: fulfillerAddress },
    }),
  })) as FulfillmentResponse;

  const tx = body.fulfillment_data?.transaction;
  if (!tx?.to || !tx?.data) return null;
  return {
    to: tx.to,
    data: tx.data,
    value: hexOrDecimalToDecimalString(tx.value ?? "0"),
  };
}

export type BestOffer = {
  /** Highest bid in ETH, decimal string. */
  priceEth: string;
  /** Seaport order hash — identifies the offer for fulfillment. */
  orderHash: string;
  /** Seaport protocol contract address for the offer's chain. */
  protocolAddress: string;
};

/** Highest active offer for a slug; throws on hard failures. */
async function fetchBestOfferOrder(
  slug: string,
  contractAddress: string,
  apiKey?: string | null,
): Promise<SeaportOrder | null> {
  const path =
    `/v2/orders/${encodeURIComponent(slug)}/seaport/offers` +
    `?asset_contract_address=${encodeURIComponent(contractAddress)}` +
    `&order_by=eth_price&order_direction=desc&limit=1`;
  const body = (await openseaFetch(path, apiKey)) as { orders?: SeaportOrder[] };
  return body.orders?.[0] ?? null;
}

/**
 * Highest active collection offer (bid) for a contract on a chain — the
 * price the vault can sell into right now. Returns null when the chain is
 * unsupported or the collection has no offers; transport failures throw.
 */
export async function getBestOffer(
  chainId: number,
  contractAddress: string,
  apiKey?: string | null,
): Promise<BestOffer | null> {
  let slug = openseaChainSlug(chainId);
  if (!slug) return null;

  let order: SeaportOrder | null;
  try {
    order = await fetchBestOfferOrder(slug, contractAddress, apiKey);
  } catch (err) {
    // Same legacy "matic" fallback as getFloorAsk.
    if (
      slug === "polygon" &&
      err instanceof Error &&
      /\((404|400)\)/.test(err.message)
    ) {
      slug = "matic";
      order = await fetchBestOfferOrder(slug, contractAddress, apiKey);
    } else {
      throw err;
    }
  }
  if (!order?.order_hash || !order.protocol_address) return null;

  // Same price-parsing discipline as getFloorAsk: documented current_price
  // (smallest unit of the payment currency) first, then the payment items
  // paying the offerer. For offers the payment side sits in the offer items
  // (the bidder is the offerer) and is ERC20 on every chain — the chain's
  // offer payment token (WETH 18dp; USDC 6dp on Arc) is normalised to 18dp.
  const offerDecimals = OFFER_PAYMENT_DECIMALS[chainId] ?? 18;
  const offerToken = OFFER_PAYMENT_TOKEN[chainId]?.toLowerCase() ?? null;
  let priceWei: bigint | null = null;
  if (order.current_price !== undefined && order.current_price !== null) {
    try {
      priceWei = paymentToWei(BigInt(order.current_price), offerDecimals);
    } catch {
      priceWei = null;
    }
  }
  if (priceWei === null) {
    const params = order.protocol_data?.parameters;
    const offerer = params?.offerer?.toLowerCase();
    priceWei = (params?.offer ?? [])
      .filter((o) => {
        const c = o as OfferItem & ConsiderationItem;
        const token = c.token?.toLowerCase();
        return (
          !!offerer &&
          (token === "0x0000000000000000000000000000000000000000" ||
            (offerToken !== null && token === offerToken))
        );
      })
      .reduce((sum, o) => {
        const c = o as OfferItem & ConsiderationItem;
        const isNative = c.token === "0x0000000000000000000000000000000000000000";
        try {
          const raw = BigInt(c.endAmount ?? c.startAmount ?? 0);
          return sum + (isNative ? raw : paymentToWei(raw, offerDecimals));
        } catch {
          return sum;
        }
      }, 0n);
  }
  if (priceWei <= 0n) return null;

  return {
    priceEth: weiToEth(priceWei),
    orderHash: order.order_hash,
    protocolAddress: order.protocol_address,
  };
}

/**
 * Execution calldata for ACCEPTING (fulfilling) the Seaport offer
 * `orderHash` as `fulfillerAddress` — i.e. selling the NFT into the bid.
 * Extracts the transaction from POST /v2/offers/fulfillment_data.
 *
 * Criteria-offer handling (documented v2 shape): collection-wide / trait
 * offers have no fixed token identifier, so the fulfiller must tell OpenSea
 * WHICH token it is selling. The v2 request accepts a top-level
 * `consideration: { asset_contract_address, token_id }` object for exactly
 * this (same field the listings endpoint uses). `tokenId`/`contractAddress`
 * are therefore optional here but REQUIRED in practice for criteria offers —
 * pass them whenever they are known. The response transaction keeps the
 * documented `to`/`data`/`value` shape (hex or decimal `value`, normalised
 * like buys); some responses additionally embed a decoded Seaport struct
 * under `transaction.input_data`, which we do not need since `data` is the
 * ready-to-send calldata.
 */
export async function getSellCalldata(
  chainId: number,
  orderHash: string,
  protocolAddress: string,
  fulfillerAddress: string,
  apiKey?: string | null,
  tokenId?: string | null,
  contractAddress?: string | null,
): Promise<BuyCalldata | null> {
  const slug = openseaChainSlug(chainId);
  if (!slug) return null;

  const body = (await openseaFetch("/v2/offers/fulfillment_data", apiKey, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      offer: { hash: orderHash, chain: slug, protocol_address: protocolAddress },
      fulfiller: { address: fulfillerAddress },
      // Required by OpenSea when the offer is criteria/collection-wide so the
      // Seaport criteria proof is resolved for the specific token sold.
      ...(tokenId != null && contractAddress != null
        ? {
            consideration: {
              asset_contract_address: contractAddress,
              token_id: tokenId,
            },
          }
        : {}),
    }),
  })) as FulfillmentResponse;

  const tx = body.fulfillment_data?.transaction;
  if (!tx?.to || !tx?.data) return null;
  return {
    to: tx.to,
    data: tx.data,
    value: hexOrDecimalToDecimalString(tx.value ?? "0"),
  };
}

type AccountNft = { identifier?: string | number; contract?: string };

/**
 * First token id in `contractAddress` currently owned by `ownerAddress`,
 * via the account-NFTs endpoint (GET /v2/chain/{slug}/account/{addr}/nfts).
 * Used to fill in positions recorded without a token id (e.g. mints).
 * Returns null when the vault holds nothing in that collection.
 */
export async function getOwnedTokenId(
  chainId: number,
  contractAddress: string,
  ownerAddress: string,
  apiKey?: string | null,
): Promise<string | null> {
  const slug = openseaChainSlug(chainId);
  if (!slug) return null;
  const path =
    `/v2/chain/${encodeURIComponent(slug)}/account/${encodeURIComponent(ownerAddress)}/nfts` +
    `?limit=50`;
  const body = (await openseaFetch(path, apiKey)) as { nfts?: AccountNft[] };
  const target = contractAddress.toLowerCase();
  for (const nft of body.nfts ?? []) {
    if (
      nft.contract?.toLowerCase() === target &&
      nft.identifier !== undefined &&
      nft.identifier !== null
    ) {
      return String(nft.identifier);
    }
  }
  return null;
}

/** OpenSea returns `value` as a hex string; normalise to a decimal string. */
function hexOrDecimalToDecimalString(v: string | number): string {
  if (typeof v === "number") return String(v);
  const trimmed = v.trim();
  try {
    return trimmed.startsWith("0x") ? BigInt(trimmed).toString() : trimmed;
  } catch {
    return trimmed;
  }
}
