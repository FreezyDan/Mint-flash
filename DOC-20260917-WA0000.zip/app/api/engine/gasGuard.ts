/**
 * Gas guard — pure decision logic for "is the network too expensive to
 * fire right now?". The mint engine evaluates this before every live
 * broadcast attempt; a negative verdict holds fire (never fails the task)
 * because gas may drop on the next poll cycle.
 *
 * Effective cap: the task's own `maxMaxFeeGwei` wins when set; otherwise
 * the global `user_settings.maxGasGwei`. When neither is set the guard is
 * disabled (always ok).
 */

export type GasGuardOpts = {
  /** Current network max fee (EIP-1559 maxFeePerGas) in gwei. */
  maxFeeGwei: number;
  /** Current network priority fee in gwei (informational). */
  priorityGwei: number;
  /** Per-task ceiling (mint_tasks.maxMaxFeeGwei); null when unset. */
  taskMaxMaxFeeGwei: number | null;
  /** Global ceiling (user_settings.maxGasGwei); null when unset. */
  globalMaxGasGwei: number | null;
};

export type GasGuardVerdict = {
  ok: boolean;
  /** e.g. "gas 612.5 gwei above cap 500 gwei" — present iff ok is false. */
  reason?: string;
};

/** Trim to at most 2 decimals, dropping trailing zeros ("612.5", "500"). */
export function formatGwei(v: number): string {
  return String(Number(v.toFixed(2)));
}

/** The cap that actually applies: task ceiling beats the global ceiling. */
export function effectiveCapGwei(
  taskMaxMaxFeeGwei: number | null,
  globalMaxGasGwei: number | null,
): number | null {
  return taskMaxMaxFeeGwei ?? globalMaxGasGwei;
}

export function evaluateGas(opts: GasGuardOpts): GasGuardVerdict {
  const cap = effectiveCapGwei(opts.taskMaxMaxFeeGwei, opts.globalMaxGasGwei);
  if (cap === null) return { ok: true };
  if (opts.maxFeeGwei > cap) {
    return {
      ok: false,
      reason: `gas ${formatGwei(opts.maxFeeGwei)} gwei above cap ${formatGwei(cap)} gwei`,
    };
  }
  return { ok: true };
}
