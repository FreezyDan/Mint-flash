/**
 * Historical token→ETH price oracle backed by the DefiLlama coins API
 * (free, no API key):
 *
 *   GET https://coins.llama.fi/prices/historical/{unixTs}/{coin},{coin}…
 *
 * where coins are `{chainPrefix}:{tokenAddress}` (comma-batched, ≤25 per
 * call) and ETH's own USD price is resolved via `coingecko:ethereum` in the
 * same batch. Conversion for a token-denominated sale:
 *
 *   usd = tokenAmount × tokenUsd(at hour)      eth = usd ÷ ethUsd(at hour)
 *
 * Fallback chain for any (chain, token, hour) the historical endpoint
 * misses (Robinhood Chain has NO historical coverage — `robinhood:` there
 * returns `{}` — but the CURRENT endpoint does price its tokens):
 *
 *   1. historical price at the sale hour (exact);
 *   2. CURRENT price `GET /prices/current/{prefix}:{token}` (≤25 per call),
 *      trying the chain's own prefix first, then — for Robinhood only —
 *      `ethereum:` for tokens in a small built-in canonical-address map.
 *      Conversion uses CURRENT token USD × HISTORICAL ETH USD at the sale
 *      hour (the ETH historical price exists), flagged `approx: true`;
 *   3. null → the profiler marks the sale unpriced (never zero).
 *
 * `closing_date` is rounded DOWN to the hour for cache efficiency; results
 * are cached per resolver (`{coinKey}:{hourTs}`) and misses are
 * negative-cached for 1h so a dead oracle is never hammered.
 *
 * Usage is per profiling run: `request(…)` every non-native payment while
 * parsing events, `await resolve()` once (batched, ~15s total budget, 6s
 * per-request abort, ≤2 retries), then `get(…)` synchronously during FIFO
 * pairing. Oracle outages are non-fatal — unresolved sales come back null
 * and the profiler marks them unpriced (never zero-profit).
 *
 * All math is bigint fixed-point: token amounts are 18dp fixed (wei-style),
 * USD prices are scaled by 1e12, so ethWei = tokenWei × tokenUsd / ethUsd
 * with no floating-point noise in the pairing math.
 */

/** DefiLlama coins chain prefix per EVM chain id. */
const LLAMA_PREFIX: Record<number, string> = {
  1: "ethereum",
  8453: "base",
  42161: "arbitrum",
  137: "polygon",
  57073: "ink", // confirmed against the DefiLlama chain list
  5042: "arc", // confirmed live 2026-09-17 (historical + current USDC)
  // 4663 Robinhood Chain: no HISTORICAL DefiLlama coverage ("robinhood:"
  // returns {} there) → tokens on it fall through to the current-price
  // fallback below (CURRENT does price `robinhood:` coins, e.g. USDG).
};

/**
 * Chain prefixes tried against the CURRENT-price endpoint when historical
 * pricing misses. Same as LLAMA_PREFIX plus Robinhood, whose current prices
 * exist even though its history doesn't.
 */
const CURRENT_PREFIX: Record<number, string> = { ...LLAMA_PREFIX, 4663: "robinhood" };

/**
 * Known canonical Robinhood Chain tokens → their Ethereum-mainnet twin, for
 * the second current-price candidate (`ethereum:`) when the `robinhood:`
 * prefix itself has no quote. Keys/values lowercased.
 * USDG: Paxos Global Dollar — Robinhood `0x5fc5…d168` ↔ Ethereum proxy
 * `0xe343…491D` (Paxos deployment record).
 */
const ROBINHOOD_CANONICAL: Record<string, string> = {
  "0x5fc5360d0400a0fd4f2af552add042d716f1d168":
    "0xe343167631d89b6ffc58b88d6b7fb0228795491d",
};

const BASE_URL = "https://coins.llama.fi";
/** ETH's own USD price, resolved alongside token prices in every batch. */
const ETH_COIN = "coingecko:ethereum";
const MAX_COINS_PER_CALL = 25;
const REQUEST_TIMEOUT_MS = 6_000;
const MAX_RETRIES = 2;
const RETRY_DELAY_MS = 300;
const RESOLVE_BUDGET_MS = 15_000;
const NEGATIVE_TTL_MS = 60 * 60 * 1000;
const CONCURRENCY = 4;
const USD_SCALE = 10n ** 12n;
const FIXED18 = 10n ** 18n;

export type CoinPrice = {
  priceUsd: number;
  decimals: number | null;
  symbol: string | null;
};

export type OracleConversion = {
  /** ETH value in wei (bigint) — exact, for FIFO/pairing math. */
  ethWei: bigint;
  /** ETH value as a 10dp-truncated decimal string (formatEth10 style). */
  eth: string;
  /** USD value as a 2dp-truncated decimal string. */
  usd: string;
  /**
   * True when the token leg came from the CURRENT-price fallback (nearest
   * available rate) instead of a historical price at the sale hour.
   */
  approx: boolean;
};

/** Injectable price fetcher — tests stub this; production uses fetch. */
export type PriceFetcher = (url: string, signal: AbortSignal) => Promise<unknown>;

const defaultFetcher: PriceFetcher = async (url, signal) => {
  const res = await fetch(url, { signal, headers: { accept: "application/json" } });
  if (!res.ok) throw new Error(`DefiLlama request failed (${res.status})`);
  return res.json();
};

/** DefiLlama coin key for a token, or null when the chain has no coverage. */
export function llamaCoinKey(chainId: number, tokenAddress: string): string | null {
  const prefix = LLAMA_PREFIX[chainId];
  if (!prefix) return null;
  const addr = tokenAddress.toLowerCase();
  return addr.startsWith("0x") && addr.length === 42 ? `${prefix}:${addr}` : null;
}

/**
 * Ordered CURRENT-price coin-key candidates for the historical-miss
 * fallback: the chain's own prefix first; for Robinhood also `ethereum:`
 * when the token is in the canonical-address map. Empty when no candidate
 * exists (then the sale stays unpriced).
 */
export function currentCoinCandidates(chainId: number, tokenAddress: string): string[] {
  const addr = tokenAddress.toLowerCase();
  if (!addr.startsWith("0x") || addr.length !== 42) return [];
  const out: string[] = [];
  const prefix = CURRENT_PREFIX[chainId];
  if (prefix) out.push(`${prefix}:${addr}`);
  if (chainId === 4663) {
    const canonical = ROBINHOOD_CANONICAL[addr];
    if (canonical) out.push(`ethereum:${canonical}`);
  }
  return out;
}

/** Round a unix-second timestamp DOWN to the hour (cache key granularity). */
export function hourFloor(ts: number): number {
  return Math.floor(ts / 3600) * 3600;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Validate a DefiLlama coin entry: price must be a finite number > 0. */
function parseCoin(raw: unknown): CoinPrice | null {
  const c = raw as { price?: unknown; decimals?: unknown; symbol?: unknown } | null;
  const price = typeof c?.price === "number" ? c.price : NaN;
  if (!Number.isFinite(price) || price <= 0) return null;
  return {
    priceUsd: price,
    decimals:
      typeof c?.decimals === "number" && Number.isInteger(c.decimals) && c.decimals >= 0
        ? c.decimals
        : null,
    symbol: typeof c?.symbol === "string" ? c.symbol : null,
  };
}

/** Float USD price → bigint scaled by `scale`, via string fixed-point. */
function floatToScaled(value: number, scale: bigint): bigint | null {
  if (!Number.isFinite(value) || value <= 0) return null;
  const dp = scale.toString().length - 1;
  const scaled = BigInt(value.toFixed(dp).replace(".", ""));
  return scaled > 0n ? scaled : null;
}

/** 18dp fixed-point bigint → decimal string truncated to `dp` places. */
function formatFixed18(v: bigint, dp: number): string {
  const neg = v < 0n;
  const abs = neg ? -v : v;
  const whole = abs / FIXED18;
  const frac = (abs % FIXED18) / 10n ** BigInt(18 - dp);
  return `${neg ? "-" : ""}${whole}.${frac.toString().padStart(dp, "0")}`;
}

export type PriceResolver = {
  /**
   * Register a (token, hour) pair to resolve; no-op when neither the
   * historical nor the current-price endpoint can address the token.
   */
  request(chainId: number, tokenAddress: string, closingTs: number): void;
  /**
   * Resolve all registered pairs: batched historical calls first, then a
   * batched CURRENT-price call for whatever history missed. Never throws.
   */
  resolve(): Promise<void>;
  /**
   * Convert a token amount (18dp fixed-point) to ETH/USD using the prices
   * fetched by resolve(). Returns null when either price is unavailable.
   */
  get(
    chainId: number,
    tokenAddress: string,
    tokenAmountWei: bigint,
    closingTs: number,
  ): OracleConversion | null;
  /**
   * Oracle-reported token decimals (fallback when OpenSea omits them) —
   * historical entry first, then the current-price fallback entry.
   */
  decimals(chainId: number, tokenAddress: string, closingTs: number): number | null;
};

export function createPriceResolver(opts: {
  fetcher?: PriceFetcher;
  budgetMs?: number;
} = {}): PriceResolver {
  const fetcher = opts.fetcher ?? defaultFetcher;
  const budgetMs = opts.budgetMs ?? RESOLVE_BUDGET_MS;
  /** Registered pairs awaiting resolve(). Key: `{chainId}:{token}@{hourTs}`. */
  const pending = new Map<
    string,
    { chainId: number; token: string; coin: string | null; hourTs: number }
  >();
  /** Resolved historical prices (1h-TTL negatives). Key: `{coin}@{hourTs}`. */
  const cache = new Map<string, { price: CoinPrice | null; at: number }>();
  /** Resolved CURRENT prices (1h-TTL negatives). Key: `{coin}` (no hour). */
  const currentCache = new Map<string, { price: CoinPrice | null; at: number }>();

  function request(chainId: number, tokenAddress: string, closingTs: number): void {
    const coin = llamaCoinKey(chainId, tokenAddress);
    // Register when historical coverage exists OR a current-price fallback
    // candidate does (e.g. Robinhood tokens via `robinhood:` current).
    if (!coin && currentCoinCandidates(chainId, tokenAddress).length === 0) return;
    const token = tokenAddress.toLowerCase();
    const key = `${chainId}:${token}@${hourFloor(closingTs)}`;
    if (!pending.has(key)) {
      pending.set(key, { chainId, token, coin, hourTs: hourFloor(closingTs) });
    }
  }

  async function fetchBatch(hourTs: number, coins: string[], deadline: number): Promise<void> {
    const url = `${BASE_URL}/prices/historical/${hourTs}/${coins.join(",")}`;
    let body: unknown = null;
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      if (Date.now() > deadline) break;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
      try {
        body = await fetcher(url, controller.signal);
        break;
      } catch {
        body = null;
        if (attempt < MAX_RETRIES) await sleep(RETRY_DELAY_MS);
      } finally {
        clearTimeout(timer);
      }
    }
    const coinsBody = (body as { coins?: Record<string, unknown> } | null)?.coins ?? {};
    for (const coin of coins) {
      cache.set(`${coin}@${hourTs}`, { price: parseCoin(coinsBody[coin]), at: Date.now() });
    }
  }

  /**
   * Batched CURRENT-price call (fallback step). Same abort/retry/deadline
   * discipline as fetchBatch; results (incl. negatives) land in currentCache.
   */
  async function fetchCurrentBatch(coins: string[], deadline: number): Promise<void> {
    const url = `${BASE_URL}/prices/current/${coins.join(",")}`;
    let body: unknown = null;
    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      if (Date.now() > deadline) break;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
      try {
        body = await fetcher(url, controller.signal);
        break;
      } catch {
        body = null;
        if (attempt < MAX_RETRIES) await sleep(RETRY_DELAY_MS);
      } finally {
        clearTimeout(timer);
      }
    }
    const coinsBody = (body as { coins?: Record<string, unknown> } | null)?.coins ?? {};
    for (const coin of coins) {
      currentCache.set(coin, { price: parseCoin(coinsBody[coin]), at: Date.now() });
    }
  }

  async function resolve(): Promise<void> {
    const deadline = Date.now() + budgetMs;
    // ---- Phase A: historical. Group uncached coins by hour; ETH's own USD
    // price rides every batch. Hours that only need the current-price
    // fallback still need ETH's HISTORICAL price (for the conversion), so
    // they get an ETH-only job when ETH isn't already cached for that hour.
    const byHour = new Map<number, Set<string>>();
    const hourNeedsEth = new Set<number>();
    for (const { coin, hourTs } of pending.values()) {
      let set = byHour.get(hourTs);
      if (!set) {
        set = new Set();
        byHour.set(hourTs, set);
      }
      if (coin !== null) {
        const hit = cache.get(`${coin}@${hourTs}`);
        if (hit && (hit.price !== null || Date.now() - hit.at < NEGATIVE_TTL_MS)) {
          if (hit.price === null) hourNeedsEth.add(hourTs); // fallback will need ETH
          continue;
        }
        set.add(coin);
      } else {
        hourNeedsEth.add(hourTs); // no historical prefix at all (e.g. robinhood)
      }
    }
    const jobs: Array<{ hourTs: number; coins: string[] }> = [];
    for (const [hourTs, coins] of byHour) {
      const ethHit = cache.get(`${ETH_COIN}@${hourTs}`);
      const ethCached =
        ethHit !== undefined &&
        (ethHit.price !== null || Date.now() - ethHit.at < NEGATIVE_TTL_MS);
      if (coins.size === 0 && (!hourNeedsEth.has(hourTs) || ethCached)) continue;
      coins.add(ETH_COIN);
      // ≤25 coins per call; ETH's USD price always rides the first chunk.
      const arr = [ETH_COIN, ...[...coins].filter((c) => c !== ETH_COIN)];
      for (let i = 0; i < arr.length; i += MAX_COINS_PER_CALL) {
        jobs.push({ hourTs, coins: arr.slice(i, i + MAX_COINS_PER_CALL) });
      }
    }
    let idx = 0;
    const worker = async () => {
      while (idx < jobs.length && Date.now() <= deadline) {
        const job = jobs[idx++];
        await fetchBatch(job.hourTs, job.coins, deadline);
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, jobs.length) }, worker));

    // ---- Phase B: current-price fallback for whatever history missed.
    // All uncached candidates are fetched in one batched round (≤25 per
    // call); get() then walks each token's candidates in prefix order.
    const wanted = new Set<string>();
    for (const { chainId, token, coin, hourTs } of pending.values()) {
      if (coin !== null && cache.get(`${coin}@${hourTs}`)?.price) continue;
      for (const cand of currentCoinCandidates(chainId, token)) {
        const hit = currentCache.get(cand);
        if (hit && (hit.price !== null || Date.now() - hit.at < NEGATIVE_TTL_MS)) continue;
        wanted.add(cand);
      }
    }
    const arr = [...wanted];
    let cidx = 0;
    const cworker = async () => {
      while (cidx < arr.length && Date.now() <= deadline) {
        const chunk = arr.slice(cidx, (cidx += MAX_COINS_PER_CALL));
        await fetchCurrentBatch(chunk, deadline);
      }
    };
    await Promise.all(
      Array.from({ length: Math.min(CONCURRENCY, Math.ceil(arr.length / MAX_COINS_PER_CALL)) }, cworker),
    );
    pending.clear();
  }

  function priceOf(coin: string, closingTs: number): CoinPrice | null {
    return cache.get(`${coin}@${hourFloor(closingTs)}`)?.price ?? null;
  }

  /** Shared fixed-point conversion: tokenWei × tokenUsd ÷ ethUsd. */
  function convertAmount(
    tokenAmountWei: bigint,
    tokenUsd: number,
    ethUsdScaled: bigint,
    approx: boolean,
  ): OracleConversion | null {
    const tokenUsdScaled = floatToScaled(tokenUsd, USD_SCALE);
    if (!tokenUsdScaled) return null;
    // ethWei = tokenWei × tokenUsd / ethUsd (the 1e12 scales cancel).
    const ethWei = (tokenAmountWei * tokenUsdScaled) / ethUsdScaled;
    const usdFixed = (tokenAmountWei * tokenUsdScaled) / USD_SCALE;
    return { ethWei, eth: formatFixed18(ethWei, 10), usd: formatFixed18(usdFixed, 2), approx };
  }

  function get(
    chainId: number,
    tokenAddress: string,
    tokenAmountWei: bigint,
    closingTs: number,
  ): OracleConversion | null {
    if (tokenAmountWei < 0n) return null;
    // ETH's HISTORICAL USD price at the sale hour anchors both paths.
    const eth = priceOf(ETH_COIN, closingTs);
    const ethUsdScaled = eth ? floatToScaled(eth.priceUsd, USD_SCALE) : null;
    if (!ethUsdScaled) return null;
    // Step 1: exact historical token price.
    const coin = llamaCoinKey(chainId, tokenAddress);
    const token = coin ? priceOf(coin, closingTs) : null;
    if (token) return convertAmount(tokenAmountWei, token.priceUsd, ethUsdScaled, false);
    // Step 2: nearest available rate — CURRENT token price, candidates in
    // prefix order (own chain first, then Robinhood's canonical ethereum:).
    for (const cand of currentCoinCandidates(chainId, tokenAddress)) {
      const cur = currentCache.get(cand)?.price;
      if (cur) return convertAmount(tokenAmountWei, cur.priceUsd, ethUsdScaled, true);
    }
    // Step 3: unpriced.
    return null;
  }

  function decimals(chainId: number, tokenAddress: string, closingTs: number): number | null {
    const coin = llamaCoinKey(chainId, tokenAddress);
    const hist = coin ? priceOf(coin, closingTs)?.decimals : null;
    if (hist !== null && hist !== undefined) return hist;
    for (const cand of currentCoinCandidates(chainId, tokenAddress)) {
      const cur = currentCache.get(cand)?.price;
      if (cur?.decimals !== null && cur?.decimals !== undefined) return cur.decimals;
    }
    return null;
  }

  return { request, resolve, get, decimals };
}

/**
 * One-shot convenience conversion: resolves a single (token, hour) pair.
 * `amountWeiString` is the payment quantity in the token's smallest unit;
 * `decimals` is the token's decimals (OpenSea `payment.decimals`).
 */
export async function convertToEth(
  chainId: number,
  tokenAddress: string,
  amountWeiString: string,
  decimals: number,
  closingTs: number,
  opts: { fetcher?: PriceFetcher } = {},
): Promise<{ eth: string; usd: string; approx: boolean } | null> {
  try {
    let q = BigInt(amountWeiString);
    if (decimals > 18) q /= 10n ** BigInt(decimals - 18);
    else if (decimals < 18) q *= 10n ** BigInt(18 - decimals);
    const resolver = createPriceResolver(opts);
    resolver.request(chainId, tokenAddress, closingTs);
    await resolver.resolve();
    const conv = resolver.get(chainId, tokenAddress, q, closingTs);
    return conv ? { eth: conv.eth, usd: conv.usd, approx: conv.approx } : null;
  } catch {
    return null;
  }
}
