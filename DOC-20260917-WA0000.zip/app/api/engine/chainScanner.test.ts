/**
 * Offline verification of the scanner's pairing + open-position mark math.
 * Synthetic Seaport OrderFulfilled logs are encoded with the real ABI, so
 * this exercises decode → aggregate → FIFO pairing → last-sale marking.
 */
import { describe, expect, it } from "vitest";
import { ethers } from "ethers";
import {
  aggregateOrderFulfilledLogs,
  buildMintFlips,
  buildOpenMintPositions,
  decodeMintTransfer,
  formatEth10,
  TRANSFER_TOPIC,
  ZERO_ADDRESS_TOPIC,
  type RawSeaportLog,
} from "./chainScanner";

const CHAIN_ID = 1; // ethereum — WETH known
const SEAPORT = "0x00000000000000ADc04C56Bf30aC9d3c0aAF14dC";
const COLLECTION = "0x1111111111111111111111111111111111111111";
const OTHER_COLLECTION = "0x2222222222222222222222222222222222222222";

const iface = new ethers.Interface([
  "event OrderFulfilled(bytes32 orderHash, address indexed offerer, address indexed zone, address recipient, (uint8 itemType, address token, uint256 identifier, uint256 amount)[] offer, (uint8 itemType, address token, uint256 identifier, uint256 amount, address recipient)[] consideration)",
]);

let hashCounter = 0;
const nextHash = () => `0x${(++hashCounter).toString(16).padStart(64, "0")}`;

/** Encode a single-NFT sale: seller offers 1 ERC721, buyer pays `priceWei` ETH. */
function saleLog(args: {
  seller: string;
  buyer: string;
  contract?: string;
  tokenId: bigint;
  priceWei: bigint;
  blockNumber: number;
  logIndex?: number;
  txHash?: string;
}): RawSeaportLog {
  const contract = args.contract ?? COLLECTION;
  const encoded = iface.encodeEventLog(iface.getEvent("OrderFulfilled")!, [
    ethers.zeroPadValue(ethers.toBeHex(++hashCounter), 32),
    args.seller,
    args.seller, // zone (irrelevant)
    args.buyer,
    [[2, contract, args.tokenId, 1n]], // offer: ERC721
    [[0, ethers.ZeroAddress, 0n, args.priceWei, args.seller]], // consideration: NATIVE → seller
  ]);
  return {
    address: SEAPORT,
    transactionHash: args.txHash ?? nextHash(),
    blockNumber: args.blockNumber,
    logIndex: args.logIndex ?? 0,
    topics: encoded.topics,
    data: encoded.data,
  };
}

function mintLog(args: {
  contract?: string;
  tokenId: bigint;
  recipient: string;
  blockNumber: number;
  txHash: string;
}): RawSeaportLog {
  const pad = (a: string) => ethers.zeroPadValue(a, 32);
  return {
    address: args.contract ?? COLLECTION,
    transactionHash: args.txHash,
    blockNumber: args.blockNumber,
    logIndex: 0,
    topics: [
      TRANSFER_TOPIC,
      ZERO_ADDRESS_TOPIC,
      pad(args.recipient),
      pad(ethers.toBeHex(args.tokenId)),
    ],
    data: "0x",
  };
}

const A = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const B = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
const C = "0xcccccccccccccccccccccccccccccccccccccccc";

describe("aggregateOrderFulfilledLogs — pairing + open positions", () => {
  it("pairs buy→sell FIFO and marks leftover buys at the latest in-window sale", () => {
    const logs = [
      // A buys token 1 @ 1 ETH (block 100)
      saleLog({ seller: B, buyer: A, tokenId: 1n, priceWei: 10n ** 18n, blockNumber: 100 }),
      // A buys token 2 @ 2 ETH (block 101) — never sold → open
      saleLog({ seller: B, buyer: A, tokenId: 2n, priceWei: 2n * 10n ** 18n, blockNumber: 101 }),
      // C buys token 3 @ 1 ETH (block 102) — never sold, mark unknown? no — collection has sales
      saleLog({ seller: B, buyer: C, tokenId: 3n, priceWei: 10n ** 18n, blockNumber: 102 }),
      // A sells token 1 @ 3 ETH to C (block 103) → realized +2 for A
      saleLog({ seller: A, buyer: C, tokenId: 1n, priceWei: 3n * 10n ** 18n, blockNumber: 103 }),
      // unrelated wallet sells token 9 @ 5 ETH (block 104) → new collection mark
      saleLog({ seller: B, buyer: C, tokenId: 9n, priceWei: 5n * 10n ** 18n, blockNumber: 104 }),
    ];
    const res = aggregateOrderFulfilledLogs(logs, CHAIN_ID);

    // Realized: A flipped token 1, +2 ETH.
    expect(res.secondaryFlips).toHaveLength(1);
    const flip = res.secondaryFlips[0];
    expect(flip.address).toBe(A.toLowerCase());
    expect(flip.pnlWei).toBe(2n * 10n ** 18n);
    expect(flip.holdBlocks).toBe(3);
    expect(res.traders.get(A.toLowerCase())?.realizedPnlWei).toBe(2n * 10n ** 18n);

    // Last-sale map: latest in-window sale of the collection is 5 ETH @ 104.
    expect(res.lastSaleByCollection.get(COLLECTION)?.priceWei).toBe(5n * 10n ** 18n);

    // Open positions: A's token 2 (cost 2, mark 5 → +3) and C's tokens 1, 3
    // and 9 — C bought token 1 from A @3 at block 103 and never resold it.
    const opens = res.openPositions;
    const aOpen = opens.find(
      (p) => p.address === A.toLowerCase() && p.tokenId === "2",
    );
    expect(aOpen).toBeDefined();
    expect(aOpen!.markWei).toBe(5n * 10n ** 18n);
    expect(aOpen!.unrealizedPnlWei).toBe(3n * 10n ** 18n);
    const cOpen1 = opens.find((p) => p.address === C.toLowerCase() && p.tokenId === "1");
    expect(cOpen1!.unrealizedPnlWei).toBe(2n * 10n ** 18n);
    const cOpen3 = opens.find((p) => p.address === C.toLowerCase() && p.tokenId === "3");
    expect(cOpen3!.unrealizedPnlWei).toBe(4n * 10n ** 18n);
    // C also holds token 9 (bought from B at the mark-setting sale).
    const cOpen9 = opens.find((p) => p.address === C.toLowerCase() && p.tokenId === "9");
    expect(cOpen9!.unrealizedPnlWei).toBe(0n);
    expect(opens).toHaveLength(4);
  });

  it("marks an open buy at its own purchase price when it is the only sale of the collection", () => {
    // Every Seaport buy is itself an in-window sale of that collection, so an
    // open buy's mark is at least its own purchase price (here: the only sale).
    const logs = [
      saleLog({
        seller: B,
        buyer: A,
        contract: OTHER_COLLECTION,
        tokenId: 1n,
        priceWei: 10n ** 18n,
        blockNumber: 100,
      }),
    ];
    const res = aggregateOrderFulfilledLogs(logs, CHAIN_ID);
    const open = res.openPositions.find(
      (p) => p.address === A.toLowerCase() && p.contract === OTHER_COLLECTION,
    );
    expect(open).toBeDefined();
    expect(open!.markWei).toBe(10n ** 18n);
    expect(open!.unrealizedPnlWei).toBe(0n);
    expect(open!.costWei).toBe(10n ** 18n);
  });
});

describe("mint pass — closed vs open mint positions", () => {
  it("matches sold mints as closed flips and keeps the rest open with unit cost", () => {
    // One tx mints 2 units for 0.08 ETH total → 0.04 each.
    const txHash = nextHash();
    const mints = [
      mintLog({ tokenId: 1n, recipient: A, blockNumber: 100, txHash }),
      mintLog({ tokenId: 2n, recipient: A, blockNumber: 100, txHash }),
    ];
    const sales = [
      // A sells token 1 @ 0.5 ETH → closed mint flip
      saleLog({ seller: A, buyer: B, tokenId: 1n, priceWei: 5n * 10n ** 17n, blockNumber: 110 }),
      // someone else sells token 8 @ 0.4 → latest mark for the collection
      saleLog({ seller: B, buyer: C, tokenId: 8n, priceWei: 4n * 10n ** 17n, blockNumber: 111 }),
    ];
    const agg = aggregateOrderFulfilledLogs(sales, CHAIN_ID);
    const txValues = new Map([[txHash, 8n * 10n ** 16n]]);

    const { flips, mintsMatched } = buildMintFlips(mints, agg.soldKeys, txValues);
    expect(mintsMatched).toBe(1);
    expect(flips).toHaveLength(1);
    // cost 0.04, proceeds 0.5 → pnl 0.46
    expect(flips[0].costWei).toBe(4n * 10n ** 16n);
    expect(flips[0].pnlWei).toBe(5n * 10n ** 17n - 4n * 10n ** 16n);

    const opens = buildOpenMintPositions(
      mints,
      agg.soldKeys,
      txValues,
      agg.lastSaleByCollection,
    );
    expect(opens).toHaveLength(1);
    expect(opens[0].tokenId).toBe("2");
    expect(opens[0].costWei).toBe(4n * 10n ** 16n);
    expect(opens[0].markWei).toBe(4n * 10n ** 17n);
    expect(opens[0].unrealizedPnlWei).toBe(4n * 10n ** 17n - 4n * 10n ** 16n);
    expect(opens[0].kind).toBe("mint");
  });

  it("records open mints with null cost when the mint tx value was not fetched", () => {
    const txHash = nextHash();
    const mints = [mintLog({ tokenId: 5n, recipient: A, blockNumber: 100, txHash })];
    const sales = [
      saleLog({ seller: B, buyer: C, tokenId: 9n, priceWei: 10n ** 18n, blockNumber: 105 }),
    ];
    const agg = aggregateOrderFulfilledLogs(sales, CHAIN_ID);
    const opens = buildOpenMintPositions(mints, agg.soldKeys, new Map(), agg.lastSaleByCollection);
    expect(opens).toHaveLength(1);
    expect(opens[0].costWei).toBeNull();
    expect(opens[0].markWei).toBe(10n ** 18n);
    expect(opens[0].unrealizedPnlWei).toBeNull();
  });

  it("records open mints with null mark when the collection never sold in-window", () => {
    // E.g. only bundle sales of that collection happened (no single-NFT
    // sale → no mark). soldKeys and lastSaleByCollection are both empty.
    const txHash = nextHash();
    const mints = [mintLog({ tokenId: 6n, recipient: A, blockNumber: 100, txHash })];
    const txValues = new Map([[txHash, 2n * 10n ** 17n]]);
    const opens = buildOpenMintPositions(mints, new Map(), txValues, new Map());
    expect(opens).toHaveLength(1);
    expect(opens[0].costWei).toBe(2n * 10n ** 17n);
    expect(opens[0].markWei).toBeNull();
    expect(opens[0].unrealizedPnlWei).toBeNull();
  });

  it("decodes mint transfers and rejects non-mint logs", () => {
    const m = decodeMintTransfer(
      mintLog({ tokenId: 42n, recipient: A, blockNumber: 7, txHash: nextHash() }),
    );
    expect(m).not.toBeNull();
    expect(m!.tokenId).toBe("42");
    expect(m!.recipient).toBe(A.toLowerCase());
    expect(decodeMintTransfer({ ...mintLog({ tokenId: 1n, recipient: A, blockNumber: 1, txHash: nextHash() }), topics: [TRANSFER_TOPIC] })).toBeNull();
  });
});

describe("formatEth10", () => {
  it("truncates to 10 decimals and keeps the sign", () => {
    expect(formatEth10(1234567890123456789n)).toBe("1.2345678901");
    expect(formatEth10(-5n * 10n ** 17n)).toBe("-0.5000000000");
    expect(formatEth10(0n)).toBe("0.0000000000");
  });
});

/* ------------------------------------------------------------------------- */
/* Arc (5042): ERC20 offers are paid in 6-decimal USDC — raw amounts must be */
/* scaled ×10^12 onto the 18dp wei scale the PnL pipeline uses.              */
/* ------------------------------------------------------------------------- */

describe("Arc USDC offer payments", () => {
  const ARC = 5042;
  const ARC_USDC = "0x3600000000000000000000000000000000000000";

  /** Single-NFT sale paid with an ERC20 token (Seaport offer acceptance). */
  function erc20SaleLog(args: {
    seller: string;
    buyer: string;
    tokenId: bigint;
    payToken: string;
    rawAmount: bigint;
    blockNumber: number;
  }): RawSeaportLog {
    const encoded = iface.encodeEventLog(iface.getEvent("OrderFulfilled")!, [
      ethers.zeroPadValue(ethers.toBeHex(++hashCounter), 32),
      args.seller,
      args.seller,
      args.buyer,
      [[2, COLLECTION, args.tokenId, 1n]],
      [[1, args.payToken, 0n, args.rawAmount, args.seller]],
    ]);
    return {
      address: SEAPORT,
      transactionHash: nextHash(),
      blockNumber: args.blockNumber,
      logIndex: 0,
      topics: encoded.topics,
      data: encoded.data,
    };
  }

  it("scales 6-decimal USDC payments ×10^12 (matches the live Arc sale shape)", () => {
    const seller = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const buyer = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    // Live Arc pattern: 41_000 + 4_100 raw units = $0.0451 at 6dp.
    const raw = 45_100n;
    const result = aggregateOrderFulfilledLogs(
      [
        erc20SaleLog({
          seller,
          buyer,
          tokenId: 1n,
          payToken: ARC_USDC,
          rawAmount: raw,
          blockNumber: 100,
        }),
      ],
      ARC,
    );
    expect(result.tradesCounted).toBe(1);
    expect(result.nonWethTrades).toBe(0); // USDC counts as payment on Arc
    expect(result.traders.get(buyer)?.spendWei).toBe(raw * 10n ** 12n);
    expect(result.traders.get(seller)?.proceedsWei).toBe(raw * 10n ** 12n);
    // PnL pairing runs (single-NFT, payment-token sale).
    expect(result.soldKeys.get(`${COLLECTION}:1`)?.proceedsWei).toBe(raw * 10n ** 12n);
  });

  it("still excludes unknown ERC20 payment tokens on Arc", () => {
    const result = aggregateOrderFulfilledLogs(
      [
        erc20SaleLog({
          seller: "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
          buyer: "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
          tokenId: 2n,
          payToken: "0xdead00000000000000000000000000000000dead",
          rawAmount: 1n,
          blockNumber: 101,
        }),
      ],
      ARC,
    );
    expect(result.nonWethTrades).toBe(1);
    expect(result.soldKeys.size).toBe(0);
  });
});
