/**
 * On-chain discovery of profitable OpenSea traders.
 *
 * OpenSea settles through Seaport, whose `OrderFulfilled` event is identical
 * across Seaport 1.1–1.6 on every EVM chain. This module scans the recent
 * block window for those events via plain `eth_getLogs` (no API keys),
 * aggregates per-wallet buys/sells/volume, pairs buys with later sales of the
 * same NFT inside the window to compute realized PnL (FIFO), and stores the
 * ranked candidates in `discovered_traders`.
 *
 * Mint-profit detection: a second pass scans ERC-721 `Transfer` events whose
 * `from` is the zero address (mints) for the collections that sold in-window.
 * When a minted token was later sold by the mint recipient inside the window,
 * the mint transaction's `value` is attributed across the quantity minted in
 * that tx (value ÷ count) to produce a mint flip with real cost basis.
 *
 * Methodology limits (surfaced in the UI): only Seaport-settled trades in the
 * scanned window count; realized PnL requires BOTH legs in-window; Blur/other
 * marketplaces and non-ETH/WETH payments are excluded from PnL math; mint cost
 * attribution ignores gas and assumes the tx paid only for the minted units.
 */
import { ethers } from "ethers";
import { TRPCError } from "@trpc/server";
import type { ScanSummary } from "@contracts/discover";
import type { InsertDiscoveredFlip, InsertDiscoveredTrader } from "@db/schema";
import { logActivity } from "../queries/activity";
import { cleanRpcError } from "../lib/rpcError";
import { replaceDiscoveredFlips, replaceDiscoveredTraders } from "../queries/discover";
import { resolveRpcForUser } from "./rpcManager";
import { computeLabels, serializeLabels } from "./walletLabels";

/** Seaport deployments to scan on every chain (1.1 / 1.5 / 1.6). Missing
 *  deployments simply return zero logs. */
export const SEAPORT_ADDRESSES = [
  "0x00000000000001ad428e4906aE43D8F9852d0dD6",
  "0x00000000000000ADc04C56Bf30aC9d3c0aAF14dC",
  "0x0000000000000068F116a894984e2DB1123eB395",
] as const;

export const ORDER_FULFILLED_TOPIC =
  "0x9d9af8e38d66c62e2c12f0225249fd9d721c54b83f48d9352c97c6cacdcb6f31";

/** ERC-721 Transfer(address,address,uint256) — all indexed. */
export const TRANSFER_TOPIC =
  "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
/** topics[1] (from) of a mint: the zero address, left-padded to 32 bytes. */
export const ZERO_ADDRESS_TOPIC =
  "0x0000000000000000000000000000000000000000000000000000000000000000";

const ORDER_FULFILLED_ABI = [
  "event OrderFulfilled(bytes32 orderHash, address indexed offerer, address indexed zone, address recipient, (uint8 itemType, address token, uint256 identifier, uint256 amount)[] offer, (uint8 itemType, address token, uint256 identifier, uint256 amount, address recipient)[] consideration)",
];

/** WETH per chain id — ERC20 consideration is only treated as payment here. */
const WETH_BY_CHAIN: Record<number, string> = {
  1: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
  8453: "0x4200000000000000000000000000000000000006",
  137: "0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619",
  42161: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
  4663: "0x4200000000000000000000000000000000000006",
  57073: "0x4200000000000000000000000000000000000006",
  // Arc: offers are paid in USDC (native USDC's ERC20 interface, 6 decimals —
  // verified against live OrderFulfilled logs on 2026-09-17).
  5042: "0x3600000000000000000000000000000000000000",
};

/**
 * Decimals of the ERC20 payment token per chain id (default 18). Arc USDC is
 * 6dp, so raw amounts are scaled ×10^12 onto the 18dp wei scale the rest of
 * the pipeline (PnL, volume, floor marks) uses.
 */
const PAYMENT_TOKEN_DECIMALS: Record<number, number> = {
  5042: 6,
};

/** Approximate seconds per block, used to convert holdBlocks → hours. */
const SECONDS_PER_BLOCK: Record<number, number> = {
  1: 12, // ethereum
  8453: 2, // base
  42161: 2, // arbitrum
  4663: 2, // robinhood
  57073: 2, // ink
  137: 2, // polygon
  5042: 1, // arc (~1s blocks, sub-second finality)
};
const DEFAULT_SECONDS_PER_BLOCK = 12;

/** itemType enum: 0=NATIVE, 1=ERC20, 2=ERC721, 3=ERC1155 */
const ITEM_NATIVE = 0n;
const ITEM_ERC20 = 1n;
const ITEM_ERC721 = 2n;
const ITEM_ERC1155 = 3n;

const DEFAULT_SCAN_BLOCKS = Math.max(
  100,
  Number.parseInt(process.env.SCANNER_BLOCKS ?? "3000", 10) || 3000,
);
const MAX_SCAN_BLOCKS = 20_000;
const BASE_CHUNK = 500;
const MIN_CHUNK = 50;
const CHUNK_CONCURRENCY = 3;
const CHUNK_STAGGER_MS = 100;
/** Shared budget for BOTH passes (Seaport sales + mint logs + mint txs). */
const SCAN_BUDGET_MS = 150_000;
const RPC_TIMEOUT_MS = 15_000;

/** Mint-pass bounds (RPC load control). */
const MINT_COLLECTION_CAP = 60;
const MINT_ADDRESS_BATCH = 20;
const TX_FETCH_CONCURRENCY = 5;

/** Candidate thresholds (see aggregate/scan filters). */
export const DEFAULT_THRESHOLDS = {
  minTrades: 2,
  minSpendEth: "0.05",
};

const seaport = new ethers.Interface(ORDER_FULFILLED_ABI);

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const toHex = (n: number) => `0x${n.toString(16)}`;

export type RawSeaportLog = {
  address: string;
  transactionHash: string;
  blockNumber: number;
  logIndex: number;
  topics: string[];
  data: string;
};

export type TraderAggregate = {
  address: string;
  buys: number;
  sells: number;
  trades: number;
  spendWei: bigint;
  proceedsWei: bigint;
  realizedPnlWei: bigint;
  collections: Set<string>;
  lastSeenBlock: number;
  /** Earliest in-window block the wallet traded at (0 = never). Feeds the
   *  'fresh' behavior label's first-observed-activity age. */
  firstSeenBlock: number;
};

/** One completed flip (mint→sell or buy→sell) with cost basis + proceeds. */
export type Flip = {
  kind: "mint" | "secondary";
  /** Wallet that realized the flip (the seller). */
  address: string;
  contract: string;
  tokenId: string;
  costWei: bigint;
  proceedsWei: bigint;
  pnlWei: bigint;
  /** pnl/cost*100; null when cost is zero (free mint / free acquisition). */
  roiPct: number | null;
  holdBlocks: number;
  buyTxHash: string | null;
  sellTxHash: string | null;
};

/** Sale leg of a single-NFT in-window sale, keyed by `${contract}:${tokenId}`. */
export type SoldInfo = {
  seller: string;
  proceedsWei: bigint;
  sellBlock: number;
  sellTxHash: string;
};

/** Latest single-NFT sale price observed for a collection in the window —
 *  used to mark open (unsold) positions. */
export type CollectionMark = {
  priceWei: bigint;
  blockNumber: number;
};

/** An unsold in-window acquisition (buy or mint) still held at scan end. */
export type OpenPosition = {
  kind: "mint" | "secondary";
  /** Wallet holding the position. */
  address: string;
  contract: string;
  tokenId: string;
  /** Unit cost; null when unknowable (mint tx value not fetched). */
  costWei: bigint | null;
  /** Latest in-window sale price for the collection; null when no sale. */
  markWei: bigint | null;
  /** markWei - costWei; null when either leg is unknown. */
  unrealizedPnlWei: bigint | null;
  entryBlock: number;
  entryTxHash: string | null;
};

export type AggregateResult = {
  traders: Map<string, TraderAggregate>;
  /** Distinct decoded OrderFulfilled events processed. */
  tradesCounted: number;
  /** Trades involving non-WETH ERC20 payment (excluded from PnL math). */
  nonWethTrades: number;
  /** Completed buy→sell flips (FIFO pairing), kind 'secondary'. */
  secondaryFlips: Flip[];
  /** `${contract}:${tokenId}` → sale leg, for mint pairing. */
  soldKeys: Map<string, SoldInfo>;
  /** NFT contract → sold-item count in window (mint-pass candidates). */
  collectionSales: Map<string, number>;
  /** NFT contract → latest in-window sale price (open-position marks). */
  lastSaleByCollection: Map<string, CollectionMark>;
  /** Unsold in-window buys (kind 'secondary'), marked when possible. */
  openPositions: OpenPosition[];
};

type BuyEntry = {
  buyer: string;
  priceWei: bigint;
  blockNumber: number;
  txHash: string;
  used: boolean;
};

/** ROI percent; null when cost is zero (free mint passes any ROI filter). */
export function roiOf(pnlWei: bigint, costWei: bigint): number | null {
  if (costWei <= 0n) return null;
  return (Number(pnlWei) / Number(costWei)) * 100;
}

/** Clamp an ROI percent into the varchar(16) / DECIMAL(18,2) storage range. */
export function clampRoi(roi: number): number {
  return Math.max(-999_999_999.99, Math.min(999_999_999.99, roi));
}

function walletAgg(map: Map<string, TraderAggregate>, address: string): TraderAggregate {
  let agg = map.get(address);
  if (!agg) {
    agg = {
      address,
      buys: 0,
      sells: 0,
      trades: 0,
      spendWei: 0n,
      proceedsWei: 0n,
      realizedPnlWei: 0n,
      collections: new Set<string>(),
      lastSeenBlock: 0,
      firstSeenBlock: 0,
    };
    map.set(address, agg);
  }
  return agg;
}

/**
 * Pure aggregation over raw logs — exported for offline testing.
 * Logs are sorted by (blockNumber, logIndex) so buy→sale pairing is FIFO.
 */
export function aggregateOrderFulfilledLogs(
  logs: RawSeaportLog[],
  chainId: number,
): AggregateResult {
  const weth = WETH_BY_CHAIN[chainId]?.toLowerCase() ?? null;
  const paymentScale = 10n ** BigInt(18 - (PAYMENT_TOKEN_DECIMALS[chainId] ?? 18));
  const sorted = [...logs].sort(
    (a, b) => a.blockNumber - b.blockNumber || a.logIndex - b.logIndex,
  );

  const traders = new Map<string, TraderAggregate>();
  /** `${nftContract}:${tokenId}` → FIFO buy entries recorded in this window. */
  const buyBook = new Map<string, BuyEntry[]>();
  const secondaryFlips: Flip[] = [];
  const soldKeys = new Map<string, SoldInfo>();
  const collectionSales = new Map<string, number>();
  const lastSaleByCollection = new Map<string, CollectionMark>();
  const seen = new Set<string>();
  let tradesCounted = 0;
  let nonWethTrades = 0;

  for (const log of sorted) {
    let decoded: ethers.LogDescription | null;
    try {
      decoded = seaport.parseLog({ topics: log.topics, data: log.data });
    } catch {
      continue; // not a well-formed OrderFulfilled log
    }
    if (!decoded) continue;

    const orderHash = String(decoded.args[0]);
    const dedupeKey = `${log.transactionHash}:${orderHash}`;
    if (seen.has(dedupeKey)) continue;
    seen.add(dedupeKey);

    const offerer = String(decoded.args[1]).toLowerCase();
    const recipient = String(decoded.args[3]).toLowerCase();
    const offer = decoded.args[4] as unknown as Array<[bigint, string, bigint, bigint]>;
    const consideration = decoded.args[5] as unknown as Array<
      [bigint, string, bigint, bigint, string]
    >;

    const nftItems = offer.filter(
      (it) => it[0] === ITEM_ERC721 || it[0] === ITEM_ERC1155,
    );

    let buyerPaidWei = 0n;
    let sellerProceedsWei = 0n;
    let hasNonWethPayment = false;
    for (const c of consideration) {
      const [itemType, token, , amount, payee] = c;
      const isNative = itemType === ITEM_NATIVE;
      const isWeth = itemType === ITEM_ERC20 && weth !== null && token.toLowerCase() === weth;
      if (itemType === ITEM_ERC20 && !isWeth) {
        hasNonWethPayment = true;
        continue;
      }
      if (!isNative && !isWeth) continue;
      // ERC20 payments (offers) are scaled onto the 18dp native scale —
      // matters on Arc where USDC has 6 decimals.
      const scaled = isWeth && paymentScale !== 1n ? amount * paymentScale : amount;
      buyerPaidWei += scaled;
      if (payee.toLowerCase() === offerer) sellerProceedsWei += scaled;
    }
    if (hasNonWethPayment) nonWethTrades += 1;

    tradesCounted += 1;
    const buyer = walletAgg(traders, recipient);
    buyer.buys += nftItems.length;
    buyer.spendWei += buyerPaidWei;
    buyer.lastSeenBlock = Math.max(buyer.lastSeenBlock, log.blockNumber);

    const seller = walletAgg(traders, offerer);
    seller.sells += nftItems.length;
    seller.proceedsWei += sellerProceedsWei;
    seller.lastSeenBlock = Math.max(seller.lastSeenBlock, log.blockNumber);

    for (const it of nftItems) {
      const contract = it[1].toLowerCase();
      buyer.collections.add(contract);
      seller.collections.add(contract);
      collectionSales.set(contract, (collectionSales.get(contract) ?? 0) + 1);
    }

    // PnL pairing: only single-NFT orders have an unambiguous price. Bundles
    // count toward volume but not PnL. Trades with non-WETH ERC20 payment are
    // excluded from PnL math entirely.
    if (nftItems.length === 1 && !hasNonWethPayment) {
      const nft = nftItems[0];
      const contract = nft[1].toLowerCase();
      const tokenId = nft[2].toString();
      const key = `${contract}:${tokenId}`;

      // Record the sale leg for mint-flip pairing (mint pass).
      soldKeys.set(key, {
        seller: offerer,
        proceedsWei: sellerProceedsWei,
        sellBlock: log.blockNumber,
        sellTxHash: log.transactionHash,
      });

      // Logs are processed in ascending (block, logIndex) order, so each
      // overwrite leaves the LATEST in-window sale price per collection —
      // the mark for open positions. Gross buyer-paid price is used.
      lastSaleByCollection.set(contract, {
        priceWei: buyerPaidWei,
        blockNumber: log.blockNumber,
      });

      // Pair a sale FIRST (the buy leg must have been recorded earlier).
      const entries = buyBook.get(key);
      if (entries) {
        const entry = entries.find((e) => !e.used && e.buyer === offerer);
        if (entry) {
          entry.used = true; // consume — each buy pairs once (FIFO)
          const pnlWei = sellerProceedsWei - entry.priceWei;
          seller.realizedPnlWei += pnlWei;
          secondaryFlips.push({
            kind: "secondary",
            address: offerer,
            contract,
            tokenId,
            costWei: entry.priceWei,
            proceedsWei: sellerProceedsWei,
            pnlWei,
            roiPct: roiOf(pnlWei, entry.priceWei),
            holdBlocks: Math.max(0, log.blockNumber - entry.blockNumber),
            buyTxHash: entry.txHash,
            sellTxHash: log.transactionHash,
          });
        }
      }

      // Then record this event's buy leg for future pairing.
      const entry: BuyEntry = {
        buyer: recipient,
        priceWei: buyerPaidWei,
        blockNumber: log.blockNumber,
        txHash: log.transactionHash,
        used: false,
      };
      const list = buyBook.get(key);
      if (list) list.push(entry);
      else buyBook.set(key, [entry]);
    }
  }

  for (const agg of traders.values()) {
    agg.trades = agg.buys + agg.sells;
  }

  // Leftover (unconsumed) buy-book entries are open positions: acquired
  // in-window, never sold in-window. Mark each at the collection's latest
  // in-window sale price when one exists (null mark = unknown).
  const openPositions: OpenPosition[] = [];
  for (const [key, entries] of buyBook) {
    const sep = key.indexOf(":");
    const contract = key.slice(0, sep);
    const tokenId = key.slice(sep + 1);
    const mark = lastSaleByCollection.get(contract) ?? null;
    for (const e of entries) {
      if (e.used) continue;
      openPositions.push({
        kind: "secondary",
        address: e.buyer,
        contract,
        tokenId,
        costWei: e.priceWei,
        markWei: mark?.priceWei ?? null,
        unrealizedPnlWei: mark ? mark.priceWei - e.priceWei : null,
        entryBlock: e.blockNumber,
        entryTxHash: e.txHash,
      });
    }
  }

  return {
    traders,
    tradesCounted,
    nonWethTrades,
    secondaryFlips,
    soldKeys,
    collectionSales,
    lastSaleByCollection,
    openPositions,
  };
}

/* ------------------------------------------------------------------------- */
/* Mint pass (pure parts — exported for offline testing)                      */
/* ------------------------------------------------------------------------- */

export type MintTransfer = {
  contract: string;
  tokenId: string;
  recipient: string;
  txHash: string;
  blockNumber: number;
};

/** Decode an ERC-721 Transfer-from-zero log. Returns null if not a mint. */
export function decodeMintTransfer(log: RawSeaportLog): MintTransfer | null {
  if (log.topics.length < 4) return null; // ERC-721 mint: tokenId is indexed
  if (log.topics[0]?.toLowerCase() !== TRANSFER_TOPIC) return null;
  if (log.topics[1]?.toLowerCase() !== ZERO_ADDRESS_TOPIC) return null;
  return {
    contract: log.address.toLowerCase(),
    tokenId: BigInt(log.topics[3]).toString(),
    recipient: `0x${log.topics[2].slice(26).toLowerCase()}`,
    txHash: log.transactionHash,
    blockNumber: log.blockNumber,
  };
}

/**
 * Pair mint Transfer logs with in-window sales and attribute mint cost.
 *
 * A mint counts when the minted `${contract}:${tokenId}` was sold in-window
 * AND the mint recipient is the seller. Mint cost per NFT =
 * `tx.value / (mint-Transfer logs in that tx for that contract)` — a 0.08 ETH
 * transaction minting 2 units costs 0.04 each; a zero-value tx is a free mint
 * (cost 0, ROI null).
 *
 * `txValues` maps mint tx hash → tx.value in wei (fetched via
 * eth_getTransactionByHash). Mints whose tx is missing from the map are
 * skipped (cost unknowable).
 */
export function buildMintFlips(
  mintLogs: RawSeaportLog[],
  soldKeys: Map<string, SoldInfo>,
  txValues: ReadonlyMap<string, bigint>,
): { flips: Flip[]; mintsMatched: number } {
  const mints: MintTransfer[] = [];
  for (const log of mintLogs) {
    const m = decodeMintTransfer(log);
    if (m) mints.push(m);
  }

  // Quantity minted per (tx, contract) — the cost divisor.
  const mintCountByTxContract = new Map<string, number>();
  for (const m of mints) {
    const k = `${m.txHash}:${m.contract}`;
    mintCountByTxContract.set(k, (mintCountByTxContract.get(k) ?? 0) + 1);
  }

  const flips: Flip[] = [];
  let mintsMatched = 0;
  for (const m of mints) {
    const sold = soldKeys.get(`${m.contract}:${m.tokenId}`);
    if (!sold || sold.seller !== m.recipient) continue;
    mintsMatched += 1;
    const valueWei = txValues.get(m.txHash);
    if (valueWei === undefined) continue; // tx fetch failed — cost unknowable
    const qty = BigInt(mintCountByTxContract.get(`${m.txHash}:${m.contract}`) ?? 1);
    const costWei = valueWei > 0n ? valueWei / qty : 0n;
    const pnlWei = sold.proceedsWei - costWei;
    flips.push({
      kind: "mint",
      address: m.recipient,
      contract: m.contract,
      tokenId: m.tokenId,
      costWei,
      proceedsWei: sold.proceedsWei,
      pnlWei,
      roiPct: roiOf(pnlWei, costWei),
      holdBlocks: Math.max(0, sold.sellBlock - m.blockNumber),
      buyTxHash: m.txHash,
      sellTxHash: sold.sellTxHash,
    });
  }
  return { flips, mintsMatched };
}

/**
 * Unsold in-window mints → open positions. A mint is open when its
 * `${contract}:${tokenId}` was NOT sold in-window by the mint recipient.
 * Unit cost uses the same tx.value ÷ quantity attribution as closed mint
 * flips; null when the mint tx value was not fetched. Marks come from the
 * Seaport pass's per-collection last-sale map (no extra RPC calls).
 */
export function buildOpenMintPositions(
  mintLogs: RawSeaportLog[],
  soldKeys: Map<string, SoldInfo>,
  txValues: ReadonlyMap<string, bigint>,
  lastSaleByCollection: ReadonlyMap<string, CollectionMark>,
): OpenPosition[] {
  const mints: MintTransfer[] = [];
  for (const log of mintLogs) {
    const m = decodeMintTransfer(log);
    if (m) mints.push(m);
  }

  const mintCountByTxContract = new Map<string, number>();
  for (const m of mints) {
    const k = `${m.txHash}:${m.contract}`;
    mintCountByTxContract.set(k, (mintCountByTxContract.get(k) ?? 0) + 1);
  }

  const positions: OpenPosition[] = [];
  for (const m of mints) {
    const sold = soldKeys.get(`${m.contract}:${m.tokenId}`);
    if (sold && sold.seller === m.recipient) continue; // closed mint flip
    const valueWei = txValues.get(m.txHash);
    const costWei =
      valueWei === undefined
        ? null
        : valueWei > 0n
          ? valueWei / BigInt(mintCountByTxContract.get(`${m.txHash}:${m.contract}`) ?? 1)
          : 0n;
    const mark = lastSaleByCollection.get(m.contract) ?? null;
    positions.push({
      kind: "mint",
      address: m.recipient,
      contract: m.contract,
      tokenId: m.tokenId,
      costWei,
      markWei: mark?.priceWei ?? null,
      unrealizedPnlWei: mark && costWei !== null ? mark.priceWei - costWei : null,
      entryBlock: m.blockNumber,
      entryTxHash: m.txHash,
    });
  }
  return positions;
}

/** Format wei as a decimal string truncated to 10 places — fits the
 *  DECIMAL(20,10) mark/unrealized columns without rounding errors. */
export function formatEth10(wei: bigint): string {
  const neg = wei < 0n;
  const abs = neg ? -wei : wei;
  const whole = abs / 10n ** 18n;
  const frac = (abs % 10n ** 18n) / 10n ** 8n;
  return `${neg ? "-" : ""}${whole}.${frac.toString().padStart(10, "0")}`;
}

/** Per-wallet detail stats across ALL flips (mint + secondary). */
export type WalletFlipStats = {
  flips: number;
  wins: number;
  winRatePct: string;
  avgPnlEth: string;
  bestFlipEth: string;
  roiPct: string | null;
  avgHoldHours: string | null;
  mintPnlEth: string;
  mintFlips: number;
};

export function computeWalletFlipStats(
  flips: Flip[],
  secondsPerBlock: number,
): WalletFlipStats {
  const n = flips.length;
  if (n === 0) {
    return {
      flips: 0,
      wins: 0,
      winRatePct: "0",
      avgPnlEth: "0",
      bestFlipEth: "0",
      roiPct: null,
      avgHoldHours: null,
      mintPnlEth: "0",
      mintFlips: 0,
    };
  }
  let sumPnl = 0n;
  let sumCost = 0n;
  let best = flips[0].pnlWei;
  let sumHold = 0;
  let wins = 0;
  let mintPnl = 0n;
  let mintFlips = 0;
  for (const f of flips) {
    sumPnl += f.pnlWei;
    sumCost += f.costWei;
    if (f.pnlWei > best) best = f.pnlWei;
    sumHold += f.holdBlocks;
    if (f.pnlWei > 0n) wins += 1;
    if (f.kind === "mint") {
      mintFlips += 1;
      mintPnl += f.pnlWei;
    }
  }
  const roi = sumCost > 0n ? roiOf(sumPnl, sumCost) : null;
  const avgHoldHours = (sumHold / n) * (secondsPerBlock / 3600);
  return {
    flips: n,
    wins,
    winRatePct: ((wins / n) * 100).toFixed(1),
    avgPnlEth: ethers.formatEther(sumPnl / BigInt(n)),
    bestFlipEth: ethers.formatEther(best),
    roiPct: roi === null ? null : clampRoi(roi).toFixed(2),
    avgHoldHours: avgHoldHours.toFixed(1),
    mintPnlEth: ethers.formatEther(mintPnl),
    mintFlips,
  };
}

/* ------------------------------------------------------------------------- */
/* RPC plumbing                                                               */
/* ------------------------------------------------------------------------- */

async function rpcCall(url: string, method: string, params: unknown[]): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), RPC_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`RPC HTTP ${res.status}`);
    const body = (await res.json()) as {
      result?: unknown;
      error?: { code?: number; message?: string };
    };
    if (body.error) {
      // Surface only the cleaned message — never the raw JSON-RPC blob.
      throw new Error(`RPC ${body.error.code ?? ""}: ${cleanRpcError(body.error.message ?? "unknown")}`);
    }
    return body.result;
  } finally {
    clearTimeout(timer);
  }
}

type LogFilter = {
  address: string | string[];
  topics: (string | null)[];
};

async function rpcGetLogs(
  url: string,
  fromBlock: number,
  toBlock: number,
  filter: LogFilter,
): Promise<RawSeaportLog[]> {
  const result = (await rpcCall(url, "eth_getLogs", [
    {
      address: filter.address,
      topics: filter.topics,
      fromBlock: toHex(fromBlock),
      toBlock: toHex(toBlock),
    },
  ])) as Array<{
    address: string;
    transactionHash: string;
    blockNumber: string;
    logIndex: string;
    topics: string[];
    data: string;
  }>;
  return result.map((l) => ({
    address: l.address,
    transactionHash: l.transactionHash,
    blockNumber: Number.parseInt(l.blockNumber, 16),
    logIndex: Number.parseInt(l.logIndex, 16),
    topics: l.topics,
    data: l.data,
  }));
}

type FetchCtx = {
  url: string;
  deadline: number;
  okLeaves: number;
  failedLeaves: number;
  coveredBlocks: number;
  timedOut: boolean;
};

/**
 * Fetch one chunk; on any range/limit error recursively halve the range
 * (500 → 250 → 125 → 62 → 50, floor 50) before giving up on the leaf.
 */
async function fetchChunkAdaptive(
  ctx: FetchCtx,
  a: number,
  b: number,
  filter: LogFilter,
): Promise<RawSeaportLog[]> {
  if (Date.now() > ctx.deadline) {
    ctx.timedOut = true;
    ctx.failedLeaves += 1;
    return [];
  }
  try {
    const logs = await rpcGetLogs(ctx.url, a, b, filter);
    ctx.okLeaves += 1;
    ctx.coveredBlocks += b - a + 1;
    return logs;
  } catch {
    const size = b - a + 1;
    if (size <= MIN_CHUNK) {
      ctx.failedLeaves += 1;
      return [];
    }
    const mid = a + Math.floor(size / 2) - 1;
    const left = await fetchChunkAdaptive(ctx, a, mid, filter);
    const right = await fetchChunkAdaptive(ctx, mid + 1, b, filter);
    return [...left, ...right];
  }
}

/** Sweep [fromBlock, toBlock] in staggered adaptive chunks sharing `ctx`. */
async function sweepWindow(
  ctx: FetchCtx,
  fromBlock: number,
  toBlock: number,
  filter: LogFilter,
): Promise<RawSeaportLog[]> {
  const out: RawSeaportLog[] = [];
  let cursor = fromBlock;
  while (cursor <= toBlock) {
    if (Date.now() > ctx.deadline) {
      ctx.timedOut = true;
      break;
    }
    const group: Array<[number, number]> = [];
    for (let i = 0; i < CHUNK_CONCURRENCY && cursor <= toBlock; i += 1) {
      const a = cursor;
      const b = Math.min(a + BASE_CHUNK - 1, toBlock);
      group.push([a, b]);
      cursor = b + 1;
    }
    const results = await Promise.all(
      group.map(async ([a, b], i) => {
        if (i > 0) await sleep(CHUNK_STAGGER_MS * i);
        return fetchChunkAdaptive(ctx, a, b, filter);
      }),
    );
    for (const logs of results) out.push(...logs);
  }
  return out;
}

/* ------------------------------------------------------------------------- */
/* Public entry point                                                         */
/* ------------------------------------------------------------------------- */

export type ScanOpts = {
  /** Window size in blocks (default 3000, env SCANNER_BLOCKS, cap 20000). */
  blocks?: number;
  thresholds?: { minTrades?: number; minSpendEth?: string };
};

export async function scanChain(
  userId: number,
  chainId: number,
  opts: ScanOpts = {},
): Promise<ScanSummary> {
  const startedAt = Date.now();
  const rpc = await resolveRpcForUser(userId, chainId);

  const latestHex = (await rpcCall(rpc.url, "eth_blockNumber", [])) as string;
  const toBlock = Number.parseInt(latestHex, 16);
  const windowBlocks = Math.min(Math.max(1, opts.blocks ?? DEFAULT_SCAN_BLOCKS), MAX_SCAN_BLOCKS);
  const fromBlock = Math.max(0, toBlock - windowBlocks + 1);

  const ctx: FetchCtx = {
    url: rpc.url,
    deadline: startedAt + SCAN_BUDGET_MS,
    okLeaves: 0,
    failedLeaves: 0,
    coveredBlocks: 0,
    timedOut: false,
  };

  // Pass 1 — Seaport OrderFulfilled (sales).
  const allLogs = await sweepWindow(ctx, fromBlock, toBlock, {
    address: [...SEAPORT_ADDRESSES],
    topics: [ORDER_FULFILLED_TOPIC],
  });

  if (ctx.okLeaves === 0 && ctx.failedLeaves > 0) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message:
        "Public RPC rate-limited the scan — add a private RPC in Settings (auto mode off) for deep scans.",
    });
  }

  const {
    traders,
    tradesCounted,
    nonWethTrades,
    secondaryFlips,
    soldKeys,
    collectionSales,
    lastSaleByCollection,
    openPositions: openBuyPositions,
  } = aggregateOrderFulfilledLogs(allLogs, chainId);

  // Pass 2 — mint detection over the collections that sold in-window.
  const candidateCollections = [...collectionSales.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, MINT_COLLECTION_CAP)
    .map(([contract]) => contract);

  const mintLogs: RawSeaportLog[] = [];
  if (candidateCollections.length > 0 && soldKeys.size > 0) {
    for (let i = 0; i < candidateCollections.length; i += MINT_ADDRESS_BATCH) {
      if (Date.now() > ctx.deadline) {
        ctx.timedOut = true;
        break;
      }
      const batch = candidateCollections.slice(i, i + MINT_ADDRESS_BATCH);
      const logs = await sweepWindow(ctx, fromBlock, toBlock, {
        address: batch,
        topics: [TRANSFER_TOPIC, ZERO_ADDRESS_TOPIC],
      });
      mintLogs.push(...logs);
    }
  }

  // Fetch mint transactions (cached by hash — several mints can share one tx).
  // All decoded mints are fetched, not just sale-matched ones: unsold mints
  // become open positions and need the same unit-cost attribution.
  const mints = mintLogs
    .map(decodeMintTransfer)
    .filter((m): m is MintTransfer => m !== null);
  const txValues = new Map<string, bigint>();
  const txHashes = [...new Set(mints.map((m) => m.txHash))];
  let txFetchFailed = false;
  for (let i = 0; i < txHashes.length; i += TX_FETCH_CONCURRENCY) {
    if (Date.now() > ctx.deadline) {
      ctx.timedOut = true;
      txFetchFailed = true;
      break;
    }
    await Promise.all(
      txHashes.slice(i, i + TX_FETCH_CONCURRENCY).map(async (hash) => {
        try {
          const tx = (await rpcCall(rpc.url, "eth_getTransactionByHash", [hash])) as {
            value?: string;
          } | null;
          txValues.set(hash, tx?.value ? BigInt(tx.value) : 0n);
        } catch {
          txFetchFailed = true; // cost unknowable for these mints
        }
      }),
    );
  }

  const { flips: mintFlips, mintsMatched } = buildMintFlips(mintLogs, soldKeys, txValues);
  const openMintPositions = buildOpenMintPositions(
    mintLogs,
    soldKeys,
    txValues,
    lastSaleByCollection,
  );
  const openPositions = [...openBuyPositions, ...openMintPositions];

  const partial = ctx.timedOut || ctx.failedLeaves > 0 || txFetchFailed;

  // Open positions per wallet (unsold in-window acquisitions).
  const openByWallet = new Map<string, OpenPosition[]>();
  for (const p of openPositions) {
    const list = openByWallet.get(p.address);
    if (list) list.push(p);
    else openByWallet.set(p.address, [p]);
  }

  // Per-wallet flip stats (mint + secondary combined).
  const secondsPerBlock = SECONDS_PER_BLOCK[chainId] ?? DEFAULT_SECONDS_PER_BLOCK;
  const flipsByWallet = new Map<string, Flip[]>();
  for (const f of [...secondaryFlips, ...mintFlips]) {
    const list = flipsByWallet.get(f.address);
    if (list) list.push(f);
    else flipsByWallet.set(f.address, [f]);
  }

  const thresholds = {
    minTrades: opts.thresholds?.minTrades ?? DEFAULT_THRESHOLDS.minTrades,
    minSpendWei: ethers.parseEther(opts.thresholds?.minSpendEth ?? DEFAULT_THRESHOLDS.minSpendEth),
  };

  const candidates = [...traders.values()].filter(
    (t) =>
      t.trades >= thresholds.minTrades ||
      t.realizedPnlWei !== 0n ||
      t.spendWei >= thresholds.minSpendWei ||
      (flipsByWallet.get(t.address)?.length ?? 0) > 0,
  );
  candidates.sort((a, b) => {
    if (a.realizedPnlWei !== b.realizedPnlWei) return a.realizedPnlWei > b.realizedPnlWei ? -1 : 1;
    const va = a.spendWei + a.proceedsWei;
    const vb = b.spendWei + b.proceedsWei;
    if (va !== vb) return va > vb ? -1 : 1;
    return b.trades - a.trades;
  });

  // Behavior labels (GMGN-style wallet tags) are derived from the same
  // aggregates and stored alongside each row as a JSON array string.
  // `labels` is written via the labels-aware shadow table in
  // queries/discover.ts (the ORM schema may lag the ensureSchema migration).
  const rows: Array<InsertDiscoveredTrader & { labels: string | null }> = candidates.map((t) => {
    const stats = computeWalletFlipStats(flipsByWallet.get(t.address) ?? [], secondsPerBlock);
    const opens = openByWallet.get(t.address) ?? [];
    let unrealizedSum = 0n;
    let hasMark = false;
    for (const p of opens) {
      if (p.unrealizedPnlWei !== null) {
        unrealizedSum += p.unrealizedPnlWei;
        hasMark = true;
      }
    }
    const labels = computeLabels({
      winRatePct: stats.flips > 0 ? Number(stats.winRatePct) : null,
      flips: stats.flips,
      mintFlips: stats.mintFlips,
      realizedPnlEth: Number(ethers.formatEther(t.realizedPnlWei)),
      volumeEth: Number(ethers.formatEther(t.spendWei + t.proceedsWei)),
      avgHoldHours: stats.avgHoldHours !== null ? Number(stats.avgHoldHours) : null,
      firstActivityAgeHours:
        t.firstSeenBlock > 0
          ? ((toBlock - t.firstSeenBlock) * secondsPerBlock) / 3600
          : null,
      openPositions: opens.length,
      unrealizedPnlEth: hasMark ? Number(formatEth10(unrealizedSum)) : null,
    });
    return {
      chainId,
      address: t.address,
      buys: t.buys,
      sells: t.sells,
      trades: t.trades,
      spendEth: ethers.formatEther(t.spendWei),
      proceedsEth: ethers.formatEther(t.proceedsWei),
      realizedPnlEth: ethers.formatEther(t.realizedPnlWei),
      flips: stats.flips,
      wins: stats.wins,
      winRatePct: stats.winRatePct,
      avgPnlEth: stats.avgPnlEth,
      bestFlipEth: stats.bestFlipEth,
      roiPct: stats.roiPct,
      mintPnlEth: stats.mintPnlEth,
      mintFlips: stats.mintFlips,
      avgHoldHours: stats.avgHoldHours,
      unrealizedPnlEth: hasMark ? formatEth10(unrealizedSum) : null,
      openPositions: opens.length,
      collections: t.collections.size,
      labels: serializeLabels(labels),
      fromBlock,
      toBlock,
    };
  });

  const candidateAddrs = new Set(candidates.map((t) => t.address));
  const flipRows: InsertDiscoveredFlip[] = [];
  for (const [address, flips] of flipsByWallet) {
    if (!candidateAddrs.has(address)) continue;
    for (const f of flips) {
      flipRows.push({
        chainId,
        address,
        contractAddress: f.contract,
        tokenId: f.tokenId,
        kind: f.kind,
        status: "closed",
        buyPriceEth: ethers.formatEther(f.costWei),
        sellPriceEth: ethers.formatEther(f.proceedsWei),
        pnlEth: ethers.formatEther(f.pnlWei),
        roiPct: f.roiPct === null ? null : clampRoi(f.roiPct).toFixed(2),
        holdBlocks: f.holdBlocks,
        buyTxHash: f.buyTxHash,
        sellTxHash: f.sellTxHash,
      });
    }
  }
  // Open positions: realized fields stay null; holdBlocks = blocks held from
  // entry to scan end (drives the age display in the UI).
  for (const [address, opens] of openByWallet) {
    if (!candidateAddrs.has(address)) continue;
    for (const p of opens) {
      flipRows.push({
        chainId,
        address,
        contractAddress: p.contract,
        tokenId: p.tokenId,
        kind: p.kind,
        status: "open",
        markPriceEth: p.markWei !== null ? formatEth10(p.markWei) : null,
        unrealizedPnlEth: p.unrealizedPnlWei !== null ? formatEth10(p.unrealizedPnlWei) : null,
        buyPriceEth: p.costWei !== null ? ethers.formatEther(p.costWei) : null,
        sellPriceEth: null,
        pnlEth: null,
        roiPct: null,
        holdBlocks: Math.max(0, toBlock - p.entryBlock),
        buyTxHash: p.entryTxHash,
        sellTxHash: null,
      });
    }
  }

  await replaceDiscoveredTraders(chainId, rows);
  await replaceDiscoveredFlips(chainId, flipRows);

  await logActivity({
    userId,
    level: partial ? "warn" : "success",
    source: "system",
    message:
      `Chain scan ${chainId}: blocks ${fromBlock}–${toBlock} (${ctx.coveredBlocks} covered), ` +
      `${allLogs.length} Seaport logs / ${tradesCounted} trades, ${rows.length} traders stored` +
      `, ${mintLogs.length} mint logs / ${mintsMatched} matched / ${mintFlips.length} mint flips` +
      `, ${openPositions.length} open positions marked` +
      `${nonWethTrades > 0 ? `, ${nonWethTrades} non-WETH-payment trade(s) excluded from PnL` : ""}` +
      `${partial ? " — PARTIAL (RPC budget/rate limits)" : ""}`,
    meta: { chainId, fromBlock, toBlock, partial, endpointSource: rpc.source },
  });

  return {
    chainId,
    fromBlock,
    toBlock,
    scannedBlocks: ctx.coveredBlocks,
    logsFound: allLogs.length,
    mintLogsFound: mintLogs.length,
    txsFetched: txValues.size,
    mintFlips: mintFlips.length,
    openPositions: openPositions.length,
    tradersStored: rows.length,
    partial,
    durationMs: Date.now() - startedAt,
    endpointSource: rpc.source,
  };
}
