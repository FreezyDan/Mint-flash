/**
 * All-time wallet PnL profiler — OpenSea API v2 account trade history.
 *
 * Unlike the bounded on-chain scan window (chainScanner.ts), this module
 * pulls a wallet's COMPLETE OpenSea (Seaport) sale history via
 *   GET /v2/events/accounts/{address}?event_type=sale&limit=50&next=…
 * pairs buys↔sells FIFO per (chain, contract) for all-time realized PnL,
 * and marks still-held positions at the CURRENT collection floor
 *   GET /v2/collections/{slug}/stats → total.floor_price
 * for all-time unrealized PnL.
 *
 * Sales paid in ETH/WETH are priced directly (`pricedWith: "native"`).
 * Sales paid in other ERC-20 tokens (USDC, etc.) are converted to ETH at
 * the historical DefiLlama rate via priceOracle.ts (`pricedWith: "oracle"`);
 * when the oracle can't price a token the sale is kept in history with null
 * amounts (`pricedWith: "unpriced"`) — excluded from realized PnL and the
 * equity curve, counted in `unpricedSales`, NEVER counted as zero profit.
 * Sells with an empty FIFO book (acquired via transfer/mint off-OpenSea)
 * are recorded with null cost basis and null PnL — never pure profit either.
 *
 * Aggregates are computed for three period windows from the same event set
 * (anchored at fetch time): all time, 3 weeks, 1 week.
 *
 * Same conventions as opensea.ts: x-api-key header, 8s per-request abort,
 * clear error messages; the whole profile run has a ~60s soft budget.
 */
import { openseaChainIdFromSlug, openseaFetch } from "./opensea";
import { createPriceResolver, type PriceResolver } from "./priceOracle";
import type {
  ProfileChainBreakdown,
  ProfileFlip,
  ProfileHolding,
  ProfileOpenPosition,
  ProfilePeriodStats,
  ProfilePricedWith,
  WalletProfile,
} from "@contracts/profile";

const MAX_PAGES = 40; // 40 × 50 = 2000 sale events
const PAGE_LIMIT = 50;
const PROFILE_BUDGET_MS = 60_000;
/** Floor marks are fetched for at most this many open groups (by open count). */
const MAX_FLOOR_GROUPS = 15;
/** Holdings step is skipped when less than this remains of the soft budget. */
const HOLDINGS_MIN_REMAINING_MS = 10_000;
/** Pages per chain on the account-NFTs endpoint (2 × 50 = 100 NFTs). */
const HOLDINGS_MAX_PAGES = 2;
/** Floor lookups for at most this many holding groups (by count). */
const MAX_HOLDING_FLOOR_GROUPS = 8;
/** Holdings shown in the payload. */
const TOP_HOLDINGS = 3;

/** WETH per chain id — ERC20 payment is only priced when it is WETH/ETH. */
const WETH_BY_CHAIN: Record<number, string> = {
  1: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
  8453: "0x4200000000000000000000000000000000000006",
  137: "0x7ceb23fd6bc0add59e62ac25578270cff1b9f619",
  42161: "0x82af49447d8a07e3bd95bd0d56f35241523fbab1",
  4663: "0x4200000000000000000000000000000000000006",
  57073: "0x4200000000000000000000000000000000000006",
  // Arc: USDC offers (6dp — toWei normalises; verified against live logs).
  5042: "0x3600000000000000000000000000000000000000",
};
const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";

/** Normalized sale event from the target wallet's perspective. */
export type ProfileSale = {
  chainId: number;
  /** NFT contract, lowercased. */
  contract: string;
  tokenId: string;
  collectionSlug: string | null;
  name: string | null;
  imageUrl: string | null;
  /**
   * Payment total normalized to wei (18 decimals). Null when the price
   * couldn't be resolved (unpriced). For non-native payments PENDING oracle
   * resolution this temporarily holds the token amount in 18dp fixed-point.
   */
  priceWei: bigint | null;
  pricedWith: ProfilePricedWith;
  /** True when priced via the oracle's nearest-current-rate fallback. */
  approxPrice?: boolean;
  /** Payment token symbol, uppercased (e.g. "ETH", "USDC"). */
  paymentSymbol: string | null;
  /** Payment token address, lowercased. */
  paymentToken: string | null;
  /** OpenSea payment.decimals when present; oracle decimals as fallback. */
  paymentDecimals: number | null;
  /** Raw payment quantity in the token's smallest unit. */
  paymentQuantity: string | null;
  /** Human-readable payment amount in whole tokens (4dp) for display. */
  paymentAmount: string | null;
  /** Target wallet is the buyer. */
  isBuy: boolean;
  /** Target wallet is the seller. */
  isSell: boolean;
  /** closing_date, unix seconds. */
  ts: number;
  txHash: string | null;
};

/** wei (bigint) → ETH decimal string truncated to 10 places, sign preserved. */
export function formatEth10(wei: bigint): string {
  const neg = wei < 0n;
  const abs = neg ? -wei : wei;
  const whole = abs / 10n ** 18n;
  const frac = (abs % 10n ** 18n) / 10n ** 8n;
  return `${neg ? "-" : ""}${whole}.${frac.toString().padStart(10, "0")}`;
}

/** True when the payment leg of a v2 sale event is ETH/WETH on this chain. */
function isEthPayment(
  symbol: unknown,
  tokenAddress: unknown,
  chainId: number,
): boolean {
  const sym = typeof symbol === "string" ? symbol.toUpperCase() : "";
  if (sym === "ETH" || sym === "WETH") return true;
  const token = typeof tokenAddress === "string" ? tokenAddress.toLowerCase() : "";
  if (token === ZERO_ADDRESS) return true;
  return token !== "" && token === WETH_BY_CHAIN[chainId];
}

/** Normalize a payment quantity (smallest unit per `decimals`) to wei. */
function toWei(quantity: unknown, decimals: unknown): bigint | null {
  try {
    let q = BigInt(String(quantity ?? "0"));
    const dec = typeof decimals === "number" && Number.isInteger(decimals) ? decimals : 18;
    if (dec > 18) q /= 10n ** BigInt(dec - 18);
    else if (dec < 18) q *= 10n ** BigInt(18 - dec);
    return q;
  } catch {
    return null;
  }
}

/** Whole-token amount (4dp truncated) for display, from raw quantity + decimals. */
function formatTokenAmount(quantity: string, decimals: number): string | null {
  const wei = toWei(quantity, decimals);
  if (wei === null) return null;
  const whole = wei / 10n ** 18n;
  const frac = (wei % 10n ** 18n) / 10n ** 14n;
  return `${whole}.${frac.toString().padStart(4, "0")}`;
}

/**
 * Parse raw v2 `asset_events` into normalized sales for `address`
 * (case-insensitive buyer/seller match). Events on unknown chains or not
 * involving the target are skipped. ETH/WETH payments are priced directly
 * (`native`); other ERC-20 payments are KEPT as `oracle`-pending (token
 * amount in priceWei when decimals are known) for applyOraclePrices().
 */
export function parseSaleEvents(rawEvents: unknown[], address: string): ProfileSale[] {
  const target = address.toLowerCase();
  const out: ProfileSale[] = [];
  for (const raw of rawEvents) {
    const ev = raw as Record<string, unknown> | null;
    if (!ev || ev.event_type !== "sale") continue;
    const chainId =
      typeof ev.chain === "string" ? openseaChainIdFromSlug(ev.chain) : null;
    if (chainId === null) continue;

    const nft = ev.nft as Record<string, unknown> | undefined;
    const contract = typeof nft?.contract === "string" ? nft.contract.toLowerCase() : null;
    const tokenId = nft?.identifier !== undefined && nft?.identifier !== null
      ? String(nft.identifier)
      : null;
    if (!contract || tokenId === null) continue;

    const payment = ev.payment as Record<string, unknown> | undefined;
    const native = isEthPayment(payment?.symbol, payment?.token_address, chainId);
    const symbol = typeof payment?.symbol === "string" ? payment.symbol.toUpperCase() : null;
    const tokenAddress =
      typeof payment?.token_address === "string" ? payment.token_address.toLowerCase() : null;
    // OpenSea payment.decimals is authoritative when present.
    const decimals =
      typeof payment?.decimals === "number" && Number.isInteger(payment.decimals)
        ? payment.decimals
        : null;
    const quantity =
      payment?.quantity !== undefined && payment?.quantity !== null
        ? String(payment.quantity)
        : null;

    let pricedWith: ProfilePricedWith;
    let priceWei: bigint | null;
    let paymentAmount: string | null = null;
    if (native) {
      priceWei = toWei(quantity, decimals ?? 18);
      if (priceWei === null) continue; // unparseable native amount — drop
      pricedWith = "native";
    } else if (quantity === null || tokenAddress === null) {
      pricedWith = "unpriced"; // no amount or no token to look up
      priceWei = null;
    } else if (decimals === null) {
      // Decimals may come back from the oracle at apply time.
      pricedWith = "oracle";
      priceWei = null;
    } else {
      priceWei = toWei(quantity, decimals); // token amount @18dp, ETH pending
      pricedWith = priceWei !== null ? "oracle" : "unpriced";
      paymentAmount = priceWei !== null ? formatTokenAmount(quantity, decimals) : null;
    }

    const seller = typeof ev.seller === "string" ? ev.seller.toLowerCase() : "";
    const buyer = typeof ev.buyer === "string" ? ev.buyer.toLowerCase() : "";
    const isSell = seller === target;
    const isBuy = buyer === target;
    if (!isSell && !isBuy) continue;

    out.push({
      chainId,
      contract,
      tokenId,
      collectionSlug: typeof nft?.collection === "string" ? nft.collection : null,
      name: typeof nft?.name === "string" ? nft.name : null,
      imageUrl: typeof nft?.image_url === "string" ? nft.image_url : null,
      priceWei,
      pricedWith,
      paymentSymbol: symbol,
      paymentToken: tokenAddress,
      paymentDecimals: decimals,
      paymentQuantity: quantity,
      paymentAmount,
      isBuy,
      isSell,
      ts: typeof ev.closing_date === "number" ? ev.closing_date : 0,
      txHash: typeof ev.transaction === "string" ? ev.transaction : null,
    });
  }
  return out;
}

/**
 * Resolve `oracle`-pending sales in place via the price oracle: token
 * amount × token USD ÷ historical ETH USD → ETH wei. Token USD is the
 * historical price when available, otherwise the oracle's CURRENT-price
 * fallback (`approxPrice: true` on the sale). When the oracle can't price
 * the token at all (or decimals are missing from both OpenSea and the
 * oracle) the sale becomes `unpriced` with a null priceWei — it is
 * kept in history but excluded from PnL, never treated as zero.
 */
export function applyOraclePrices(sales: ProfileSale[], oracle: PriceResolver): void {
  for (const s of sales) {
    if (s.pricedWith !== "oracle") continue;
    if (s.paymentToken === null || s.paymentQuantity === null) {
      s.pricedWith = "unpriced";
      continue;
    }
    let tokenWei = s.priceWei;
    if (tokenWei === null) {
      const dec = oracle.decimals(s.chainId, s.paymentToken, s.ts);
      const resolved = dec !== null ? toWei(s.paymentQuantity, dec) : null;
      if (resolved === null || dec === null) {
        s.pricedWith = "unpriced";
        continue;
      }
      tokenWei = resolved;
      s.paymentDecimals = dec;
      s.paymentAmount = formatTokenAmount(s.paymentQuantity, dec);
    }
    const conv = oracle.get(s.chainId, s.paymentToken, tokenWei, s.ts);
    if (conv === null) {
      s.pricedWith = "unpriced";
      s.priceWei = null;
      continue;
    }
    s.priceWei = conv.ethWei;
    s.approxPrice = conv.approx;
  }
}

type EventsPage = { asset_events?: unknown[]; next?: string | null };

/**
 * Page through the account's complete sale history (newest-first pages via
 * the `next` cursor) until exhausted, the page cap, or the soft time budget.
 * A rate-limit/timeout mid-pagination returns the partial history with
 * `truncated: true`; first-page failures throw.
 */
export async function fetchAccountSaleEvents(
  address: string,
  apiKey: string,
): Promise<{ rawEvents: unknown[]; eventsScanned: number; truncated: boolean }> {
  const startedAt = Date.now();
  const rawEvents: unknown[] = [];
  let next: string | null = null;
  let truncated = false;

  for (let page = 0; page < MAX_PAGES; page++) {
    if (Date.now() - startedAt > PROFILE_BUDGET_MS) {
      truncated = true;
      break;
    }
    const path =
      `/v2/events/accounts/${encodeURIComponent(address)}` +
      `?event_type=sale&limit=${PAGE_LIMIT}` +
      (next ? `&next=${encodeURIComponent(next)}` : "");
    let body: EventsPage;
    try {
      body = (await openseaFetch(path, apiKey)) as EventsPage;
    } catch (err) {
      if (page === 0) throw err;
      truncated = true;
      break;
    }
    const events = Array.isArray(body.asset_events) ? body.asset_events : [];
    rawEvents.push(...events);
    next = typeof body.next === "string" && body.next !== "" ? body.next : null;
    if (!next || events.length === 0) break;
    if (page === MAX_PAGES - 1) truncated = true;
  }

  return { rawEvents, eventsScanned: rawEvents.length, truncated };
}

/**
 * Current collection floor in wei from /v2/collections/{slug}/stats.
 * Returns null on any failure or a non-ETH floor — callers treat missing
 * floors as unpriced (never fatal).
 */
export async function fetchCollectionFloorWei(
  collectionSlug: string,
  apiKey: string,
): Promise<bigint | null> {
  try {
    const body = (await openseaFetch(
      `/v2/collections/${encodeURIComponent(collectionSlug)}/stats`,
      apiKey,
    )) as { total?: { floor_price?: number; floor_price_symbol?: string } };
    const total = body.total;
    const floor = total?.floor_price;
    const symbol = total?.floor_price_symbol?.toUpperCase();
    if (typeof floor !== "number" || !Number.isFinite(floor) || floor <= 0) return null;
    if (symbol && symbol !== "ETH" && symbol !== "WETH") return null;
    // floor_price is a float ETH value — convert via fixed-point string to
    // avoid binary float noise leaking into bigint math.
    return BigInt(floor.toFixed(18).replace(".", ""));
  } catch {
    return null;
  }
}

type BookEntry = {
  /** Entry cost in wei — null when the buy was paid in an unpriced token. */
  costWei: bigint | null;
  ts: number;
  tokenId: string;
  txHash: string | null;
  name: string | null;
  imageUrl: string | null;
};

type FlipInternal = Omit<ProfileFlip, "buyEth" | "sellEth" | "pnlEth"> & {
  buyWei: bigint | null;
  sellWei: bigint | null;
  pnlWei: bigint | null;
};

export type ComputeOptions = {
  /** Floor in wei keyed by `${chainId}:${collectionSlug}`; missing → unpriced. */
  floors?: Map<string, bigint>;
  flipsCap?: number;
  openCap?: number;
  /** "Now" in ms — period windows anchor here (defaults to Date.now()). */
  now?: number;
};

function emptyChainBreakdown(): ProfileChainBreakdown {
  return {
    realizedPnlEth: "0",
    unrealizedPnlEth: null,
    wins: 0,
    losses: 0,
    totalBuys: 0,
    totalSells: 0,
    flips: 0,
    unmatchedSells: 0,
    volumeEth: "0",
    openCount: 0,
  };
}

/**
 * Summary of leftover (open) FIFO book groups — used by the orchestrator to
 * pick which collections get a current-floor mark. Sorted by open count
 * desc, then last activity desc.
 */
export function openGroupSummary(
  sales: ProfileSale[],
): Array<{ chainId: number; contract: string; slug: string | null; openCount: number; lastTs: number }> {
  const books = new Map<string, { chainId: number; contract: string; slug: string | null; entries: BookEntry[]; lastTs: number }>();
  for (const s of [...sales].sort((a, b) => a.ts - b.ts)) {
    const key = `${s.chainId}:${s.contract}`;
    let g = books.get(key);
    if (!g) {
      g = { chainId: s.chainId, contract: s.contract, slug: s.collectionSlug, entries: [], lastTs: 0 };
      books.set(key, g);
    }
    if (s.collectionSlug) g.slug = s.collectionSlug;
    g.lastTs = Math.max(g.lastTs, s.ts);
    if (s.isSell && g.entries.length > 0) g.entries.shift();
    if (s.isBuy) g.entries.push({ costWei: s.priceWei, ts: s.ts, tokenId: s.tokenId, txHash: s.txHash, name: s.name, imageUrl: s.imageUrl });
  }
  return [...books.values()]
    .filter((g) => g.entries.length > 0)
    .map((g) => ({ chainId: g.chainId, contract: g.contract, slug: g.slug, openCount: g.entries.length, lastTs: g.lastTs }))
    .sort((a, b) => b.openCount - a.openCount || b.lastTs - a.lastTs);
}

/**
 * Pure all-time PnL computation. Groups sales per (chainId, contract),
 * sorts ascending by closing_date (stable), and runs a FIFO book: buys push
 * {qty 1, cost}, sells pop the oldest entry into a realized flip. A sell on
 * an empty book is recorded with null cost basis (unmatchedSell) — never
 * pure profit. Unpriced sales (null priceWei) still consume FIFO units but
 * contribute null amounts — excluded from PnL, volume, and equity curves.
 * Leftover entries are open positions marked at the provided current floors
 * (null floor → null unrealized). Also computes the all/3-week/1-week
 * period aggregates from the same flips + open positions.
 */
export function computeWalletProfile(
  address: string,
  sales: ProfileSale[],
  opts: ComputeOptions = {},
): WalletProfile {
  const flipsCap = opts.flipsCap ?? 50;
  const openCap = opts.openCap ?? 30;
  const floors = opts.floors ?? new Map<string, bigint>();

  // Group per (chainId, contract); Array.prototype.sort is stable, so
  // equal closing dates keep API order.
  const groups = new Map<string, ProfileSale[]>();
  for (const s of sales) {
    const key = `${s.chainId}:${s.contract}`;
    const g = groups.get(key);
    if (g) g.push(s);
    else groups.set(key, [s]);
  }

  const flips: FlipInternal[] = [];
  const openPositions: Array<Omit<ProfileOpenPosition, "costEth" | "floorEth" | "unrealizedPnlEth"> & { costWei: bigint | null; floorWei: bigint | null }> = [];

  let realizedWei = 0n;
  let volumeWei = 0n;
  let wins = 0;
  let losses = 0;
  let totalBuys = 0;
  let totalSells = 0;
  let unmatchedSells = 0;
  let oraclePricedCount = 0;
  let approxPricedCount = 0;
  let unpricedSales = 0;
  const paymentSymbols = new Set<string>();
  let firstActivityTs: number | null = null;
  let lastActivityTs: number | null = null;

  const chainsWei = new Map<number, {
    realizedWei: bigint;
    wins: number;
    losses: number;
    totalBuys: number;
    totalSells: number;
    flips: number;
    unmatchedSells: number;
    volumeWei: bigint;
    openCount: number;
    unrealizedWei: bigint;
    pricedOpens: number;
  }>();
  const chainAgg = (chainId: number) => {
    let c = chainsWei.get(chainId);
    if (!c) {
      c = { realizedWei: 0n, wins: 0, losses: 0, totalBuys: 0, totalSells: 0, flips: 0, unmatchedSells: 0, volumeWei: 0n, openCount: 0, unrealizedWei: 0n, pricedOpens: 0 };
      chainsWei.set(chainId, c);
    }
    return c;
  };

  for (const groupSales of groups.values()) {
    const sorted = [...groupSales].sort((a, b) => a.ts - b.ts);
    const book: BookEntry[] = [];
    let slug: string | null = null;
    for (const s of sorted) {
      if (s.collectionSlug) slug = s.collectionSlug;
      firstActivityTs = firstActivityTs === null ? s.ts : Math.min(firstActivityTs, s.ts);
      lastActivityTs = lastActivityTs === null ? s.ts : Math.max(lastActivityTs, s.ts);
      if (s.paymentSymbol) paymentSymbols.add(s.paymentSymbol);
      if (s.pricedWith === "oracle") {
        oraclePricedCount += 1;
        if (s.approxPrice) approxPricedCount += 1;
      }
      if (s.pricedWith === "unpriced") unpricedSales += 1;
      const agg = chainAgg(s.chainId);
      if (s.isSell) {
        totalSells += 1;
        agg.totalSells += 1;
        if (s.priceWei !== null) {
          volumeWei += s.priceWei;
          agg.volumeWei += s.priceWei;
        }
        const entry = book.shift() ?? null;
        const pnlWei =
          entry !== null && entry.costWei !== null && s.priceWei !== null
            ? s.priceWei - entry.costWei
            : null;
        if (pnlWei !== null) {
          realizedWei += pnlWei;
          agg.realizedWei += pnlWei;
          agg.flips += 1;
          if (pnlWei > 0n) { wins += 1; agg.wins += 1; }
          else { losses += 1; agg.losses += 1; }
        }
        if (entry === null) {
          unmatchedSells += 1;
          agg.unmatchedSells += 1;
        }
        flips.push({
          chainId: s.chainId,
          contract: s.contract,
          collectionSlug: s.collectionSlug ?? slug,
          name: s.name,
          imageUrl: s.imageUrl,
          tokenId: s.tokenId,
          buyWei: entry?.costWei ?? null,
          sellWei: s.priceWei,
          pnlWei,
          pricedWith: s.pricedWith,
          approxPrice: s.approxPrice === true ? true : undefined,
          paymentSymbol: s.paymentSymbol,
          paymentAmount: s.paymentAmount,
          buyTs: entry?.ts ?? null,
          sellTs: s.ts,
          buyTxHash: entry?.txHash ?? null,
          txHash: s.txHash,
          unmatchedSell: entry === null,
        });
      }
      if (s.isBuy) {
        totalBuys += 1;
        agg.totalBuys += 1;
        if (s.priceWei !== null) {
          volumeWei += s.priceWei;
          agg.volumeWei += s.priceWei;
        }
        book.push({ costWei: s.priceWei, ts: s.ts, tokenId: s.tokenId, txHash: s.txHash, name: s.name, imageUrl: s.imageUrl });
      }
    }
    // Leftover book = open positions, marked at the current collection floor.
    const sample = sorted[sorted.length - 1];
    const floorWei =
      slug !== null ? floors.get(`${sample.chainId}:${slug}`) ?? null : null;
    for (const entry of book) {
      chainAgg(sample.chainId).openCount += 1;
      if (floorWei !== null && entry.costWei !== null) {
        const c = chainAgg(sample.chainId);
        c.unrealizedWei += floorWei - entry.costWei;
        c.pricedOpens += 1;
      }
      openPositions.push({
        chainId: sample.chainId,
        contract: sample.contract,
        collectionSlug: slug,
        name: entry.name,
        imageUrl: entry.imageUrl,
        tokenId: entry.tokenId,
        costWei: entry.costWei,
        entryTs: entry.ts,
        buyTxHash: entry.txHash,
        floorWei,
      });
    }
  }

  // ---- assemble JSON payload ----
  const flipsOut: ProfileFlip[] = flips
    .map((f) => ({
      ...f,
      buyEth: f.buyWei !== null ? formatEth10(f.buyWei) : null,
      sellEth: f.sellWei !== null ? formatEth10(f.sellWei) : null,
      pnlEth: f.pnlWei !== null ? formatEth10(f.pnlWei) : null,
    }))
    .map(({ buyWei: _b, sellWei: _s, pnlWei: _p, ...rest }) => rest);
  // Best-first; unmatched (null PnL) always last.
  flipsOut.sort((a, b) => {
    if (a.pnlEth === null) return b.pnlEth === null ? b.sellTs - a.sellTs : 1;
    if (b.pnlEth === null) return -1;
    return Number(b.pnlEth) - Number(a.pnlEth);
  });

  const matched = flipsOut.filter((f) => f.pnlEth !== null);
  const bestFlip = matched.length > 0 ? matched[0] : null;
  const worstFlip = matched.length > 0 ? matched[matched.length - 1] : null;

  const openOut: ProfileOpenPosition[] = openPositions.map((p) => ({
    chainId: p.chainId,
    contract: p.contract,
    collectionSlug: p.collectionSlug,
    name: p.name,
    imageUrl: p.imageUrl,
    tokenId: p.tokenId,
    costEth: p.costWei !== null ? formatEth10(p.costWei) : null,
    entryTs: p.entryTs,
    buyTxHash: p.buyTxHash,
    floorEth: p.floorWei !== null ? formatEth10(p.floorWei) : null,
    unrealizedPnlEth:
      p.floorWei !== null && p.costWei !== null ? formatEth10(p.floorWei - p.costWei) : null,
  }));
  openOut.sort((a, b) => {
    if (a.unrealizedPnlEth === null) return b.unrealizedPnlEth === null ? b.entryTs - a.entryTs : 1;
    if (b.unrealizedPnlEth === null) return -1;
    return Number(b.unrealizedPnlEth) - Number(a.unrealizedPnlEth);
  });

  let unrealizedWei = 0n;
  let pricedOpens = 0;
  const chains: Record<string, ProfileChainBreakdown> = {};
  for (const [chainId, c] of [...chainsWei.entries()].sort((a, b) => a[0] - b[0])) {
    unrealizedWei += c.unrealizedWei;
    pricedOpens += c.pricedOpens;
    chains[String(chainId)] = {
      ...emptyChainBreakdown(),
      realizedPnlEth: formatEth10(c.realizedWei),
      unrealizedPnlEth: c.pricedOpens > 0 ? formatEth10(c.unrealizedWei) : null,
      wins: c.wins,
      losses: c.losses,
      totalBuys: c.totalBuys,
      totalSells: c.totalSells,
      flips: c.flips,
      unmatchedSells: c.unmatchedSells,
      volumeEth: formatEth10(c.volumeWei),
      openCount: c.openCount,
    };
  }

  // Equity curve: cumulative realized PnL over matched flips by sell time.
  let cum = 0n;
  const equityCurve = flips
    .filter((f) => f.pnlWei !== null)
    .sort((a, b) => a.sellTs - b.sellTs)
    .map((f) => {
      cum += f.pnlWei!;
      return { ts: f.sellTs, pnlEth: formatEth10(cum) };
    });

  // ---- period windows (all time / 3 weeks / 1 week), anchored at now ----
  // Realized stats: flips whose SELL ts is inside the window (a flip's PnL
  // realizes at sale time; the entry may be older). Unrealized stats: open
  // positions whose ENTRY ts is inside the window, at the same floors.
  const nowMs = opts.now ?? Date.now();
  const nowSec = Math.floor(nowMs / 1000);
  const WEEK_SEC = 7 * 24 * 3600;

  const buildPeriod = (windowSec: number | null): ProfilePeriodStats => {
    const start = windowSec === null ? null : nowSec - windowSec;
    const inWin = (ts: number) => start === null || ts >= start;

    let pRealized = 0n;
    let pVolume = 0n;
    let pWins = 0;
    let pLosses = 0;
    let pBuys = 0;
    let pSells = 0;
    let pCum = 0n;
    const pCurve: Array<{ ts: number; pnlEth: string }> = [];
    const pChains = new Map<number, {
      realizedWei: bigint; wins: number; losses: number; totalBuys: number;
      totalSells: number; flips: number; unmatchedSells: number;
      volumeWei: bigint; openCount: number; unrealizedWei: bigint; pricedOpens: number;
    }>();
    const pChainAgg = (chainId: number) => {
      let c = pChains.get(chainId);
      if (!c) {
        c = { realizedWei: 0n, wins: 0, losses: 0, totalBuys: 0, totalSells: 0, flips: 0, unmatchedSells: 0, volumeWei: 0n, openCount: 0, unrealizedWei: 0n, pricedOpens: 0 };
        pChains.set(chainId, c);
      }
      return c;
    };

    const winFlips = flips.filter((f) => inWin(f.sellTs)).sort((a, b) => a.sellTs - b.sellTs);
    for (const f of winFlips) {
      pSells += 1;
      const c = pChainAgg(f.chainId);
      c.totalSells += 1;
      if (f.sellWei !== null) {
        pVolume += f.sellWei;
        c.volumeWei += f.sellWei;
      }
      if (f.unmatchedSell) c.unmatchedSells += 1;
      if (f.buyTs !== null && inWin(f.buyTs)) {
        pBuys += 1;
        c.totalBuys += 1;
        if (f.buyWei !== null) {
          pVolume += f.buyWei;
          c.volumeWei += f.buyWei;
        }
      }
      if (f.pnlWei !== null) {
        pRealized += f.pnlWei;
        c.realizedWei += f.pnlWei;
        c.flips += 1;
        if (f.pnlWei > 0n) { pWins += 1; c.wins += 1; }
        else { pLosses += 1; c.losses += 1; }
        pCum += f.pnlWei;
        pCurve.push({ ts: f.sellTs, pnlEth: formatEth10(pCum) });
      }
    }

    let pUnrealized = 0n;
    let pPricedOpens = 0;
    let pOpenCount = 0;
    for (const p of openPositions) {
      if (!inWin(p.entryTs)) continue;
      pOpenCount += 1;
      pBuys += 1;
      const c = pChainAgg(p.chainId);
      c.openCount += 1;
      c.totalBuys += 1;
      if (p.costWei !== null) {
        pVolume += p.costWei;
        c.volumeWei += p.costWei;
      }
      if (p.floorWei !== null && p.costWei !== null) {
        pUnrealized += p.floorWei - p.costWei;
        pPricedOpens += 1;
        c.unrealizedWei += p.floorWei - p.costWei;
        c.pricedOpens += 1;
      }
    }

    const pChainsOut: Record<string, ProfileChainBreakdown> = {};
    for (const [chainId, c] of [...pChains.entries()].sort((a, b) => a[0] - b[0])) {
      pChainsOut[String(chainId)] = {
        ...emptyChainBreakdown(),
        realizedPnlEth: formatEth10(c.realizedWei),
        unrealizedPnlEth: c.pricedOpens > 0 ? formatEth10(c.unrealizedWei) : null,
        wins: c.wins,
        losses: c.losses,
        totalBuys: c.totalBuys,
        totalSells: c.totalSells,
        flips: c.flips,
        unmatchedSells: c.unmatchedSells,
        volumeEth: formatEth10(c.volumeWei),
        openCount: c.openCount,
      };
    }

    const pDecided = pWins + pLosses;
    return {
      realizedPnlEth: formatEth10(pRealized),
      unrealizedPnlEth: pPricedOpens > 0 ? formatEth10(pUnrealized) : null,
      wins: pWins,
      losses: pLosses,
      winRatePct: pDecided > 0 ? Math.round((pWins / pDecided) * 1000) / 10 : 0,
      buys: pBuys,
      sells: pSells,
      volumeEth: formatEth10(pVolume),
      openCount: pOpenCount,
      equityCurve: pCurve,
      chains: pChainsOut,
    };
  };

  const decided = wins + losses;
  const unrealized = pricedOpens > 0 ? formatEth10(unrealizedWei) : null;
  return {
    address: address.toLowerCase(),
    realizedPnlEth: formatEth10(realizedWei),
    unrealizedPnlEth: unrealized,
    totalPnlEth: formatEth10(realizedWei + unrealizedWei),
    winRatePct: decided > 0 ? Math.round((wins / decided) * 1000) / 10 : 0,
    wins,
    losses,
    totalBuys,
    totalSells,
    volumeEth: formatEth10(volumeWei),
    openCount: openOut.length,
    unpricedOpenCount: openOut.filter((p) => p.floorEth === null).length,
    unmatchedSells,
    chains,
    bestFlip,
    worstFlip,
    flips: flipsOut.slice(0, flipsCap),
    openPositions: openOut.slice(0, openCap),
    equityCurve,
    firstActivityTs,
    lastActivityTs,
    fetchedAt: new Date(nowMs).toISOString(),
    eventsScanned: sales.length,
    truncated: false,
    collectionsPriced: 0,
    oraclePricedCount,
    approxPricedCount,
    unpricedSales,
    paymentSymbols: [...paymentSymbols].sort(),
    periods: {
      all: buildPeriod(null),
      week3: buildPeriod(3 * WEEK_SEC),
      week1: buildPeriod(WEEK_SEC),
    },
  };
}

/* ------------------------------------------------------------------ */
/* Current holdings (top NFT collections held right now)               */
/* ------------------------------------------------------------------ */

/** One currently-held NFT from GET /v2/chain/{slug}/account/{addr}/nfts. */
export type HoldingNft = {
  chainId: number;
  /** NFT contract, lowercased. */
  contract: string;
  collectionSlug: string;
  /** OpenSea metadata name (e.g. "Bored Ape #1234") when present. */
  name: string | null;
  imageUrl: string | null;
};

/** Aggregated per (chainId, collectionSlug) before formatting. */
export type HoldingGroup = {
  chainId: number;
  collectionSlug: string;
  name: string;
  imageUrl: string | null;
  count: number;
  floorWei: bigint | null;
  /** count × floorWei — null when the floor is unknown. */
  valueWei: bigint | null;
};

/**
 * Parse the `nfts` array of the account-NFTs v2 response for one chain.
 * Items without a contract or collection slug are skipped; every other
 * field is read defensively (the endpoint's shape varies per chain).
 */
export function parseAccountNfts(rawNfts: unknown[], chainId: number): HoldingNft[] {
  const out: HoldingNft[] = [];
  for (const raw of rawNfts) {
    const nft = raw as Record<string, unknown> | null;
    if (!nft) continue;
    const contract =
      typeof nft.contract === "string" && nft.contract !== ""
        ? nft.contract.toLowerCase()
        : null;
    const collection =
      typeof nft.collection === "string" && nft.collection !== "" ? nft.collection : null;
    if (!contract || !collection) continue;
    out.push({
      chainId,
      contract,
      collectionSlug: collection,
      name: typeof nft.name === "string" && nft.name !== "" ? nft.name : null,
      imageUrl: typeof nft.image_url === "string" && nft.image_url !== "" ? nft.image_url : null,
    });
  }
  return out;
}

type AccountNftsPage = { nfts?: unknown[]; next?: string | null };

/**
 * Current holdings across the six OpenSea chains — at most
 * HOLDINGS_MAX_PAGES × 50 NFTs per chain, chains scanned with a small
 * concurrency pool. A failing chain is skipped (partial = true); the
 * whole step NEVER throws — total failure yields zero NFTs + partial.
 */
export async function fetchHoldings(
  address: string,
  apiKey: string,
): Promise<{ nfts: HoldingNft[]; chainsScanned: number; partial: boolean }> {
  const slugs = ["ethereum", "base", "arbitrum", "polygon", "robinhood", "ink"];
  const nfts: HoldingNft[] = [];
  let chainsScanned = 0;
  let failed = 0;

  const scanChain = async (slug: string): Promise<void> => {
    const chainId = openseaChainIdFromSlug(slug);
    if (chainId === null) {
      failed += 1;
      return;
    }
    try {
      let next: string | null = null;
      for (let page = 0; page < HOLDINGS_MAX_PAGES; page++) {
        const path =
          `/v2/chain/${encodeURIComponent(slug)}/account/${encodeURIComponent(address)}/nfts` +
          `?limit=${PAGE_LIMIT}` +
          (next ? `&next=${encodeURIComponent(next)}` : "");
        const body = (await openseaFetch(path, apiKey)) as AccountNftsPage;
        const items = Array.isArray(body.nfts) ? body.nfts : [];
        nfts.push(...parseAccountNfts(items, chainId));
        next = typeof body.next === "string" && body.next !== "" ? body.next : null;
        if (!next || items.length === 0) break;
      }
      chainsScanned += 1;
    } catch {
      failed += 1; // chain skipped — never fatal
    }
  };

  // Concurrency-3 pool across chains.
  for (let i = 0; i < slugs.length; i += 3) {
    await Promise.all(slugs.slice(i, i + 3).map(scanChain));
  }
  return { nfts, chainsScanned, partial: failed > 0 };
}

/**
 * Best display name for a holding group: the nft.name with its trailing
 * token id ("Name #1234" → "Name") when that leaves a real word,
 * otherwise the collection slug.
 */
function holdingDisplayName(nftName: string | null, slug: string): string {
  if (nftName === null) return slug;
  const stripped = nftName.replace(/\s*#\s*\S+\s*$/, "").trim();
  return stripped !== "" && !/^\d+$/.test(stripped) ? stripped : slug;
}

/** Rank: est. value desc (nulls last), tiebreak count desc. */
function compareHoldingGroups(a: HoldingGroup, b: HoldingGroup): number {
  if (a.valueWei === null) return b.valueWei === null ? b.count - a.count : 1;
  if (b.valueWei === null) return -1;
  if (a.valueWei !== b.valueWei) return a.valueWei > b.valueWei ? -1 : 1;
  return b.count - a.count;
}

/**
 * Pure holdings aggregation: group per (chainId, collectionSlug), value
 * each group at count × floor (null floor → null value), rank value-first
 * (unpriced last, count tiebreak) and cut to the top `topN`. Floors are
 * keyed `${chainId}:${collectionSlug}`; missing → unpriced.
 */
export function aggregateHoldings(
  nfts: HoldingNft[],
  floors: Map<string, bigint>,
  topN = TOP_HOLDINGS,
): { holdings: ProfileHolding[]; nftCount: number; collectionCount: number } {
  const groups = new Map<string, HoldingGroup>();
  for (const nft of nfts) {
    const key = `${nft.chainId}:${nft.collectionSlug}`;
    let g = groups.get(key);
    if (!g) {
      g = {
        chainId: nft.chainId,
        collectionSlug: nft.collectionSlug,
        name: holdingDisplayName(nft.name, nft.collectionSlug),
        imageUrl: nft.imageUrl,
        count: 0,
        floorWei: null,
        valueWei: null,
      };
      groups.set(key, g);
    }
    g.count += 1;
    if (g.imageUrl === null && nft.imageUrl !== null) g.imageUrl = nft.imageUrl;
  }
  for (const [key, g] of groups) {
    g.floorWei = floors.get(key) ?? null;
    g.valueWei = g.floorWei !== null ? g.floorWei * BigInt(g.count) : null;
  }
  const ranked = [...groups.values()].sort(compareHoldingGroups);
  return {
    holdings: ranked.slice(0, topN).map((g) => ({
      chainId: g.chainId,
      collectionSlug: g.collectionSlug,
      name: g.name,
      imageUrl: g.imageUrl,
      count: g.count,
      floorEth: g.floorWei !== null ? formatEth10(g.floorWei) : null,
      valueEth: g.valueWei !== null ? formatEth10(g.valueWei) : null,
    })),
    nftCount: nfts.length,
    collectionCount: groups.size,
  };
}

/**
 * Attach the top-holdings section to a computed profile. Skipped entirely
 * when the soft budget is nearly exhausted (holdingsSkipped); any chain
 * failure degrades to holdingsPartial. NEVER throws.
 */
async function attachHoldings(
  profile: WalletProfile,
  address: string,
  apiKey: string,
  startedAt: number,
): Promise<void> {
  if (PROFILE_BUDGET_MS - (Date.now() - startedAt) < HOLDINGS_MIN_REMAINING_MS) {
    profile.holdings = [];
    profile.holdingsTotals = { nftCount: 0, collectionCount: 0, chainsScanned: 0 };
    profile.holdingsPartial = false;
    profile.holdingsSkipped = true;
    return;
  }
  const { nfts, chainsScanned, partial } = await fetchHoldings(address, apiKey);

  // Value the largest groups: floors for the top MAX_HOLDING_FLOOR_GROUPS
  // by count (concurrency 3, within the remaining soft budget).
  const byCount = new Map<string, { chainId: number; slug: string; count: number }>();
  for (const nft of nfts) {
    const key = `${nft.chainId}:${nft.collectionSlug}`;
    const g = byCount.get(key);
    if (g) g.count += 1;
    else byCount.set(key, { chainId: nft.chainId, slug: nft.collectionSlug, count: 1 });
  }
  const topGroups = [...byCount.entries()]
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, MAX_HOLDING_FLOOR_GROUPS);
  const floors = new Map<string, bigint>();
  for (let i = 0; i < topGroups.length; i += 3) {
    if (Date.now() - startedAt > PROFILE_BUDGET_MS) break;
    await Promise.all(
      topGroups.slice(i, i + 3).map(async ([key, g]) => {
        const floorWei = await fetchCollectionFloorWei(g.slug, apiKey);
        if (floorWei !== null) floors.set(key, floorWei);
      }),
    );
  }

  const { holdings, nftCount, collectionCount } = aggregateHoldings(nfts, floors);
  profile.holdings = holdings;
  profile.holdingsTotals = { nftCount, collectionCount, chainsScanned };
  profile.holdingsPartial = partial;
  profile.holdingsSkipped = false;
}

/**
 * Full orchestration: fetch the complete sale history, fetch current floors
 * for the largest open groups (cap MAX_FLOOR_GROUPS, within the soft
 * budget), and compute the all-time profile.
 */
export async function profileWallet(address: string, apiKey: string): Promise<WalletProfile> {
  const startedAt = Date.now();
  const { rawEvents, eventsScanned, truncated } = await fetchAccountSaleEvents(address, apiKey);
  const sales = parseSaleEvents(rawEvents, address);

  // Convert non-ETH/WETH payments at historical rates. The oracle has its
  // own ~15s budget and never throws — unresolved sales stay unpriced.
  if (sales.some((s) => s.pricedWith === "oracle")) {
    const oracle = createPriceResolver();
    for (const s of sales) {
      if (s.pricedWith === "oracle" && s.paymentToken !== null) {
        oracle.request(s.chainId, s.paymentToken, s.ts);
      }
    }
    await oracle.resolve();
    applyOraclePrices(sales, oracle);
  }

  const groups = openGroupSummary(sales).filter((g) => g.slug !== null);
  const floors = new Map<string, bigint>();
  let collectionsPriced = 0;
  for (const g of groups.slice(0, MAX_FLOOR_GROUPS)) {
    if (Date.now() - startedAt > PROFILE_BUDGET_MS) break;
    const key = `${g.chainId}:${g.slug}`;
    if (floors.has(key)) continue;
    const floorWei = await fetchCollectionFloorWei(g.slug!, apiKey);
    if (floorWei !== null) {
      floors.set(key, floorWei);
      collectionsPriced += 1;
    }
  }

  const profile = computeWalletProfile(address, sales, { floors });
  profile.eventsScanned = eventsScanned;
  profile.truncated = truncated;
  profile.collectionsPriced = collectionsPriced;

  // Current holdings (top collections) — best-effort, within the soft
  // budget; failures degrade to partial/empty, never fail the profile.
  try {
    await attachHoldings(profile, address, apiKey, startedAt);
  } catch {
    profile.holdings = [];
    profile.holdingsTotals = { nftCount: 0, collectionCount: 0, chainsScanned: 0 };
    profile.holdingsPartial = true;
    profile.holdingsSkipped = false;
  }
  return profile;
}
