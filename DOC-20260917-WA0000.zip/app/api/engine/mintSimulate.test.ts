import { describe, expect, it } from "vitest";
import {
  extractRevertReason,
  shouldSendAfterSim,
  simulateMint,
  type SimulateProvider,
} from "./mintSimulate";

const ADDR = "0x" + "ab".repeat(20);

describe("shouldSendAfterSim", () => {
  it("sends when the simulation succeeds", () => {
    expect(shouldSendAfterSim({ ok: true })).toBe(true);
  });

  it("holds fire when the simulation reverts", () => {
    expect(
      shouldSendAfterSim({ ok: false, kind: "revert", reason: "not whitelisted" }),
    ).toBe(false);
  });

  it("sends anyway on infra failure (never block on node hiccups)", () => {
    expect(
      shouldSendAfterSim({ ok: false, kind: "infra", reason: "simulation timeout" }),
    ).toBe(true);
  });

  it("holds only for reverts — an empty-reason infra error still sends", () => {
    expect(shouldSendAfterSim({ ok: false, kind: "infra", reason: "" })).toBe(true);
  });
});

describe("extractRevertReason", () => {
  it("prefers ethers' decoded reason", () => {
    expect(
      extractRevertReason({ code: "CALL_EXCEPTION", reason: "Not on allowlist" }),
    ).toBe("Not on allowlist");
  });

  it("falls back to the nested node error message and strips the wrapper", () => {
    expect(
      extractRevertReason({
        code: "CALL_EXCEPTION",
        reason: null,
        info: { error: { message: "execution reverted: Sale not active" } },
      }),
    ).toBe("Sale not active");
  });

  it("caps the reason at 120 chars", () => {
    const long = extractRevertReason({ code: "CALL_EXCEPTION", reason: "x".repeat(200) });
    expect(long.length).toBe(120);
    expect(long.endsWith("...")).toBe(true);
  });

  it("degrades to a generic reason for shapeless errors", () => {
    expect(extractRevertReason({})).toBe("execution reverted");
  });
});

describe("simulateMint", () => {
  const tx = { from: ADDR, contractAddress: ADDR, data: "0x1234", valueWei: 0n };

  it("returns ok when eth_call succeeds", async () => {
    const provider: SimulateProvider = { call: async () => "0x" };
    expect(await simulateMint(provider, tx)).toEqual({ ok: true });
  });

  it("classifies CALL_EXCEPTION as a revert with the decoded reason", async () => {
    const provider: SimulateProvider = {
      call: async () => {
        throw { code: "CALL_EXCEPTION", reason: "Merkle proof invalid" };
      },
    };
    const r = await simulateMint(provider, tx);
    expect(r.ok).toBe(false);
    expect(r).toMatchObject({ kind: "revert", reason: "Merkle proof invalid" });
  });

  it("classifies plain node errors as infra (send proceeds)", async () => {
    const provider: SimulateProvider = {
      call: async () => {
        throw new Error("fetch failed");
      },
    };
    const r = await simulateMint(provider, tx);
    expect(r.ok).toBe(false);
    expect(r).toMatchObject({ kind: "infra" });
    expect(shouldSendAfterSim(r)).toBe(true);
  });
});
