/**
 * Wallet behavior labels (competitor: GMGN wallet tags).
 *
 * Pure derivation from the aggregates the chain scanner already computes —
 * no extra RPC calls. Labels are returned in importance order (smart-money
 * first) and capped at MAX_LABELS so the UI never shows a wall of chips.
 *
 * Rule thresholds (tuned for a short recency-weighted scan window):
 *  - smart-money : win rate ≥ 60% AND ≥ 10 flips AND realized PnL > 0
 *    Consistently profitable over a meaningful sample — the headline tag.
 *  - sniper      : mint flips ≥ 60% of flips AND ≥ 5 flips
 *    Mints-and-dumps rather than trading the secondary market.
 *  - whale       : total volume (spend + proceeds) ≥ 25 ETH in the window
 *    Size alone, regardless of profitability.
 *  - fresh       : first observed activity < 30 days (720h) before scan end
 *    Caveat: the scanner only observes the scan window, so "first observed
 *    activity" is the wallet's earliest sighting in-window (the caller
 *    supplies firstActivityAgeHours). Windows are far shorter than 30 days,
 *    so this mainly matters when a caller has genuine first-activity data.
 *  - flipper     : avg hold < 24h across ≥ 3 flips
 *    Quick in-and-out trading style.
 *  - diamond     : avg hold > 720h (30d) across ≥ 2 flips
 *    Patient holder that eventually sells. Mutually exclusive with flipper.
 *  - bagholder   : ≥ 5 open positions AND unrealized PnL < 0
 *    Stuck holding a bag of underwater, unsold acquisitions.
 */
import type { WalletLabel } from "@contracts/discover";

export const MAX_LABELS = 3;

/** Tunable thresholds, exported so tests + docs reference one source. */
export const LABEL_THRESHOLDS = {
  smartMoneyWinRatePct: 60,
  smartMoneyMinFlips: 10,
  sniperMintShare: 0.6,
  sniperMinFlips: 5,
  whaleVolumeEth: 25,
  freshMaxAgeHours: 24 * 30, // 30 days
  flipperMaxHoldHours: 24,
  flipperMinFlips: 3,
  diamondMinHoldHours: 24 * 30, // 30 days
  diamondMinFlips: 2,
  bagholderMinOpen: 5,
} as const;

/** Scanner-computed aggregates for one wallet (ETH-denominated numbers). */
export type LabelAggregate = {
  /** Win rate across completed flips, 0–100; null when no flips. */
  winRatePct: number | null;
  /** Completed flips (mint + secondary) in the scan window. */
  flips: number;
  /** Completed flips whose origin was a mint. */
  mintFlips: number;
  /** Realized PnL across paired buy→sell legs, in ETH. */
  realizedPnlEth: number;
  /** Total volume (spend + proceeds) in ETH. */
  volumeEth: number;
  /** Mean hold time across flips in hours; null when no flips. */
  avgHoldHours: number | null;
  /** Hours between the wallet's first observed activity and scan end;
   *  null when unknown. */
  firstActivityAgeHours: number | null;
  /** Unsold in-window acquisitions still held at scan end. */
  openPositions: number;
  /** Sum of unrealized PnL over marked open positions, ETH; null when
   *  no position has a mark. */
  unrealizedPnlEth: number | null;
};

/**
 * Compute a wallet's behavior labels, importance-ordered (smart-money first),
 * capped at MAX_LABELS.
 */
export function computeLabels(agg: LabelAggregate): WalletLabel[] {
  const t = LABEL_THRESHOLDS;
  const labels: WalletLabel[] = [];

  if (
    agg.winRatePct !== null &&
    agg.winRatePct >= t.smartMoneyWinRatePct &&
    agg.flips >= t.smartMoneyMinFlips &&
    agg.realizedPnlEth > 0
  ) {
    labels.push("smart-money");
  }
  if (agg.flips >= t.sniperMinFlips && agg.mintFlips / agg.flips >= t.sniperMintShare) {
    labels.push("sniper");
  }
  if (agg.volumeEth >= t.whaleVolumeEth) {
    labels.push("whale");
  }
  if (agg.firstActivityAgeHours !== null && agg.firstActivityAgeHours < t.freshMaxAgeHours) {
    labels.push("fresh");
  }
  if (agg.avgHoldHours !== null && agg.avgHoldHours < t.flipperMaxHoldHours && agg.flips >= t.flipperMinFlips) {
    labels.push("flipper");
  }
  if (agg.avgHoldHours !== null && agg.avgHoldHours > t.diamondMinHoldHours && agg.flips >= t.diamondMinFlips) {
    labels.push("diamond");
  }
  if (agg.openPositions >= t.bagholderMinOpen && agg.unrealizedPnlEth !== null && agg.unrealizedPnlEth < 0) {
    labels.push("bagholder");
  }

  return labels.slice(0, MAX_LABELS);
}

/** Serialize for discovered_traders.labels (JSON array string; null = none). */
export function serializeLabels(labels: WalletLabel[]): string | null {
  return labels.length === 0 ? null : JSON.stringify(labels);
}

/** Parse the stored JSON array string; tolerant of null/garbage → []. */
export function parseLabels(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((v): v is string => typeof v === "string");
  } catch {
    return [];
  }
}
