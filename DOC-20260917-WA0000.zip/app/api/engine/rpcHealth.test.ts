import { beforeEach, describe, expect, it } from "vitest";
import {
  healthyEndpoints,
  isHealthy,
  markUnhealthy,
  resetEndpointHealth,
  UNHEALTHY_TTL_MS,
} from "./rpcHealth";

describe("rpcHealth", () => {
  beforeEach(() => resetEndpointHealth());

  it("unknown endpoints are healthy by default", () => {
    expect(isHealthy("https://a.example")).toBe(true);
  });

  it("markUnhealthy makes an endpoint unhealthy until the TTL expires", () => {
    const now = 1_000_000;
    markUnhealthy("https://a.example", now);
    expect(isHealthy("https://a.example", now + 1)).toBe(false);
    expect(isHealthy("https://a.example", now + UNHEALTHY_TTL_MS - 1)).toBe(false);
    // Other endpoints are unaffected.
    expect(isHealthy("https://b.example", now + 1)).toBe(true);
  });

  it("entries expire after 10 minutes (no re-probe needed)", () => {
    const now = 1_000_000;
    markUnhealthy("https://a.example", now);
    expect(isHealthy("https://a.example", now + UNHEALTHY_TTL_MS)).toBe(true);
    expect(isHealthy("https://a.example", now + UNHEALTHY_TTL_MS + 60_000)).toBe(true);
  });

  it("healthyEndpoints filters out unhealthy endpoints", () => {
    const pool = ["https://a.example", "https://b.example", "https://c.example"];
    const now = 5_000_000;
    markUnhealthy("https://a.example", now);
    markUnhealthy("https://c.example", now);
    expect(healthyEndpoints(pool, now + 1)).toEqual(["https://b.example"]);
  });

  it("healthyEndpoints falls back to the full pool when everything is unhealthy", () => {
    const pool = ["https://a.example", "https://b.example"];
    const now = 5_000_000;
    for (const url of pool) markUnhealthy(url, now);
    expect(healthyEndpoints(pool, now + 1)).toEqual(pool);
  });

  it("a custom ttlMs is honoured", () => {
    const now = 1_000;
    markUnhealthy("https://a.example", now, 30_000);
    expect(isHealthy("https://a.example", now + 29_999)).toBe(false);
    expect(isHealthy("https://a.example", now + 30_000)).toBe(true);
  });
});
