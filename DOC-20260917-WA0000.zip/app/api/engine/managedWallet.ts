import crypto from "node:crypto";
import { ethers } from "ethers";
import { botWallets } from "@db/schema";
import { env } from "../lib/env";
import { getDb } from "../queries/connection";
import { findManagedBotWallet } from "../queries/wallets";

/**
 * Managed bot wallet ("Auto vault").
 *
 * Every user gets one auto-created EVM wallet on sign-up. The private key is
 * stored AES-256-GCM encrypted in bot_wallets.encryptedKey, keyed by a
 * scrypt-derived secret from env.appSecret. Decryption happens server-side
 * only — the plaintext key is used to sign live transactions and is never
 * logged (logs print addresses / short hashes only).
 */

const KEY_DERIVATION_SALT = "mintdash-wallet-v1";

function deriveEncryptionKey(): Buffer {
  return crypto.scryptSync(env.appSecret, KEY_DERIVATION_SALT, 32);
}

/** Encrypt a private key for at-rest storage. Returns "iv:tag:ciphertext" (base64url). */
export function encryptKey(privateKey: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", deriveEncryptionKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(privateKey, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, ciphertext].map((b) => b.toString("base64url")).join(":");
}

/** Decrypt a payload produced by encryptKey. Server-side only. */
export function decryptKey(payload: string): string {
  const [ivB64, tagB64, ctB64] = payload.split(":");
  if (!ivB64 || !tagB64 || !ctB64) throw new Error("Malformed encrypted key payload");
  const decipher = crypto.createDecipheriv(
    "aes-256-gcm",
    deriveEncryptionKey(),
    Buffer.from(ivB64, "base64url"),
  );
  decipher.setAuthTag(Buffer.from(tagB64, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(ctB64, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}

/**
 * Idempotently ensure the user has a managed vault wallet. Race-tolerant: on
 * a duplicate-key insert (concurrent creation) the existing row is re-selected.
 */
export async function ensureManagedWallet(userId: number): Promise<{ address: string }> {
  const existing = await findManagedBotWallet(userId);
  if (existing) return { address: existing.address };

  const wallet = ethers.Wallet.createRandom();
  try {
    await getDb().insert(botWallets).values({
      userId,
      label: "Auto vault",
      address: wallet.address,
      managed: true,
      encryptedKey: encryptKey(wallet.privateKey),
    });
  } catch (err) {
    const raced = await findManagedBotWallet(userId);
    if (raced) return { address: raced.address };
    throw err;
  }
  return { address: wallet.address };
}

/** Decrypt the user's managed vault private key. Server-side only — never log the result. */
export async function getManagedPrivateKey(userId: number): Promise<string | null> {
  const row = await findManagedBotWallet(userId);
  if (!row?.encryptedKey) return null;
  try {
    return decryptKey(row.encryptedKey);
  } catch (err) {
    console.error("[vault] failed to decrypt managed wallet key:", err);
    return null;
  }
}

function envPrivateKeys(): string[] {
  return (process.env.BOT_PRIVATE_KEYS ?? "")
    .split(",")
    .map((k) => k.trim())
    .filter(Boolean);
}

/**
 * Full live-mode signing key set for a user: the managed vault key is the
 * primary signer (first), BOT_PRIVATE_KEYS env keys remain as extra wallets.
 * Falls back to env keys only if the vault key cannot be loaded.
 */
export async function getLiveExecutionKeys(userId: number): Promise<string[]> {
  const envKeys = envPrivateKeys();
  const managed = await getManagedPrivateKey(userId);
  const all = managed ? [managed, ...envKeys] : envKeys;
  return [...new Set(all)];
}
