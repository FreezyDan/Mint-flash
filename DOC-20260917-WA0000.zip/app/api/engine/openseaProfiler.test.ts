/**
 * Offline verification of the all-time profiler's parsing + FIFO math.
 * Raw events mimic the OpenSea API v2 `asset_events` sale shape, so this
 * exercises parse → chain/payment filtering → FIFO pairing → floor marking
 * → equity curve accumulation without any network access.
 */
import { describe, expect, it } from "vitest";
import {
  aggregateHoldings,
  applyOraclePrices,
  computeWalletProfile,
  formatEth10,
  openGroupSummary,
  parseAccountNfts,
  parseSaleEvents,
  type HoldingNft,
  type ProfileSale,
} from "./openseaProfiler";
import { createPriceResolver, type PriceFetcher } from "./priceOracle";

const TARGET = "0x1111111111111111111111111111111111111111";
const OTHER = "0x2222222222222222222222222222222222222222";
const COLLECTION = "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
const COLLECTION_B = "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
const ETH = 10n ** 18n;

let hashCounter = 0;
const nextHash = () => `0x${(++hashCounter).toString(16).padStart(64, "0")}`;

/** Build a raw OpenSea v2 sale event (the wire shape of asset_events[]). */
function saleEvent(args: {
  seller: string;
  buyer: string;
  ts: number;
  wei?: bigint;
  chain?: string;
  contract?: string;
  tokenId?: string;
  collection?: string;
  name?: string | null;
  symbol?: string;
  tokenAddress?: string;
  decimals?: number;
  quantity?: string;
  tx?: string;
}): Record<string, unknown> {
  return {
    event_type: "sale",
    order_hash: nextHash(),
    chain: args.chain ?? "ethereum",
    closing_date: args.ts,
    nft: {
      identifier: args.tokenId ?? "1",
      collection: args.collection ?? "test-collection",
      contract: (args.contract ?? COLLECTION).toLowerCase(),
      token_standard: "erc721",
      name: args.name === undefined ? "Test NFT" : args.name,
      image_url: "https://img.example/1.png",
    },
    quantity: 1,
    seller: args.seller,
    buyer: args.buyer,
    payment: {
      quantity: args.quantity ?? (args.wei ?? ETH).toString(),
      token_address:
        args.tokenAddress ?? "0x0000000000000000000000000000000000000000",
      decimals: args.decimals ?? 18,
      symbol: args.symbol ?? "ETH",
    },
    transaction: args.tx ?? nextHash(),
  };
}

describe("parseSaleEvents — v2 shape, chain + payment filtering", () => {
  it("keeps target sales, skips strangers, unknown chains and non-sale events", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100 }), // buy → keep
      saleEvent({ seller: OTHER, buyer: OTHER, ts: 101 }), // stranger → skip
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 102, chain: "unknownchain" }), // unknown chain → skip
      { event_type: "transfer", chain: "ethereum" }, // not a sale → skip
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 103, chain: "base", tokenId: "7" }), // sell on base → keep
    ];
    const sales = parseSaleEvents(raw, TARGET);
    expect(sales).toHaveLength(2);
    expect(sales[0]).toMatchObject({ isBuy: true, isSell: false, chainId: 1, ts: 100 });
    expect(sales[1]).toMatchObject({ isBuy: false, isSell: true, chainId: 8453, tokenId: "7" });
  });

  it("matches buyer/seller case-insensitively", () => {
    const checksummed = "0x1111111111111111111111111111111111111111".toUpperCase().replace("0X", "0x");
    const raw = [saleEvent({ seller: OTHER, buyer: checksummed, ts: 100 })];
    const sales = parseSaleEvents(raw, TARGET);
    expect(sales).toHaveLength(1);
    expect(sales[0].isBuy).toBe(true);
  });

  it("keeps non-ETH/WETH payments as oracle-pending; ETH/WETH stay native", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, symbol: "USDC", tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", decimals: 6, quantity: "2000000" }),
      // WETH payment on ethereum IS priced natively:
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 101, symbol: "WETH", tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2", wei: 2n * ETH }),
    ];
    const sales = parseSaleEvents(raw, TARGET);
    expect(sales).toHaveLength(2);
    // USDC: kept, pending oracle conversion — priceWei holds the 18dp TOKEN
    // amount (2 USDC) until applyOraclePrices swaps in the ETH value.
    expect(sales[0].pricedWith).toBe("oracle");
    expect(sales[0].priceWei).toBe(2n * ETH);
    expect(sales[0].paymentSymbol).toBe("USDC");
    expect(sales[0].paymentAmount).toBe("2.0000");
    expect(sales[1].pricedWith).toBe("native");
    expect(sales[1].priceWei).toBe(2n * ETH);
    expect(sales[1].ts).toBe(101);
  });

  it("normalizes payment quantities to wei via decimals (bigint, no float noise)", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, decimals: 8, quantity: "150000000" }), // 1.5 ETH in 8dp units
    ];
    const sales = parseSaleEvents(raw, TARGET);
    expect(sales[0].priceWei).toBe(15n * 10n ** 17n);
  });
});

describe("computeWalletProfile — FIFO pairing + aggregates", () => {
  it("pairs interleaved buys/sells FIFO per collection and aggregates", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 200, wei: 2n * ETH, tokenId: "2" }),
      // Sell pops the OLDEST buy (token 1, cost 1) even though token 3 is sold:
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 300, wei: 4n * ETH, tokenId: "3" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 400, wei: 1n * ETH, tokenId: "2" }),
    ];
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET));

    expect(p.realizedPnlEth).toBe(formatEth10(3n * ETH - 1n * ETH)); // +3 and -1 → +2
    expect(p.wins).toBe(1);
    expect(p.losses).toBe(1);
    expect(p.winRatePct).toBe(50);
    expect(p.totalBuys).toBe(2);
    expect(p.totalSells).toBe(2);
    // volume = buys (1+2) + sells (4+1) = 8
    expect(p.volumeEth).toBe(formatEth10(8n * ETH));
    expect(p.bestFlip!.pnlEth).toBe(formatEth10(3n * ETH));
    expect(p.worstFlip!.pnlEth).toBe(formatEth10(-1n * ETH));
    // First flip sold token 3 but consumed token 1's cost basis (FIFO).
    expect(p.flips.find((f) => f.tokenId === "3")!.buyEth).toBe(formatEth10(1n * ETH));
    expect(p.openCount).toBe(0);
    expect(p.unmatchedSells).toBe(0);
    expect(p.chains["1"].realizedPnlEth).toBe(formatEth10(2n * ETH));
  });

  it("records a sell on an empty book as no-cost-basis — never pure profit", () => {
    const raw = [
      // Acquired off-OpenSea (transfer/mint elsewhere), then sold on OpenSea:
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 100, wei: 5n * ETH, tokenId: "9" }),
    ];
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET));

    expect(p.unmatchedSells).toBe(1);
    expect(p.realizedPnlEth).toBe(formatEth10(0n));
    expect(p.flips).toHaveLength(1);
    expect(p.flips[0].unmatchedSell).toBe(true);
    expect(p.flips[0].buyEth).toBeNull();
    expect(p.flips[0].pnlEth).toBeNull();
    expect(p.wins).toBe(0);
    expect(p.losses).toBe(0);
    expect(p.bestFlip).toBeNull();
    // Proceeds still count toward volume; the sell is excluded from the curve.
    expect(p.volumeEth).toBe(formatEth10(5n * ETH));
    expect(p.equityCurve).toHaveLength(0);
  });

  it("marks open positions at the current floor; null floor → null unrealized", () => {
    const raw = [
      // Held: 2 units of test-collection (1 ETH each), 1 unit of col-b (2 ETH)
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 101, wei: 1n * ETH, tokenId: "2" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 102, wei: 2n * ETH, tokenId: "5", contract: COLLECTION_B, collection: "col-b", chain: "base" }),
      // One sold unit of test-collection so the group also has a realized leg:
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 103, wei: 1n * ETH, tokenId: "3" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 104, wei: 2n * ETH, tokenId: "3" }),
    ];
    const floors = new Map([["1:test-collection", 3n * ETH]]); // col-b unpriced
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET), { floors });

    expect(p.openCount).toBe(3);
    // Two priced opens: (3−1)×2 = +4; col-b has no floor → excluded.
    expect(p.unrealizedPnlEth).toBe(formatEth10(4n * ETH));
    expect(p.unpricedOpenCount).toBe(1);
    expect(p.totalPnlEth).toBe(formatEth10(1n * ETH + 4n * ETH)); // realized +1

    const colB = p.openPositions.find((o) => o.contract === COLLECTION_B)!;
    expect(colB.floorEth).toBeNull();
    expect(colB.unrealizedPnlEth).toBeNull();
    expect(colB.costEth).toBe(formatEth10(2n * ETH));
    expect(p.chains["8453"].unrealizedPnlEth).toBeNull();
    expect(p.chains["8453"].openCount).toBe(1);
    expect(p.chains["1"].unrealizedPnlEth).toBe(formatEth10(4n * ETH));
  });

  it("accumulates the equity curve over sell timestamps ascending", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 110, wei: 1n * ETH, tokenId: "2" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 120, wei: 1n * ETH, tokenId: "3" }),
      // Deliberately out-of-order sells in the array — curve must sort by ts.
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 300, wei: 1n * ETH, tokenId: "c" }), // pnl 0 → cum 2
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 200, wei: 3n * ETH, tokenId: "b" }), // pnl +2 → cum 2
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 250, wei: 0n, tokenId: "a" }), // pnl -1 → cum 1
    ];
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET));
    expect(p.equityCurve.map((e) => e.ts)).toEqual([200, 250, 300]);
    expect(p.equityCurve.map((e) => e.pnlEth)).toEqual([
      formatEth10(2n * ETH),
      formatEth10(1n * ETH),
      formatEth10(1n * ETH),
    ]);
  });

  it("keeps per-chain aggregates separate across collections and chains", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 200, wei: 2n * ETH, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 150, wei: 1n * ETH, tokenId: "4", chain: "polygon", collection: "poly-col" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 250, wei: 0n, tokenId: "4", chain: "polygon", collection: "poly-col" }),
    ];
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET));
    expect(p.chains["1"].realizedPnlEth).toBe(formatEth10(1n * ETH));
    expect(p.chains["137"].realizedPnlEth).toBe(formatEth10(-1n * ETH));
    expect(p.chains["1"].wins).toBe(1);
    expect(p.chains["137"].losses).toBe(1);
    expect(p.firstActivityTs).toBe(100);
    expect(p.lastActivityTs).toBe(250);
    expect(p.winRatePct).toBe(50);
  });
});

const USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48";

/** Mock DefiLlama fetcher keyed by coin (`chain:addr` / `coingecko:ethereum`). */
function mockPrices(prices: Record<string, { price: number; decimals?: number; symbol?: string }>) {
  const calls: string[] = [];
  const fetcher: PriceFetcher = async (url) => {
    calls.push(url);
    const m = url.match(/\/prices\/historical\/(\d+)\/(.+)$/);
    const coins: Record<string, unknown> = {};
    if (m) {
      for (const key of decodeURIComponent(m[2]).split(",")) {
        if (prices[key]) coins[key] = { timestamp: Number(m[1]), ...prices[key] };
      }
    }
    return { coins };
  };
  return { fetcher, calls };
}

/** Parse raw events and resolve oracle-pending sales with a mocked oracle. */
async function parseAndPrice(
  raw: unknown[],
  prices: Record<string, { price: number; decimals?: number; symbol?: string }>,
): Promise<ProfileSale[]> {
  const sales = parseSaleEvents(raw, TARGET);
  const { fetcher } = mockPrices(prices);
  const oracle = createPriceResolver({ fetcher });
  for (const s of sales) {
    if (s.pricedWith === "oracle" && s.paymentToken) oracle.request(s.chainId, s.paymentToken, s.ts);
  }
  await oracle.resolve();
  applyOraclePrices(sales, oracle);
  return sales;
}

describe("oracle pricing — non-ETH/WETH payments", () => {
  it("converts an ERC-20 sale at correct decimals and pairs it FIFO", async () => {
    const raw = [
      // Buy for 1000 USDC, sell for 3000 USDC; USDC $1, ETH $2000.
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, symbol: "USDC", tokenAddress: USDC, decimals: 6, quantity: "1000000000", tokenId: "1" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 200, symbol: "USDC", tokenAddress: USDC, decimals: 6, quantity: "3000000000", tokenId: "1" }),
    ];
    const sales = await parseAndPrice(raw, {
      [`ethereum:${USDC}`]: { price: 1.0, decimals: 6, symbol: "USDC" },
      "coingecko:ethereum": { price: 2000 },
    });
    expect(sales.every((s) => s.pricedWith === "oracle")).toBe(true);
    expect(sales[0].priceWei).toBe(5n * 10n ** 17n); // 0.5 ETH
    expect(sales[1].priceWei).toBe(15n * 10n ** 17n); // 1.5 ETH

    const p = computeWalletProfile(TARGET, sales);
    expect(p.realizedPnlEth).toBe(formatEth10(1n * ETH)); // +1 ETH
    expect(p.wins).toBe(1);
    expect(p.oraclePricedCount).toBe(2);
    expect(p.unpricedSales).toBe(0);
    expect(p.paymentSymbols).toEqual(["USDC"]);
    const flip = p.flips[0];
    expect(flip.pricedWith).toBe("oracle");
    expect(flip.paymentSymbol).toBe("USDC");
    expect(flip.paymentAmount).toBe("3000.0000");
    expect(flip.sellEth).toBe(formatEth10(15n * 10n ** 17n));
    expect(flip.buyEth).toBe(formatEth10(5n * 10n ** 17n));
    expect(p.equityCurve).toHaveLength(1);
  });

  it("oracle null → unpriced: kept in history, excluded from realized, never zero", async () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, wei: 1n * ETH, tokenId: "1" }),
      // Sell paid in USDC, but the oracle has no price for it:
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 200, symbol: "USDC", tokenAddress: USDC, decimals: 6, quantity: "3000000000", tokenId: "1" }),
    ];
    const sales = await parseAndPrice(raw, {}); // oracle knows nothing
    expect(sales[1].pricedWith).toBe("unpriced");
    expect(sales[1].priceWei).toBeNull();

    const p = computeWalletProfile(TARGET, sales);
    expect(p.unpricedSales).toBe(1);
    expect(p.realizedPnlEth).toBe(formatEth10(0n)); // NOT +1.5 or zero-profit tricks
    expect(p.wins).toBe(0);
    expect(p.losses).toBe(0);
    expect(p.equityCurve).toHaveLength(0);
    expect(p.bestFlip).toBeNull();
    // Only the native buy counts toward volume.
    expect(p.volumeEth).toBe(formatEth10(1n * ETH));
    const flip = p.flips[0];
    expect(flip.pricedWith).toBe("unpriced");
    expect(flip.unmatchedSell).toBe(false); // FIFO cost basis existed
    expect(flip.buyEth).toBe(formatEth10(1n * ETH));
    expect(flip.sellEth).toBeNull();
    expect(flip.pnlEth).toBeNull();
  });

  it("unpriced buy → null cost basis on the later native sell (never pure profit)", async () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, symbol: "USDC", tokenAddress: USDC, decimals: 6, quantity: "1000000000", tokenId: "1" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 200, wei: 2n * ETH, tokenId: "1" }),
    ];
    const sales = await parseAndPrice(raw, {}); // USDC buy unpriced
    const p = computeWalletProfile(TARGET, sales);
    expect(p.unpricedSales).toBe(1);
    expect(p.realizedPnlEth).toBe(formatEth10(0n));
    expect(p.flips[0].unmatchedSell).toBe(false); // unit was in the FIFO book
    expect(p.flips[0].buyEth).toBeNull();
    expect(p.flips[0].sellEth).toBe(formatEth10(2n * ETH));
    expect(p.flips[0].pnlEth).toBeNull();
    expect(p.volumeEth).toBe(formatEth10(2n * ETH));
  });

  it("falls back to oracle decimals when OpenSea omits payment.decimals", async () => {
    const ev = saleEvent({
      seller: OTHER, buyer: TARGET, ts: 100, symbol: "USDC", tokenAddress: USDC,
      decimals: 6, quantity: "1000000000", tokenId: "1",
    });
    delete (ev.payment as Record<string, unknown>).decimals; // OpenSea omitted it
    const sales = await parseAndPrice([ev], {
      [`ethereum:${USDC}`]: { price: 1.0, decimals: 6 },
      "coingecko:ethereum": { price: 2000 },
    });
    expect(sales[0].pricedWith).toBe("oracle");
    expect(sales[0].paymentDecimals).toBe(6);
    expect(sales[0].priceWei).toBe(5n * 10n ** 17n);
    expect(sales[0].paymentAmount).toBe("1000.0000");
  });

  it("no decimals from OpenSea AND none from the oracle → unpriced", async () => {
    const ev = saleEvent({
      seller: OTHER, buyer: TARGET, ts: 100, symbol: "USDC", tokenAddress: USDC,
      decimals: 6, quantity: "1000000000", tokenId: "1",
    });
    delete (ev.payment as Record<string, unknown>).decimals;
    const sales = await parseAndPrice([ev], {
      [`ethereum:${USDC}`]: { price: 1.0 }, // price but no decimals
      "coingecko:ethereum": { price: 2000 },
    });
    expect(sales[0].pricedWith).toBe("unpriced");
    expect(sales[0].priceWei).toBeNull();
  });

  it("mixes native and oracle-priced flips in one aggregation", async () => {
    const raw = [
      // Native flip: +1 ETH
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 200, wei: 2n * ETH, tokenId: "1" }),
      // Oracle flip on base: +0.5 ETH (1000→2000 USDC at $1, ETH $2000)
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 150, chain: "base", collection: "base-col", contract: COLLECTION_B, symbol: "USDC", tokenAddress: USDC, decimals: 6, quantity: "1000000000", tokenId: "2" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: 250, chain: "base", collection: "base-col", contract: COLLECTION_B, symbol: "USDC", tokenAddress: USDC, decimals: 6, quantity: "2000000000", tokenId: "2" }),
    ];
    const sales = await parseAndPrice(raw, {
      [`base:${USDC}`]: { price: 1.0, decimals: 6 },
      "coingecko:ethereum": { price: 2000 },
    });
    const p = computeWalletProfile(TARGET, sales);
    expect(p.realizedPnlEth).toBe(formatEth10(15n * 10n ** 17n)); // 1 + 0.5
    expect(p.wins).toBe(2);
    expect(p.oraclePricedCount).toBe(2);
    expect(p.paymentSymbols).toEqual(["ETH", "USDC"]);
    expect(p.chains["1"].realizedPnlEth).toBe(formatEth10(1n * ETH));
    expect(p.chains["8453"].realizedPnlEth).toBe(formatEth10(5n * 10n ** 17n));
    // Equity curve accumulates both, by sell time.
    expect(p.equityCurve.map((e) => e.pnlEth)).toEqual([
      formatEth10(1n * ETH),
      formatEth10(15n * 10n ** 17n),
    ]);
  });
});

describe("period windows — 1 week / 3 weeks / all time", () => {
  const NOW_SEC = 10_000_000_000;
  const NOW_MS = NOW_SEC * 1000;
  const DAY = 86_400;
  const COL_C = "0xcccccccccccccccccccccccccccccccccccccccc";

  // Three independent +1/+2/+4 ETH flips closed 30d / 10d / 2d ago.
  function windowEvents(): unknown[] {
    return [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: NOW_SEC - 40 * DAY, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: NOW_SEC - 30 * DAY, wei: 2n * ETH, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: NOW_SEC - 25 * DAY, wei: 1n * ETH, tokenId: "2", contract: COLLECTION_B, collection: "col-b" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: NOW_SEC - 10 * DAY, wei: 3n * ETH, tokenId: "2", contract: COLLECTION_B, collection: "col-b" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: NOW_SEC - 6 * DAY, wei: 1n * ETH, tokenId: "3", contract: COL_C, collection: "col-c" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: NOW_SEC - 2 * DAY, wei: 5n * ETH, tokenId: "3", contract: COL_C, collection: "col-c" }),
    ];
  }

  it("buckets flips by SELL ts into 1w / 3w / all, entries may be older", () => {
    const p = computeWalletProfile(TARGET, parseSaleEvents(windowEvents(), TARGET), { now: NOW_MS });

    expect(p.periods.all.realizedPnlEth).toBe(formatEth10(7n * ETH));
    expect(p.periods.all.sells).toBe(3);
    expect(p.periods.all.buys).toBe(3);
    expect(p.periods.all.wins).toBe(3);

    // 3w: sells at −10d and −2d are in; the −30d sell is out. Flip B's
    // entry (−25d) is outside the window, so only 1 buy is counted.
    expect(p.periods.week3.realizedPnlEth).toBe(formatEth10(6n * ETH));
    expect(p.periods.week3.sells).toBe(2);
    expect(p.periods.week3.buys).toBe(1);
    expect(p.periods.week3.volumeEth).toBe(formatEth10((3n + 1n + 5n) * ETH));

    // 1w: only the −2d sell.
    expect(p.periods.week1.realizedPnlEth).toBe(formatEth10(4n * ETH));
    expect(p.periods.week1.sells).toBe(1);
    expect(p.periods.week1.buys).toBe(1);
    expect(p.periods.week1.winRatePct).toBe(100);
  });

  it("builds independent equity curves per window (no carry-over)", () => {
    const p = computeWalletProfile(TARGET, parseSaleEvents(windowEvents(), TARGET), { now: NOW_MS });
    expect(p.periods.all.equityCurve.map((e) => e.pnlEth)).toEqual([
      formatEth10(1n * ETH),
      formatEth10(3n * ETH),
      formatEth10(7n * ETH),
    ]);
    expect(p.periods.week3.equityCurve.map((e) => e.pnlEth)).toEqual([
      formatEth10(2n * ETH),
      formatEth10(6n * ETH),
    ]);
    expect(p.periods.week1.equityCurve).toEqual([
      { ts: NOW_SEC - 2 * DAY, pnlEth: formatEth10(4n * ETH) },
    ]);
    // periods.all matches the top-level aggregates.
    expect(p.periods.all.equityCurve).toEqual(p.equityCurve);
    expect(p.periods.all.realizedPnlEth).toBe(p.realizedPnlEth);
    expect(p.periods.all.chains["1"].realizedPnlEth).toBe(p.chains["1"].realizedPnlEth);
  });

  it("filters open positions by ENTRY ts per window at the same floors", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: NOW_SEC - 15 * DAY, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: NOW_SEC - 2 * DAY, wei: 1n * ETH, tokenId: "2", contract: COLLECTION_B, collection: "col-b" }),
    ];
    const floors = new Map([
      ["1:test-collection", 3n * ETH],
      ["1:col-b", 4n * ETH],
    ]);
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET), { floors, now: NOW_MS });

    expect(p.periods.all.openCount).toBe(2);
    expect(p.periods.all.unrealizedPnlEth).toBe(formatEth10((2n + 3n) * ETH));
    // 3w contains both entries (−15d and −2d).
    expect(p.periods.week3.openCount).toBe(2);
    expect(p.periods.week3.unrealizedPnlEth).toBe(formatEth10(5n * ETH));
    expect(p.periods.week3.buys).toBe(2);
    // 1w contains only the −2d entry (4 − 1 = +3).
    expect(p.periods.week1.openCount).toBe(1);
    expect(p.periods.week1.unrealizedPnlEth).toBe(formatEth10(3n * ETH));
    expect(p.periods.week1.buys).toBe(1);
    expect(p.periods.week1.sells).toBe(0);
    expect(p.periods.week1.equityCurve).toHaveLength(0);
    expect(p.periods.week1.chains["1"].openCount).toBe(1);
    // Per-chain windowed rows exist.
    expect(p.periods.week3.chains["1"].unrealizedPnlEth).toBe(formatEth10(5n * ETH));
  });

  it("renders empty windows as zeros, not crashes", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: NOW_SEC - 40 * DAY, wei: 1n * ETH, tokenId: "1" }),
      saleEvent({ seller: TARGET, buyer: OTHER, ts: NOW_SEC - 30 * DAY, wei: 2n * ETH, tokenId: "1" }),
    ];
    const p = computeWalletProfile(TARGET, parseSaleEvents(raw, TARGET), { now: NOW_MS });
    expect(p.periods.week1.realizedPnlEth).toBe(formatEth10(0n));
    expect(p.periods.week1.sells).toBe(0);
    expect(p.periods.week1.buys).toBe(0);
    expect(p.periods.week1.winRatePct).toBe(0);
    expect(p.periods.week1.volumeEth).toBe(formatEth10(0n));
    expect(p.periods.week1.openCount).toBe(0);
    expect(p.periods.week1.unrealizedPnlEth).toBeNull();
    expect(p.periods.week1.equityCurve).toEqual([]);
    expect(p.periods.week1.chains).toEqual({});
  });
});

describe("openGroupSummary + formatEth10", () => {
  it("ranks leftover groups by open count desc for the floor-pricing cap", () => {
    const raw = [
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 100, tokenId: "1" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 101, tokenId: "2" }),
      saleEvent({ seller: OTHER, buyer: TARGET, ts: 102, tokenId: "9", contract: COLLECTION_B, collection: "col-b" }),
    ];
    const groups = openGroupSummary(parseSaleEvents(raw, TARGET));
    expect(groups).toHaveLength(2);
    expect(groups[0].slug).toBe("test-collection");
    expect(groups[0].openCount).toBe(2);
    expect(groups[1].slug).toBe("col-b");
    expect(groups[1].openCount).toBe(1);
  });

  it("formatEth10 truncates to 10 decimals and keeps the sign", () => {
    expect(formatEth10(1234567890123456789n)).toBe("1.2345678901");
    expect(formatEth10(-5n * 10n ** 17n)).toBe("-0.5000000000");
    expect(formatEth10(0n)).toBe("0.0000000000");
  });
});

/** Build one parsed holding NFT (post parseAccountNfts shape). */
function holdingNft(args: {
  chainId?: number;
  contract?: string;
  collection: string;
  name?: string | null;
  imageUrl?: string | null;
}): HoldingNft {
  return {
    chainId: args.chainId ?? 1,
    contract: (args.contract ?? COLLECTION).toLowerCase(),
    collectionSlug: args.collection,
    name: args.name === undefined ? "Test NFT #1" : args.name,
    imageUrl: args.imageUrl === undefined ? "https://img.example/1.png" : args.imageUrl,
  };
}

describe("parseAccountNfts — defensive v2 account-NFTs parsing", () => {
  it("keeps items with contract + collection, skips malformed ones", () => {
    const raw = [
      { contract: COLLECTION, collection: "test-collection", name: "Test NFT #1", image_url: "https://img.example/1.png", identifier: "1" },
      { contract: COLLECTION, name: "No collection" }, // missing collection → skip
      { collection: "no-contract", name: "No contract" }, // missing contract → skip
      null,
      "garbage",
      { contract: COLLECTION_B, collection: "col-b", identifier: 7 }, // no name/image → nulls
    ];
    const nfts = parseAccountNfts(raw, 8453);
    expect(nfts).toHaveLength(2);
    expect(nfts[0]).toMatchObject({
      chainId: 8453,
      contract: COLLECTION,
      collectionSlug: "test-collection",
      name: "Test NFT #1",
      imageUrl: "https://img.example/1.png",
    });
    expect(nfts[1]).toMatchObject({
      chainId: 8453,
      contract: COLLECTION_B,
      collectionSlug: "col-b",
      name: null,
      imageUrl: null,
    });
  });
});

describe("aggregateHoldings — grouping, valuation, ranking, top-3", () => {
  it("groups per (chain, collection) — same slug on different chains stays separate", () => {
    const nfts = [
      holdingNft({ collection: "shared-slug", chainId: 1, name: "Alpha #1" }),
      holdingNft({ collection: "shared-slug", chainId: 1, name: "Alpha #2" }),
      // Same slug on base is a different group:
      holdingNft({ collection: "shared-slug", chainId: 8453, name: "Alpha #9" }),
      holdingNft({ collection: "col-b", chainId: 1, name: null, imageUrl: null }),
    ];
    const { holdings, nftCount, collectionCount } = aggregateHoldings(nfts, new Map(), 10);
    expect(nftCount).toBe(4);
    expect(collectionCount).toBe(3);
    const ethGroup = holdings.find((h) => h.chainId === 1 && h.collectionSlug === "shared-slug")!;
    expect(ethGroup.count).toBe(2);
    // Display name: nft.name prefix with the token id stripped.
    expect(ethGroup.name).toBe("Alpha");
    expect(ethGroup.imageUrl).toBe("https://img.example/1.png");
    const baseGroup = holdings.find((h) => h.chainId === 8453)!;
    expect(baseGroup.count).toBe(1);
    // Null nft name → collection slug as display name.
    expect(holdings.find((h) => h.collectionSlug === "col-b")!.name).toBe("col-b");
  });

  it("values groups at count × floor; missing floor → null floor and value", () => {
    const nfts = [
      holdingNft({ collection: "priced", name: "P #1" }),
      holdingNft({ collection: "priced", name: "P #2" }),
      holdingNft({ collection: "priced", name: "P #3" }),
      holdingNft({ collection: "unpriced", name: "U #1" }),
    ];
    const floors = new Map([["1:priced", 2n * ETH]]); // 2 ETH floor
    const { holdings } = aggregateHoldings(nfts, floors, 10);
    const priced = holdings.find((h) => h.collectionSlug === "priced")!;
    expect(priced.floorEth).toBe(formatEth10(2n * ETH));
    expect(priced.valueEth).toBe(formatEth10(6n * ETH)); // 3 × 2 ETH
    const unpriced = holdings.find((h) => h.collectionSlug === "unpriced")!;
    expect(unpriced.floorEth).toBeNull();
    expect(unpriced.valueEth).toBeNull();
  });

  it("ranks value-first with null floors last, then count as tiebreak", () => {
    const nfts = [
      // big: 1 NFT at 5 ETH floor → value 5
      holdingNft({ collection: "big", name: "B #1" }),
      // small: 2 NFTs at 1 ETH floor → value 2
      holdingNft({ collection: "small", name: "S #1" }),
      holdingNft({ collection: "small", name: "S #2" }),
      // two unpriced groups: 3-count before 1-count despite no value
      ...[1, 2, 3].map((i) => holdingNft({ collection: "nofloor-many", name: `N #${i}` })),
      holdingNft({ collection: "nofloor-one", name: "O #1" }),
      // equal value to "small" (2 × 1): count tiebreak puts 2-count "small" first
      holdingNft({ collection: "tied", name: "T #1" }),
    ];
    const floors = new Map([
      ["1:big", 5n * ETH],
      ["1:small", 1n * ETH],
      ["1:tied", 2n * ETH], // value 2 — ties with "small"
    ]);
    const { holdings } = aggregateHoldings(nfts, floors, 10);
    expect(holdings.map((h) => h.collectionSlug)).toEqual([
      "big", // 5 ETH
      "small", // 2 ETH, count 2
      "tied", // 2 ETH, count 1
      "nofloor-many", // null value, count 3
      "nofloor-one", // null value, count 1
    ]);
  });

  it("cuts to the top 3 after ranking", () => {
    const nfts = [
      holdingNft({ collection: "a", name: "A #1" }),
      holdingNft({ collection: "b", name: "B #1" }),
      holdingNft({ collection: "c", name: "C #1" }),
      holdingNft({ collection: "d", name: "D #1" }),
    ];
    const floors = new Map([
      ["1:a", 1n * ETH],
      ["1:b", 4n * ETH],
      ["1:c", 3n * ETH],
      ["1:d", 2n * ETH],
    ]);
    const { holdings, nftCount, collectionCount } = aggregateHoldings(nfts, floors);
    expect(holdings.map((h) => h.collectionSlug)).toEqual(["b", "c", "d"]);
    // Totals cover the whole scan, not just the cut.
    expect(nftCount).toBe(4);
    expect(collectionCount).toBe(4);
  });

  it("handles empty input gracefully", () => {
    const { holdings, nftCount, collectionCount } = aggregateHoldings([], new Map());
    expect(holdings).toEqual([]);
    expect(nftCount).toBe(0);
    expect(collectionCount).toBe(0);
  });
});
