import { describe, expect, it } from "vitest";
import {
  injectProofArgs,
  phaseFromSignals,
  resolvePhase,
} from "./mintPhase";

describe("phaseFromSignals", () => {
  it("returns 'unknown' when every getter reverted (no signals)", () => {
    expect(phaseFromSignals([])).toBe("unknown");
  });

  it("returns 'public' when a public getter is true", () => {
    expect(
      phaseFromSignals([
        { name: "publicSaleActive", active: true },
        { name: "presaleActive", active: false },
      ]),
    ).toBe("public");
  });

  it("returns 'whitelist' when only a whitelist getter is true", () => {
    expect(
      phaseFromSignals([
        { name: "saleActive", active: false },
        { name: "allowlistActive", active: true },
      ]),
    ).toBe("whitelist");
  });

  it("public beats whitelist when both read true", () => {
    expect(
      phaseFromSignals([
        { name: "publicMintActive", active: true },
        { name: "whitelistSaleActive", active: true },
      ]),
    ).toBe("public");
  });

  it("paused()=true closes the mint even when a sale getter is true", () => {
    expect(
      phaseFromSignals([
        { name: "saleActive", active: true },
        { name: "paused", active: true },
      ]),
    ).toBe("closed");
  });

  it("paused()=false alone does not close an otherwise-public mint", () => {
    expect(
      phaseFromSignals([
        { name: "saleActive", active: true },
        { name: "paused", active: false },
      ]),
    ).toBe("public");
  });

  it("returns 'closed' when getters answered but none are true", () => {
    expect(
      phaseFromSignals([
        { name: "saleActive", active: false },
        { name: "presaleActive", active: false },
      ]),
    ).toBe("closed");
  });

  it("a single false answer is still 'closed', not 'unknown'", () => {
    expect(phaseFromSignals([{ name: "paused", active: false }])).toBe("closed");
  });
});

describe("resolvePhase", () => {
  it("'auto'/null follows the detected phase", () => {
    expect(resolvePhase("whitelist", "auto")).toEqual({ phase: "whitelist" });
    expect(resolvePhase("closed", null)).toEqual({ phase: "closed" });
    expect(resolvePhase("unknown", undefined)).toEqual({ phase: "unknown" });
  });

  it("task override wins and notes a mismatch with detection", () => {
    const r = resolvePhase("whitelist", "public");
    expect(r.phase).toBe("public");
    expect(r.note).toMatch(/forces phase 'public'/);
  });

  it("matching override carries no mismatch note", () => {
    expect(resolvePhase("whitelist", "whitelist")).toEqual({ phase: "whitelist" });
  });

  it("override against an undetectable contract carries no note", () => {
    expect(resolvePhase("unknown", "whitelist")).toEqual({ phase: "whitelist" });
  });
});

describe("injectProofArgs", () => {
  const proof = ["0x" + "11".repeat(32), "0x" + "22".repeat(32)];

  it("appends the proof as the final arg by default", () => {
    expect(injectProofArgs([1], proof)).toEqual([1, proof]);
  });

  it("substitutes the '$proof' placeholder in place", () => {
    expect(injectProofArgs(["$proof", 2], proof)).toEqual([proof, 2]);
  });

  it("does not mutate the original args array", () => {
    const args = [1];
    injectProofArgs(args, proof);
    expect(args).toEqual([1]);
  });
});
