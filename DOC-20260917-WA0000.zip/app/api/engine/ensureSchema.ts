/**
 * Embedded, idempotent schema ensure.
 *
 * The drizzle-kit folder-based migrator depends on `db/migrations` being
 * readable from the server's cwd — which is not guaranteed in the preview
 * runtime. This module carries the full DDL inline and applies it
 * idempotently on every boot:
 *   - CREATE TABLE IF NOT EXISTS for every table (final shape)
 *   - information_schema-checked ADD COLUMN for later additions
 *   - FK constraint adds with duplicate-name errors ignored
 * It never throws — failures are logged and the server keeps running.
 */
import mysql from "mysql2/promise";
import { env } from "../lib/env";

const TABLES: string[] = [
  `CREATE TABLE IF NOT EXISTS \`users\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`unionId\` varchar(255) NOT NULL,
	\`name\` varchar(255),
	\`email\` varchar(320),
	\`passwordHash\` varchar(255),
	\`avatar\` text,
	\`role\` enum('user','admin') NOT NULL DEFAULT 'user',
	\`plan\` varchar(8) NOT NULL DEFAULT 'free',
	\`planExpiresAt\` timestamp NULL,
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	\`updatedAt\` timestamp NOT NULL DEFAULT (now()),
	\`lastSignInAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`users_id\` PRIMARY KEY(\`id\`),
	CONSTRAINT \`users_unionId_unique\` UNIQUE(\`unionId\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`mint_tasks\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`name\` varchar(255) NOT NULL,
	\`contractAddress\` varchar(42) NOT NULL,
	\`chainId\` int NOT NULL DEFAULT 1,
	\`mintFunction\` varchar(128) NOT NULL DEFAULT 'mint',
	\`mintArgs\` json NOT NULL,
	\`mintValueEth\` varchar(64) NOT NULL DEFAULT '0',
	\`gasLimit\` int NOT NULL DEFAULT 200000,
	\`triggerMode\` varchar(16) NOT NULL DEFAULT 'time',
	\`openTime\` timestamp,
	\`flagMethod\` varchar(128) NOT NULL DEFAULT 'saleActive',
	\`pollIntervalMs\` int NOT NULL DEFAULT 1000,
	\`eventName\` varchar(128),
	\`startMaxFeeGwei\` int NOT NULL DEFAULT 60,
	\`startPriorityGwei\` int NOT NULL DEFAULT 3,
	\`gasBumpGwei\` int NOT NULL DEFAULT 10,
	\`mintPhase\` varchar(16),
	\`merkleProofs\` json,
	\`simulateFirst\` boolean NOT NULL DEFAULT true,
	\`maxMaxFeeGwei\` int NOT NULL DEFAULT 500,
	\`maxRetries\` int NOT NULL DEFAULT 8,
	\`status\` varchar(16) NOT NULL DEFAULT 'draft',
	\`dryRun\` boolean NOT NULL DEFAULT false,
	\`walletCount\` int NOT NULL DEFAULT 1,
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	\`updatedAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`mint_tasks_id\` PRIMARY KEY(\`id\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`bot_wallets\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`label\` varchar(255) NOT NULL,
	\`address\` varchar(42) NOT NULL,
	\`managed\` boolean NOT NULL DEFAULT false,
	\`encryptedKey\` text,
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`bot_wallets_id\` PRIMARY KEY(\`id\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`watched_wallets\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`address\` varchar(42) NOT NULL,
	\`label\` varchar(255) NOT NULL,
	\`chain\` varchar(32) NOT NULL DEFAULT 'ethereum',
	\`enabled\` boolean NOT NULL DEFAULT true,
	\`copyMints\` boolean NOT NULL DEFAULT true,
	\`copyBuys\` boolean NOT NULL DEFAULT false,
	\`maxPerTradeEth\` varchar(64) NOT NULL DEFAULT '0.1',
	\`maxDailyEth\` varchar(64) NOT NULL DEFAULT '1',
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`watched_wallets_id\` PRIMARY KEY(\`id\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`signals\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`watchedWalletId\` bigint unsigned,
	\`type\` varchar(16) NOT NULL,
	\`contractAddress\` varchar(42) NOT NULL,
	\`tokenId\` varchar(78),
	\`collectionName\` varchar(255),
	\`priceEth\` varchar(64),
	\`txHash\` varchar(66),
	\`status\` varchar(16) NOT NULL DEFAULT 'detected',
	\`pnlEth\` varchar(64),
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`signals_id\` PRIMARY KEY(\`id\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`activity_logs\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`taskId\` bigint unsigned,
	\`level\` varchar(16) NOT NULL DEFAULT 'info',
	\`source\` varchar(16) NOT NULL,
	\`message\` text NOT NULL,
	\`meta\` json,
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`activity_logs_id\` PRIMARY KEY(\`id\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`user_settings\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`rpcUrl\` varchar(512),
	\`rpcAuto\` boolean NOT NULL DEFAULT true,
	\`chainId\` int NOT NULL DEFAULT 1,
	\`executionMode\` varchar(16) NOT NULL DEFAULT 'live',
	\`maxGasGwei\` int NOT NULL DEFAULT 500,
	\`reservoirApiKey\` varchar(128),
	\`openseaApiKey\` varchar(128),
	\`mevProtection\` boolean NOT NULL DEFAULT true,
	\`halted\` boolean NOT NULL DEFAULT false,
	\`updatedAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`user_settings_id\` PRIMARY KEY(\`id\`),
	CONSTRAINT \`user_settings_userId_unique\` UNIQUE(\`userId\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`discovered_traders\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`chainId\` int NOT NULL,
	\`address\` varchar(42) NOT NULL,
	\`buys\` int NOT NULL DEFAULT 0,
	\`sells\` int NOT NULL DEFAULT 0,
	\`trades\` int NOT NULL DEFAULT 0,
	\`spendEth\` varchar(64) NOT NULL DEFAULT '0',
	\`proceedsEth\` varchar(64) NOT NULL DEFAULT '0',
	\`realizedPnlEth\` varchar(64) NOT NULL DEFAULT '0',
	\`flips\` int NOT NULL DEFAULT 0,
	\`wins\` int NOT NULL DEFAULT 0,
	\`winRatePct\` varchar(16) NOT NULL DEFAULT '0',
	\`avgPnlEth\` varchar(64) NOT NULL DEFAULT '0',
	\`bestFlipEth\` varchar(64) NOT NULL DEFAULT '0',
	\`roiPct\` varchar(16),
	\`mintPnlEth\` varchar(64) NOT NULL DEFAULT '0',
	\`mintFlips\` int NOT NULL DEFAULT 0,
	\`avgHoldHours\` varchar(16),
	\`unrealizedPnlEth\` decimal(20,10),
	\`openPositions\` int NOT NULL DEFAULT 0,
	\`labels\` varchar(256),
	\`collections\` int NOT NULL DEFAULT 0,
	\`fromBlock\` bigint unsigned NOT NULL,
	\`toBlock\` bigint unsigned NOT NULL,
	\`scannedAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`discovered_traders_id\` PRIMARY KEY(\`id\`),
	INDEX \`discovered_traders_chainId_idx\` (\`chainId\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`discovered_flips\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`chainId\` int NOT NULL,
	\`address\` varchar(42) NOT NULL,
	\`contractAddress\` varchar(42) NOT NULL,
	\`tokenId\` varchar(78),
	\`kind\` varchar(16) NOT NULL DEFAULT 'secondary',
	\`status\` varchar(16) NOT NULL DEFAULT 'closed',
	\`markPriceEth\` decimal(20,10),
	\`unrealizedPnlEth\` decimal(20,10),
	\`buyPriceEth\` varchar(64),
	\`sellPriceEth\` varchar(64),
	\`pnlEth\` varchar(64),
	\`roiPct\` varchar(16),
	\`holdBlocks\` bigint unsigned,
	\`buyTxHash\` varchar(66),
	\`sellTxHash\` varchar(66),
	\`scannedAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`discovered_flips_id\` PRIMARY KEY(\`id\`),
	INDEX \`discovered_flips_chainId_address_idx\` (\`chainId\`,\`address\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`wallet_profiles\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`walletAddress\` varchar(42) NOT NULL,
	\`payload\` json NOT NULL,
	\`fetchedAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`wallet_profiles_id\` PRIMARY KEY(\`id\`),
	CONSTRAINT \`wallet_profiles_walletAddress_unique\` UNIQUE(\`walletAddress\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`sweep_rules\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`chainId\` int NOT NULL,
	\`contractAddress\` varchar(42) NOT NULL,
	\`collectionName\` varchar(255),
	\`mode\` varchar(8) NOT NULL DEFAULT 'below',
	\`thresholdEth\` varchar(64) NOT NULL,
	\`maxBuys\` int NOT NULL DEFAULT 1,
	\`maxSpendEth\` varchar(64) NOT NULL DEFAULT '1',
	\`maxRarityRank\` int,
	\`enabled\` boolean NOT NULL DEFAULT true,
	\`boughtCount\` int NOT NULL DEFAULT 0,
	\`spentEth\` varchar(64) NOT NULL DEFAULT '0',
	\`lastFloorEth\` varchar(64),
	\`lastCheckedAt\` timestamp,
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT \`sweep_rules_id\` PRIMARY KEY(\`id\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`site_settings\` (
	\`key\` varchar(64) NOT NULL,
	\`value\` text,
	\`updatedAt\` timestamp NOT NULL DEFAULT (now()) ON UPDATE now(),
	CONSTRAINT \`site_settings_key\` PRIMARY KEY(\`key\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`payment_claims\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`chainId\` int NOT NULL,
	\`txHash\` varchar(66) NOT NULL,
	\`status\` varchar(12) NOT NULL DEFAULT 'pending',
	\`adminNote\` varchar(256),
	\`createdAt\` timestamp NOT NULL DEFAULT (now()),
	\`reviewedAt\` timestamp,
	CONSTRAINT \`payment_claims_id\` PRIMARY KEY(\`id\`),
	INDEX \`payment_claims_userId_idx\` (\`userId\`)
)`,
  `CREATE TABLE IF NOT EXISTS \`bot_positions\` (
	\`id\` serial AUTO_INCREMENT NOT NULL,
	\`userId\` bigint unsigned NOT NULL,
	\`source\` varchar(8) NOT NULL,
	\`refId\` int,
	\`chainId\` int NOT NULL,
	\`contractAddress\` varchar(42) NOT NULL,
	\`tokenId\` varchar(80),
	\`qty\` int NOT NULL DEFAULT 1,
	\`entryEth\` decimal(20,10),
	\`status\` varchar(8) NOT NULL DEFAULT 'open',
	\`tpPct\` int,
	\`slPct\` int,
	\`sellReason\` varchar(16),
	\`sellTxHash\` varchar(66),
	\`sellEth\` decimal(20,10),
	\`realizedPnlEth\` decimal(20,10),
	\`openedAt\` timestamp NOT NULL DEFAULT (now()),
	\`soldAt\` timestamp,
	CONSTRAINT \`bot_positions_id\` PRIMARY KEY(\`id\`),
	INDEX \`bot_positions_userId_idx\` (\`userId\`),
	INDEX \`bot_positions_status_idx\` (\`status\`)
)`,
];

/** Later additions for tables that may already exist without these columns. */
const COLUMN_ADDS: Array<{ table: string; column: string; ddl: string }> = [
  {
    table: "user_settings",
    column: "reservoirApiKey",
    ddl: "ALTER TABLE `user_settings` ADD `reservoirApiKey` varchar(128)",
  },
  {
    table: "user_settings",
    column: "openseaApiKey",
    ddl: "ALTER TABLE `user_settings` ADD `openseaApiKey` varchar(128)",
  },
  {
    table: "users",
    column: "passwordHash",
    ddl: "ALTER TABLE `users` ADD `passwordHash` varchar(255)",
  },
  {
    table: "users",
    column: "plan",
    ddl: "ALTER TABLE `users` ADD `plan` varchar(8) DEFAULT 'free' NOT NULL",
  },
  {
    table: "users",
    column: "planExpiresAt",
    ddl: "ALTER TABLE `users` ADD `planExpiresAt` timestamp NULL",
  },
  {
    table: "users",
    column: "createdAt",
    ddl: "ALTER TABLE `users` ADD `createdAt` timestamp DEFAULT (now()) NOT NULL",
  },
  {
    table: "mint_tasks",
    column: "walletCount",
    ddl: "ALTER TABLE `mint_tasks` ADD `walletCount` int DEFAULT 1 NOT NULL",
  },
  {
    table: "bot_wallets",
    column: "managed",
    ddl: "ALTER TABLE `bot_wallets` ADD `managed` boolean DEFAULT false NOT NULL",
  },
  {
    table: "bot_wallets",
    column: "encryptedKey",
    ddl: "ALTER TABLE `bot_wallets` ADD `encryptedKey` text",
  },
  {
    table: "user_settings",
    column: "rpcAuto",
    ddl: "ALTER TABLE `user_settings` ADD `rpcAuto` boolean DEFAULT true NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "flips",
    ddl: "ALTER TABLE `discovered_traders` ADD `flips` int DEFAULT 0 NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "wins",
    ddl: "ALTER TABLE `discovered_traders` ADD `wins` int DEFAULT 0 NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "winRatePct",
    ddl: "ALTER TABLE `discovered_traders` ADD `winRatePct` varchar(16) DEFAULT '0' NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "avgPnlEth",
    ddl: "ALTER TABLE `discovered_traders` ADD `avgPnlEth` varchar(64) DEFAULT '0' NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "bestFlipEth",
    ddl: "ALTER TABLE `discovered_traders` ADD `bestFlipEth` varchar(64) DEFAULT '0' NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "roiPct",
    ddl: "ALTER TABLE `discovered_traders` ADD `roiPct` varchar(16)",
  },
  {
    table: "discovered_traders",
    column: "mintPnlEth",
    ddl: "ALTER TABLE `discovered_traders` ADD `mintPnlEth` varchar(64) DEFAULT '0' NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "mintFlips",
    ddl: "ALTER TABLE `discovered_traders` ADD `mintFlips` int DEFAULT 0 NOT NULL",
  },
  {
    table: "discovered_traders",
    column: "avgHoldHours",
    ddl: "ALTER TABLE `discovered_traders` ADD `avgHoldHours` varchar(16)",
  },
  {
    table: "discovered_traders",
    column: "unrealizedPnlEth",
    ddl: "ALTER TABLE `discovered_traders` ADD `unrealizedPnlEth` decimal(20,10)",
  },
  {
    table: "discovered_traders",
    column: "openPositions",
    ddl: "ALTER TABLE `discovered_traders` ADD `openPositions` int DEFAULT 0 NOT NULL",
  },
  {
    table: "discovered_flips",
    column: "status",
    ddl: "ALTER TABLE `discovered_flips` ADD `status` varchar(16) DEFAULT 'closed' NOT NULL",
  },
  {
    table: "discovered_flips",
    column: "markPriceEth",
    ddl: "ALTER TABLE `discovered_flips` ADD `markPriceEth` decimal(20,10)",
  },
  {
    table: "discovered_flips",
    column: "unrealizedPnlEth",
    ddl: "ALTER TABLE `discovered_flips` ADD `unrealizedPnlEth` decimal(20,10)",
  },
  {
    table: "user_settings",
    column: "mevProtection",
    ddl: "ALTER TABLE `user_settings` ADD `mevProtection` boolean NOT NULL DEFAULT true",
  },
  {
    table: "user_settings",
    column: "halted",
    ddl: "ALTER TABLE `user_settings` ADD `halted` boolean NOT NULL DEFAULT false",
  },
  {
    table: "discovered_traders",
    column: "labels",
    ddl: "ALTER TABLE `discovered_traders` ADD `labels` varchar(256)",
  },
  {
    table: "mint_tasks",
    column: "mintPhase",
    ddl: "ALTER TABLE `mint_tasks` ADD `mintPhase` varchar(16)",
  },
  {
    table: "mint_tasks",
    column: "merkleProofs",
    ddl: "ALTER TABLE `mint_tasks` ADD `merkleProofs` json",
  },
  {
    table: "mint_tasks",
    column: "simulateFirst",
    ddl: "ALTER TABLE `mint_tasks` ADD `simulateFirst` boolean NOT NULL DEFAULT true",
  },
  {
    table: "sweep_rules",
    column: "maxRarityRank",
    ddl: "ALTER TABLE `sweep_rules` ADD `maxRarityRank` int",
  },
];

const FOREIGN_KEYS: string[] = [
  "ALTER TABLE `activity_logs` ADD CONSTRAINT `activity_logs_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `activity_logs` ADD CONSTRAINT `activity_logs_taskId_mint_tasks_id_fk` FOREIGN KEY (`taskId`) REFERENCES `mint_tasks`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `bot_wallets` ADD CONSTRAINT `bot_wallets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `mint_tasks` ADD CONSTRAINT `mint_tasks_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `payment_claims` ADD CONSTRAINT `payment_claims_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `signals` ADD CONSTRAINT `signals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `signals` ADD CONSTRAINT `signals_watchedWalletId_watched_wallets_id_fk` FOREIGN KEY (`watchedWalletId`) REFERENCES `watched_wallets`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `sweep_rules` ADD CONSTRAINT `sweep_rules_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `user_settings` ADD CONSTRAINT `user_settings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `watched_wallets` ADD CONSTRAINT `watched_wallets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
  "ALTER TABLE `bot_positions` ADD CONSTRAINT `bot_positions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action",
];

export async function ensureSchemaEmbedded(): Promise<void> {
  let pool: mysql.Pool | null = null;
  try {
    pool = mysql.createPool(env.databaseUrl);

    for (const ddl of TABLES) {
      await pool.query(ddl);
    }
    console.log("[db] embedded ensure: tables verified");

    for (const add of COLUMN_ADDS) {
      const [rows] = await pool.query<mysql.RowDataPacket[]>(
        "SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?",
        [add.table, add.column],
      );
      if (Number(rows[0]?.c ?? 0) === 0) {
        await pool.query(add.ddl);
        console.log(`[db] embedded ensure: added ${add.table}.${add.column}`);
      }
    }

    for (const fk of FOREIGN_KEYS) {
      try {
        await pool.query(fk);
      } catch {
        // Duplicate constraint name — already applied. Safe to ignore.
      }
    }
    console.log("[db] embedded ensure: schema up to date");
  } catch (e) {
    console.error(
      "[db] embedded ensure failed (server continues):",
      e instanceof Error ? e.message : e,
    );
  } finally {
    if (pool) await pool.end().catch(() => undefined);
  }
}
