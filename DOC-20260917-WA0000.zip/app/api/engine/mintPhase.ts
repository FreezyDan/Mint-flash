import { ethers } from "ethers";

/**
 * Mint-phase detection for whitelist/allowlist-aware minting.
 *
 * NFT contracts expose the current sale state through a grab-bag of
 * conventions: `publicSaleActive()`, `presaleActive()`, `paused()`, …
 * This module probes the common no-arg boolean getters via eth_call
 * (tolerating reverts = getter absent) and folds the answers into a
 * single phase: "whitelist" | "public" | "closed" | "unknown".
 *
 * The folding logic is pure (phaseFromSignals / resolvePhase /
 * injectProofArgs) so the decision matrix is unit-testable without RPC.
 */

export type MintPhaseName = "whitelist" | "public" | "closed" | "unknown";

export type PhaseSignal = { name: string; active: boolean };

type GetterKind = "public" | "whitelist" | "paused";

/** Minimal provider surface so the wrappers are easy to fake in tests. */
export type EthCallProvider = {
  call: (tx: { to: string; data: string }) => Promise<string>;
};

const PROBE_STAGGER_MS = 200;
const PER_CALL_TIMEOUT_MS = 3_000;

function selector(signature: string): string {
  return ethers.id(signature).slice(0, 10);
}

/**
 * Common no-arg boolean sale-state getters, probed via eth_call.
 * `paused()` is special: when true BOTH phases are closed.
 */
const GETTER_DEFS: ReadonlyArray<{ name: string; kind: GetterKind }> = [
  { name: "publicSaleActive", kind: "public" },
  { name: "saleActive", kind: "public" },
  { name: "publicMintActive", kind: "public" },
  { name: "whitelistSaleActive", kind: "whitelist" },
  { name: "presaleActive", kind: "whitelist" },
  { name: "allowlistActive", kind: "whitelist" },
  { name: "paused", kind: "paused" },
];

export const SALE_STATE_GETTERS: ReadonlyArray<{
  name: string;
  signature: string;
  selector: string;
  kind: GetterKind;
}> = GETTER_DEFS.map((g) => ({
  ...g,
  signature: `${g.name}()`,
  selector: selector(`${g.name}()`),
}));

const KIND_BY_NAME = new Map(SALE_STATE_GETTERS.map((g) => [g.name, g.kind]));

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error("probe timeout")), ms)),
  ]);
}

/** Decode a 32-byte eth_call bool word; null when the return data is unusable. */
function decodeBoolWord(raw: string): boolean | null {
  if (!raw || raw === "0x") return null;
  const hex = raw.startsWith("0x") ? raw.slice(2) : raw;
  if (hex.length !== 64 || !/^[0-9a-fA-F]+$/.test(hex)) return null;
  return BigInt(`0x${hex}`) !== 0n;
}

/**
 * Pure phase fold over the answered probe signals (reverted/absent getters
 * simply never make it into `signals`).
 *
 * Precedence:
 *  1. paused() true                       → closed (both phases off)
 *  2. any public getter true              → public (beats whitelist)
 *  3. any whitelist getter true           → whitelist
 *  4. ≥1 getter answered, none true       → closed
 *  5. everything reverted                 → unknown
 */
export function phaseFromSignals(signals: PhaseSignal[]): MintPhaseName {
  const kindOf = (name: string): GetterKind => KIND_BY_NAME.get(name) ?? "public";
  const active = signals.filter((s) => s.active);
  if (active.some((s) => kindOf(s.name) === "paused")) return "closed";
  if (active.some((s) => kindOf(s.name) === "public")) return "public";
  if (active.some((s) => kindOf(s.name) === "whitelist")) return "whitelist";
  return signals.length > 0 ? "closed" : "unknown";
}

/**
 * Pure task-override resolution. A task configured 'public' or 'whitelist'
 * always wins over detection (with a mismatch note when the contract
 * disagrees); 'auto'/null follows the detected phase.
 */
export function resolvePhase(
  detected: MintPhaseName,
  taskPhase: string | null | undefined,
): { phase: MintPhaseName; note?: string } {
  const task = taskPhase ?? "auto";
  if (task === "public" || task === "whitelist") {
    const note =
      detected !== "unknown" && detected !== task
        ? `task forces phase '${task}' but the contract currently reads '${detected}'`
        : undefined;
    return { phase: task, note };
  }
  return { phase: detected };
}

/**
 * Pure merkle-proof injection into mint args. If the args contain the
 * placeholder element exactly "$proof", the proof is substituted in place
 * (user controls the arg position); otherwise it is appended as the final
 * argument — the common `mint(uint256 qty, bytes32[] proof)` shape.
 */
export function injectProofArgs(args: unknown[], proof: string[]): unknown[] {
  const idx = args.findIndex((a) => a === "$proof");
  if (idx >= 0) {
    const next = [...args];
    next[idx] = proof;
    return next;
  }
  return [...args, proof];
}

/**
 * Probe the contract's sale-state getters. Reverts (getter absent), bad
 * return data and per-call timeouts are tolerated; answers are staggered
 * 0.2s apart to stay friendly with public RPCs.
 */
export async function detectMintPhase(
  provider: EthCallProvider,
  contractAddress: string,
): Promise<{ phase: MintPhaseName; signals: PhaseSignal[] }> {
  const signals: PhaseSignal[] = [];
  for (const getter of SALE_STATE_GETTERS) {
    try {
      const raw = await withTimeout(
        provider.call({ to: contractAddress, data: getter.selector }),
        PER_CALL_TIMEOUT_MS,
      );
      const active = decodeBoolWord(raw);
      if (active !== null) signals.push({ name: getter.name, active });
    } catch {
      // getter absent (revert) or RPC hiccup — tolerated, probe the next one
    }
    await sleep(PROBE_STAGGER_MS);
  }
  return { phase: phaseFromSignals(signals), signals };
}
