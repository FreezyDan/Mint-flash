import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { Chains } from "@contracts/bot";
import type { CopyStats } from "@contracts/bot";
import { createRouter, authedQuery } from "./middleware";
import { assertPro } from "./lib/entitlements";
import {
  addWatchedWallet,
  findSignalsByUser,
  findWatchedWalletById,
  findWatchedWalletsByUser,
  removeWatchedWallet,
  updateWatchedWallet,
} from "./queries/copy";

const addressSchema = z
  .string()
  .regex(/^0x[0-9a-fA-F]{40}$/, "Must be a valid 0x address");

const ethAmountSchema = z
  .string()
  .regex(/^\d+(\.\d+)?$/, "Must be a decimal ETH amount like 0.1");

/** Fallback label for bulk-imported wallets without a CSV label. */
function truncateAddress(address: string): string {
  return `${address.slice(0, 6)}…${address.slice(-4)}`;
}

const watchedWalletInput = z.object({
  address: addressSchema,
  label: z.string().min(1).max(255),
  chain: z.enum(Chains).default("ethereum"),
  copyMints: z.boolean().default(true),
  copyBuys: z.boolean().default(false),
  maxPerTradeEth: ethAmountSchema.default("0.1"),
  maxDailyEth: ethAmountSchema.default("1"),
});

export const copyRouter = createRouter({
  /**
   * Watched wallets, each with a `sparkline`: cumulative estimated PnL (ETH)
   * over that wallet's signals, oldest → newest, for the watchlist sparkline.
   */
  list: authedQuery.query(async ({ ctx }) => {
    const [wallets, walletSignals] = await Promise.all([
      findWatchedWalletsByUser(ctx.user.id),
      findSignalsByUser(ctx.user.id, 1000),
    ]);
    // findSignalsByUser returns newest-first; accumulate oldest-first.
    const series = new Map<number, number[]>();
    for (const s of [...walletSignals].reverse()) {
      if (s.watchedWalletId === null || s.pnlEth === null) continue;
      const pts = series.get(s.watchedWalletId) ?? [];
      pts.push((pts.at(-1) ?? 0) + Number(s.pnlEth));
      series.set(s.watchedWalletId, pts);
    }
    return wallets.map((w) => ({ ...w, sparkline: series.get(w.id) ?? [] }));
  }),

  add: authedQuery
    .input(watchedWalletInput)
    .mutation(({ ctx, input }) => {
      assertPro(ctx);
      return addWatchedWallet({ ...input, userId: ctx.user.id });
    }),

  /**
   * CSV bulk import: up to 100 wallets in one call. Addresses are
   * normalized to lowercase; duplicates against the existing watchlist and
   * within the payload are skipped (not errors). Valid rows are inserted
   * with the same defaults as copy.add (label falls back to a truncated
   * address when the CSV row has none).
   */
  bulkAdd: authedQuery
    .input(
      z.object({
        entries: z
          .array(
            z.object({
              address: addressSchema,
              label: z.string().max(64).optional(),
            }),
          )
          .min(1)
          .max(100),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      const existing = await findWatchedWalletsByUser(ctx.user.id);
      const watched = new Set(existing.map((w) => w.address.toLowerCase()));
      const seen = new Set<string>();
      const skipped: { address: string; reason: string }[] = [];
      let added = 0;

      for (const entry of input.entries) {
        const address = entry.address.toLowerCase();
        if (watched.has(address)) {
          skipped.push({ address, reason: "already watched" });
          continue;
        }
        if (seen.has(address)) {
          skipped.push({ address, reason: "duplicate in import" });
          continue;
        }
        seen.add(address);
        await addWatchedWallet({
          userId: ctx.user.id,
          address,
          label: entry.label?.trim() || truncateAddress(address),
          chain: "ethereum",
          copyMints: true,
          copyBuys: false,
          maxPerTradeEth: "0.1",
          maxDailyEth: "1",
        });
        watched.add(address);
        added++;
      }

      return { added, skipped };
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        data: watchedWalletInput.partial(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      const wallet = await findWatchedWalletById(ctx.user.id, input.id);
      if (!wallet) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Watched wallet not found" });
      }
      return updateWatchedWallet(ctx.user.id, input.id, input.data);
    }),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      await removeWatchedWallet(ctx.user.id, input.id);
      return { success: true };
    }),

  toggle: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      const wallet = await findWatchedWalletById(ctx.user.id, input.id);
      if (!wallet) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Watched wallet not found" });
      }
      return updateWatchedWallet(ctx.user.id, input.id, {
        enabled: !wallet.enabled,
      });
    }),

  signals: authedQuery.query(({ ctx }) => findSignalsByUser(ctx.user.id, 100)),

  copyStats: authedQuery.query(async ({ ctx }): Promise<CopyStats> => {
    const all = await findSignalsByUser(ctx.user.id, 1000);
    const mirrored = all.filter((s) => s.status === "mirrored");
    const pnl = mirrored.reduce((sum, s) => sum + Number(s.pnlEth ?? 0), 0);
    return {
      mirroredCount: mirrored.length,
      pnlEth: pnl.toFixed(4),
    };
  }),
});
