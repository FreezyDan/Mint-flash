import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { ethers } from "ethers";
import { explorerTxUrl } from "@contracts/rpc";
import { createRouter, authedQuery } from "./middleware";
import { canExecute, computeEntitlement, type ExecutableFeature } from "./lib/entitlements";
import { resolveOpenseaKey } from "./lib/openseaKey";
import { executeSell } from "./engine/sellEngine";
import { getOwnedTokenId } from "./engine/opensea";
import { getManagedPrivateKey } from "./engine/managedWallet";
import { resolveRarity, topRarestTraits } from "./engine/rarity";
import {
  findPositionById,
  findPositionsByUser,
  updatePosition,
} from "./queries/positions";

/**
 * Positions router — the sell side of the bot: open positions (TP/SL
 * editors, sell-now, close) plus exit history.
 */

const idInput = z.object({ positionId: z.number().int().positive() });

const setExitInput = z.object({
  positionId: z.number().int().positive(),
  // null = disabled, undefined = leave unchanged.
  tpPct: z.number().int().min(1).max(1000).nullish(),
  slPct: z.number().int().min(1).max(99).nullish(),
});

type PositionRow = NonNullable<Awaited<ReturnType<typeof findPositionById>>>;

/** Rows plus the computed fields the client needs. */
function withComputed(p: PositionRow) {
  return {
    ...p,
    explorerUrl: p.sellTxHash ? explorerTxUrl(p.chainId, p.sellTxHash) : null,
  };
}

async function ownedOpenPosition(userId: number, positionId: number) {
  const position = await findPositionById(userId, positionId);
  if (!position) {
    throw new TRPCError({ code: "NOT_FOUND", message: "Position not found" });
  }
  if (position.status !== "open") {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Position is already ${position.status}`,
    });
  }
  return position;
}

export const positionsRouter = createRouter({
  /** Open first (newest first), then sold/closed newest first. */
  list: authedQuery.query(async ({ ctx }) => {
    const rows = await findPositionsByUser(ctx.user.id);
    const rank = (s: string) => (s === "open" ? 0 : 1);
    const sorted = [...rows].sort((a, b) => {
      const r = rank(a.status) - rank(b.status);
      if (r !== 0) return r;
      return b.openedAt.getTime() - a.openedAt.getTime();
    });
    return sorted.map(withComputed);
  }),

  /** Set / clear the take-profit and stop-loss triggers for a position. */
  setExit: authedQuery.input(setExitInput).mutation(async ({ ctx, input }) => {
    const position = await ownedOpenPosition(ctx.user.id, input.positionId);
    return updatePosition(ctx.user.id, position.id, {
      tpPct: input.tpPct === undefined ? position.tpPct : input.tpPct,
      slPct: input.slPct === undefined ? position.slPct : input.slPct,
    });
  }),

  /**
   * Manual exit — sell into the best OpenSea offer right now via the same
   * executeSell path the engine loop uses. Plan gate by source (snipe
   * allowed during the trial; copy/sweep are PRO-only) — same rule as the
   * engine, so the UI can't bypass it.
   */
  sellNow: authedQuery.input(idInput).mutation(async ({ ctx, input }) => {
    const position = await ownedOpenPosition(ctx.user.id, input.positionId);
    const ent = computeEntitlement(ctx.user);
    if (!canExecute(ent, position.source as ExecutableFeature)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message:
          "PRO_REQUIRED — exits for copy/sweep positions are part of the PRO plan ($15/mo). Upgrade from the Upgrade tab.",
      });
    }
    const { key: apiKey } = await resolveOpenseaKey(ctx.user.id);
    const result = await executeSell({
      userId: ctx.user.id,
      position,
      apiKey,
      reason: "manual",
    });
    if (!result.ok) {
      throw new TRPCError({ code: "BAD_REQUEST", message: result.error });
    }
    return { ...result, position: await findPositionById(ctx.user.id, position.id) };
  }),

  /** Mark closed without selling (the user sold/transferred elsewhere). */
  close: authedQuery.input(idInput).mutation(async ({ ctx, input }) => {
    const position = await ownedOpenPosition(ctx.user.id, input.positionId);
    return updatePosition(ctx.user.id, position.id, { status: "closed" });
  }),

  /**
   * Rarity check for one position (user-initiated from the dashboard — no
   * polling). Resolves the OpenRarity rank when OpenSea has computed it,
   * else a local trait-frequency score; 'unknown' when neither exists.
   * Positions recorded without a token id (e.g. mints) fall back to the
   * first token the managed vault holds in that collection.
   */
  rarity: authedQuery.input(idInput).query(async ({ ctx, input }) => {
    const position = await findPositionById(ctx.user.id, input.positionId);
    if (!position) {
      throw new TRPCError({ code: "NOT_FOUND", message: "Position not found" });
    }
    const checkedAt = new Date().toISOString();
    const { key: apiKey } = await resolveOpenseaKey(ctx.user.id);

    let tokenId = position.tokenId;
    if (!tokenId) {
      // Same fallback as the sell engine: look up what the vault holds.
      const privateKey = await getManagedPrivateKey(ctx.user.id);
      if (privateKey) {
        try {
          const owner = new ethers.Wallet(privateKey).address;
          tokenId = await getOwnedTokenId(
            position.chainId,
            position.contractAddress,
            owner,
            apiKey,
          );
        } catch {
          tokenId = null; // best-effort — fall through to unknown
        }
      }
    }
    if (!tokenId) {
      return {
        kind: "unknown" as const,
        tokenId: null,
        rank: null,
        score: null,
        topTraits: null,
        checkedAt,
      };
    }

    const resolved = await resolveRarity(
      position.chainId,
      position.contractAddress,
      tokenId,
      apiKey,
    );

    // Top-2 rarest traits with collection % for the hover tooltip —
    // best-effort for both rank and score results.
    let topTraits: Array<{ type: string; value: string; pct: number }> | null = null;
    if (resolved.kind !== "unknown" && resolved.collectionSlug) {
      topTraits = await topRarestTraits(
        position.chainId,
        resolved.collectionSlug,
        resolved.traits,
        apiKey,
      );
    }

    return {
      kind: resolved.kind,
      tokenId,
      rank: resolved.kind === "rank" ? resolved.rank : null,
      score: resolved.kind === "score" ? resolved.score : null,
      topTraits: topTraits && topTraits.length > 0 ? topTraits : null,
      checkedAt,
    };
  }),
});
