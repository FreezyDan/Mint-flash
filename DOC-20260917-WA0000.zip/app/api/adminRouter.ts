import { z } from "zod";
import { TRPCError } from "@trpc/server";
import {
  ADMIN_EMAIL,
  isPaymentChain,
  PAYMENT_ADDRESS_SETTING_KEY,
  PAYMENT_CHAIN_IDS,
  PLANS,
  PRO_PAYMENT_ADDRESS,
  PRO_PRICE_USD,
} from "@contracts/plans";
import { createRouter, authedQuery } from "./middleware";
import { computeEntitlement } from "./lib/entitlements";
import {
  SHARED_OPENSEA_KEY_SETTING,
  maskOpenseaKey,
} from "./lib/openseaKey";
import { generateTempPassword, hashPassword } from "./lib/passwords";
import { logActivity } from "./queries/activity";
import {
  findPendingClaim,
  insertClaim,
  listClaimsByUser,
  listPendingClaims,
  reviewClaim,
} from "./queries/payments";
import { getSetting, setSetting } from "./queries/siteSettings";
import {
  findUserById,
  listUsers,
  setUserPlan,
  updateUserPassword,
} from "./queries/users";

/**
 * Admin console — every procedure here requires the ADMIN_EMAIL account.
 * PRO is granted manually after the buyer pays the configurable payment
 * address on a supported EVM chain and submits a claim (no payment processor
 * is integrated on-platform).
 */

/** Effective PRO payment address: site_settings override, else built-in. */
async function effectivePaymentAddress() {
  return (await getSetting(PAYMENT_ADDRESS_SETTING_KEY)) ?? PRO_PAYMENT_ADDRESS;
}

function assertAdmin(ctx: { user?: { email?: string | null } }) {
  if (!ctx.user || ctx.user.email?.toLowerCase() !== ADMIN_EMAIL) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
}

export const adminRouter = createRouter({
  users: createRouter({
    /** All users with computed trial state for the admin table. */
    list: authedQuery.query(async ({ ctx }) => {
      assertAdmin(ctx);
      const rows = await listUsers();
      return rows.map((u) => {
        const ent = computeEntitlement(u);
        return {
          id: u.id,
          name: u.name,
          email: u.email,
          plan: u.plan,
          planExpiresAt: u.planExpiresAt,
          createdAt: u.createdAt,
          trialDaysLeft: ent.trialDaysLeft,
          admin: ent.admin,
        };
      });
    }),

    /** Grant/revoke PRO. expiresAt null = no expiry. */
    setPlan: authedQuery
      .input(
        z.object({
          userId: z.number().int().positive(),
          plan: z.enum(PLANS),
          expiresAt: z.coerce.date().nullish(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        assertAdmin(ctx);
        const updated = await setUserPlan(
          input.userId,
          input.plan,
          input.expiresAt ?? null,
        );
        if (!updated) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }
        await logActivity({
          userId: input.userId,
          level: "info",
          source: "admin",
          message: `Plan set to ${input.plan.toUpperCase()} by admin${
            input.expiresAt ? ` (expires ${input.expiresAt.toISOString()})` : " (no expiry)"
          }`,
        });
        return { success: true };
      }),

    /**
     * Admin-assisted password reset: generates a 12-char temp password, sets
     * the hash and returns the plaintext ONCE to the admin (never the hash).
     */
    resetPassword: authedQuery
      .input(z.object({ userId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        assertAdmin(ctx);
        const target = await findUserById(input.userId);
        if (!target) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }
        const tempPassword = generateTempPassword(12);
        await updateUserPassword(input.userId, hashPassword(tempPassword));
        await logActivity({
          userId: input.userId,
          level: "warn",
          source: "admin",
          message:
            "Password reset by admin — sign in with the temporary password and change it in Settings",
        });
        return { tempPassword };
      }),
  }),

  /* ---- [platform config] shared OpenSea key override -------------------- */
  platform: createRouter({
    /**
     * Shared OpenSea key status. NEVER returns the actual key value — only
     * whether an override is stored and a masked ••••last4 form.
     */
    getSharedOpenseaKey: authedQuery.query(async ({ ctx }) => {
      assertAdmin(ctx);
      const stored = await getSetting(SHARED_OPENSEA_KEY_SETTING);
      return {
        stored: stored ? maskOpenseaKey(stored) : null,
        isSet: stored != null,
        usingBuiltin: stored == null,
      };
    }),

    /** Set/clear the shared-key override (null = back to built-in). */
    setSharedOpenseaKey: authedQuery
      .input(
        z.object({
          key: z
            .string()
            .regex(/^[0-9a-f]{32}$/, "Must be a 32-char hex OpenSea API key")
            .nullish(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        assertAdmin(ctx);
        await setSetting(SHARED_OPENSEA_KEY_SETTING, input.key ?? null);
        return { success: true, isSet: input.key != null };
      }),
  }),
  /* ---- [/platform config] ------------------------------------------------ */

  /* ---- [crypto billing] admin pay-to-address + claim review ------------- */
  billing: createRouter({
    /** Payment address config: stored override + effective value. */
    getPaymentAddress: authedQuery.query(async ({ ctx }) => {
      assertAdmin(ctx);
      const stored = await getSetting(PAYMENT_ADDRESS_SETTING_KEY);
      return {
        stored,
        effective: stored ?? PRO_PAYMENT_ADDRESS,
        isDefault: stored == null,
      };
    }),

    /** Set/clear the payment address override (null = back to built-in). */
    setPaymentAddress: authedQuery
      .input(
        z.object({
          address: z
            .string()
            .regex(/^0x[0-9a-fA-F]{40}$/, "Must be a 0x-prefixed 40-hex EVM address")
            .nullish(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        assertAdmin(ctx);
        await setSetting(PAYMENT_ADDRESS_SETTING_KEY, input.address ?? null);
        return { success: true };
      }),

    /** Pending payment claims (oldest first) with claimant identity. */
    claims: authedQuery.query(async ({ ctx }) => {
      assertAdmin(ctx);
      const rows = await listPendingClaims();
      return rows.map((r) => ({
        id: r.id,
        userId: r.userId,
        userEmail: r.userEmail,
        userName: r.userName,
        chainId: r.chainId,
        txHash: r.txHash,
        createdAt: r.createdAt,
        ageMs: Date.now() - new Date(r.createdAt).getTime(),
      }));
    }),

    /**
     * Approve → claim approved + user granted PRO for 30 days.
     * Reject  → claim rejected (with optional note shown to no one but admin).
     */
    reviewClaim: authedQuery
      .input(
        z.object({
          claimId: z.number().int().positive(),
          approve: z.boolean(),
          note: z.string().max(256).optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        assertAdmin(ctx);
        const claim = await reviewClaim({
          claimId: input.claimId,
          approve: input.approve,
          note: input.note,
        });
        if (!claim) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Claim not found" });
        }
        if (input.approve) {
          const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
          await setUserPlan(claim.userId, "pro", expiresAt);
          await logActivity({
            userId: claim.userId,
            level: "success",
            source: "admin",
            message: `PRO activated for 30 days — payment claim approved (tx ${claim.txHash})`,
          });
        }
        return { success: true, status: claim.status };
      }),
  }),
  /* ---- [/crypto billing] ------------------------------------------------- */
});

/** User-facing billing — pay-to-address info + payment claims. */
export const billingRouter = createRouter({
  /* ---- [crypto billing] public pay-to-address + claims ------------------- */
  /** Payment address, price and accepted EVM chains for the Upgrade page. */
  paymentInfo: authedQuery.query(async () => ({
    address: await effectivePaymentAddress(),
    priceUsd: PRO_PRICE_USD,
    chains: [...PAYMENT_CHAIN_IDS],
  })),

  /** Submit a payment tx hash for review. One pending claim per user+tx. */
  submitClaim: authedQuery
    .input(
      z.object({
        chainId: z
          .number()
          .int()
          .refine(isPaymentChain, "Unsupported chain — pay on a supported EVM chain"),
        txHash: z
          .string()
          .regex(/^0x[0-9a-fA-F]{64}$/, "Must be a 0x-prefixed 64-hex transaction hash"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user!.id;
      const existing = await findPendingClaim(userId, input.txHash);
      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message:
            "This transaction hash is already submitted and awaiting review — no need to resend it.",
        });
      }
      await insertClaim({ userId, chainId: input.chainId, txHash: input.txHash });
      return { success: true };
    }),

  /** The user's own claims with status — Upgrade page history. */
  myClaims: authedQuery.query(async ({ ctx }) => {
    const rows = await listClaimsByUser(ctx.user!.id);
    return rows.map((r) => ({
      id: r.id,
      chainId: r.chainId,
      txHash: r.txHash,
      status: r.status,
      adminNote: r.adminNote,
      createdAt: r.createdAt,
      reviewedAt: r.reviewedAt,
    }));
  }),
  /* ---- [/crypto billing] -------------------------------------------------- */
});
