import { TRPCError } from "@trpc/server";
import {
  ADMIN_EMAIL,
  FREE_LIMITS,
  type Entitlement,
} from "@contracts/plans";

/**
 * Plan entitlement computation + tRPC guards.
 *
 * - ADMIN_EMAIL always gets full access (pro + admin flag, never expires),
 *   regardless of the stored row.
 * - plan='pro' is honoured while planExpiresAt is null or in the future.
 * - everyone else is on the free 7-day snipe-bot trial counted from
 *   users.createdAt. A missing createdAt (legacy rows) is treated as an
 *   active trial — never lock a user out over a migration artifact.
 */

const DAY_MS = 24 * 60 * 60 * 1000;

type EntitlementUser = {
  email?: string | null;
  plan?: string | null;
  planExpiresAt?: Date | null;
  createdAt?: Date | null;
};

export function isAdminEmail(email?: string | null): boolean {
  return !!email && email.trim().toLowerCase() === ADMIN_EMAIL;
}

export function computeEntitlement(
  user: EntitlementUser,
  now: number = Date.now(),
): Entitlement {
  if (isAdminEmail(user.email)) {
    return {
      plan: "pro",
      admin: true,
      trialEndsAt: null,
      trialDaysLeft: null,
      trialExpired: false,
    };
  }

  const proActive =
    user.plan === "pro" &&
    (!user.planExpiresAt || user.planExpiresAt.getTime() > now);
  if (proActive) {
    return {
      plan: "pro",
      admin: false,
      trialEndsAt: null,
      trialDaysLeft: null,
      trialExpired: false,
    };
  }

  if (!user.createdAt) {
    // Legacy row without a signup timestamp — fail open.
    return {
      plan: "free",
      admin: false,
      trialEndsAt: null,
      trialDaysLeft: FREE_LIMITS.trialDays,
      trialExpired: false,
    };
  }

  const trialEndsAt = user.createdAt.getTime() + FREE_LIMITS.trialDays * DAY_MS;
  const trialExpired = now >= trialEndsAt;
  return {
    plan: "free",
    admin: false,
    trialEndsAt,
    trialDaysLeft: Math.max(0, Math.ceil((trialEndsAt - now) / DAY_MS)),
    trialExpired,
  };
}

/**
 * Engine-loop gate: may this entitlement actually EXECUTE a feature?
 * Routers gate new activity; this closes the hole where engine loops kept
 * running for users who were downgraded or whose trial expired mid-flight.
 *
 * - admin / active-PRO: everything.
 * - free: snipe only while the 7-day trial is live; copy + sweep are PRO-only.
 */
export type ExecutableFeature = "snipe" | "copy" | "sweep";

export function canExecute(
  entitlement: Entitlement,
  feature: ExecutableFeature,
): boolean {
  if (entitlement.admin) return true;
  if (entitlement.plan === "pro") return true;
  if (feature === "snipe") return !entitlement.trialExpired;
  return false;
}

type GuardCtx = { user: EntitlementUser };

/** Everything except the (trial-limited) snipe bot requires PRO. */
export function assertPro(ctx: GuardCtx): Entitlement {
  const ent = computeEntitlement(ctx.user);
  if (ent.plan !== "pro") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message:
        "PRO_REQUIRED — this feature is part of the PRO plan ($15/mo). Upgrade from the Upgrade tab.",
    });
  }
  return ent;
}

/**
 * Snipe-bot guard: free users need an active trial and stay within the
 * per-task wallet cap. The pending-order cap is enforced in taskRouter
 * (it needs a DB count). Admin and active-PRO pass unconditionally.
 */
export function assertSnipeAllowed(ctx: GuardCtx, walletCount: number): Entitlement {
  const ent = computeEntitlement(ctx.user);
  if (ent.plan === "pro") return ent;
  if (ent.trialExpired) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message:
        "TRIAL_EXPIRED — your 7-day free trial has ended. Upgrade to PRO ($15/mo) to keep sniping.",
    });
  }
  if (walletCount > FREE_LIMITS.maxSnipeWallets) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Free plan snipes with up to ${FREE_LIMITS.maxSnipeWallets} wallets per task — PRO unlocks unlimited wallets.`,
    });
  }
  return ent;
}

/** Free-plan pending-order cap (draft + armed tasks). Call with a DB count. */
export function assertPendingSnipeCap(ent: Entitlement, pendingCount: number): void {
  if (ent.plan === "pro") return;
  if (pendingCount >= FREE_LIMITS.maxPendingSnipes) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Free plan allows up to ${FREE_LIMITS.maxPendingSnipes} pending snipe orders (${pendingCount}/${FREE_LIMITS.maxPendingSnipes} in use) — PRO removes the cap.`,
    });
  }
}
