/**
 * Clean RPC/ethers error extraction + per-key error throttling for engines.
 *
 * Raw ethers v6 errors are verbose objects ("could not coalesce error
 * (error={ \"code\": -32046, ...})", "(code=TIMEOUT, version=6.17.0)" tails,
 * request/response payload dumps). cleanRpcError unwraps them to the INNER
 * human-readable message so the activity feed never shows raw noise.
 *
 * ErrorThrottle dedupes repeated identical errors (key = walletId/ruleId +
 * cleaned message) so a failing endpoint logs AT MOST once per 15 minutes
 * instead of every poll cycle.
 */

const MAX_LEN = 160;

/** Extract a short, human-readable message from any thrown value. */
export function cleanRpcError(e: unknown): string {
  let msg = unwrapCoalesce(extractMessage(e, 0));
  // ethers HTTP boilerplate: "server response 403 Forbidden (request=...)" —
  // keep the status text, drop the request/response dump.
  if (msg.startsWith("server response")) {
    const paren = msg.indexOf(" (");
    if (paren > 0) msg = msg.slice(0, paren);
  }
  msg = msg.replace(/\s+/g, " ").trim();
  if (msg.length === 0) return "unknown error";
  return msg.length > MAX_LEN ? `${msg.slice(0, MAX_LEN - 1)}…` : msg;
}

function extractMessage(e: unknown, depth: number): string {
  if (e === null || e === undefined) return "unknown error";
  if (typeof e === "string") return e;
  if (typeof e === "number" || typeof e === "boolean") return String(e);
  if (typeof e !== "object") return String(e);
  if (depth > 4) return "unknown error";

  const obj = e as Record<string, unknown>;
  // ethers v6 nesting: error.info.error.message (the JSON-RPC inner payload).
  const info = obj.info as Record<string, unknown> | undefined;
  const infoErr = info?.error as Record<string, unknown> | undefined;
  if (typeof infoErr?.message === "string") return infoErr.message;
  // error.error.message (one level of wrapping).
  const nested = obj.error as Record<string, unknown> | undefined;
  if (typeof nested?.message === "string") return nested.message;
  // ethers shortMessage ("request timeout", "could not coalesce error", ...).
  if (typeof obj.shortMessage === "string" && obj.shortMessage.length > 0) {
    const short = obj.shortMessage;
    if (!short.startsWith("could not coalesce")) return short;
    // coalesce wrapper with no nested payload — fall through to message so
    // unwrapCoalesce can dig the inner JSON out of the full text.
  }
  if (typeof obj.message === "string") return obj.message;
  // A raw JSON-RPC error payload { code, message } is covered above; anything
  // else must NEVER be dumped wholesale into the feed.
  return e instanceof Error ? e.message : "unknown error";
}

/**
 * ethers v6 coalesce wrapper: the full message embeds the inner JSON-RPC
 * error as `error={ ...json... }, code=...`. Parse out the inner `message`
 * field only — never surface the whole { code, message, data } blob.
 */
function unwrapCoalesce(msg: string): string {
  if (!msg.includes("could not coalesce error")) return msg;
  const m = msg.match(/error=(\{.*?\})\s*,\s*code=/s);
  if (m) {
    try {
      const parsed = JSON.parse(m[1]) as { message?: unknown };
      if (typeof parsed.message === "string" && parsed.message.length > 0) {
        return parsed.message;
      }
    } catch {
      // malformed inner JSON — fall through to the trimmed wrapper text
    }
  }
  return msg.replace(/^could not coalesce error\s*/, "").replace(/\s*\(error=$/, "").trim() || msg;
}

/** Default dedupe window: identical errors log at most once per 15 minutes. */
export const ERROR_THROTTLE_INTERVAL_MS = 15 * 60_000;

/**
 * In-memory per-key error throttle. First occurrence (or one past the
 * interval) logs; consecutive repeats are silently counted. clearPrefix()
 * is called on a successful poll to reset the key and report whether an
 * error had been logged (for a one-line "recovered" info log).
 */
export class ErrorThrottle {
  private entries = new Map<string, { lastLogAt: number; suppressed: number }>();
  private readonly intervalMs: number;
  private readonly now: () => number;

  constructor(
    intervalMs: number = ERROR_THROTTLE_INTERVAL_MS,
    now: () => number = Date.now,
  ) {
    this.intervalMs = intervalMs;
    this.now = now;
  }

  /** True when this error should be logged now; repeats return false and count. */
  shouldLog(key: string): boolean {
    const now = this.now();
    const entry = this.entries.get(key);
    if (!entry || now - entry.lastLogAt >= this.intervalMs) {
      this.entries.set(key, { lastLogAt: now, suppressed: 0 });
      return true;
    }
    entry.suppressed += 1;
    return false;
  }

  /**
   * Clear every key starting with `prefix` (call after a successful poll).
   * Returns how many error keys were active and how many repeats were
   * suppressed — `cleared > 0` means the caller may log a recovery line.
   */
  clearPrefix(prefix: string): { cleared: number; suppressed: number } {
    let cleared = 0;
    let suppressed = 0;
    for (const [key, entry] of [...this.entries]) {
      if (key.startsWith(prefix)) {
        cleared += 1;
        suppressed += entry.suppressed;
        this.entries.delete(key);
      }
    }
    return { cleared, suppressed };
  }
}
