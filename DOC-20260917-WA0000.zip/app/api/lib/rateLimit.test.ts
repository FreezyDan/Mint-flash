import { describe, expect, it } from "vitest";
import { SlidingWindowLimiter } from "./rateLimit";

const WINDOW = 15 * 60 * 1000;
const T0 = 1_000_000;

function makeLimiter(max = 5) {
  return new SlidingWindowLimiter(max, WINDOW);
}

describe("SlidingWindowLimiter", () => {
  it("allows attempts under the failure limit", () => {
    const l = makeLimiter();
    for (let i = 0; i < 4; i++) l.recordFailure("a@b.c", T0 + i * 1000);
    expect(l.check("a@b.c", T0 + 5000)).toEqual({ allowed: true });
  });

  it("blocks at the failure limit with a retry-after inside the window", () => {
    const l = makeLimiter();
    for (let i = 0; i < 5; i++) l.recordFailure("a@b.c", T0 + i * 1000);
    const check = l.check("a@b.c", T0 + 5000);
    expect(check.allowed).toBe(false);
    if (!check.allowed) {
      // Oldest failure expires at T0 + WINDOW.
      expect(check.retryAfterMs).toBe(WINDOW - 5000);
    }
  });

  it("allows again once the lockout window expires", () => {
    const l = makeLimiter();
    for (let i = 0; i < 5; i++) l.recordFailure("a@b.c", T0 + i * 1000);
    expect(l.check("a@b.c", T0 + WINDOW).allowed).toBe(true);
  });

  it("clears the counter on success", () => {
    const l = makeLimiter();
    for (let i = 0; i < 5; i++) l.recordFailure("a@b.c", T0 + i * 1000);
    expect(l.check("a@b.c", T0 + 5000).allowed).toBe(false);
    l.recordSuccess("a@b.c");
    expect(l.check("a@b.c", T0 + 5000)).toEqual({ allowed: true });
  });

  it("tracks keys independently and slides the window", () => {
    const l = makeLimiter();
    for (let i = 0; i < 5; i++) l.recordFailure("a@b.c", T0 + i * 1000);
    // A different email is unaffected.
    expect(l.check("x@y.z", T0 + 5000).allowed).toBe(true);
    // Sliding: after the oldest failures age out, fewer than max remain —
    // new failures re-trip the limit without a hard window reset.
    const t = T0 + WINDOW + 1000; // failures at T0/+1000 have expired, 3 remain
    expect(l.check("a@b.c", t).allowed).toBe(true);
    l.recordFailure("a@b.c", t);
    expect(l.check("a@b.c", t).allowed).toBe(true); // 4 recent
    l.recordFailure("a@b.c", t + 1);
    expect(l.check("a@b.c", t + 1).allowed).toBe(false); // 5 recent → blocked
  });
});
