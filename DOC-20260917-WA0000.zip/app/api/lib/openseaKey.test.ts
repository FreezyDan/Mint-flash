import { describe, expect, it } from "vitest";
import { maskOpenseaKey, pickOpenseaKey } from "./openseaKey";

describe("pickOpenseaKey", () => {
  it("prefers the user's own key (source 'user')", () => {
    const res = pickOpenseaKey("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "b".repeat(32));
    expect(res.source).toBe("user");
    expect(res.key).toBe("a".repeat(32));
  });

  it("falls back to the admin shared override (source 'shared')", () => {
    const res = pickOpenseaKey(null, "c".repeat(32));
    expect(res.source).toBe("shared");
    expect(res.key).toBe("c".repeat(32));
  });

  it("falls back to the built-in shared key when nothing is configured", () => {
    const res = pickOpenseaKey(undefined, null);
    expect(res.source).toBe("shared");
    expect(res.key).toMatch(/^[0-9a-f]{32}$/);
  });

  it("treats blank/whitespace keys as unset", () => {
    const res = pickOpenseaKey("   ", "");
    expect(res.source).toBe("shared");
    expect(res.key).toMatch(/^[0-9a-f]{32}$/);
  });
});

describe("maskOpenseaKey", () => {
  it("masks everything except the last 4 chars", () => {
    const masked = maskOpenseaKey("d".repeat(28) + "8bcc");
    expect(masked).toBe("••••8bcc");
    expect(masked).not.toContain("d".repeat(5));
  });
});
