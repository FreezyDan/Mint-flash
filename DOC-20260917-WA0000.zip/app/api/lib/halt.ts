/**
 * Per-user emergency kill switch. When `user_settings.halted` is true every
 * engine (snipe, copy, sweep, sell) refuses to broadcast transactions for
 * that user. Checked at each engine's execution gate with a 10s in-process
 * cache so the DB is not hit on every engine tick.
 */
import { getOrCreateSettings } from "../queries/settings";

const TTL_MS = 10_000;
const cache = new Map<number, { halted: boolean; at: number }>();

/** True when the user's emergency stop is active. Fails OPEN on DB errors —
 *  a database hiccup must never freeze a user's trading unexpectedly. */
export async function isHalted(userId: number): Promise<boolean> {
  const hit = cache.get(userId);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.halted;
  try {
    const settings = await getOrCreateSettings(userId);
    const halted = settings.halted === true;
    cache.set(userId, { halted, at: Date.now() });
    return halted;
  } catch {
    return false;
  }
}

/** Drop the cached flag (called by the settings router after an update). */
export function invalidateHaltCache(userId: number): void {
  cache.delete(userId);
}
