import { describe, expect, it } from "vitest";
import { TRPCError } from "@trpc/server";
import { ADMIN_EMAIL, FREE_LIMITS } from "@contracts/plans";
import {
  assertPendingSnipeCap,
  assertPro,
  assertSnipeAllowed,
  canExecute,
  computeEntitlement,
} from "./entitlements";

const DAY = 24 * 60 * 60 * 1000;
const NOW = Date.UTC(2025, 0, 10, 12, 0, 0);

function freeUser(createdAt: Date | null) {
  return {
    email: "degen@example.com",
    plan: "free",
    planExpiresAt: null,
    createdAt,
  };
}

describe("computeEntitlement", () => {
  it("gives the admin email permanent full access regardless of stored plan", () => {
    const ent = computeEntitlement(
      { email: ADMIN_EMAIL, plan: "free", planExpiresAt: null, createdAt: new Date(0) },
      NOW,
    );
    expect(ent).toEqual({
      plan: "pro",
      admin: true,
      trialEndsAt: null,
      trialDaysLeft: null,
      trialExpired: false,
    });
  });

  it("matches the admin email case-insensitively", () => {
    const ent = computeEntitlement({ email: "  Dioruhanan@Gmail.com " }, NOW);
    expect(ent.admin).toBe(true);
    expect(ent.plan).toBe("pro");
  });

  it("treats pro without expiry as active", () => {
    const ent = computeEntitlement(
      { email: "a@b.c", plan: "pro", planExpiresAt: null, createdAt: null },
      NOW,
    );
    expect(ent.plan).toBe("pro");
    expect(ent.admin).toBe(false);
  });

  it("treats pro with a future expiry as active", () => {
    const ent = computeEntitlement(
      { email: "a@b.c", plan: "pro", planExpiresAt: new Date(NOW + DAY), createdAt: null },
      NOW,
    );
    expect(ent.plan).toBe("pro");
  });

  it("treats pro with a past expiry as an expired-trial free user", () => {
    const createdAt = new Date(NOW - 30 * DAY);
    const ent = computeEntitlement(
      { email: "a@b.c", plan: "pro", planExpiresAt: new Date(NOW - DAY), createdAt },
      NOW,
    );
    expect(ent.plan).toBe("free");
    expect(ent.trialExpired).toBe(true);
  });

  it("trial boundary: day 6 still active with 1 day left", () => {
    const createdAt = new Date(NOW - 6 * DAY - 60_000);
    const ent = computeEntitlement(freeUser(createdAt), NOW);
    expect(ent.trialExpired).toBe(false);
    expect(ent.trialDaysLeft).toBe(1);
    expect(ent.trialEndsAt).toBe(createdAt.getTime() + FREE_LIMITS.trialDays * DAY);
  });

  it("trial boundary: exactly 7 days is expired", () => {
    const createdAt = new Date(NOW - FREE_LIMITS.trialDays * DAY);
    const ent = computeEntitlement(freeUser(createdAt), NOW);
    expect(ent.trialExpired).toBe(true);
    expect(ent.trialDaysLeft).toBe(0);
  });

  it("trial boundary: day 8 is expired", () => {
    const ent = computeEntitlement(freeUser(new Date(NOW - 8 * DAY)), NOW);
    expect(ent.trialExpired).toBe(true);
    expect(ent.trialDaysLeft).toBe(0);
  });

  it("fresh signup gets the full trial", () => {
    const createdAt = new Date(NOW - 60_000);
    const ent = computeEntitlement(freeUser(createdAt), NOW);
    expect(ent.trialExpired).toBe(false);
    expect(ent.trialDaysLeft).toBe(FREE_LIMITS.trialDays);
  });

  it("missing createdAt fails open with a full-trial fallback", () => {
    const ent = computeEntitlement(freeUser(null), NOW);
    expect(ent.plan).toBe("free");
    expect(ent.trialExpired).toBe(false);
    expect(ent.trialEndsAt).toBeNull();
    expect(ent.trialDaysLeft).toBe(FREE_LIMITS.trialDays);
  });
});

describe("guards", () => {
  const proCtx = { user: { email: "a@b.c", plan: "pro", planExpiresAt: null } };
  const trialCtx = { user: freeUser(new Date()) };
  const expiredCtx = { user: freeUser(new Date(NOW - 30 * DAY)) };

  it("assertPro passes for pro/admin and throws PRO_REQUIRED for free", () => {
    expect(() => assertPro(proCtx)).not.toThrow();
    expect(() => assertPro({ user: { email: ADMIN_EMAIL } })).not.toThrow();
    try {
      assertPro(trialCtx);
      expect.unreachable();
    } catch (e) {
      expect(e).toBeInstanceOf(TRPCError);
      expect((e as TRPCError).code).toBe("FORBIDDEN");
      expect((e as TRPCError).message).toContain("PRO_REQUIRED");
    }
  });

  it("assertSnipeAllowed enforces the free wallet cap", () => {
    expect(() => assertSnipeAllowed(trialCtx, FREE_LIMITS.maxSnipeWallets)).not.toThrow();
    try {
      assertSnipeAllowed(trialCtx, FREE_LIMITS.maxSnipeWallets + 1);
      expect.unreachable();
    } catch (e) {
      expect((e as TRPCError).code).toBe("BAD_REQUEST");
    }
    // Pro has no wallet cap.
    expect(() => assertSnipeAllowed(proCtx, 25)).not.toThrow();
  });

  it("assertSnipeAllowed throws TRIAL_EXPIRED after the trial", () => {
    try {
      assertSnipeAllowed(expiredCtx, 1);
      expect.unreachable();
    } catch (e) {
      expect((e as TRPCError).code).toBe("FORBIDDEN");
      expect((e as TRPCError).message).toContain("TRIAL_EXPIRED");
    }
  });

  it("assertPendingSnipeCap blocks the 4th pending order on free", () => {
    const ent = computeEntitlement(trialCtx.user);
    expect(() => assertPendingSnipeCap(ent, FREE_LIMITS.maxPendingSnipes - 1)).not.toThrow();
    expect(() => assertPendingSnipeCap(ent, FREE_LIMITS.maxPendingSnipes)).toThrowError(
      /pending snipe orders/,
    );
    expect(() =>
      assertPendingSnipeCap(computeEntitlement(proCtx.user), 999),
    ).not.toThrow();
  });
});

describe("canExecute (engine-loop gate)", () => {
  const adminEnt = computeEntitlement({ email: ADMIN_EMAIL }, NOW);
  const proEnt = computeEntitlement(
    { email: "a@b.c", plan: "pro", planExpiresAt: null },
    NOW,
  );
  const trialEnt = computeEntitlement(freeUser(new Date(NOW - 60_000)), NOW);
  const expiredEnt = computeEntitlement(freeUser(new Date(NOW - 30 * DAY)), NOW);

  it("admin can execute every feature, always", () => {
    expect(adminEnt.admin).toBe(true);
    expect(canExecute(adminEnt, "snipe")).toBe(true);
    expect(canExecute(adminEnt, "copy")).toBe(true);
    expect(canExecute(adminEnt, "sweep")).toBe(true);
  });

  it("pro can execute every feature", () => {
    expect(canExecute(proEnt, "snipe")).toBe(true);
    expect(canExecute(proEnt, "copy")).toBe(true);
    expect(canExecute(proEnt, "sweep")).toBe(true);
  });

  it("free user inside the trial can snipe", () => {
    expect(trialEnt.trialExpired).toBe(false);
    expect(canExecute(trialEnt, "snipe")).toBe(true);
  });

  it("free user past the trial cannot snipe", () => {
    expect(expiredEnt.trialExpired).toBe(true);
    expect(canExecute(expiredEnt, "snipe")).toBe(false);
  });

  it("free users can never copy or sweep (PRO features), even in trial", () => {
    expect(canExecute(trialEnt, "copy")).toBe(false);
    expect(canExecute(trialEnt, "sweep")).toBe(false);
    expect(canExecute(expiredEnt, "copy")).toBe(false);
    expect(canExecute(expiredEnt, "sweep")).toBe(false);
  });

  it("expired-PRO downgrade stops copy/sweep immediately", () => {
    const downgraded = computeEntitlement(
      {
        email: "a@b.c",
        plan: "pro",
        planExpiresAt: new Date(NOW - DAY),
        createdAt: new Date(NOW - 30 * DAY),
      },
      NOW,
    );
    expect(downgraded.plan).toBe("free");
    expect(canExecute(downgraded, "copy")).toBe(false);
    expect(canExecute(downgraded, "sweep")).toBe(false);
    expect(canExecute(downgraded, "snipe")).toBe(false);
  });
});
