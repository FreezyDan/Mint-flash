/**
 * In-memory sliding-window rate limiter for failed login attempts.
 *
 * Pure + testable core: every method takes `now` (epoch ms) so tests can
 * inject time. State lives in a Map on the instance — per process, which is
 * fine for a single-node deployment and resets harmlessly on restart.
 */

export type RateLimitCheck =
  | { allowed: true }
  | { allowed: false; retryAfterMs: number };

export class SlidingWindowLimiter {
  private failures = new Map<string, number[]>();
  /** Failed attempts allowed inside the window before lockout. */
  private readonly maxFailures: number;
  /** Window (and lockout) length in ms. */
  private readonly windowMs: number;

  constructor(maxFailures: number, windowMs: number) {
    this.maxFailures = maxFailures;
    this.windowMs = windowMs;
  }

  /** Prune entries outside the window; drops empty keys. */
  private recent(key: string, now: number): number[] {
    const kept = (this.failures.get(key) ?? []).filter(
      (t) => now - t < this.windowMs,
    );
    if (kept.length === 0) this.failures.delete(key);
    else this.failures.set(key, kept);
    return kept;
  }

  /** Is another attempt allowed right now? */
  check(key: string, now: number = Date.now()): RateLimitCheck {
    const recent = this.recent(key, now);
    if (recent.length < this.maxFailures) return { allowed: true };
    const oldest = recent[0];
    return {
      allowed: false,
      retryAfterMs: Math.max(0, oldest + this.windowMs - now),
    };
  }

  /** Record a failed attempt; returns the post-record check result. */
  recordFailure(key: string, now: number = Date.now()): RateLimitCheck {
    const recent = this.recent(key, now);
    recent.push(now);
    this.failures.set(key, recent);
    return this.check(key, now);
  }

  /** Successful login — clear the counter for this key. */
  recordSuccess(key: string): void {
    this.failures.delete(key);
  }
}

/** Shared limiter for creds.login: 5 failures → 15-minute lockout. */
export const LOGIN_MAX_FAILURES = 5;
export const LOGIN_LOCKOUT_MS = 15 * 60 * 1000;
export const loginLimiter = new SlidingWindowLimiter(
  LOGIN_MAX_FAILURES,
  LOGIN_LOCKOUT_MS,
);
