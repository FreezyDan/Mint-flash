import { describe, expect, it } from "vitest";
import {
  generateTempPassword,
  hashPassword,
  verifyPassword,
} from "./passwords";

describe("hashPassword / verifyPassword", () => {
  it("round-trips a correct password", () => {
    const hash = hashPassword("s3cure-passphrase");
    expect(hash).toMatch(/^[0-9a-f]{32}:[0-9a-f]{128}$/);
    expect(verifyPassword("s3cure-passphrase", hash)).toBe(true);
  });

  it("rejects a wrong password and malformed stored values", () => {
    const hash = hashPassword("s3cure-passphrase");
    expect(verifyPassword("wrong-password", hash)).toBe(false);
    expect(verifyPassword("s3cure-passphrase", "garbage")).toBe(false);
    expect(verifyPassword("s3cure-passphrase", "")).toBe(false);
  });

  it("salts every hash differently", () => {
    expect(hashPassword("same-password")).not.toBe(hashPassword("same-password"));
  });
});

describe("generateTempPassword", () => {
  it("generates a 12-char unambiguous temp password by default", () => {
    const pw = generateTempPassword();
    expect(pw).toHaveLength(12);
    expect(pw).toMatch(/^[A-HJ-NP-Za-km-np-z2-9]{12}$/);
  });

  it("never repeats and honours custom lengths", () => {
    const a = generateTempPassword(16);
    const b = generateTempPassword(16);
    expect(a).toHaveLength(16);
    expect(a).not.toBe(b);
  });
});
