/**
 * MEV protection via Flashbots Protect (https://rpc.flashbots.net).
 *
 * Protect is a drop-in JSON-RPC endpoint for Ethereum mainnet: it accepts
 * standard `eth_sendRawTransaction` (no auth, no API key, no bundle logic)
 * and routes signed transactions to a private mempool so snipes are hidden
 * from sandwich/frontrun bots until mined. Reads/polling stay on the normal
 * RPC — only the LIVE broadcast is rerouted.
 *
 * The `user_settings.mevProtection` column is applied by ensureSchema
 * (boolean NOT NULL DEFAULT true) but intentionally lives outside the
 * Drizzle table definition, so settings objects may not carry the field —
 * an absent value means the schema default: ON.
 */

/** Chains with a private-mempool broadcast endpoint. Ethereum mainnet only. */
export const MEV_PROTECT_RPC: Record<number, string> = {
  1: "https://rpc.flashbots.net",
};

/**
 * Minimal structural view of user settings for MEV decisions. Any object
 * with an optional `mevProtection` flag qualifies (a Drizzle UserSettings
 * row is assignable even though the column isn't in the table definition).
 */
export type MevProtectionSettings = { mevProtection?: boolean | null } | null | undefined;

/** True when private-mempool routing applies: chain supported AND not disabled. */
export function shouldUseMevProtect(chainId: number, settings: MevProtectionSettings): boolean {
  if (!(chainId in MEV_PROTECT_RPC)) return false;
  // Default ON (schema default true) unless explicitly disabled.
  return (settings?.mevProtection ?? true) === true;
}

/**
 * Resolve the RPC URL used for LIVE transaction broadcasts. Returns the
 * Flashbots Protect endpoint when MEV protection applies, otherwise the
 * given RPC unchanged. Non-broadcast traffic must keep using `rpcUrl`.
 */
export function resolveExecutionRpc(
  chainId: number,
  rpcUrl: string,
  settings: MevProtectionSettings,
): string {
  return shouldUseMevProtect(chainId, settings) ? MEV_PROTECT_RPC[chainId] : rpcUrl;
}
