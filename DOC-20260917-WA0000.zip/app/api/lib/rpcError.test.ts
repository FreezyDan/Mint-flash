import { describe, expect, it } from "vitest";
import { cleanRpcError, ErrorThrottle } from "./rpcError";

describe("cleanRpcError", () => {
  it("unwraps a coalesce wrapper with nested info.error payload", () => {
    const err = {
      code: "UNKNOWN_ERROR",
      shortMessage: "could not coalesce error",
      message:
        'could not coalesce error (error={ "code": -32046, "message": "eth_getLogs range too large" }, code=UNKNOWN_ERROR, version=6.17.0)',
      info: { error: { code: -32046, message: "eth_getLogs range too large" } },
    };
    expect(cleanRpcError(err)).toBe("eth_getLogs range too large");
  });

  it("parses the inner JSON message out of a string-only coalesce message", () => {
    const err = new Error(
      'could not coalesce error (error={ "code": -32046, "message": "backend is unhealthy" }, code=UNKNOWN_ERROR, version=6.17.0)',
    );
    expect(cleanRpcError(err)).toBe("backend is unhealthy");
  });

  it("collapses a TIMEOUT error to the short message", () => {
    const err = {
      code: "TIMEOUT",
      shortMessage: "request timeout",
      message: "request timeout (code=TIMEOUT, version=6.17.0)",
    };
    expect(cleanRpcError(err)).toBe("request timeout");
  });

  it("strips the request/response dump off a 403 server-response error", () => {
    const err = new Error(
      'server response 403 Forbidden (request={ "jsonrpc": "2.0", "method": "eth_getLogs" }, response="Forbidden", error=null, code=SERVER_ERROR, version=6.17.0)',
    );
    expect(cleanRpcError(err)).toBe("server response 403 Forbidden");
  });

  it("prefers nested info.error.message over the outer message", () => {
    const err = {
      message: "could not coalesce error (error={ ... })",
      info: { error: { code: -32603, message: "internal JSON-RPC error" } },
    };
    expect(cleanRpcError(err)).toBe("internal JSON-RPC error");
  });

  it("passes through a plain Error message", () => {
    expect(cleanRpcError(new Error("sweep buy tx 0xabc reverted"))).toBe(
      "sweep buy tx 0xabc reverted",
    );
  });

  it("handles non-Error values without dumping objects", () => {
    expect(cleanRpcError("plain string failure")).toBe("plain string failure");
    expect(cleanRpcError(42)).toBe("42");
    expect(cleanRpcError(null)).toBe("unknown error");
    expect(cleanRpcError({ code: -32046 })).toBe("unknown error");
    expect(cleanRpcError({ code: -32046, message: "rate limited" })).toBe("rate limited");
  });

  it("caps messages at 160 chars", () => {
    const long = new Error(`x`.repeat(500));
    const out = cleanRpcError(long);
    expect(out.length).toBe(160);
    expect(out.endsWith("…")).toBe(true);
  });
});

describe("ErrorThrottle", () => {
  it("logs the first occurrence and suppresses identical repeats", () => {
    let t = 1_000_000;
    const throttle = new ErrorThrottle(15 * 60_000, () => t);
    expect(throttle.shouldLog("w1: boom")).toBe(true);
    t += 1_000;
    expect(throttle.shouldLog("w1: boom")).toBe(false);
    t += 1_000;
    expect(throttle.shouldLog("w1: boom")).toBe(false);
  });

  it("re-logs after the throttle interval expires", () => {
    let t = 1_000_000;
    const throttle = new ErrorThrottle(15 * 60_000, () => t);
    expect(throttle.shouldLog("w1: boom")).toBe(true);
    t += 15 * 60_000;
    expect(throttle.shouldLog("w1: boom")).toBe(true);
  });

  it("tracks keys independently (different wallet or message)", () => {
    const throttle = new ErrorThrottle(15 * 60_000, () => 1_000_000);
    expect(throttle.shouldLog("w1: boom")).toBe(true);
    expect(throttle.shouldLog("w2: boom")).toBe(true);
    expect(throttle.shouldLog("w1: other")).toBe(true);
    expect(throttle.shouldLog("w1: boom")).toBe(false);
  });

  it("clearPrefix resets matching keys and reports suppressed repeats", () => {
    const t = 0;
    const throttle = new ErrorThrottle(15 * 60_000, () => t);
    throttle.shouldLog("w1: boom"); // logged
    throttle.shouldLog("w1: boom"); // suppressed
    throttle.shouldLog("w1: boom"); // suppressed
    throttle.shouldLog("w2: boom"); // different prefix
    const result = throttle.clearPrefix("w1:");
    expect(result.cleared).toBe(1);
    expect(result.suppressed).toBe(2);
    // After clearing, the next occurrence logs again (recovery → fresh cycle).
    expect(throttle.shouldLog("w1: boom")).toBe(true);
    // Untouched prefix is still throttled.
    expect(throttle.shouldLog("w2: boom")).toBe(false);
  });

  it("clearPrefix on a clean prefix reports nothing to recover from", () => {
    const throttle = new ErrorThrottle(15 * 60_000, () => 0);
    expect(throttle.clearPrefix("w9:")).toEqual({ cleared: 0, suppressed: 0 });
  });
});
