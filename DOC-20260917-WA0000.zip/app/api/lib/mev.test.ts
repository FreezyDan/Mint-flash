import { describe, expect, it } from "vitest";
import { MEV_PROTECT_RPC, resolveExecutionRpc, shouldUseMevProtect } from "./mev";

describe("MEV_PROTECT_RPC", () => {
  it("maps Ethereum mainnet to Flashbots Protect", () => {
    expect(MEV_PROTECT_RPC[1]).toBe("https://rpc.flashbots.net");
  });
});

describe("shouldUseMevProtect", () => {
  it("is on for mainnet when the setting is absent (schema default true)", () => {
    expect(shouldUseMevProtect(1, null)).toBe(true);
    expect(shouldUseMevProtect(1, undefined)).toBe(true);
    expect(shouldUseMevProtect(1, {})).toBe(true);
    expect(shouldUseMevProtect(1, { mevProtection: null })).toBe(true);
  });

  it("is on for mainnet when explicitly enabled", () => {
    expect(shouldUseMevProtect(1, { mevProtection: true })).toBe(true);
  });

  it("is off when explicitly disabled", () => {
    expect(shouldUseMevProtect(1, { mevProtection: false })).toBe(false);
  });

  it("never applies to other chains, even when enabled", () => {
    expect(shouldUseMevProtect(8453, { mevProtection: true })).toBe(false);
    expect(shouldUseMevProtect(56, null)).toBe(false);
    expect(shouldUseMevProtect(137, { mevProtection: true })).toBe(false);
  });
});

describe("resolveExecutionRpc", () => {
  const custom = "https://eth-mainnet.g.alchemy.com/v2/key";

  it("returns the Flashbots Protect URL on mainnet when enabled", () => {
    expect(resolveExecutionRpc(1, custom, { mevProtection: true })).toBe(MEV_PROTECT_RPC[1]);
  });

  it("defaults to Protect on mainnet when the setting is absent", () => {
    expect(resolveExecutionRpc(1, custom, undefined)).toBe(MEV_PROTECT_RPC[1]);
  });

  it("keeps the given RPC when disabled", () => {
    expect(resolveExecutionRpc(1, custom, { mevProtection: false })).toBe(custom);
  });

  it("keeps the given RPC on unsupported chains", () => {
    expect(resolveExecutionRpc(8453, "https://mainnet.base.org", { mevProtection: true })).toBe(
      "https://mainnet.base.org",
    );
  });
});
