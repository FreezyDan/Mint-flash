import { findSettingsByUser } from "../queries/settings";
import { getSetting } from "../queries/siteSettings";

/**
 * Shared OpenSea API key resolution — server-side only.
 *
 * The built-in key below is the platform-provided shared key so every OpenSea
 * feature (floor sweeper, all-time profiler) works out of the box. It must
 * NEVER be imported from contracts/ or any frontend-shipped file.
 *
 * Resolution order:
 *  1. the user's own user_settings.openseaApiKey (source "user")
 *  2. the admin-configured site_settings override (source "shared")
 *  3. the built-in shared key (source "shared")
 */

const BUILTIN_OPENSEA_KEY = "5225995753b24d89bcf0b10ebdc28bcc";

/** site_settings key holding the admin's shared-key override. */
export const SHARED_OPENSEA_KEY_SETTING = "sharedOpenseaKey";

export type OpenseaKeySource = "user" | "shared";

/** Pure picker — split out so the precedence rules are unit-testable. */
export function pickOpenseaKey(
  userKey?: string | null,
  sharedOverride?: string | null,
): { key: string; source: OpenseaKeySource } {
  const user = userKey?.trim();
  if (user) return { key: user, source: "user" };
  const shared = sharedOverride?.trim();
  if (shared) return { key: shared, source: "shared" };
  return { key: BUILTIN_OPENSEA_KEY, source: "shared" };
}

/**
 * Resolve the effective OpenSea API key for a user. A key ALWAYS exists
 * (the built-in shared key is the floor), so callers never need a
 * "no key configured" path.
 */
export async function resolveOpenseaKey(
  userId: number,
): Promise<{ key: string; source: OpenseaKeySource }> {
  const settings = await findSettingsByUser(userId);
  const sharedOverride = settings?.openseaApiKey
    ? null // user key wins — skip the extra lookup
    : await getSetting(SHARED_OPENSEA_KEY_SETTING);
  return pickOpenseaKey(settings?.openseaApiKey, sharedOverride);
}

/** True when the site_settings override row exists (admin console display). */
export function maskOpenseaKey(key: string): string {
  return `••••${key.slice(-4)}`;
}
