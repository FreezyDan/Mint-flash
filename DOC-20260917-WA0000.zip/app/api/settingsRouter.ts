import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { invalidateHaltCache } from "./lib/halt";
import { logActivity } from "./queries/activity";
import {
  getMeProtection,
  getOrCreateSettings,
  setMeProtection,
  updateSettings,
} from "./queries/settings";

export const settingsRouter = createRouter({
  get: authedQuery.query(async ({ ctx }) => {
    const [settings, mevProtection] = await Promise.all([
      getOrCreateSettings(ctx.user.id),
      getMeProtection(ctx.user.id),
    ]);
    return { ...settings, mevProtection };
  }),

  update: authedQuery
    .input(
      z.object({
        rpcUrl: z.string().url().max(512).nullish(),
        rpcAuto: z.boolean().optional(),
        chainId: z.number().int().positive().optional(),
        maxGasGwei: z.number().int().positive().max(10_000).optional(),
        openseaApiKey: z.string().max(128).nullish(),
        mevProtection: z.boolean().optional(),
        halted: z.boolean().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const settings = await updateSettings(ctx.user.id, {
        ...(input.rpcUrl !== undefined ? { rpcUrl: input.rpcUrl } : {}),
        ...(input.rpcAuto !== undefined ? { rpcAuto: input.rpcAuto } : {}),
        ...(input.chainId !== undefined ? { chainId: input.chainId } : {}),
        ...(input.maxGasGwei !== undefined ? { maxGasGwei: input.maxGasGwei } : {}),
        ...(input.openseaApiKey !== undefined ? { openseaApiKey: input.openseaApiKey } : {}),
        ...(input.halted !== undefined ? { halted: input.halted } : {}),
      });
      if (input.mevProtection !== undefined) {
        await setMeProtection(ctx.user.id, input.mevProtection);
      }
      if (input.halted !== undefined) {
        invalidateHaltCache(ctx.user.id);
        await logActivity({
          userId: ctx.user.id,
          level: input.halted ? "warn" : "success",
          source: "system",
          message: input.halted
            ? "EMERGENCY STOP engaged — all execution halted (snipe, copy, sweep, sells)"
            : "Emergency stop released — execution resumed",
        });
      }
      const mevProtection = await getMeProtection(ctx.user.id);
      return { ...settings, mevProtection };
    }),
});
