import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { assertPro } from "./lib/entitlements";
import { resolveOpenseaKey } from "./lib/openseaKey";
import { isSweepSupportedChain } from "./engine/opensea";
import {
  addSweepRule,
  findSweepRuleById,
  findSweepRulesByUser,
  removeSweepRule,
  updateSweepRule,
} from "./queries/sweep";
import { getFloorAsk } from "./engine/opensea";

const addressSchema = z
  .string()
  .regex(/^0x[0-9a-fA-F]{40}$/, "Must be a valid 0x address");

const ethAmountSchema = z
  .string()
  .regex(/^\d+(\.\d+)?$/, "Must be a decimal ETH amount like 0.1")
  .refine((v) => Number(v) > 0, "Must be greater than 0");

const maxRarityRankSchema = z.number().int().min(1).max(100000).nullish();

const sweepRuleInput = z.object({
  chainId: z.number().int().positive(),
  contractAddress: addressSchema,
  collectionName: z.string().max(255).optional(),
  mode: z.enum(["below", "above"]).default("below"),
  thresholdEth: ethAmountSchema,
  maxBuys: z.number().int().min(1).max(50).default(1),
  maxSpendEth: ethAmountSchema.default("1"),
  // Rarity sniping: only buy floor listings ranked ≤ this (OpenRarity).
  maxRarityRank: maxRarityRankSchema,
});

const sweepRuleUpdate = z.object({
  collectionName: z.string().max(255).nullish(),
  mode: z.enum(["below", "above"]).optional(),
  thresholdEth: ethAmountSchema.optional(),
  maxBuys: z.number().int().min(1).max(50).optional(),
  maxSpendEth: ethAmountSchema.optional(),
  maxRarityRank: maxRarityRankSchema,
});

export const sweepRouter = createRouter({
  list: authedQuery.query(({ ctx }) => findSweepRulesByUser(ctx.user.id)),

  create: authedQuery.input(sweepRuleInput).mutation(async ({ ctx, input }) => {
    return addSweepRule({
      ...input,
      collectionName: input.collectionName ?? null,
      userId: ctx.user.id,
    });
  }),

  update: authedQuery
    .input(z.object({ id: z.number().int().positive(), data: sweepRuleUpdate }))
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      const rule = await findSweepRuleById(ctx.user.id, input.id);
      if (!rule) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Sweep rule not found" });
      }
      return updateSweepRule(ctx.user.id, input.id, input.data);
    }),

  toggle: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      const rule = await findSweepRuleById(ctx.user.id, input.id);
      if (!rule) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Sweep rule not found" });
      }
      return updateSweepRule(ctx.user.id, input.id, { enabled: !rule.enabled });
    }),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      await removeSweepRule(ctx.user.id, input.id);
      return { success: true };
    }),

  /** Fresh floor check for one rule — backs the "check floor" button. */
  floorNow: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      assertPro(ctx);
      const rule = await findSweepRuleById(ctx.user.id, input.id);
      if (!rule) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Sweep rule not found" });
      }
      if (!isSweepSupportedChain(rule.chainId)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Floor sweeping isn't available on this chain (no OpenSea coverage)",
        });
      }
      // A key always resolves (user key → shared override → built-in shared).
      const { key: openseaKey } = await resolveOpenseaKey(ctx.user.id);
      const floor = await getFloorAsk(
        rule.chainId,
        rule.contractAddress,
        openseaKey,
      );
      if (!floor) return { floor: null as null };
      await updateSweepRule(ctx.user.id, rule.id, {
        lastFloorEth: floor.priceEth,
        lastCheckedAt: new Date(),
      });
      return { floor };
    }),
});
