import * as cookie from "cookie";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { Session } from "@contracts/constants";
import { ADMIN_EMAIL } from "@contracts/plans";
import { getSessionCookieOptions } from "./lib/cookies";
import { env } from "./lib/env";
import { hashPassword, verifyPassword } from "./lib/passwords";
import { loginLimiter } from "./lib/rateLimit";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import type { TrpcContext } from "./context";
import { signSessionToken } from "./kimi/session";
import { logActivity } from "./queries/activity";
import {
  findUserByUnionId,
  updateUserPassword,
  upsertUser,
} from "./queries/users";
import { ensureManagedWallet } from "./engine/managedWallet";

/**
 * Email + password credential auth (the platform-supported alternative to
 * Google OAuth). Credential users are stored with unionId = "cred:<email>";
 * OAuth users never have a passwordHash.
 */

const INVALID_CREDENTIALS = new TRPCError({
  code: "UNAUTHORIZED",
  message: "Invalid email or password",
});

/** Issue the session cookie exactly like the OAuth callback does. */
async function issueSession(ctx: TrpcContext, unionId: string) {
  const token = await signSessionToken({ unionId, clientId: env.appId });
  const opts = getSessionCookieOptions(ctx.req.headers);
  ctx.resHeaders.append(
    "set-cookie",
    cookie.serialize(Session.cookieName, token, {
      httpOnly: opts.httpOnly,
      path: opts.path,
      sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
      secure: opts.secure,
      maxAge: Session.maxAgeMs / 1000,
    }),
  );
}

/** Provision the auto vault without ever breaking auth. */
async function provisionVault(userId: number) {
  try {
    await ensureManagedWallet(userId);
  } catch (err) {
    console.error("[creds] managed wallet provisioning failed:", err);
  }
}

const emailSchema = z.string().trim().toLowerCase().email().max(320);

/**
 * The admin account (ADMIN_EMAIL) always has full access: force plan='pro'
 * with no expiry on register, and self-heal the row on every login.
 */
function adminPlanFields(email: string) {
  return email === ADMIN_EMAIL
    ? { plan: "pro" as const, planExpiresAt: null as Date | null }
    : {};
}

export const credsRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        email: emailSchema,
        password: z.string().min(8).max(128),
        name: z.string().trim().min(1).max(255).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const unionId = `cred:${input.email}`;
      const existing = await findUserByUnionId(unionId);
      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Email already registered",
        });
      }

      await upsertUser({
        unionId,
        name: input.name ?? input.email.split("@")[0],
        email: input.email,
        passwordHash: hashPassword(input.password),
        lastSignInAt: new Date(),
        ...adminPlanFields(input.email),
      });

      const user = await findUserByUnionId(unionId);
      if (user) await provisionVault(user.id);

      await issueSession(ctx, unionId);
      return { success: true };
    }),

  login: publicQuery
    .input(
      z.object({
        email: emailSchema,
        password: z.string().min(1).max(128),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // Sliding-window lockout: 5 failed attempts → 15-minute pause, keyed by
      // the (schema-normalized) lowercase email.
      const rateKey = input.email;
      const gate = loginLimiter.check(rateKey);
      if (!gate.allowed) {
        const minutes = Math.max(1, Math.ceil(gate.retryAfterMs / 60_000));
        throw new TRPCError({
          code: "TOO_MANY_REQUESTS",
          message: `Too many failed attempts — try again in ${minutes} minutes`,
        });
      }

      const unionId = `cred:${input.email}`;
      const user = await findUserByUnionId(unionId);
      // Generic error — never reveal whether the email exists.
      if (!user || !user.passwordHash || !verifyPassword(input.password, user.passwordHash)) {
        loginLimiter.recordFailure(rateKey);
        throw INVALID_CREDENTIALS;
      }
      loginLimiter.recordSuccess(rateKey);

      await upsertUser({
        unionId,
        lastSignInAt: new Date(),
        ...adminPlanFields(input.email),
      });
      await provisionVault(user.id);

      await issueSession(ctx, unionId);
      return { success: true };
    }),

  /**
   * Self-serve password change (credential accounts only — OAuth-only
   * accounts have no password and get a friendly error).
   */
  changePassword: authedQuery
    .input(
      z.object({
        currentPassword: z.string().min(1).max(128),
        newPassword: z.string().min(8).max(128),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.user;
      if (!user.unionId.startsWith("cred:") || !user.passwordHash) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message:
            "This account signs in with Google OAuth — there is no password to change.",
        });
      }
      if (!verifyPassword(input.currentPassword, user.passwordHash)) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Current password is incorrect",
        });
      }
      await updateUserPassword(user.id, hashPassword(input.newPassword));
      await logActivity({
        userId: user.id,
        level: "info",
        source: "system",
        message: "Password changed from Settings",
      });
      return { success: true };
    }),
});
