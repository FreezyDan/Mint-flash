import { and, desc, eq } from "drizzle-orm";
import { botWallets, type InsertBotWallet } from "@db/schema";
import { getDb } from "./connection";

export async function findBotWalletsByUser(userId: number) {
  return getDb()
    .select()
    .from(botWallets)
    .where(eq(botWallets.userId, userId))
    .orderBy(desc(botWallets.createdAt));
}

export async function findManagedBotWallet(userId: number) {
  const rows = await getDb()
    .select()
    .from(botWallets)
    .where(and(eq(botWallets.userId, userId), eq(botWallets.managed, true)))
    .limit(1);
  return rows.at(0);
}

export async function addBotWallet(data: InsertBotWallet) {
  const [{ id }] = await getDb().insert(botWallets).values(data).$returningId();
  const rows = await getDb()
    .select()
    .from(botWallets)
    .where(eq(botWallets.id, id))
    .limit(1);
  return rows.at(0);
}

export async function removeBotWallet(userId: number, walletId: number) {
  await getDb()
    .delete(botWallets)
    .where(and(eq(botWallets.id, walletId), eq(botWallets.userId, userId)));
}
