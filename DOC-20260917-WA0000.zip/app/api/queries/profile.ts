import { eq } from "drizzle-orm";
import { walletProfiles } from "@db/schema";
import type { WalletProfile } from "@contracts/profile";
import { getDb } from "./connection";

/** Cached all-time profile row for a wallet (address stored lowercased). */
export async function findWalletProfile(address: string) {
  const rows = await getDb()
    .select()
    .from(walletProfiles)
    .where(eq(walletProfiles.walletAddress, address.toLowerCase()))
    .limit(1);
  const row = rows.at(0);
  if (!row) return null;
  return { ...row, payload: row.payload as WalletProfile };
}

/** Insert or replace the cached profile payload, stamped at now. */
export async function upsertWalletProfile(
  address: string,
  payload: WalletProfile,
): Promise<void> {
  const walletAddress = address.toLowerCase();
  await getDb()
    .insert(walletProfiles)
    .values({ walletAddress, payload })
    .onDuplicateKeyUpdate({ set: { payload, fetchedAt: new Date() } });
}
