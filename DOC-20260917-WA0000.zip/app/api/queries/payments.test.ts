import { describe, expect, it } from "vitest";
import {
  isPaymentChain,
  isValidEvmAddress,
  isValidTxHash,
  PAYMENT_CHAIN_IDS,
  PRO_PAYMENT_ADDRESS,
} from "@contracts/plans";

describe("pay-to-address validation", () => {
  it("accepts the built-in PRO payment address", () => {
    expect(isValidEvmAddress(PRO_PAYMENT_ADDRESS)).toBe(true);
  });

  it("rejects malformed addresses", () => {
    expect(isValidEvmAddress("")).toBe(false);
    expect(isValidEvmAddress("0x300ef926e05a9891e9e3f575e6ba43d55c9a97")).toBe(false); // 38 hex
    expect(isValidEvmAddress("300ef926e05a9891e9e3f575e6ba43d55c9a975e")).toBe(false); // no 0x
    expect(isValidEvmAddress("0xZZZef926e05a9891e9e3f575e6ba43d55c9a975e")).toBe(false);
  });

  it("validates tx hashes as 0x + 64 hex chars", () => {
    expect(isValidTxHash(`0x${"ab".repeat(32)}`)).toBe(true);
    expect(isValidTxHash(`0x${"AB".repeat(32)}`)).toBe(true);
    expect(isValidTxHash(`0x${"ab".repeat(31)}`)).toBe(false); // too short
    expect(isValidTxHash(`${"ab".repeat(32)}`)).toBe(false); // no 0x
    // an address is not a tx hash
    expect(isValidTxHash(PRO_PAYMENT_ADDRESS)).toBe(false);
  });

  it("supports exactly the six EVM payment chains", () => {
    expect([...PAYMENT_CHAIN_IDS]).toEqual([1, 8453, 42161, 137, 4663, 57073, 5042]);
    for (const id of PAYMENT_CHAIN_IDS) expect(isPaymentChain(id)).toBe(true);
    expect(isPaymentChain(56)).toBe(false); // BSC not supported
    expect(isPaymentChain(0)).toBe(false);
  });
});
