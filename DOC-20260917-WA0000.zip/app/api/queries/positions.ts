import { and, desc, eq } from "drizzle-orm";
import {
  botPositions,
  type BotPosition,
  type InsertBotPosition,
} from "@db/schema";
import { getDb } from "./connection";

/**
 * bot_positions persistence — one row per bot-acquired NFT (snipe mint,
 * mirrored copy buy, swept floor). The sell engine manages exits; routers
 * serve and mutate the user's own rows.
 */

/** Normalise an ETH amount to the entryEth column's DECIMAL(20,10) scale. */
export function entryEth10(v: string | number): string {
  const n = Number(v);
  return Number.isFinite(n) ? n.toFixed(10) : "0.0000000000";
}

export async function insertPosition(data: InsertBotPosition) {
  const [{ id }] = await getDb()
    .insert(botPositions)
    .values(data)
    .$returningId();
  const rows = await getDb()
    .select()
    .from(botPositions)
    .where(eq(botPositions.id, id))
    .limit(1);
  return rows.at(0);
}

/** Owner-checked fetch. */
export async function findPositionById(userId: number, id: number) {
  const rows = await getDb()
    .select()
    .from(botPositions)
    .where(and(eq(botPositions.id, id), eq(botPositions.userId, userId)))
    .limit(1);
  return rows.at(0);
}

export async function findPositionsByUser(userId: number): Promise<BotPosition[]> {
  return getDb()
    .select()
    .from(botPositions)
    .where(eq(botPositions.userId, userId))
    .orderBy(desc(botPositions.openedAt));
}

export async function updatePosition(
  userId: number,
  id: number,
  data: Partial<InsertBotPosition>,
) {
  await getDb()
    .update(botPositions)
    .set(data)
    .where(and(eq(botPositions.id, id), eq(botPositions.userId, userId)));
  return findPositionById(userId, id);
}

/** Open positions across all users — drives the sell engine's exit loop. */
export async function findOpenPositions(): Promise<BotPosition[]> {
  return getDb()
    .select()
    .from(botPositions)
    .where(eq(botPositions.status, "open"))
    .orderBy(desc(botPositions.openedAt));
}

/** Open copy-sourced positions in one collection — mirror-sell matching. */
export async function findOpenCopyPositions(
  userId: number,
  chainId: number,
  contractAddress: string,
): Promise<BotPosition[]> {
  return getDb()
    .select()
    .from(botPositions)
    .where(
      and(
        eq(botPositions.userId, userId),
        eq(botPositions.status, "open"),
        eq(botPositions.source, "copy"),
        eq(botPositions.chainId, chainId),
        eq(botPositions.contractAddress, contractAddress),
      ),
    );
}

/** Open positions in a set of collections — batch mirror-sell matching. */
export async function findOpenCopyPositionsIn(
  userId: number,
  keys: { chainId: number; contractAddress: string }[],
): Promise<BotPosition[]> {
  if (keys.length === 0) return [];
  // Small key sets per sale event — loop keeps the query plan simple.
  const out: BotPosition[] = [];
  for (const k of keys) {
    out.push(...(await findOpenCopyPositions(userId, k.chainId, k.contractAddress)));
  }
  return out;
}

/** Distinct user ids that currently hold open positions. */
export async function findUsersWithOpenPositions(): Promise<number[]> {
  const rows = await getDb()
    .selectDistinct({ userId: botPositions.userId })
    .from(botPositions)
    .where(eq(botPositions.status, "open"));
  return rows.map((r) => r.userId);
}

/** Open positions for one user (engine-side, no owner check needed). */
export async function findOpenPositionsByUser(
  userId: number,
): Promise<BotPosition[]> {
  return getDb()
    .select()
    .from(botPositions)
    .where(and(eq(botPositions.userId, userId), eq(botPositions.status, "open")));
}

// Re-export for consumers that need the enum-ish union.
export const POSITION_SOURCES = ["snipe", "copy", "sweep"] as const;
export type PositionSource = (typeof POSITION_SOURCES)[number];
