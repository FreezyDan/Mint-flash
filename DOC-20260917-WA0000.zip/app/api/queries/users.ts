import { asc, eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertUser } from "@db/schema";
import { getDb } from "./connection";
import { env } from "../lib/env";

export async function findUserByUnionId(unionId: string) {
  const rows = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.unionId, unionId))
    .limit(1);
  return rows.at(0);
}

export async function upsertUser(data: InsertUser) {
  const values = { ...data };
  const updateSet: Partial<InsertUser> = {
    lastSignInAt: new Date(),
    ...data,
  };

  if (
    values.role === undefined &&
    values.unionId &&
    values.unionId === env.ownerUnionId
  ) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  await getDb()
    .insert(schema.users)
    .values(values)
    .onDuplicateKeyUpdate({ set: updateSet });
}

export async function findUserById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.id, id))
    .limit(1);
  return rows.at(0);
}

/** All users, oldest first — admin console. */
export async function listUsers() {
  return getDb().select().from(schema.users).orderBy(asc(schema.users.id));
}

/** Set a new password hash (change/reset flows). Never returns the hash. */
export async function updateUserPassword(userId: number, passwordHash: string) {
  await getDb()
    .update(schema.users)
    .set({ passwordHash })
    .where(eq(schema.users.id, userId));
}

/** Admin plan grant/revoke. planExpiresAt null = no expiry. */
export async function setUserPlan(
  userId: number,
  plan: "free" | "pro",
  planExpiresAt: Date | null,
) {
  await getDb()
    .update(schema.users)
    .set({ plan, planExpiresAt })
    .where(eq(schema.users.id, userId));
  const rows = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.id, userId))
    .limit(1);
  return rows.at(0);
}
