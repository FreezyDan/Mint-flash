import { and, desc, eq } from "drizzle-orm";
import {
  sweepRules,
  type InsertSweepRule,
  type SweepRule,
} from "@db/schema";
import { getDb } from "./connection";

export async function findSweepRulesByUser(userId: number) {
  return getDb()
    .select()
    .from(sweepRules)
    .where(eq(sweepRules.userId, userId))
    .orderBy(desc(sweepRules.createdAt));
}

export async function findSweepRuleById(userId: number, id: number) {
  const rows = await getDb()
    .select()
    .from(sweepRules)
    .where(and(eq(sweepRules.id, id), eq(sweepRules.userId, userId)))
    .limit(1);
  return rows.at(0);
}

export async function addSweepRule(data: InsertSweepRule) {
  const [{ id }] = await getDb().insert(sweepRules).values(data).$returningId();
  const rows = await getDb()
    .select()
    .from(sweepRules)
    .where(eq(sweepRules.id, id))
    .limit(1);
  return rows.at(0);
}

export async function updateSweepRule(
  userId: number,
  id: number,
  data: Partial<InsertSweepRule>,
) {
  await getDb()
    .update(sweepRules)
    .set(data)
    .where(and(eq(sweepRules.id, id), eq(sweepRules.userId, userId)));
  return findSweepRuleById(userId, id);
}

export async function removeSweepRule(userId: number, id: number) {
  await getDb()
    .delete(sweepRules)
    .where(and(eq(sweepRules.id, id), eq(sweepRules.userId, userId)));
}

/** Enabled sweep rules across all users — used by the floor-sweeper engine. */
export async function findEnabledSweepRules(): Promise<SweepRule[]> {
  return getDb().select().from(sweepRules).where(eq(sweepRules.enabled, true));
}
