import { and, asc, desc, eq } from "drizzle-orm";
import { paymentClaims, users } from "@db/schema";
import { getDb } from "./connection";

/**
 * PRO pay-to-address payment claims. A user sends the PRO price in native
 * token to the payment address on a supported EVM chain, submits the tx hash,
 * and the admin reviews the claim (approve → grant PRO, reject → note why).
 */

export async function insertClaim(input: {
  userId: number;
  chainId: number;
  txHash: string;
}) {
  await getDb().insert(paymentClaims).values({
    userId: input.userId,
    chainId: input.chainId,
    txHash: input.txHash,
    status: "pending",
  });
  const rows = await getDb()
    .select()
    .from(paymentClaims)
    .where(
      and(
        eq(paymentClaims.userId, input.userId),
        eq(paymentClaims.txHash, input.txHash),
      ),
    )
    .orderBy(desc(paymentClaims.id))
    .limit(1);
  return rows.at(0);
}

/** A user may only have one pending claim per tx hash (dedupe guard). */
export async function findPendingClaim(userId: number, txHash: string) {
  const rows = await getDb()
    .select()
    .from(paymentClaims)
    .where(
      and(
        eq(paymentClaims.userId, userId),
        eq(paymentClaims.txHash, txHash),
        eq(paymentClaims.status, "pending"),
      ),
    )
    .limit(1);
  return rows.at(0);
}

/** The user's own claims, newest first — Upgrade page history. */
export async function listClaimsByUser(userId: number) {
  return getDb()
    .select()
    .from(paymentClaims)
    .where(eq(paymentClaims.userId, userId))
    .orderBy(desc(paymentClaims.createdAt));
}

/** Pending claims with the claimant's email — admin review queue. */
export async function listPendingClaims() {
  const rows = await getDb()
    .select({
      id: paymentClaims.id,
      userId: paymentClaims.userId,
      chainId: paymentClaims.chainId,
      txHash: paymentClaims.txHash,
      status: paymentClaims.status,
      createdAt: paymentClaims.createdAt,
      userEmail: users.email,
      userName: users.name,
    })
    .from(paymentClaims)
    .leftJoin(users, eq(paymentClaims.userId, users.id))
    .where(eq(paymentClaims.status, "pending"))
    .orderBy(asc(paymentClaims.createdAt));
  return rows;
}

export async function findClaimById(claimId: number) {
  const rows = await getDb()
    .select()
    .from(paymentClaims)
    .where(eq(paymentClaims.id, claimId))
    .limit(1);
  return rows.at(0);
}

/** Admin decision: sets status + reviewedAt (+ optional note). */
export async function reviewClaim(input: {
  claimId: number;
  approve: boolean;
  note?: string | null;
}) {
  await getDb()
    .update(paymentClaims)
    .set({
      status: input.approve ? "approved" : "rejected",
      adminNote: input.note ?? null,
      reviewedAt: new Date(),
    })
    .where(eq(paymentClaims.id, input.claimId));
  return findClaimById(input.claimId);
}
