import { and, desc, eq, gt, inArray, max, sql, count, getTableColumns } from "drizzle-orm";
import { int, mysqlTable, varchar } from "drizzle-orm/mysql-core";
import {
  discoveredFlips,
  discoveredTraders,
  type InsertDiscoveredFlip,
  type InsertDiscoveredTrader,
} from "@db/schema";
import { parseLabels } from "../engine/walletLabels";
import { getDb } from "./connection";

const INSERT_BATCH = 100;
const LABEL_UPDATE_BATCH = 500;

/**
 * Shadow of discovered_traders carrying only the `labels` column. The column
 * is created by the ensureSchema migration and may lag in the ORM table def
 * (db/schema.ts), so labels are read/written through this minimal table —
 * Drizzle only touches the columns referenced here. Once the ORM schema
 * declares `labels`, this shadow can be dropped with no behavior change.
 */
const discoveredTraderLabels = mysqlTable("discovered_traders", {
  chainId: int("chainId"),
  address: varchar("address", { length: 42 }),
  labels: varchar("labels", { length: 256 }),
});

/** A scan batch row: the ORM insert shape plus the behavior-label JSON. */
export type DiscoveredTraderRow = InsertDiscoveredTrader & {
  labels?: string | null;
};

/**
 * Replace all discovered-trader rows for a chain with a fresh scan batch.
 * Sequential delete + chunked inserts (the mysql2/planetscale-mode pool does
 * not reliably support multi-statement transactions, so this is deliberately
 * not wrapped in a Drizzle transaction).
 *
 * Behavior labels ride along on each row and are written afterwards with one
 * grouped UPDATE per distinct labels value (most wallets share the same set,
 * typically null), keyed by (chainId, address).
 */
export async function replaceDiscoveredTraders(
  chainId: number,
  rows: DiscoveredTraderRow[],
): Promise<void> {
  const db = getDb();
  await db.delete(discoveredTraders).where(eq(discoveredTraders.chainId, chainId));
  for (let i = 0; i < rows.length; i += INSERT_BATCH) {
    await db.insert(discoveredTraders).values(rows.slice(i, i + INSERT_BATCH));
  }

  const addressesByLabels = new Map<string | null, string[]>();
  for (const row of rows) {
    const key = row.labels ?? null;
    const list = addressesByLabels.get(key);
    if (list) list.push(row.address);
    else addressesByLabels.set(key, [row.address]);
  }
  for (const [labels, addresses] of addressesByLabels) {
    for (let i = 0; i < addresses.length; i += LABEL_UPDATE_BATCH) {
      await db
        .update(discoveredTraderLabels)
        .set({ labels })
        .where(
          and(
            eq(discoveredTraderLabels.chainId, chainId),
            inArray(discoveredTraderLabels.address, addresses.slice(i, i + LABEL_UPDATE_BATCH)),
          ),
        );
    }
  }
}

/** Replace per-flip detail rows for a chain alongside the trader snapshot. */
export async function replaceDiscoveredFlips(
  chainId: number,
  rows: InsertDiscoveredFlip[],
): Promise<void> {
  const db = getDb();
  await db.delete(discoveredFlips).where(eq(discoveredFlips.chainId, chainId));
  for (let i = 0; i < rows.length; i += INSERT_BATCH) {
    await db.insert(discoveredFlips).values(rows.slice(i, i + INSERT_BATCH));
  }
}

export type DiscoverListOpts = {
  /** 'mint' ranks by mint PnL (wallets with mint flips only); 'all' by realized PnL. */
  mode: "all" | "mint";
  minPnlEth?: string;
  minRoiPct?: number;
};

/** Ranked trader rows for a chain. sql`` fragments are used only for
 *  DECIMAL casts in ORDER BY / numeric comparisons — everything else is the
 *  Drizzle query API. */
export async function listDiscoveredTraders(
  chainId: number,
  limit: number,
  opts: DiscoverListOpts = { mode: "all" },
) {
  const pnlCol = opts.mode === "mint" ? discoveredTraders.mintPnlEth : discoveredTraders.realizedPnlEth;

  const conditions = [eq(discoveredTraders.chainId, chainId)];
  if (opts.mode === "mint") conditions.push(gt(discoveredTraders.mintFlips, 0));
  if (opts.minPnlEth !== undefined) {
    conditions.push(sql`CAST(${pnlCol} AS DECIMAL(38,18)) >= CAST(${opts.minPnlEth} AS DECIMAL(38,18))`);
  }
  if (opts.minRoiPct !== undefined) {
    // NULL roiPct = free-mint-derived — passes any ROI filter.
    conditions.push(
      sql`(${discoveredTraders.roiPct} IS NULL OR CAST(${discoveredTraders.roiPct} AS DECIMAL(18,2)) >= ${opts.minRoiPct})`,
    );
  }

  const orderBy =
    opts.mode === "mint"
      ? [
          sql`CAST(${discoveredTraders.mintPnlEth} AS DECIMAL(38,18)) DESC`,
          sql`CAST(${discoveredTraders.spendEth} AS DECIMAL(38,18)) + CAST(${discoveredTraders.proceedsEth} AS DECIMAL(38,18)) DESC`,
          desc(discoveredTraders.trades),
        ]
      : [
          sql`CAST(${discoveredTraders.realizedPnlEth} AS DECIMAL(38,18)) DESC`,
          sql`CAST(${discoveredTraders.spendEth} AS DECIMAL(38,18)) + CAST(${discoveredTraders.proceedsEth} AS DECIMAL(38,18)) DESC`,
          desc(discoveredTraders.trades),
        ];

  // Labels are selected through the shadow table and parsed from their JSON
  // array string into string[] (tolerant of null/garbage → []).
  const rows = await getDb()
    .select({ ...getTableColumns(discoveredTraders), labels: discoveredTraderLabels.labels })
    .from(discoveredTraders)
    .where(and(...conditions))
    .orderBy(...orderBy)
    .limit(limit);
  return rows.map((row) => ({ ...row, labels: parseLabels(row.labels) }));
}

/** Per-flip P&L detail rows for one wallet: open positions first (best
 *  unrealized PnL first, unmarked nulls last — MySQL sorts NULL lowest so
 *  DESC puts them last), then closed flips by realized PnL desc. */
export async function listDiscoveredFlips(chainId: number, address: string, limit: number) {
  return getDb()
    .select()
    .from(discoveredFlips)
    .where(and(eq(discoveredFlips.chainId, chainId), eq(discoveredFlips.address, address)))
    .orderBy(
      sql`CASE WHEN ${discoveredFlips.status} = 'open' THEN 0 ELSE 1 END`,
      sql`CASE WHEN ${discoveredFlips.status} = 'open' THEN ${discoveredFlips.unrealizedPnlEth} END DESC`,
      sql`CASE WHEN ${discoveredFlips.status} = 'closed' THEN CAST(${discoveredFlips.pnlEth} AS DECIMAL(38,18)) END DESC`,
    )
    .limit(limit);
}

/** Latest scan timestamp for a chain (null when never scanned). */
export async function lastScanForChain(chainId: number): Promise<Date | null> {
  const rows = await getDb()
    .select({ last: max(discoveredTraders.scannedAt) })
    .from(discoveredTraders)
    .where(eq(discoveredTraders.chainId, chainId));
  return rows.at(0)?.last ?? null;
}

/** Most recent stored row for a chain (for cached scan summaries). */
export async function latestDiscoveredTraderRow(chainId: number) {
  const rows = await getDb()
    .select()
    .from(discoveredTraders)
    .where(eq(discoveredTraders.chainId, chainId))
    .orderBy(desc(discoveredTraders.scannedAt))
    .limit(1);
  return rows.at(0);
}

export async function countDiscoveredTraders(chainId: number): Promise<number> {
  const rows = await getDb()
    .select({ n: count() })
    .from(discoveredTraders)
    .where(eq(discoveredTraders.chainId, chainId));
  return Number(rows.at(0)?.n ?? 0);
}

/** Row counts + last scan per chain, grouped. */
export async function discoveredChainStats() {
  return getDb()
    .select({
      chainId: discoveredTraders.chainId,
      traders: count(),
      lastScannedAt: max(discoveredTraders.scannedAt),
    })
    .from(discoveredTraders)
    .groupBy(discoveredTraders.chainId);
}

/**
 * Top traders across ALL chains, ranked by total PnL (realized + unrealized,
 * NULL unrealized counts as 0). Backs the public leaderboard — this is
 * on-chain scan output (public blockchain data), no user fields.
 */
export async function topTradersByTotalPnl(limit: number) {
  return getDb()
    .select({
      address: discoveredTraders.address,
      chainId: discoveredTraders.chainId,
      realizedPnlEth: discoveredTraders.realizedPnlEth,
      unrealizedPnlEth: discoveredTraders.unrealizedPnlEth,
      winRatePct: discoveredTraders.winRatePct,
      flips: discoveredTraders.flips,
      openPositions: discoveredTraders.openPositions,
      scannedAt: discoveredTraders.scannedAt,
    })
    .from(discoveredTraders)
    .orderBy(
      sql`CAST(${discoveredTraders.realizedPnlEth} AS DECIMAL(38,18)) + COALESCE(${discoveredTraders.unrealizedPnlEth}, 0) DESC`,
    )
    .limit(limit);
}

/** Site-wide scan coverage: total trader rows, chains covered, last scan. */
export async function scanCoverage() {
  const stats = await discoveredChainStats();
  return {
    tradersScanned: stats.reduce((sum, s) => sum + Number(s.traders), 0),
    chainsScanned: stats.filter((s) => Number(s.traders) > 0).length,
    lastScannedAt:
      stats
        .map((s) => s.lastScannedAt)
        .filter((d): d is Date => d !== null)
        .sort((a, b) => b.getTime() - a.getTime())
        .at(0) ?? null,
  };
}
