import { eq } from "drizzle-orm";
import { siteSettings } from "@db/schema";
import { getDb } from "./connection";

/** Site-wide admin-managed settings (site_settings table). */

export async function getSetting(key: string): Promise<string | null> {
  const rows = await getDb()
    .select()
    .from(siteSettings)
    .where(eq(siteSettings.key, key))
    .limit(1);
  return rows.at(0)?.value ?? null;
}

export async function setSetting(key: string, value: string | null) {
  await getDb()
    .insert(siteSettings)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value } });
}
