import { eq } from "drizzle-orm";
import type mysql from "mysql2/promise";
import {
  userSettings,
  type InsertUserSettings,
  type UserSettings,
} from "@db/schema";
import { getDb } from "./connection";

export async function findSettingsByUser(userId: number) {
  const rows = await getDb()
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);
  return rows.at(0);
}

/** Lazily create a default settings row on first access. */
export async function getOrCreateSettings(
  userId: number,
): Promise<UserSettings> {
  const existing = await findSettingsByUser(userId);
  if (existing) return existing;
  await getDb()
    .insert(userSettings)
    .values({ userId })
    .onDuplicateKeyUpdate({ set: { userId } });
  const created = await findSettingsByUser(userId);
  if (!created) throw new Error("Failed to create user settings");
  return created;
}

export async function updateSettings(
  userId: number,
  data: Partial<InsertUserSettings>,
) {
  await getOrCreateSettings(userId);
  await getDb()
    .update(userSettings)
    .set(data)
    .where(eq(userSettings.userId, userId));
  return findSettingsByUser(userId);
}

// ---------------------------------------------------------------------------
// mevProtection — the column is applied by ensureSchema (boolean NOT NULL
// DEFAULT true) but intentionally lives outside the Drizzle table definition,
// so the Drizzle select/update helpers can't see it. Raw SQL keeps the flag
// fully functional.
// ---------------------------------------------------------------------------

/** MEV-protection flag for a user; defaults to true (schema default). */
export async function getMeProtection(userId: number): Promise<boolean> {
  await getOrCreateSettings(userId);
  const [rows] = await getDb().$client.promise().query<mysql.RowDataPacket[]>(
    "SELECT `mevProtection` AS mp FROM `user_settings` WHERE `userId` = ? LIMIT 1",
    [userId],
  );
  const value = rows.at(0)?.mp;
  if (value === undefined || value === null) return true;
  return value === true || value === 1 || value === "1";
}

export async function setMeProtection(userId: number, enabled: boolean): Promise<void> {
  await getOrCreateSettings(userId);
  await getDb().$client.promise().query(
    "UPDATE `user_settings` SET `mevProtection` = ? WHERE `userId` = ?",
    [enabled, userId],
  );
}
