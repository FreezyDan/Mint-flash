import { and, count, desc, eq, inArray } from "drizzle-orm";
import { activityLogs, mintTasks, type InsertMintTask, type MintTask } from "@db/schema";
import { getDb } from "./connection";

/** Statuses that count as a "pending snipe order" for the free-plan cap. */
export const PENDING_TASK_STATUSES = ["draft", "armed"] as const;

export async function findTasksByUser(userId: number): Promise<MintTask[]> {
  return getDb()
    .select()
    .from(mintTasks)
    .where(eq(mintTasks.userId, userId))
    .orderBy(desc(mintTasks.createdAt));
}

export async function findTaskById(userId: number, taskId: number) {
  const rows = await getDb()
    .select()
    .from(mintTasks)
    .where(and(eq(mintTasks.id, taskId), eq(mintTasks.userId, userId)))
    .limit(1);
  return rows.at(0);
}

export async function createTask(data: InsertMintTask) {
  const [{ id }] = await getDb().insert(mintTasks).values(data).$returningId();
  const rows = await getDb()
    .select()
    .from(mintTasks)
    .where(eq(mintTasks.id, id))
    .limit(1);
  return rows.at(0);
}

export async function updateTask(
  userId: number,
  taskId: number,
  data: Partial<InsertMintTask>,
) {
  await getDb()
    .update(mintTasks)
    .set(data)
    .where(and(eq(mintTasks.id, taskId), eq(mintTasks.userId, userId)));
  return findTaskById(userId, taskId);
}

export async function deleteTask(userId: number, taskId: number) {
  // FK: activity_logs.taskId → mint_tasks.id (ON DELETE NO ACTION) — remove
  // the task's activity log rows first (same owner scope), then the task.
  await getDb()
    .delete(activityLogs)
    .where(and(eq(activityLogs.taskId, taskId), eq(activityLogs.userId, userId)));
  await getDb()
    .delete(mintTasks)
    .where(and(eq(mintTasks.id, taskId), eq(mintTasks.userId, userId)));
}

/** Number of pending snipe orders (draft + armed) a user currently holds. */
export async function countPendingTasks(userId: number): Promise<number> {
  const rows = await getDb()
    .select({ c: count() })
    .from(mintTasks)
    .where(
      and(
        eq(mintTasks.userId, userId),
        inArray(mintTasks.status, [...PENDING_TASK_STATUSES]),
      ),
    );
  return Number(rows.at(0)?.c ?? 0);
}

/** Armed tasks across all users — used by the engine manager on server boot. */
export async function findArmedTasks(): Promise<MintTask[]> {
  return getDb()
    .select()
    .from(mintTasks)
    .where(eq(mintTasks.status, "armed"));
}
