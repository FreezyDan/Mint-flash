import { and, desc, eq, gte } from "drizzle-orm";
import { activityLogs } from "@db/schema";
import { getDb } from "./connection";

// Note: ActivityLevel / ActivitySource types come from contracts; re-declared
// structurally here via string unions to avoid a db -> contracts dependency.
type Level = "info" | "warn" | "error" | "success";
type Source = "mint" | "copy" | "sweep" | "system" | "admin";

export async function findActivityByUser(
  userId: number,
  opts: { limit?: number; source?: Source } = {},
) {
  const { limit = 200, source } = opts;
  const where = source
    ? and(eq(activityLogs.userId, userId), eq(activityLogs.source, source))
    : eq(activityLogs.userId, userId);
  return getDb()
    .select()
    .from(activityLogs)
    .where(where)
    .orderBy(desc(activityLogs.createdAt))
    .limit(limit);
}

export async function findActivitySince(userId: number, since: Date) {
  return getDb()
    .select()
    .from(activityLogs)
    .where(
      and(eq(activityLogs.userId, userId), gte(activityLogs.createdAt, since)),
    )
    .orderBy(desc(activityLogs.createdAt));
}

export async function logActivity(entry: {
  userId: number;
  taskId?: number | null;
  level?: Level;
  source: Source;
  message: string;
  meta?: unknown;
}) {
  try {
    await getDb()
      .insert(activityLogs)
      .values({
        userId: entry.userId,
        taskId: entry.taskId ?? null,
        level: entry.level ?? "info",
        source: entry.source,
        message: entry.message,
        meta: entry.meta === undefined ? null : entry.meta,
      });
  } catch (err) {
    // Logging must never take down an engine or the server.
    console.error("[activity] failed to write log:", err);
  }
}
