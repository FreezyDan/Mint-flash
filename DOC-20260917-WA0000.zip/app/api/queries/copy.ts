import { and, desc, eq, gte } from "drizzle-orm";
import {
  signals,
  watchedWallets,
  type InsertSignal,
  type InsertWatchedWallet,
  type WatchedWallet,
} from "@db/schema";
import { getDb } from "./connection";

// ---------- watched wallets ----------

export async function findWatchedWalletsByUser(userId: number) {
  return getDb()
    .select()
    .from(watchedWallets)
    .where(eq(watchedWallets.userId, userId))
    .orderBy(desc(watchedWallets.createdAt));
}

export async function findWatchedWalletById(userId: number, id: number) {
  const rows = await getDb()
    .select()
    .from(watchedWallets)
    .where(and(eq(watchedWallets.id, id), eq(watchedWallets.userId, userId)))
    .limit(1);
  return rows.at(0);
}

export async function addWatchedWallet(data: InsertWatchedWallet) {
  const [{ id }] = await getDb()
    .insert(watchedWallets)
    .values(data)
    .$returningId();
  const rows = await getDb()
    .select()
    .from(watchedWallets)
    .where(eq(watchedWallets.id, id))
    .limit(1);
  return rows.at(0);
}

export async function updateWatchedWallet(
  userId: number,
  id: number,
  data: Partial<InsertWatchedWallet>,
) {
  await getDb()
    .update(watchedWallets)
    .set(data)
    .where(and(eq(watchedWallets.id, id), eq(watchedWallets.userId, userId)));
  return findWatchedWalletById(userId, id);
}

export async function removeWatchedWallet(userId: number, id: number) {
  // FK: signals.watchedWalletId → watched_wallets.id (ON DELETE NO ACTION) —
  // delete this wallet's signals first (same owner scope), then the wallet.
  await getDb()
    .delete(signals)
    .where(and(eq(signals.watchedWalletId, id), eq(signals.userId, userId)));
  await getDb()
    .delete(watchedWallets)
    .where(
      and(eq(watchedWallets.id, id), eq(watchedWallets.userId, userId)),
    );
}

/** Enabled watched wallets across all users — used by the copy trader. */
export async function findEnabledWatchedWallets(): Promise<WatchedWallet[]> {
  return getDb()
    .select()
    .from(watchedWallets)
    .where(eq(watchedWallets.enabled, true));
}

// ---------- signals ----------

export async function findSignalsByUser(userId: number, limit = 100) {
  return getDb()
    .select()
    .from(signals)
    .where(eq(signals.userId, userId))
    .orderBy(desc(signals.createdAt))
    .limit(limit);
}

export async function findSignalsSince(userId: number, since: Date) {
  return getDb()
    .select()
    .from(signals)
    .where(and(eq(signals.userId, userId), gte(signals.createdAt, since)))
    .orderBy(desc(signals.createdAt));
}

export async function insertSignal(data: InsertSignal) {
  const [{ id }] = await getDb().insert(signals).values(data).$returningId();
  const rows = await getDb()
    .select()
    .from(signals)
    .where(eq(signals.id, id))
    .limit(1);
  return rows.at(0);
}

/**
 * Latest engine detections across all users, stripped of user/wallet-ownership
 * fields. Drives the public live-feed visuals — on-chain detections only.
 */
export async function latestPublicSignals(limit = 15) {
  return getDb()
    .select({
      id: signals.id,
      type: signals.type,
      contractAddress: signals.contractAddress,
      tokenId: signals.tokenId,
      collectionName: signals.collectionName,
      priceEth: signals.priceEth,
      txHash: signals.txHash,
      status: signals.status,
      detectedAt: signals.createdAt,
    })
    .from(signals)
    .orderBy(desc(signals.createdAt))
    .limit(limit);
}
