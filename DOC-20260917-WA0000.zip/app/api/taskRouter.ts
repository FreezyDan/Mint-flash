import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { ethers } from "ethers";
import { MintPhases, TriggerModes } from "@contracts/bot";
import { createRouter, authedQuery } from "./middleware";
import { engineManager } from "./engine/engineManager";
import { resolveRpcForUser } from "./engine/rpcManager";
import { guardContract } from "./engine/contractGuard";
import { resolveOpenseaKey } from "./lib/openseaKey";
import { cleanRpcError } from "./lib/rpcError";
import type { GuardReport } from "@contracts/guard";
import { logActivity } from "./queries/activity";
import {
  assertPendingSnipeCap,
  assertSnipeAllowed,
} from "./lib/entitlements";
import {
  countPendingTasks,
  createTask,
  deleteTask,
  findTaskById,
  findTasksByUser,
  updateTask,
} from "./queries/tasks";

const addressSchema = z
  .string()
  .regex(/^0x[0-9a-fA-F]{40}$/, "Must be a valid 0x address");

const ethAmountSchema = z
  .string()
  .regex(/^\d+(\.\d+)?$/, "Must be a decimal ETH amount like 0.08");

const mintArgsSchema = z.array(
  z.union([z.string(), z.number(), z.boolean()]),
);

const bytes32Schema = z
  .string()
  .regex(/^0x[0-9a-fA-F]{64}$/, "Proof elements must be bytes32 (0x + 64 hex)");

/** Map of wallet address → merkle proof (bytes32[]), capped at 50 wallets. */
const merkleProofsSchema = z
  .record(addressSchema, z.array(bytes32Schema).min(1).max(64))
  .refine((m) => Object.keys(m).length <= 50, {
    message: "At most 50 wallet proofs per task",
  })
  .transform((m) =>
    Object.fromEntries(Object.entries(m).map(([addr, proof]) => [addr.toLowerCase(), proof])),
  );

const taskInputSchema = z.object({
  name: z.string().min(1).max(255),
  contractAddress: addressSchema,
  chainId: z.number().int().positive().default(1),
  mintFunction: z.string().min(1).max(128).default("mint"),
  mintArgs: mintArgsSchema.default([1]),
  mintValueEth: ethAmountSchema.default("0"),
  gasLimit: z.number().int().positive().max(10_000_000).default(200000),
  triggerMode: z.enum(TriggerModes).default("time"),
  openTime: z.coerce.date().nullish(),
  flagMethod: z.string().min(1).max(128).default("saleActive"),
  pollIntervalMs: z.number().int().min(50).max(3_600_000).default(1000),
  eventName: z.string().max(128).nullish(),
  startMaxFeeGwei: z.number().int().positive().default(60),
  startPriorityGwei: z.number().int().positive().default(3),
  gasBumpGwei: z.number().int().positive().default(10),
  maxMaxFeeGwei: z.number().int().positive().default(500),
  maxRetries: z.number().int().min(1).max(50).default(8),
  // Multi-snipe: how many of the user's bot wallets fire on this task.
  walletCount: z.number().int().min(1).max(25).default(1),
  // Whitelist/allowlist minting: 'auto' detects the phase on-chain;
  // 'public'/'whitelist' force it (whitelist needs merkleProofs).
  mintPhase: z.enum(MintPhases).nullish(),
  merkleProofs: merkleProofsSchema.nullish(),
  // Pre-flight eth_call simulation before every broadcast (default on).
  simulateFirst: z.boolean().default(true),
});

const taskUpdateSchema = taskInputSchema.partial();

function validateForArm(task: {
  contractAddress: string;
  triggerMode: string;
  openTime: Date | null;
  flagMethod: string;
  eventName: string | null;
  startMaxFeeGwei: number;
  startPriorityGwei: number;
  maxMaxFeeGwei: number;
  mintArgs: unknown;
}) {
  const problems: string[] = [];
  if (!/^0x[0-9a-fA-F]{40}$/.test(task.contractAddress)) {
    problems.push("contractAddress must be a valid address");
  }
  if (!Array.isArray(task.mintArgs)) problems.push("mintArgs must be a JSON array");
  if (task.triggerMode === "time" && !task.openTime) {
    problems.push("openTime is required for triggerMode=time");
  }
  if (task.triggerMode === "poll" && !task.flagMethod) {
    problems.push("flagMethod is required for triggerMode=poll");
  }
  if (task.triggerMode === "event" && !task.eventName) {
    problems.push("eventName is required for triggerMode=event");
  }
  if (task.startMaxFeeGwei > task.maxMaxFeeGwei) {
    problems.push("startMaxFeeGwei must not exceed maxMaxFeeGwei");
  }
  if (task.startPriorityGwei > task.startMaxFeeGwei) {
    problems.push("startPriorityGwei must not exceed startMaxFeeGwei");
  }
  return problems;
}

async function requireTask(userId: number, id: number) {
  const task = await findTaskById(userId, id);
  if (!task) throw new TRPCError({ code: "NOT_FOUND", message: "Task not found" });
  return task;
}

/* ------------------------------------------------------------------ */
/* Contract safety guard                                               */
/* ------------------------------------------------------------------ */

/**
 * Run the anti-rug guard battery against a mint contract. Resolves the
 * user's RPC + the shared OpenSea key; NEVER throws — a resolution failure
 * degrades to a warn-level report (same contract as guardContract itself).
 */
async function runContractGuard(
  userId: number,
  chainId: number,
  contractAddress: string,
): Promise<GuardReport> {
  try {
    const rpc = await resolveRpcForUser(userId, chainId);
    const { key } = await resolveOpenseaKey(userId);
    return await guardContract({ chainId, contractAddress, rpcUrl: rpc.url, openseaKey: key });
  } catch (e) {
    return {
      level: "warn",
      checks: [
        {
          name: "guard",
          level: "warn",
          detail: `contract guard unavailable: ${cleanRpcError(e)}`,
        },
      ],
    };
  }
}

/** "name: detail" summary of the checks at a given level. */
function guardDetails(report: GuardReport, level: "warn" | "danger"): string {
  return report.checks
    .filter((c) => c.level === level)
    .map((c) => `${c.name}: ${c.detail}`)
    .join("; ");
}

/* ------------------------------------------------------------------ */
/* Contract auto-inspect                                               */
/* ------------------------------------------------------------------ */

const SALE_FLAG_CANDIDATES = ["saleActive", "isSaleActive", "publicSaleActive", "publicSaleState"];
const PRICE_CANDIDATES = ["mintPrice", "cost", "price", "publicMintPrice", "publicSalePrice"];
const MAX_PER_CANDIDATES = ["maxPerTx", "maxPerTransaction", "maxMintPerWallet", "maxPerWallet"];
const MINT_FN_CANDIDATES = ["mint", "publicMint", "mintPublic", "claim", "purchase"];

export type InspectResult = {
  isContract: boolean;
  saleActive?: boolean;
  mintPriceEth?: string;
  maxPerWallet?: number;
  suggestedMintFunction: string | null;
  suggestedGasLimit?: number;
  notes: string[];
};

async function inspectContract(
  userId: number,
  chainId: number,
  contractAddress: string,
): Promise<InspectResult> {
  const rpc = await resolveRpcForUser(userId, chainId);
  const provider = new ethers.JsonRpcProvider(rpc.url, chainId);
  const notes: string[] = [
    `rpc: ${rpc.url} (${rpc.source})`,
  ];

  const code = await provider.getCode(contractAddress);
  if (code === "0x") {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "No contract deployed at this address on the selected chain",
    });
  }

  const result: InspectResult = { isContract: true, suggestedMintFunction: null, notes };

  // --- view probes: collect the first candidate that answers ---
  const viewAbi = [
    ...SALE_FLAG_CANDIDATES.map((n) => `function ${n}() view returns (bool)`),
    ...PRICE_CANDIDATES.map((n) => `function ${n}() view returns (uint256)`),
    ...MAX_PER_CANDIDATES.map((n) => `function ${n}() view returns (uint256)`),
  ];
  const contract = new ethers.Contract(contractAddress, viewAbi, provider);

  for (const name of SALE_FLAG_CANDIDATES) {
    try {
      const value = (await contract.getFunction(name)()) as boolean;
      result.saleActive = value;
      notes.push(
        value
          ? `${name}() = true — sale is OPEN`
          : `${name}() = false — sale not open yet`,
      );
      break;
    } catch {
      // candidate not present — try the next one
    }
  }
  if (result.saleActive === undefined) {
    notes.push("no sale-flag view function found (tried " + SALE_FLAG_CANDIDATES.join(", ") + ")");
  }

  let priceWei: bigint | null = null;
  for (const name of PRICE_CANDIDATES) {
    try {
      const value = (await contract.getFunction(name)()) as bigint;
      priceWei = value;
      result.mintPriceEth = ethers.formatEther(value);
      notes.push(`detected price ${result.mintPriceEth} ETH (via ${name}())`);
      break;
    } catch {
      // candidate not present
    }
  }
  if (priceWei === null) {
    notes.push("no price view function found — assuming free mint (0 ETH)");
  }

  for (const name of MAX_PER_CANDIDATES) {
    try {
      const value = (await contract.getFunction(name)()) as bigint;
      result.maxPerWallet = Number(value);
      notes.push(`wallet cap detected: ${result.maxPerWallet} per tx/wallet (via ${name}())`);
      break;
    } catch {
      // candidate not present
    }
  }

  // --- mint function probe: first candidate whose estimateGas succeeds ---
  for (const name of MINT_FN_CANDIDATES) {
    try {
      const probe = new ethers.Contract(
        contractAddress,
        [`function ${name}(uint256 quantity) payable`],
        provider,
      );
      const estimate = (await probe.getFunction(name).estimateGas(1, {
        value: priceWei ?? 0n,
      })) as bigint;
      result.suggestedMintFunction = name;
      result.suggestedGasLimit = Math.round(Number(estimate) * 1.2);
      notes.push(`mint fn: ${name}(1) estimates at ${estimate} gas — suggesting limit ${result.suggestedGasLimit}`);
      break;
    } catch {
      // reverted (wrong signature, sale closed, etc.) — try the next one
    }
  }
  if (result.suggestedMintFunction === null) {
    notes.push(
      "all mint fn candidates reverted on estimateGas (sale closed or gated?) — configure manually",
    );
  }

  return result;
}

export const taskRouter = createRouter({
  list: authedQuery.query(({ ctx }) => findTasksByUser(ctx.user.id)),

  get: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(({ ctx, input }) => requireTask(ctx.user.id, input.id)),

  inspect: authedQuery
    .input(
      z.object({
        chainId: z.number().int().positive(),
        contractAddress: addressSchema,
      }),
    )
    .query(async ({ ctx, input }) => {
      try {
        return await inspectContract(ctx.user.id, input.chainId, input.contractAddress);
      } catch (e) {
        if (e instanceof TRPCError) throw e;
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Contract inspect failed: ${(e as Error).message.slice(0, 200)}`,
        });
      }
    }),

  create: authedQuery
    .input(taskInputSchema)
    .mutation(async ({ ctx, input }) => {
      const ent = assertSnipeAllowed(ctx, input.walletCount);
      assertPendingSnipeCap(ent, await countPendingTasks(ctx.user.id));
      // Contract safety guard (anti-rug): danger blocks creation outright;
      // warn is allowed but recorded in the task's activity log.
      const guard = await runContractGuard(ctx.user.id, input.chainId, input.contractAddress);
      if (guard.level === "danger") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Contract safety guard blocked this task — ${guardDetails(guard, "danger")}`,
        });
      }
      const task = await createTask({
        ...input,
        openTime: input.openTime ?? null,
        eventName: input.eventName ?? null,
        userId: ctx.user.id,
      });
      if (guard.level === "warn") {
        await logActivity({
          userId: ctx.user.id,
          taskId: task?.id ?? null,
          level: "warn",
          source: "mint",
          message: `contract guard: warn — ${guardDetails(guard, "warn")}`,
          meta: guard,
        });
      }
      return task;
    }),

  /** Live contract-safety re-check for an existing task. */
  guardCheck: authedQuery
    .input(z.object({ taskId: z.number().int().positive() }))
    .query(async ({ ctx, input }): Promise<GuardReport> => {
      const task = await requireTask(ctx.user.id, input.taskId);
      return runContractGuard(ctx.user.id, task.chainId, task.contractAddress);
    }),

  /** Contract-safety preview for a not-yet-created task (TaskWizard). */
  guardPreview: authedQuery
    .input(
      z.object({
        chainId: z.number().int().positive(),
        contractAddress: addressSchema,
      }),
    )
    .query(({ ctx, input }): Promise<GuardReport> =>
      runContractGuard(ctx.user.id, input.chainId, input.contractAddress),
    ),

  update: authedQuery
    .input(z.object({ id: z.number().int().positive(), data: taskUpdateSchema }))
    .mutation(async ({ ctx, input }) => {
      const task = await requireTask(ctx.user.id, input.id);
      // Trial + wallet cap still apply when editing a pending order.
      assertSnipeAllowed(ctx, input.data.walletCount ?? task.walletCount);
      if (task.status === "firing") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Cannot edit a task while it is firing — stop it first",
        });
      }
      const updated = await updateTask(ctx.user.id, input.id, {
        ...input.data,
        // Editing an armed task disarms it back to draft for re-review.
        ...(task.status === "armed" ? { status: "draft" } : {}),
      });
      return updated;
    }),

  delete: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      engineManager.stopTask(input.id);
      await deleteTask(ctx.user.id, input.id);
      return { success: true };
    }),

  arm: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const task = await requireTask(ctx.user.id, input.id);
      if (task.status !== "draft") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Only draft tasks can be armed (current status: ${task.status})`,
        });
      }
      const problems = validateForArm(task);
      if (problems.length > 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Task config invalid: ${problems.join("; ")}`,
        });
      }
      await updateTask(ctx.user.id, input.id, { status: "armed" });
      await logActivity({
        userId: ctx.user.id,
        taskId: task.id,
        level: "info",
        source: "mint",
        message: `Task "${task.name}" armed`,
      });
      return findTaskById(ctx.user.id, input.id);
    }),

  start: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const task = await requireTask(ctx.user.id, input.id);
      // RUN guard: an expired trial cannot start tasks.
      assertSnipeAllowed(ctx, task.walletCount);
      if (task.status !== "armed") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Task must be armed before starting (current status: ${task.status})`,
        });
      }
      if (engineManager.isTaskRunning(task.id)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Task is already running" });
      }
      await engineManager.startTask(task);
      return { success: true, running: true };
    }),

  stop: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const task = await requireTask(ctx.user.id, input.id);
      const wasRunning = engineManager.stopTask(input.id);
      if (task.status === "armed" || task.status === "firing") {
        await updateTask(ctx.user.id, input.id, { status: "cancelled" });
        await logActivity({
          userId: ctx.user.id,
          taskId: task.id,
          level: "warn",
          source: "mint",
          message: `Task "${task.name}" stopped by user`,
        });
      }
      return { success: true, wasRunning };
    }),
});
