import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { raceEndpoints, resolveRpcForUser } from "./engine/rpcManager";
import { getOrCreateSettings } from "./queries/settings";

export const rpcRouter = createRouter({
  /** Race the public endpoint pool for a chain — used by the Settings UI. */
  race: authedQuery
    .input(z.object({ chainId: z.number().int().positive() }))
    .query(({ input }) => raceEndpoints(input.chainId)),

  /** The endpoint the engines would use right now for the user's chain. */
  current: authedQuery.query(async ({ ctx }) => {
    const settings = await getOrCreateSettings(ctx.user.id);
    const resolved = await resolveRpcForUser(ctx.user.id, settings.chainId);
    return { chainId: settings.chainId, ...resolved };
  }),
});
