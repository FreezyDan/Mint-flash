import { activityRouter, statsRouter } from "./activityRouter";
import { adminRouter, billingRouter } from "./adminRouter";
import { authRouter } from "./auth-router";
import { copyRouter } from "./copyRouter";
import { credsRouter } from "./credsRouter";
import { discoverRouter } from "./discoverRouter";
import { positionsRouter } from "./positionsRouter";
import { profileRouter } from "./profileRouter";
import { publicRouter } from "./publicRouter";
import { rpcRouter } from "./rpcRouter";
import { settingsRouter } from "./settingsRouter";
import { sweepRouter } from "./sweepRouter";
import { taskRouter } from "./taskRouter";
import { walletRouter } from "./walletRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  public: publicRouter,
  auth: authRouter,
  creds: credsRouter,
  tasks: taskRouter,
  wallets: walletRouter,
  copy: copyRouter,
  discover: discoverRouter,
  profile: profileRouter,
  activity: activityRouter,
  stats: statsRouter,
  settings: settingsRouter,
  sweep: sweepRouter,
  positions: positionsRouter,
  rpc: rpcRouter,
  admin: adminRouter,
  billing: billingRouter,
});

export type AppRouter = typeof appRouter;
