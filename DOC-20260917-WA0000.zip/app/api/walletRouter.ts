import { z } from "zod";
import { ethers } from "ethers";
import { TRPCError } from "@trpc/server";
import { RpcEndpoints } from "@contracts/rpc";
import { createRouter, authedQuery } from "./middleware";
import {
  addBotWallet,
  findBotWalletsByUser,
  findManagedBotWallet,
  removeBotWallet,
} from "./queries/wallets";
import { logActivity } from "./queries/activity";
import { ensureManagedWallet, getManagedPrivateKey } from "./engine/managedWallet";
import { resolveRpcForUser } from "./engine/rpcManager";

/** All supported chains (6) — vault funding grid. */
const VAULT_BALANCE_CHAIN_IDS = Object.keys(RpcEndpoints).map(Number);
const BALANCE_TIMEOUT_MS = 5_000;
const BALANCE_CONCURRENCY = 3;

/** Native balance for one chain; null on any RPC failure (never throws). */
async function vaultChainBalance(
  userId: number,
  chainId: number,
  address: string,
): Promise<{ chainId: number; balanceEth: string | null }> {
  try {
    const rpc = await resolveRpcForUser(userId, chainId);
    if (!rpc.url) return { chainId, balanceEth: null };
    const provider = new ethers.JsonRpcProvider(rpc.url, chainId);
    const balance = await Promise.race([
      provider.getBalance(address),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("balance timeout")), BALANCE_TIMEOUT_MS),
      ),
    ]);
    return { chainId, balanceEth: Number(ethers.formatEther(balance)).toFixed(4) };
  } catch {
    return { chainId, balanceEth: null };
  }
}

// Manually-added bot wallets store PUBLIC addresses only — their keys come
// from the BOT_PRIVATE_KEYS server env var. Each user also gets a managed
// "Auto vault" wallet (created on sign-up) whose encrypted key is stored
// server-side; the encryptedKey column is never exposed through this router.
export const walletRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    // Lazy provisioning: pre-existing users get their vault on first visit.
    try {
      await ensureManagedWallet(ctx.user.id);
    } catch (err) {
      console.error("[wallets] managed wallet provisioning failed:", err);
    }
    return findBotWalletsByUser(ctx.user.id);
  }),

  managed: authedQuery.query(async ({ ctx }) => {
    await ensureManagedWallet(ctx.user.id);
    const row = await findManagedBotWallet(ctx.user.id);
    if (!row) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Managed vault could not be provisioned",
      });
    }
    return { address: row.address, createdAt: row.createdAt };
  }),

  /**
   * Per-chain native balances of the managed vault (7 chains). Drives the
   * Wallets-tab funding guidance — a failing RPC yields null for that chain
   * instead of failing the whole query. Concurrency 3, 5s per-chain timeout.
   */
  vaultBalances: authedQuery.query(async ({ ctx }) => {
    await ensureManagedWallet(ctx.user.id);
    const row = await findManagedBotWallet(ctx.user.id);
    if (!row) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Managed vault could not be provisioned",
      });
    }
    const results: { chainId: number; balanceEth: string | null }[] = [];
    for (let i = 0; i < VAULT_BALANCE_CHAIN_IDS.length; i += BALANCE_CONCURRENCY) {
      const chunk = VAULT_BALANCE_CHAIN_IDS.slice(i, i + BALANCE_CONCURRENCY);
      results.push(
        ...(await Promise.all(
          chunk.map((chainId) => vaultChainBalance(ctx.user.id, chainId, row.address)),
        )),
      );
    }
    return results;
  }),

  reveal: authedQuery.mutation(async ({ ctx }) => {
    const privateKey = await getManagedPrivateKey(ctx.user.id);
    if (!privateKey) {
      throw new TRPCError({
        code: "NOT_FOUND",
        message: "No managed vault found for this account",
      });
    }
    await logActivity({
      userId: ctx.user.id,
      level: "warn",
      source: "system",
      message: "Vault private key revealed via dashboard",
    });
    return { privateKey };
  }),

  add: authedQuery
    .input(
      z.object({
        label: z.string().min(1).max(255),
        address: z
          .string()
          .regex(/^0x[0-9a-fA-F]{40}$/, "Must be a valid 0x address"),
      }),
    )
    .mutation(({ ctx, input }) =>
      addBotWallet({ ...input, userId: ctx.user.id }),
    ),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      await removeBotWallet(ctx.user.id, input.id);
      return { success: true };
    }),
});
