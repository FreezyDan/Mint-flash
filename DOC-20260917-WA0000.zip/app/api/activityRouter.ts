import { z } from "zod";
import { ActivitySources, type OverviewStats } from "@contracts/bot";
import { createRouter, authedQuery } from "./middleware";
import { findActivityByUser } from "./queries/activity";
import { findSignalsByUser, findWatchedWalletsByUser } from "./queries/copy";
import { findTasksByUser } from "./queries/tasks";

export const activityRouter = createRouter({
  list: authedQuery
    .input(
      z
        .object({ source: z.enum(ActivitySources).optional() })
        .optional(),
    )
    .query(({ ctx, input }) =>
      findActivityByUser(ctx.user.id, { limit: 200, source: input?.source }),
    ),
});

export const statsRouter = createRouter({
  overview: authedQuery.query(async ({ ctx }): Promise<OverviewStats> => {
    const userId = ctx.user.id;
    const [tasks, watched, signalRows] = await Promise.all([
      findTasksByUser(userId),
      findWatchedWalletsByUser(userId),
      findSignalsByUser(userId, 1000),
    ]);

    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const signalsToday = signalRows.filter((s) => s.createdAt >= dayStart);
    const mirrored = signalRows.filter((s) => s.status === "mirrored");
    const pnl = mirrored.reduce((sum, s) => sum + Number(s.pnlEth ?? 0), 0);

    return {
      tasksArmed: tasks.filter((t) => t.status === "armed" || t.status === "firing").length,
      tasksTotal: tasks.length,
      walletsTracked: watched.length,
      signalsToday: signalsToday.length,
      mirroredCount: mirrored.length,
      pnlEth: pnl.toFixed(4),
    };
  }),
});
