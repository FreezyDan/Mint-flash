import { z } from "zod";
import { TRPCError } from "@trpc/server";
import type { WalletProfile } from "@contracts/profile";
import { createRouter, authedQuery } from "./middleware";
import { assertPro } from "./lib/entitlements";
import { resolveOpenseaKey } from "./lib/openseaKey";
import { profileWallet } from "./engine/openseaProfiler";
import { findWalletProfile, upsertWalletProfile } from "./queries/profile";

const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
/** Cached profiles are served for 30 minutes unless forceRefresh is set. */
const CACHE_TTL_MS = 30 * 60 * 1000;
/** Max force-refreshes per user per 10 minutes (in-memory, per process). */
const REFRESH_LIMIT = 6;
const REFRESH_WINDOW_MS = 10 * 60 * 1000;

const refreshLog = new Map<number, number[]>();

function assertRefreshAllowed(userId: number): void {
  const now = Date.now();
  const recent = (refreshLog.get(userId) ?? []).filter((t) => now - t < REFRESH_WINDOW_MS);
  if (recent.length >= REFRESH_LIMIT) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Refresh rate-limited — try again in a few minutes",
    });
  }
  recent.push(now);
  refreshLog.set(userId, recent);
}

export const profileRouter = createRouter({
  /**
   * All-time wallet PnL from the wallet's complete OpenSea (Seaport) sale
   * history: buys↔sells paired FIFO per collection+chain for realized PnL,
   * still-held positions marked at the current collection floor for
   * unrealized PnL. Uses the resolved OpenSea key (user's own or the
   * platform's shared key — always available).
   */
  get: authedQuery
    .input(
      z.object({
        address: z.string().regex(ADDR_RE, "Must be a valid 0x address"),
        forceRefresh: z.boolean().optional(),
      }),
    )
    .query(async ({ ctx, input }): Promise<{ profile: WalletProfile; cached: boolean }> => {
      assertPro(ctx);
      // A key always resolves (user key → shared override → built-in shared).
      const { key: openseaKey } = await resolveOpenseaKey(ctx.user.id);

      const address = input.address.toLowerCase();
      if (!input.forceRefresh) {
        const cached = await findWalletProfile(address);
        if (cached && Date.now() - cached.fetchedAt.getTime() < CACHE_TTL_MS) {
          return { profile: cached.payload, cached: true };
        }
      } else {
        assertRefreshAllowed(ctx.user.id);
      }

      const profile = await profileWallet(address, openseaKey);
      await upsertWalletProfile(address, profile);
      return { profile, cached: false };
    }),
});
