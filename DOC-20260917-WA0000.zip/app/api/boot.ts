import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";
import { engineManager } from "./engine/engineManager";
import { migrate } from "drizzle-orm/mysql2/migrator";
import { getDb } from "./queries/connection";
import path from "node:path";
import fs from "node:fs";

/**
 * Auto-apply Drizzle migrations on boot. The sandbox that builds the app
 * cannot reach the cloud DB (privatelink), so schema sync must happen in the
 * runtime that can. Idempotent — Drizzle tracks applied migrations in the
 * __drizzle_migrations table. Never crashes the server on failure.
 */
async function ensureSchema() {
  // Pass 1 (best effort): drizzle-kit journal migrations from disk. Depends
  // on the migrations folder being readable from the runtime cwd, which is
  // not guaranteed — so failures here are expected in some environments.
  try {
    const candidates = [
      path.resolve(process.cwd(), "db/migrations"),
      path.resolve(path.dirname(new URL(import.meta.url).pathname), "../db/migrations"),
      path.resolve(path.dirname(new URL(import.meta.url).pathname), "../../db/migrations"),
    ];
    const folder = candidates.find((p) =>
      fs.existsSync(path.join(p, "meta", "_journal.json")),
    );
    if (!folder) {
      console.warn("[db] migrations folder not found, skipping drizzle-kit migrate");
    } else {
      await migrate(getDb(), { migrationsFolder: folder });
      console.log("[db] schema migrations applied via drizzle-kit");
    }
  } catch (e) {
    console.warn(
      "[db] drizzle-kit migrate failed, relying on embedded ensure:",
      e instanceof Error ? e.message : e,
    );
  }

  // Pass 2 (guaranteed): embedded idempotent DDL — no filesystem dependency.
  const { ensureSchemaEmbedded } = await import("./engine/ensureSchema");
  await ensureSchemaEmbedded();
}

// Bound the wait so an unreachable DB can never block server start.
await Promise.race([
  ensureSchema(),
  new Promise((resolve) => setTimeout(resolve, 20_000)),
]);

// Boot the mint/copy engines once the server module loads. Failures are
// contained inside the manager and must never crash the server.
void engineManager.boot();

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
