import type {
  PublicLeaderboardRow,
  PublicScanStats,
  PublicSignal,
} from "@contracts/discover";
import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  fetchSupplyInfo,
  getContractActivity,
  getTrendingSnapshot,
  MINT_WATCH_CHAINS,
  type TrendingEntry,
} from "./engine/mintWatch";
import { getBestRpc } from "./engine/rpcManager";

/** Row shape of the per-chain gas widget. */
export type GasRow = { chainId: number; gwei: number | null };

const GAS_CACHE_TTL_MS = 15_000;
let gasCache: { at: number; rows: GasRow[] } | null = null;

/** eth_gasPrice via the chain's fastest healthy endpoint (4s budget). */
async function fetchGasGwei(chainId: number): Promise<number | null> {
  try {
    const url = await getBestRpc(chainId);
    if (!url) return null;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4_000);
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", method: "eth_gasPrice", params: [], id: 1 }),
        signal: controller.signal,
      });
      const body = (await res.json()) as { result?: string };
      if (!body.result) return null;
      return Math.round((Number(BigInt(body.result)) / 1e9) * 10) / 10;
    } finally {
      clearTimeout(timer);
    }
  } catch {
    return null;
  }
}
import { latestPublicSignals } from "./queries/copy";
import { scanCoverage, topTradersByTotalPnl } from "./queries/discover";

/** Row shape of the public "Minting Now" trending feed. */
export type TrendingMintRow = {
  chainId: number;
  contract: string;
  name: string | null;
  symbol: string | null;
  m1: number;
  m5: number;
  m15: number;
  h1: number;
  uniqueMinters15m: number;
  totalSupply: number | null;
  lastMintTs: number;
};

/** Result of the per-contract mint-progress monitor (nulls tolerated). */
export type MintProgressResult = {
  total: number | null;
  max: number | null;
  pct: number | null;
  m5: number | null;
  m15: number | null;
  uniqueMinters15m: number | null;
  lastMintTs: number | null;
};

/**
 * Public, unauthenticated read-only endpoints exposing REAL on-chain data
 * (engine scan output + detections). No user ids, no wallet ownership info.
 * Empty tables return empty arrays — clients render an honest empty state.
 */
export const publicRouter = createRouter({
  /**
   * Top 20 discovered traders across all chains, ranked by total PnL
   * (realized + unrealized). Straight from the on-chain scanner snapshot.
   */
  leaderboard: publicQuery.query(async (): Promise<PublicLeaderboardRow[]> => {
    const rows = await topTradersByTotalPnl(20);
    return rows.map((r, i) => {
      const realized = Number(r.realizedPnlEth);
      const unrealized = r.unrealizedPnlEth === null ? 0 : Number(r.unrealizedPnlEth);
      return {
        rank: i + 1,
        address: r.address,
        chainId: r.chainId,
        realizedPnlEth: r.realizedPnlEth,
        unrealizedPnlEth:
          r.unrealizedPnlEth === null ? null : String(r.unrealizedPnlEth),
        totalPnlEth: (realized + unrealized).toFixed(6),
        winRatePct: r.winRatePct,
        flips: r.flips,
        openPositions: r.openPositions,
        scannedAt: r.scannedAt,
      };
    });
  }),

  /** Latest 15 engine detections (mints/buys observed on-chain). */
  recentSignals: publicQuery.query(async (): Promise<PublicSignal[]> => {
    return latestPublicSignals(15);
  }),

  /** Scan coverage counters for honest aggregate stats. */
  scanStats: publicQuery.query(async (): Promise<PublicScanStats> => {
    return scanCoverage();
  }),

  /**
   * Live gas price per watched chain (gwei, 1dp) for the dashboard gas
   * widget. 15s server-side cache; a failing chain yields null, never an
   * error for the whole widget.
   */
  gasNow: publicQuery.query(async (): Promise<GasRow[]> => {
    if (gasCache && Date.now() - gasCache.at < GAS_CACHE_TTL_MS) return gasCache.rows;
    const rows = await Promise.all(
      MINT_WATCH_CHAINS.map(async (chainId) => ({ chainId, gwei: await fetchGasGwei(chainId) })),
    );
    gasCache = { at: Date.now(), rows };
    return rows;
  }),

  /**
   * "Minting Now" trending feed — top 20 contracts by live mint velocity
   * across all seven chains, straight from the in-memory watcher snapshot.
   * Empty array while the watcher warms up (honest — no fabricated rows).
   */
  trendingMints: publicQuery.query(async (): Promise<TrendingMintRow[]> => {
    return getTrendingSnapshot()
      .slice(0, 20)
      .map((e: TrendingEntry) => ({
        chainId: e.chainId,
        contract: e.contract,
        name: e.name,
        symbol: e.symbol,
        m1: e.m1,
        m5: e.m5,
        m15: e.m15,
        h1: e.h1,
        uniqueMinters15m: e.uniqueMinters15m,
        totalSupply: e.totalSupply,
        lastMintTs: e.lastMintTs,
      }));
  }),

  /**
   * Per-contract mint progress for the task-detail monitor: on-chain
   * totalSupply + first answering max-supply getter (5s budget, never
   * throws — every field degrades to null), merged with the watcher's
   * live velocity windows when the contract has been seen minting.
   */
  mintProgress: publicQuery
    .input(
      z.object({
        chainId: z.number().int().positive(),
        contractAddress: z.string().regex(/^0x[0-9a-fA-F]{40}$/),
      }),
    )
    .query(async ({ input }): Promise<MintProgressResult> => {
      const empty: MintProgressResult = {
        total: null,
        max: null,
        pct: null,
        m5: null,
        m15: null,
        uniqueMinters15m: null,
        lastMintTs: null,
      };
      try {
        const url = await getBestRpc(input.chainId);
        if (!url) return empty;
        const supply = await fetchSupplyInfo(url, input.contractAddress, 5_000);
        const activity = getContractActivity(input.chainId, input.contractAddress);
        return {
          total: supply.total,
          max: supply.max,
          pct: supply.pct,
          m5: activity?.m5 ?? null,
          m15: activity?.m15 ?? null,
          uniqueMinters15m: activity?.uniqueMinters15m ?? null,
          lastMintTs: activity && activity.lastMintTs > 0 ? activity.lastMintTs : null,
        };
      } catch {
        return empty;
      }
    }),
});
