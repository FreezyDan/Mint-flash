import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { ChainKeyToId } from "@contracts/rpc";
import type { DiscoverChainStat, DiscoverScanResult } from "@contracts/discover";
import { createRouter, authedQuery } from "./middleware";
import { assertPro } from "./lib/entitlements";
import { cleanRpcError } from "./lib/rpcError";
import { scanChain } from "./engine/chainScanner";
import {
  countDiscoveredTraders,
  discoveredChainStats,
  lastScanForChain,
  latestDiscoveredTraderRow,
  listDiscoveredFlips,
  listDiscoveredTraders,
} from "./queries/discover";

const SUPPORTED_CHAIN_IDS = [...new Set(Object.values(ChainKeyToId))];
const SCAN_COOLDOWN_MS = 10 * 60 * 1000;
const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;

const chainIdSchema = z
  .number()
  .int()
  .refine((id) => SUPPORTED_CHAIN_IDS.includes(id), {
    message: `Unsupported chainId — expected one of ${SUPPORTED_CHAIN_IDS.join(", ")}`,
  });

export const discoverRouter = createRouter({
  /**
   * Scan a chain for profitable Seaport/OpenSea traders. Per-chain cooldown:
   * if the last scan is <10m old the cached snapshot is returned instead.
   */
  scan: authedQuery
    .input(z.object({ chainId: chainIdSchema }))
    .mutation(async ({ ctx, input }): Promise<DiscoverScanResult> => {
      assertPro(ctx);
      const last = await lastScanForChain(input.chainId);
      if (last && Date.now() - last.getTime() < SCAN_COOLDOWN_MS) {
        const latestRow = await latestDiscoveredTraderRow(input.chainId);
        return {
          cached: true,
          chainId: input.chainId,
          scannedAt: last,
          tradersStored: await countDiscoveredTraders(input.chainId),
          fromBlock: latestRow?.fromBlock ?? null,
          toBlock: latestRow?.toBlock ?? null,
        };
      }
      try {
        const summary = await scanChain(ctx.user.id, input.chainId);
        return { cached: false, scannedAt: new Date(), ...summary };
      } catch (e) {
        if (e instanceof TRPCError) throw e;
        // Never leak raw ethers/SQL text into the UI toast.
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Chain scan failed: ${cleanRpcError(e)}`,
        });
      }
    }),

  /** Ranked discovered traders for a chain + when it was last scanned. */
  list: authedQuery
    .input(
      z.object({
        chainId: chainIdSchema,
        limit: z.number().int().min(1).max(100).default(50),
        /** 'mint' = only wallets with mint flips, ranked by mint PnL. */
        mode: z.enum(["all", "mint"]).default("all"),
        /** Decimal ETH floor applied to the mode's PnL column. */
        minPnlEth: z
          .string()
          .regex(/^-?\d+(\.\d+)?$/, "minPnlEth must be a decimal string")
          .optional(),
        /** ROI floor; NULL roiPct (free-mint-derived) always passes. */
        minRoiPct: z.number().optional(),
      }),
    )
    .query(async ({ input }) => {
      const [rows, lastScannedAt] = await Promise.all([
        listDiscoveredTraders(input.chainId, input.limit, {
          mode: input.mode,
          minPnlEth: input.minPnlEth,
          minRoiPct: input.minRoiPct,
        }),
        lastScanForChain(input.chainId),
      ]);
      return { rows, lastScannedAt };
    }),

  /** Per-flip P&L detail for one discovered wallet (drilldown drawer). */
  flips: authedQuery
    .input(
      z.object({
        chainId: chainIdSchema,
        address: z.string().regex(ADDR_RE, "Must be a valid 0x address"),
        limit: z.number().int().min(1).max(500).default(100),
      }),
    )
    .query(async ({ input }) => {
      const rows = await listDiscoveredFlips(
        input.chainId,
        input.address.toLowerCase(),
        input.limit,
      );
      return { rows };
    }),

  /** Per-chain row counts + last scan time for the 6 supported chains. */
  chains: authedQuery.query(async (): Promise<DiscoverChainStat[]> => {
    const stats = await discoveredChainStats();
    const byChain = new Map(stats.map((s) => [s.chainId, s]));
    return SUPPORTED_CHAIN_IDS.map((chainId) => ({
      chainId,
      traders: Number(byChain.get(chainId)?.traders ?? 0),
      lastScannedAt: byChain.get(chainId)?.lastScannedAt ?? null,
    }));
  }),
});
