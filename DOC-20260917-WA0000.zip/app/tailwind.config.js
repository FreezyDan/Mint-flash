/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive) / <alpha-value>)",
          foreground: "hsl(var(--destructive-foreground) / <alpha-value>)",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
        /* MintDash design tokens */
        void: "#07080D",
        panel: "#0D0F16",
        panel2: "#12141E",
        hairline: "#1E2230",
        violet: { DEFAULT: "#7C5CFF", deep: "#4A2EDB" },
        neon: { DEFAULT: "#39FF8E", dim: "#1A3A2A" },
        alarm: "#FF4D6A",
        amber: { DEFAULT: "#FFB224" },
        cyan: { DEFAULT: "#41E6E0" },
        tpri: "#F2F4F8",
        tsec: "#9BA3B4",
        tmut: "#5A6274",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        sans: ["Inter", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      backgroundImage: {
        "g-brand": "linear-gradient(135deg, #7C5CFF 0%, #4A2EDB 100%)",
        "g-profit": "linear-gradient(135deg, #39FF8E 0%, #14B8A6 100%)",
        "g-hero-glow": "radial-gradient(ellipse at center, rgba(124,92,255,0.22) 0%, transparent 65%)",
        "g-green-glow": "radial-gradient(ellipse at center, rgba(57,255,142,0.14) 0%, transparent 65%)",
      },
      boxShadow: {
        "glow-violet": "0 0 40px rgba(124,92,255,0.15)",
        "glow-violet-lg": "0 0 60px rgba(124,92,255,0.25)",
        "glow-green": "0 0 24px rgba(57,255,142,0.12)",
        xs: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
      },
      borderRadius: {
        xl: "calc(var(--radius) + 4px)",
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        xs: "calc(var(--radius) - 6px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "caret-blink": {
          "0%,70%,100%": { opacity: "1" },
          "20%,50%": { opacity: "0" },
        },
        marquee: {
          from: { transform: "translateX(0)" },
          to: { transform: "translateX(-50%)" },
        },
        "pulse-ring": {
          "0%": { transform: "scale(1)", opacity: "0.8" },
          "100%": { transform: "scale(2.2)", opacity: "0" },
        },
        "chip-flash": {
          "0%, 100%": { backgroundColor: "rgba(57,255,142,0.10)" },
          "50%": { backgroundColor: "rgba(57,255,142,0.30)" },
        },
        "glow-pulse": {
          "0%, 100%": { boxShadow: "0 0 40px rgba(124,92,255,0.10)" },
          "50%": { boxShadow: "0 0 40px rgba(124,92,255,0.18)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "caret-blink": "caret-blink 1.25s ease-out infinite",
        marquee: "marquee 40s linear infinite",
        "pulse-ring": "pulse-ring 1.6s ease-out infinite",
        "chip-flash": "chip-flash 600ms ease-in-out",
        "glow-pulse": "glow-pulse 3s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
