/**
 * Subscription plan contracts shared between api/ and src/.
 *
 * FREE: NFT snipe bot (mint tasks) only, 7-day trial from signup,
 *       capped at 3 pending snipe orders and 2 wallets per snipe.
 * PRO ($15/mo): everything, no caps.
 * ADMIN (ADMIN_EMAIL): permanent full access to everything.
 */

export const PLANS = ["free", "pro"] as const;
export type Plan = (typeof PLANS)[number];

/** This account always has full access to everything. */
export const ADMIN_EMAIL = "dioruhanan@gmail.com";

export const FREE_LIMITS = {
  trialDays: 7,
  maxPendingSnipes: 3,
  maxSnipeWallets: 2,
} as const;

export const PRO_PRICE_USD = 15;

/** site_settings key holding the admin-configured PRO payment address. */
export const PAYMENT_ADDRESS_SETTING_KEY = "proPaymentAddress";

/**
 * Built-in pay-to address for PRO ($15/mo). Buyers send $15 worth of
 * ETH/native token on any supported EVM chain, submit the tx hash, and the
 * admin activates PRO after confirming the payment on-chain. Used whenever
 * site_settings has no override — the Admin console can replace it at
 * runtime (takes precedence).
 */
export const PRO_PAYMENT_ADDRESS = "0x300ef926e05a9891e9e3f575e6ba43d55c9a975e";

/** EVM chains accepted for PRO payment (native token on any of these). */
export const PAYMENT_CHAIN_IDS = [1, 8453, 42161, 137, 4663, 57073, 5042] as const;

/** Pure validators — shared by the API input checks and unit tests. */
export const EVM_ADDRESS_RE = /^0x[0-9a-fA-F]{40}$/;
export const EVM_TX_HASH_RE = /^0x[0-9a-fA-F]{64}$/;

export function isValidEvmAddress(value: string): boolean {
  return EVM_ADDRESS_RE.test(value);
}

export function isValidTxHash(value: string): boolean {
  return EVM_TX_HASH_RE.test(value);
}

export function isPaymentChain(chainId: number): boolean {
  return (PAYMENT_CHAIN_IDS as readonly number[]).includes(chainId);
}

/** Payment claim lifecycle for the manual pay-to-address flow. */
export const CLAIM_STATUSES = ["pending", "approved", "rejected"] as const;
export type ClaimStatus = (typeof CLAIM_STATUSES)[number];

export type Entitlement = {
  plan: Plan;
  admin: boolean;
  /** Epoch ms when the free trial ends; null for pro/admin/unknown. */
  trialEndsAt: number | null;
  /** Whole days remaining in the trial (0 once expired); null when n/a. */
  trialDaysLeft: number | null;
  trialExpired: boolean;
};
