/**
 * Pure link parsers for NFT drops and trader wallets.
 * No dependencies — safe to import from both frontend and backend.
 *
 * parseNftLink: OpenSea / Blur / MagicEden / Zora / Rarible / explorers / bare 0x.
 * parseWalletLink: bare 0x, OpenSea profile, explorer /address/ pages.
 */

export type ParsedNftLink =
  | {
      ok: true;
      chainId: number | null;
      contractAddress: string;
      tokenId: string | null;
      source: string;
    }
  | { ok: false; reason: string };

export type ParsedWalletLink =
  | { ok: true; address: string }
  | { ok: false; reason: string };

const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
/** 0x address possibly followed by ":tokenId" (rarible style). */
const ADDR_IN_SEG_RE = /(0x[0-9a-fA-F]{40})(?::(\d+))?/;

/** OpenSea (and generic marketplace) chain slug → chain id. */
const CHAIN_SLUGS: Record<string, number> = {
  ethereum: 1,
  base: 8453,
  matic: 137,
  polygon: 137,
  arbitrum: 42161,
  "arbitrum-one": 42161,
  robinhood: 4663,
  ink: 57073,
  arc: 5042,
};

/** Explorer hosts where the chain id is unambiguous. */
const EXPLORER_CHAIN_IDS: Record<string, number> = {
  "etherscan.io": 1,
  "basescan.org": 8453,
  "polygonscan.com": 137,
  "arbiscan.io": 42161,
};

function isExplorerHost(host: string): boolean {
  return (
    host in EXPLORER_CHAIN_IDS ||
    host.endsWith(".etherscan.io") ||
    host.includes("blockscout")
  );
}

function explorerChainId(host: string): number | null {
  // Exact match first (unambiguous L2 explorers).
  if (host in EXPLORER_CHAIN_IDS) return EXPLORER_CHAIN_IDS[host];
  // *.etherscan.io is Ethereum mainnet unless it is an unknown subdomain.
  if (host === "etherscan.io" || host.endsWith(".etherscan.io")) return 1;
  return null; // blockscout instances are multi-chain — ambiguous
}

function normalizeUrl(input: string): URL | null {
  const trimmed = input.trim();
  if (!trimmed || /\s/.test(trimmed)) return null;
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)
    ? trimmed
    : `https://${trimmed}`;
  try {
    return new URL(withScheme);
  } catch {
    return null;
  }
}

function segments(url: URL): string[] {
  return url.pathname.split("/").filter(Boolean).map(decodeURIComponent);
}

/** Split a "slug:0xaddr(:id)" compound segment (zora / rarible style). */
function matchAddressIn(text: string): { address: string; tokenId: string | null } | null {
  const m = ADDR_IN_SEG_RE.exec(text);
  if (!m) return null;
  return { address: m[1], tokenId: m[2] ?? null };
}

export function parseNftLink(input: string): ParsedNftLink {
  const trimmed = input.trim();
  if (!trimmed) return { ok: false, reason: "Paste a link or a 0x contract address" };

  // Bare contract address.
  if (ADDR_RE.test(trimmed)) {
    return {
      ok: true,
      chainId: null,
      contractAddress: trimmed,
      tokenId: null,
      source: "address",
    };
  }

  const url = normalizeUrl(trimmed);
  if (!url) return { ok: false, reason: "Not a recognizable link or address" };

  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  const segs = segments(url);

  // ---- OpenSea ----
  if (host === "opensea.io" || host.endsWith(".opensea.io")) {
    if (segs[0] === "collection") {
      return {
        ok: false,
        reason:
          "OpenSea collection links don't expose the contract — paste the contract address or an /assets/ link",
      };
    }
    if (segs[0] === "assets" && segs.length >= 3) {
      const slug = segs[1].toLowerCase();
      const found = matchAddressIn(segs[2]);
      if (!found) return { ok: false, reason: "No contract address found in this OpenSea link" };
      return {
        ok: true,
        chainId: CHAIN_SLUGS[slug] ?? null,
        contractAddress: found.address,
        tokenId: segs[3] ?? found.tokenId,
        source: "opensea",
      };
    }
    // opensea.io/:address profile or unknown shape.
    const loose = matchAddressIn(url.pathname);
    if (loose) {
      return {
        ok: true,
        chainId: null,
        contractAddress: loose.address,
        tokenId: loose.tokenId,
        source: "opensea",
      };
    }
    return { ok: false, reason: "Unsupported OpenSea link — use an /assets/ link or a 0x address" };
  }

  // ---- Blur (Ethereum only) ----
  if (host === "blur.io" || host.endsWith(".blur.io")) {
    if ((segs[0] === "collection" || segs[0] === "asset") && segs[1]) {
      const found = matchAddressIn(segs[1]);
      if (!found) return { ok: false, reason: "No contract address found in this Blur link" };
      return {
        ok: true,
        chainId: 1,
        contractAddress: found.address,
        tokenId: segs[0] === "asset" ? (segs[2] ?? found.tokenId) : null,
        source: "blur",
      };
    }
    return { ok: false, reason: "Unsupported Blur link — use a /collection/ or /asset/ link" };
  }

  // ---- Magic Eden ----
  if (host === "magiceden.io" || host.endsWith(".magiceden.io")) {
    if (segs[0] === "collections" && segs[2]) {
      const found = matchAddressIn(segs[2]);
      if (!found) return { ok: false, reason: "No contract address found in this Magic Eden link" };
      const slug = segs[1].toLowerCase();
      return {
        ok: true,
        chainId: CHAIN_SLUGS[slug] ?? null,
        contractAddress: found.address,
        tokenId: null,
        source: "magiceden",
      };
    }
    if (segs[0] === "item-details" && segs[1]) {
      const found = matchAddressIn(segs[1]);
      if (!found) return { ok: false, reason: "No contract address found in this Magic Eden link" };
      return {
        ok: true,
        chainId: null,
        contractAddress: found.address,
        tokenId: segs[2] ?? found.tokenId,
        source: "magiceden",
      };
    }
    return { ok: false, reason: "Unsupported Magic Eden link" };
  }

  // ---- Zora: zora.co/collect/<slug>:<address>(/<id>) ----
  if (host === "zora.co" || host.endsWith(".zora.co")) {
    if (segs[0] === "collect" && segs[1]) {
      const found = matchAddressIn(segs[1]);
      if (!found) return { ok: false, reason: "No contract address found in this Zora link" };
      const slug = segs[1].split(":")[0]?.toLowerCase() ?? "";
      return {
        ok: true,
        chainId: CHAIN_SLUGS[slug] ?? null,
        contractAddress: found.address,
        tokenId: segs[2] ?? found.tokenId,
        source: "zora",
      };
    }
    return { ok: false, reason: "Unsupported Zora link — use a /collect/ link" };
  }

  // ---- Rarible: /token|collection/…<address>(:<id>) ----
  if (host === "rarible.com" || host.endsWith(".rarible.com")) {
    if (segs[0] === "token" || segs[0] === "collection") {
      // Address may sit in any later segment, embedded as "<chain>/?0xaddr:id".
      for (const seg of segs.slice(1)) {
        const found = matchAddressIn(seg);
        if (found) {
          const prev = segs[segs.indexOf(seg) - 1]?.toLowerCase() ?? "";
          return {
            ok: true,
            chainId: CHAIN_SLUGS[prev] ?? null,
            contractAddress: found.address,
            tokenId: segs[0] === "token" ? found.tokenId : null,
            source: "rarible",
          };
        }
      }
      return { ok: false, reason: "No contract address found in this Rarible link" };
    }
    return { ok: false, reason: "Unsupported Rarible link — use a /token/ or /collection/ link" };
  }

  // ---- Explorers: /address/<address> ----
  if (isExplorerHost(host)) {
    if (segs[0] === "address" && segs[1]) {
      const found = matchAddressIn(segs[1]);
      if (found) {
        return {
          ok: true,
          chainId: explorerChainId(host),
          contractAddress: found.address,
          tokenId: null,
          source: "explorer",
        };
      }
    }
    // Fall through: any 0x address anywhere in the path.
    const loose = matchAddressIn(url.pathname);
    if (loose) {
      return {
        ok: true,
        chainId: explorerChainId(host),
        contractAddress: loose.address,
        tokenId: loose.tokenId,
        source: "explorer",
      };
    }
    return { ok: false, reason: "No contract address found in this explorer link" };
  }

  // Last resort: any 0x address in the URL.
  const loose = matchAddressIn(url.pathname);
  if (loose) {
    return {
      ok: true,
      chainId: null,
      contractAddress: loose.address,
      tokenId: loose.tokenId,
      source: host,
    };
  }
  return { ok: false, reason: `Unrecognized link (${host}) — paste a 0x contract address` };
}

/** Parse a trader/wallet link: bare 0x, OpenSea profile, explorer address page. */
export function parseWalletLink(input: string): ParsedWalletLink {
  const trimmed = input.trim();
  if (!trimmed) return { ok: false, reason: "Paste a wallet address or profile link" };

  if (ADDR_RE.test(trimmed)) return { ok: true, address: trimmed };

  const url = normalizeUrl(trimmed);
  if (!url) return { ok: false, reason: "Not a recognizable wallet link or address" };

  const host = url.hostname.toLowerCase().replace(/^www\./, "");

  // opensea.io/<address> profile.
  if (host === "opensea.io" || host.endsWith(".opensea.io")) {
    const first = segments(url)[0] ?? "";
    if (ADDR_RE.test(first)) return { ok: true, address: first };
    return { ok: false, reason: "OpenSea profile link must contain a 0x wallet address" };
  }

  // explorer /address/<address>.
  if (isExplorerHost(host)) {
    const found = matchAddressIn(url.pathname);
    if (found) return { ok: true, address: found.address };
    return { ok: false, reason: "No wallet address found in this explorer link" };
  }

  // Any 0x address embedded anywhere else.
  const loose = matchAddressIn(url.pathname);
  if (loose) return { ok: true, address: loose.address };

  return { ok: false, reason: "Couldn't find a wallet address — paste a bare 0x address" };
}
