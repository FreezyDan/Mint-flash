/**
 * Shared types for the all-time wallet PnL profiler
 * (OpenSea API v2 account trade history). Frontend imports from
 * `@contracts/profile` — never from `api/`.
 *
 * All ETH amounts are decimal strings (10dp truncated, signed where a PnL);
 * timestamps are unix seconds; `fetchedAt` is an ISO string. Everything is
 * plain JSON — the payload is stored verbatim in the wallet_profiles cache
 * table.
 */

/** How a sale's ETH value was established. */
export type ProfilePricedWith =
  /** ETH/WETH payment — used directly. */
  | "native"
  /**
   * Other ERC-20 converted via DefiLlama — historical rate, or the nearest
   * CURRENT rate when history is missing (see ProfileFlip.approxPrice).
   */
  | "oracle"
  /** Price could not be resolved — excluded from PnL, never zero. */
  | "unpriced";

/** One completed buy→sell pair (or a sell with no known OpenSea cost basis). */
export type ProfileFlip = {
  chainId: number;
  /** NFT contract, lowercased. */
  contract: string;
  collectionSlug: string | null;
  /** Sold NFT display name (OpenSea metadata), when present. */
  name: string | null;
  imageUrl: string | null;
  /** Token id of the SOLD unit (the buy leg may be a different token). */
  tokenId: string | null;
  /** Entry cost in ETH — null when acquired off-OpenSea or paid unpriced. */
  buyEth: string | null;
  /** Proceeds in ETH — null when the payment token couldn't be priced. */
  sellEth: string | null;
  /** sellEth − buyEth — null whenever either leg is unknown (never pure profit). */
  pnlEth: string | null;
  pricedWith: ProfilePricedWith;
  /**
   * True when an oracle-priced flip used the nearest available (CURRENT)
   * rate because no historical price exists (e.g. some Robinhood tokens).
   * Optional: cached payloads written before this field existed lack it.
   */
  approxPrice?: boolean;
  /** Original payment token symbol (uppercased) — e.g. "ETH", "USDC". */
  paymentSymbol: string | null;
  /** Original payment amount in whole tokens (4dp) for non-native payments. */
  paymentAmount: string | null;
  buyTs: number | null;
  sellTs: number;
  buyTxHash: string | null;
  /** Sell transaction hash. */
  txHash: string | null;
  /** True when the FIFO book was empty at sell time (transfer/mint elsewhere). */
  unmatchedSell: boolean;
};

/** A still-held position (leftover FIFO book entry) marked at today's floor. */
export type ProfileOpenPosition = {
  chainId: number;
  contract: string;
  collectionSlug: string | null;
  name: string | null;
  imageUrl: string | null;
  tokenId: string | null;
  /** Entry cost in ETH — null when the buy was paid in an unpriced token. */
  costEth: string | null;
  entryTs: number;
  buyTxHash: string | null;
  /** Current collection floor in ETH — null when unpriced. */
  floorEth: string | null;
  /** floorEth − costEth — null when no floor is available. */
  unrealizedPnlEth: string | null;
};

/** Same aggregates as the top level, keyed by chainId (as string keys). */
export type ProfileChainBreakdown = {
  realizedPnlEth: string;
  unrealizedPnlEth: string | null;
  wins: number;
  losses: number;
  totalBuys: number;
  totalSells: number;
  /** Matched flips (non-null PnL). */
  flips: number;
  unmatchedSells: number;
  volumeEth: string;
  openCount: number;
};

/**
 * Aggregates for one period window. Realized stats come from flips whose
 * SELL timestamp is inside the window (PnL realizes at sale time — the entry
 * may be older); unrealized stats from open positions whose ENTRY is inside
 * the window, marked at the same current floors. `all` is the full history
 * (window anchored at `fetchedAt` for week3/week1).
 */
export type ProfilePeriodStats = {
  realizedPnlEth: string;
  /** Σ(floor − entry) over priced open positions entered in the window. */
  unrealizedPnlEth: string | null;
  wins: number;
  losses: number;
  winRatePct: number;
  /** Buy events in the window (flip entries + open-position entries). */
  buys: number;
  /** Sell events in the window (one per flip, incl. unmatched/unpriced). */
  sells: number;
  volumeEth: string;
  /** Open positions entered in the window. */
  openCount: number;
  /** Cumulative realized PnL within the window, by sell ts ascending. */
  equityCurve: Array<{ ts: number; pnlEth: string }>;
  /** Same windowed aggregates broken down per chain. */
  chains: Record<string, ProfileChainBreakdown>;
};

/** One aggregated current holding group (top-3 selection). */
export type ProfileHolding = {
  chainId: number;
  collectionSlug: string;
  /** Best display name — nft.name prefix or the collection slug. */
  name: string;
  /** First image seen in the group; null → placeholder tile. */
  imageUrl: string | null;
  /** NFTs currently held in this (chain, collection) group. */
  count: number;
  /** Current collection floor in ETH — null when unpriced. */
  floorEth: string | null;
  /** count × floor in ETH — null when the floor is unknown. */
  valueEth: string | null;
};

/** Aggregate counts over the whole holdings scan (not just the top 3). */
export type ProfileHoldingsTotals = {
  nftCount: number;
  collectionCount: number;
  /** Chains whose holdings endpoint answered successfully. */
  chainsScanned: number;
};

export type WalletProfile = {
  address: string;
  realizedPnlEth: string;
  /** Σ(floor − entry) over priced open positions; null when none priced. */
  unrealizedPnlEth: string | null;
  /** realized + unrealized (unrealized treated as 0 when null). */
  totalPnlEth: string;
  winRatePct: number;
  wins: number;
  losses: number;
  totalBuys: number;
  totalSells: number;
  volumeEth: string;
  openCount: number;
  unpricedOpenCount: number;
  unmatchedSells: number;
  chains: Record<string, ProfileChainBreakdown>;
  bestFlip: ProfileFlip | null;
  worstFlip: ProfileFlip | null;
  /** Capped (best-first, unmatched last). */
  flips: ProfileFlip[];
  /** Capped (priced by unrealized desc, unpriced last). */
  openPositions: ProfileOpenPosition[];
  /** Cumulative realized PnL over sell timestamps ascending. */
  equityCurve: Array<{ ts: number; pnlEth: string }>;
  firstActivityTs: number | null;
  lastActivityTs: number | null;
  /** ISO timestamp of the OpenSea fetch. */
  fetchedAt: string;
  /** Sale events pulled from the account-events endpoint. */
  eventsScanned: number;
  /** True when the page/time cap cut the history short. */
  truncated: boolean;
  /** Collections whose current floor was fetched for unrealized marks. */
  collectionsPriced: number;
  /** Sale events (buys + sells) converted from a token via the oracle. */
  oraclePricedCount: number;
  /**
   * Subset of oraclePricedCount converted at the nearest CURRENT rate
   * (historical price missing — marked ≈ in the UI). Optional: cached
   * payloads written before this field existed don't have it.
   */
  approxPricedCount?: number;
  /** Sale events whose token price couldn't be resolved (excluded from PnL). */
  unpricedSales: number;
  /** Distinct payment token symbols seen across the history, sorted. */
  paymentSymbols: string[];
  /** Period windows anchored at fetchedAt: 7d / 21d / all time. */
  periods: {
    all: ProfilePeriodStats;
    week3: ProfilePeriodStats;
    week1: ProfilePeriodStats;
  };
  /**
   * Top 3 current holdings (per chain+collection, ranked by est. value).
   * Optional: cached payloads written before this field existed don't have
   * it — the UI must tolerate its absence.
   */
  holdings?: ProfileHolding[];
  /** Totals over the full holdings scan. */
  holdingsTotals?: ProfileHoldingsTotals;
  /** True when at least one chain's holdings fetch failed. */
  holdingsPartial?: boolean;
  /** True when the holdings step was skipped for the soft time budget. */
  holdingsSkipped?: boolean;
};
