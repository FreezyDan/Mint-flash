/**
 * Shared MintDash bot types & constants.
 * Frontend imports from `@contracts/bot` — never from `api/`.
 * Row types (MintTask, BotWallet, WatchedWallet, Signal, ActivityLog,
 * UserSettings) are schema-inferred and re-exported from `@contracts/types`.
 */

export const TriggerModes = ["time", "poll", "event"] as const;
export type TriggerMode = (typeof TriggerModes)[number];

/** Mint-phase targeting: 'auto' detects on-chain, or force public/whitelist. */
export const MintPhases = ["auto", "public", "whitelist"] as const;
export type MintPhase = (typeof MintPhases)[number];

/** Merkle proof map: lowercase wallet address → bytes32[] proof. */
export type MerkleProofMap = Record<string, string[]>;

export const TaskStatuses = [
  "draft",
  "armed",
  "firing",
  "done",
  "failed",
  "cancelled",
] as const;
export type TaskStatus = (typeof TaskStatuses)[number];

export const SignalTypes = ["mint", "buy"] as const;
export type SignalType = (typeof SignalTypes)[number];

export const SignalStatuses = [
  "detected",
  "mirrored",
  "skipped",
  "failed",
] as const;
export type SignalStatus = (typeof SignalStatuses)[number];

export const ActivityLevels = ["info", "warn", "error", "success"] as const;
export type ActivityLevel = (typeof ActivityLevels)[number];

export const ActivitySources = ["mint", "copy", "sweep", "system"] as const;
export type ActivitySource = (typeof ActivitySources)[number];

export const Chains = [
  "ethereum",
  "base",
  "polygon",
  "arbitrum",
  "robinhood",
  "ink",
  "arc",
] as const;
export type Chain = (typeof Chains)[number];

/** Aggregate numbers for the dashboard overview card. */
export type OverviewStats = {
  tasksArmed: number;
  tasksTotal: number;
  walletsTracked: number;
  signalsToday: number;
  mirroredCount: number;
  /** Realized PnL (ETH) summed over mirrored signals — on-chain executions only. */
  pnlEth: string;
};

/** Aggregate copy-trading numbers. */
export type CopyStats = {
  mirroredCount: number;
  /** Realized PnL (ETH) summed over mirrored signals — on-chain executions only. */
  pnlEth: string;
};
