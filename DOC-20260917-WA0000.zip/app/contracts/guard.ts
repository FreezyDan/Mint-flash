/**
 * Shared types for the contract safety guard (competitor: Maestro anti-rug).
 * Frontend imports from `@contracts/guard` — never from `api/`.
 */

export type GuardLevel = "ok" | "warn" | "danger";

/** One named safety probe result. */
export type GuardCheck = {
  /** Stable machine name, e.g. "bytecode", "proxy", "mint-selector", "opensea". */
  name: string;
  level: GuardLevel;
  /** Human-readable explanation of what was found. */
  detail: string;
};

/** Full report; `level` is the worst check level. */
export type GuardReport = {
  level: GuardLevel;
  checks: GuardCheck[];
};

const LEVEL_RANK: Record<GuardLevel, number> = { ok: 0, warn: 1, danger: 2 };

/** Worst level across a set of checks ("ok" for an empty set). */
export function worstGuardLevel(checks: GuardCheck[]): GuardLevel {
  let worst: GuardLevel = "ok";
  for (const c of checks) {
    if (LEVEL_RANK[c.level] > LEVEL_RANK[worst]) worst = c.level;
  }
  return worst;
}
