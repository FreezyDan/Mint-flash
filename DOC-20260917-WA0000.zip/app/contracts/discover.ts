/**
 * Shared types for the on-chain trader discovery feature
 * (Seaport OrderFulfilled scanner). Frontend imports from
 * `@contracts/discover` — never from `api/`.
 */

/** Summary returned by a fresh chain scan. */
export type ScanSummary = {
  chainId: number;
  fromBlock: number;
  toBlock: number;
  scannedBlocks: number;
  logsFound: number;
  /** Mint (Transfer-from-zero) logs matched against in-window sales. */
  mintLogsFound: number;
  /** Unique mint transactions fetched via eth_getTransactionByHash. */
  txsFetched: number;
  /** Mint→sell flips detected (mint cost attribution applied). */
  mintFlips: number;
  /** Unsold in-window acquisitions stored as open positions. */
  openPositions: number;
  tradersStored: number;
  partial: boolean;
  durationMs: number;
  endpointSource: "custom" | "auto";
};

/**
 * Result of discover.scan — either a fresh ScanSummary or a cached
 * placeholder when the chain was scanned less than 10 minutes ago.
 */
export type DiscoverScanResult =
  | ({ cached: false; scannedAt: Date } & ScanSummary)
  | {
      cached: true;
      chainId: number;
      scannedAt: Date | null;
      tradersStored: number;
      fromBlock: number | null;
      toBlock: number | null;
    };

/** Per-chain stats for the discover tab's chain chips. */
export type DiscoverChainStat = {
  chainId: number;
  traders: number;
  lastScannedAt: Date | null;
};

/**
 * One row of the public leaderboard — output of the on-chain scanner
 * (discovered_traders). Public blockchain data; safe to serve unauthenticated.
 */
export type PublicLeaderboardRow = {
  rank: number;
  address: string;
  chainId: number;
  realizedPnlEth: string;
  unrealizedPnlEth: string | null;
  /** realized + unrealized (unrealized null counts as 0). */
  totalPnlEth: string;
  winRatePct: string;
  flips: number;
  openPositions: number;
  scannedAt: Date;
};

/**
 * One recent engine detection from the signals table, stripped of any
 * user/wallet-ownership fields — collection, chain-agnostic, public.
 */
export type PublicSignal = {
  id: number;
  type: string;
  contractAddress: string;
  tokenId: string | null;
  collectionName: string | null;
  priceEth: string | null;
  txHash: string | null;
  status: string;
  detectedAt: Date;
};

/**
 * Wallet behavior label ids, in display/importance order. Computed by the
 * chain scanner (api/engine/walletLabels.ts) from the aggregates it already
 * derives, stored as a JSON array string in discovered_traders.labels and
 * surfaced to clients as a parsed string[]. Rules:
 *  - smart-money : win rate ≥ 60% AND ≥ 10 flips AND realized PnL > 0
 *  - sniper      : mint flips ≥ 60% of flips AND ≥ 5 flips
 *  - whale       : total volume (spend + proceeds) ≥ 25 ETH
 *  - fresh       : first observed activity < 30 days before scan end
 *  - flipper     : avg hold < 24h across ≥ 3 flips
 *  - diamond     : avg hold > 720h (30d) across ≥ 2 flips
 *  - bagholder   : ≥ 5 open positions AND unrealized PnL < 0
 */
export const WALLET_LABELS = [
  "smart-money",
  "sniper",
  "whale",
  "fresh",
  "flipper",
  "diamond",
  "bagholder",
] as const;

export type WalletLabel = (typeof WALLET_LABELS)[number];

/** Aggregate scan coverage for honest marketing stats. */
export type PublicScanStats = {
  tradersScanned: number;
  chainsScanned: number;
  lastScannedAt: Date | null;
};
