import { describe, expect, it } from "vitest";
import {
  ChainKeyToId,
  ExplorerBaseUrls,
  NATIVE_SYMBOLS,
  RpcEndpoints,
  explorerTxUrl,
  nativeSymbol,
} from "./rpc";

describe("chain constants", () => {
  it("arc is chain 5042 with USDC as the native symbol", () => {
    expect(ChainKeyToId.arc).toBe(5042);
    expect(nativeSymbol(5042)).toBe("USDC");
    expect(NATIVE_SYMBOLS[5042]).toBe("USDC");
  });

  it("nativeSymbol defaults to ETH on every other chain", () => {
    for (const id of Object.values(ChainKeyToId)) {
      if (id !== 5042) expect(nativeSymbol(id)).toBe("ETH");
    }
    expect(nativeSymbol(999999)).toBe("ETH");
  });

  it("every supported chain has ≥2 RPC endpoints and an explorer", () => {
    for (const id of Object.values(ChainKeyToId)) {
      expect(RpcEndpoints[id]?.length ?? 0).toBeGreaterThanOrEqual(2);
      expect(ExplorerBaseUrls[id]).toMatch(/^https:\/\//);
      expect(explorerTxUrl(id, "0xabc")).toContain("/tx/0xabc");
    }
  });

  it("no pool contains a known-dead endpoint", () => {
    const dead = [
      "eth.llamarpc.com",
      "polygon-rpc.com",
      "rpc-gel.inkonchain.com",
      "robinhood.rpc.blxrbdn.com",
      "robinhood-rpc.publicnode.com",
      "ankr.com",
    ];
    for (const urls of Object.values(RpcEndpoints)) {
      for (const url of urls) {
        for (const d of dead) expect(url).not.toContain(d);
      }
    }
  });
});
