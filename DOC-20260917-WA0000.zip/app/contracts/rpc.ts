/**
 * Shared RPC constants — public endpoint pools per chain + racing types.
 * Frontend imports from `@contracts/rpc` — never from `api/`.
 */
import type { Chain } from "./bot";

/** Map a chain key (as stored on watched wallets / tasks) to its EVM chain id. */
export const ChainKeyToId: Record<Chain, number> = {
  ethereum: 1,
  base: 8453,
  polygon: 137,
  arbitrum: 42161,
  robinhood: 4663,
  ink: 57073,
  arc: 5042,
};

/**
 * Public HTTPS RPC endpoint pools, keyed by chain id. Every entry was
 * live-verified with a keyless `eth_chainId` POST (ankr.com endpoints were
 * dropped — they now require an API key; polygon-rpc.com disabled keyless
 * access). Endpoint health is re-checked live by api/engine/rpcManager.ts.
 */
export const RpcEndpoints: Record<number, string[]> = {
  1: [
    // eth.llamarpc.com dead (Cloudflare 525).
    "https://ethereum-rpc.publicnode.com",
    "https://cloudflare-eth.com",
    "https://eth.drpc.org",
    "https://eth.rpc.blxrbdn.com",
    "https://rpc.mevblocker.io",
  ],
  8453: [
    "https://mainnet.base.org",
    "https://base-rpc.publicnode.com",
    "https://base.drpc.org",
  ],
  137: [
    "https://polygon.drpc.org",
    "https://polygon-bor-rpc.publicnode.com",
    "https://1rpc.io/matic",
  ],
  42161: [
    "https://arb1.arbitrum.io/rpc",
    "https://arbitrum-one-rpc.publicnode.com",
    "https://arbitrum.drpc.org",
  ],
  4663: [
    "https://rpc.mainnet.chain.robinhood.com",
    // robinhood-rpc.publicnode.com: eth_getLogs token-gated ("Archive requests
    // require a personal token"); robinhood.rpc.blxrbdn.com: 403s eth_getLogs.
    "https://robinhood.drpc.org",
  ],
  57073: [
    // rpc-gel.inkonchain.com is dead (empty responses).
    "https://rpc-qnd.inkonchain.com",
    "https://ink.drpc.org",
    "https://ink-rpc.publicnode.com",
    "https://57073.rpc.thirdweb.com",
  ],
  5042: [
    // Arc (Circle USDC-gas L1, mainnet launched 2026-09-16) — all verified.
    "https://rpc.mainnet.arc.io",
    "https://rpc.drpc.mainnet.arc.io",
    "https://rpc.blockdaemon.mainnet.arc.io",
    "https://rpc.quicknode.mainnet.arc.io",
    "https://5042.rpc.thirdweb.com",
  ],
};

/** Result of racing one endpoint. latencyMs is null on timeout/failure. */
export type RpcRaceResult = {
  url: string;
  latencyMs: number | null;
  ok: boolean;
};

/** Which endpoint won and where it came from. */
export type ResolvedRpc = {
  url: string;
  source: "custom" | "auto";
};

/** Public block-explorer base URLs, keyed by chain id. */
export const ExplorerBaseUrls: Record<number, string> = {
  1: "https://etherscan.io",
  8453: "https://basescan.org",
  137: "https://polygonscan.com",
  42161: "https://arbiscan.io",
  4663: "https://robinhoodchain.blockscout.com",
  57073: "https://explorer.inkonchain.com",
  // explorer.arc.io is the official one but sits behind Cloudflare Access for
  // now; arcexplorer.io is live and serves /tx/<hash> pages.
  5042: "https://arcexplorer.io",
};

/** Explorer URL for a transaction, or null when the chain has no known explorer. */
export function explorerTxUrl(chainId: number, txHash: string): string | null {
  const base = ExplorerBaseUrls[chainId];
  return base ? `${base}/tx/${txHash}` : null;
}

/**
 * Native currency symbol per chain id. Arc's native gas token is USDC
 * (18 decimals, $1-pegged) — values denominated in the native token there
 * are dollars, not ETH. Every other supported chain uses ETH.
 */
export const NATIVE_SYMBOLS: Record<number, string> = {
  5042: "USDC",
};

/** Display symbol for a chain's native token. */
export function nativeSymbol(chainId: number): string {
  return NATIVE_SYMBOLS[chainId] ?? "ETH";
}
