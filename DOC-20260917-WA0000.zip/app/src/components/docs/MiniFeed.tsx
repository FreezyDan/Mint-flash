import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import LivePulseDot from "@/components/LivePulseDot";

interface FeedRow {
  id: number;
  text: string;
  tone: "green" | "violet" | "cyan";
}

const SCRIPT: Omit<FeedRow, "id">[] = [
  { text: "✓ MINT CONFIRMED  PixelWraiths #4412  0.08 ETH", tone: "green" },
  { text: "⚡ TASK FIRED  BasePunks Deriv  12 wallets", tone: "violet" },
  { text: "⧉ COPIED  goblinmode → Azuki #8841  +0.84 ETH est.", tone: "cyan" },
  { text: "✓ MINT CONFIRMED  Degen Apes S2 #0901  0.05 ETH", tone: "green" },
  { text: "⧉ COPIED  0x7a3F…9e2B → Neon Kanji #221  +0.31 ETH est.", tone: "cyan" },
];

const TONE_CLS = { green: "text-neon", violet: "text-violet", cyan: "text-cyan" } as const;

/**
 * Mini 3-row live feed (quickstart step 4) — rows insert every ~2.4s with
 * slide-in + green flash once the block scrolls into view.
 */
export default function MiniFeed() {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  const [rows, setRows] = useState<FeedRow[]>([]);
  const counter = useRef(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setActive(true);
          obs.disconnect();
        }
      },
      { threshold: 0.4 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!active) return;
    const push = () => {
      const next = SCRIPT[counter.current % SCRIPT.length];
      counter.current += 1;
      setRows((prev) => [...prev.slice(-2), { ...next, id: counter.current }]);
    };
    push();
    const t = setInterval(push, 2400);
    return () => clearInterval(t);
  }, [active]);

  return (
    <div ref={ref} className="overflow-hidden rounded-lg border border-hairline bg-void">
      <div className="flex items-center gap-2 border-b border-hairline bg-panel2/60 px-4 py-2.5">
        <LivePulseDot />
        <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-tmut">
          live fills — your dashboard
        </span>
      </div>
      <div className="flex h-[104px] flex-col justify-end gap-1 p-4 font-mono text-[12.5px]">
        <AnimatePresence initial={false}>
          {rows.map((r) => (
            <motion.p
              key={r.id}
              initial={{ opacity: 0, x: 20, backgroundColor: "rgba(57,255,142,0.10)" }}
              animate={{ opacity: 1, x: 0, backgroundColor: "rgba(57,255,142,0)" }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className={TONE_CLS[r.tone]}
            >
              {r.text}
            </motion.p>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
