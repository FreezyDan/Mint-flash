import { useEffect, useRef, useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

export type CodeLineTone = "prompt" | "out" | "success" | "cyan" | "amber" | "key" | "str";

export interface CodeLine {
  text: string;
  tone: CodeLineTone;
}

const TONE_CLS: Record<CodeLineTone, string> = {
  prompt: "text-tpri",
  out: "text-tsec",
  success: "text-neon",
  cyan: "text-cyan",
  amber: "text-amber",
  key: "text-violet",
  str: "text-neon",
};

interface CodeBlockProps {
  lines: CodeLine[];
  /** Type lines character-by-character once 60% visible (15ms/char). */
  typing?: boolean;
  className?: string;
  /** Raw text copied by the copy button (defaults to all line text). */
  copyText?: string;
}

/**
 * Docs code/terminal block — bg-void inner panel, hairline, mono 13px,
 * `$` prompts in violet, hover copy button with "copied" feedback.
 */
export default function CodeBlock({ lines, typing = false, className, copyText }: CodeBlockProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(!typing);
  const [visibleCount, setVisibleCount] = useState(typing ? 0 : lines.length);
  const [typingText, setTypingText] = useState("");
  const [copied, setCopied] = useState(false);

  // Start typing when 60% visible, once.
  useEffect(() => {
    if (!typing || started) return;
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setStarted(true);
          obs.disconnect();
        }
      },
      { threshold: 0.6 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [typing, started]);

  useEffect(() => {
    if (!typing || !started) return;
    let line = 0;
    let char = 0;
    let timer: ReturnType<typeof setTimeout>;
    const step = () => {
      if (line >= lines.length) return;
      const current = lines[line];
      if (char < current.text.length) {
        char += 1;
        setTypingText(current.text.slice(0, char));
        timer = setTimeout(step, 15);
      } else {
        setVisibleCount(line + 1);
        setTypingText("");
        line += 1;
        char = 0;
        timer = setTimeout(step, 160);
      }
    };
    timer = setTimeout(step, 120);
    return () => clearTimeout(timer);
  }, [typing, started, lines]);

  const done = visibleCount >= lines.length;

  return (
    <div
      ref={ref}
      className={cn(
        "group relative overflow-hidden rounded-lg border border-hairline bg-void",
        className,
      )}
    >
      <button
        type="button"
        title="Copy"
        onClick={() => {
          navigator.clipboard
            ?.writeText(copyText ?? lines.map((l) => l.text).join("\n"))
            .catch(() => {});
          setCopied(true);
          setTimeout(() => setCopied(false), 1200);
        }}
        className="absolute right-2.5 top-2.5 z-10 rounded-md border border-hairline bg-panel2 p-1.5 text-tmut opacity-0 transition-all hover:text-tpri group-hover:opacity-100"
      >
        {copied ? <Check className="h-3.5 w-3.5 text-neon" /> : <Copy className="h-3.5 w-3.5" />}
      </button>
      {copied && (
        <span className="absolute right-10 top-3 z-10 font-mono text-[10px] text-neon">
          copied
        </span>
      )}
      <div className="flex flex-col gap-1 p-4 font-mono text-[13px] leading-relaxed">
        {lines.slice(0, visibleCount).map((l, i) => (
          <p key={i} className={cn("whitespace-pre-wrap", TONE_CLS[l.tone])}>
            {l.tone === "prompt" ? (
              <>
                <span className="mr-2 text-violet">$</span>
                {l.text}
              </>
            ) : (
              l.text
            )}
          </p>
        ))}
        {typing && started && !done && (
          <p className="whitespace-pre-wrap text-tpri">
            {lines[visibleCount]?.tone === "prompt" && <span className="mr-2 text-violet">$</span>}
            {typingText}
            <span className="ml-0.5 inline-block h-3.5 w-2 translate-y-0.5 animate-caret-blink bg-neon" />
          </p>
        )}
      </div>
    </div>
  );
}
