import { useEffect, useRef, useState } from "react";
import { animate, motion } from "framer-motion";
import { cn } from "@/lib/utils";

/** Single odometer digit — vertical 0–9 column that rolls to the target. */
function Digit({ d, className }: { d: number; className?: string }) {
  return (
    <span className={cn("inline-block h-[1em] overflow-hidden leading-none", className)}>
      <motion.span
        className="flex flex-col"
        animate={{ y: `-${d}em` }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      >
        {Array.from({ length: 10 }, (_, i) => (
          <span key={i} className="flex h-[1em] items-center justify-center leading-none">
            {i}
          </span>
        ))}
      </motion.span>
    </span>
  );
}

/** Price text with odometer-rolling digits (300ms). Non-digit chars render as-is. */
export function Odometer({ text, className }: { text: string; className?: string }) {
  return (
    <span className={cn("inline-flex leading-none", className)} aria-label={text}>
      {text.split("").map((ch, i) =>
        /\d/.test(ch) ? (
          <Digit key={i} d={Number(ch)} />
        ) : (
          <span key={i} className="leading-none">
            {ch}
          </span>
        ),
      )}
    </span>
  );
}

/** Numeric value that rolls (200ms) to its target whenever it changes. */
export function RollingValue({
  value,
  format,
  className,
}: {
  value: number;
  format: (v: number) => string;
  className?: string;
}) {
  const [display, setDisplay] = useState(value);
  const prev = useRef(value);

  useEffect(() => {
    const from = prev.current;
    prev.current = value;
    if (from === value) return;
    const controls = animate(from, value, {
      duration: 0.2,
      ease: "easeOut",
      onUpdate: (v) => setDisplay(v),
    });
    return () => controls.stop();
  }, [value]);

  return <span className={cn("tnum", className)}>{format(display)}</span>;
}
