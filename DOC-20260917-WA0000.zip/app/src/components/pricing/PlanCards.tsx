import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { ButtonLink } from "@/components/Button";
import { cn } from "@/lib/utils";
import { Odometer } from "./Odometer";

export type Billing = "monthly" | "quarterly";

/** S1 billing toggle — sliding pill indicator (layoutId, 250ms spring). */
export function BillingToggle({ billing, onChange }: { billing: Billing; onChange: (b: Billing) => void }) {
  const opts: { id: Billing; label: string }[] = [
    { id: "monthly", label: "Monthly" },
    { id: "quarterly", label: "Quarterly (−20%)" },
  ];
  return (
    <div className="inline-flex items-center gap-1 rounded-full border border-hairline bg-panel p-1">
      {opts.map((o) => {
        const active = billing === o.id;
        return (
          <button
            key={o.id}
            onClick={() => onChange(o.id)}
            className={cn(
              "relative rounded-full px-4 py-2 font-mono text-xs font-medium transition-colors duration-200",
              active ? "text-white" : "text-tmut hover:text-tsec",
            )}
          >
            {active && (
              <motion.span
                layoutId="billing-pill"
                transition={{ type: "spring", stiffness: 400, damping: 32 }}
                className="absolute inset-0 rounded-full bg-violet"
              />
            )}
            <span className="relative z-10">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

interface Plan {
  tier: string;
  name: string;
  pitch: string;
  features: string[];
  cta: string;
  variant: "ghost" | "primary" | "success";
}

const PLANS: Plan[] = [
  {
    tier: "Free",
    name: "Scout",
    pitch: "Watch the floor and take your first shots.",
    features: [
      "1 active task",
      "3 wallets",
      "Community snipers only",
      "Public RPC speed",
      "Basic risk scan",
    ],
    cta: "Start free",
    variant: "ghost",
  },
  {
    tier: "Pro",
    name: "Sniper",
    pitch: "The full mint engine, plus copy trading on everything.",
    features: [
      "Unlimited tasks",
      "25 wallets",
      "Copy any sniper",
      "Anti-Rug Shield full scans",
      "Dynamic gas warfare",
      "Failed-gas reimbursement",
      "Priority support",
    ],
    cta: "Go Pro",
    variant: "primary",
  },
  {
    tier: "Whale",
    name: "God Mode",
    pitch: "Private infrastructure for wallets that move markets.",
    features: [
      "Everything in Pro",
      "50 wallets/task",
      "Private mempool routing + builder bundles",
      "God-mode gas",
      "Dedicated RPC node",
      "1-on-1 strategy onboarding",
      "API access",
    ],
    cta: "Go Whale",
    variant: "success",
  },
];

/** S2 plan cards — stagger up 120ms, popular card lands last at 1.03 scale. */
export default function PlanCards({ billing }: { billing: Billing }) {
  // entrance order: Scout (0), Whale (1), Sniper last (2)
  const delays = [0, 0.24, 0.12];

  return (
    <section className="container-x pb-16 md:pb-24">
      <div className="grid items-start gap-6 md:grid-cols-3">
        {PLANS.map((p, i) => {
          const popular = i === 1;
          const whale = i === 2;
          return (
            <motion.div
              key={p.name}
              initial={{ opacity: 0, y: 28, scale: popular ? 0.98 : 1 }}
              whileInView={{ opacity: 1, y: 0, scale: popular ? 1.03 : 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={
                popular
                  ? { type: "spring", stiffness: 220, damping: 22, delay: delays[i] }
                  : { duration: 0.5, delay: delays[i], ease: [0.16, 1, 0.3, 1] }
              }
              className={cn(
                "relative rounded-xl border bg-panel p-8",
                popular ? "z-10 border-violet shadow-glow-violet-lg" : "border-hairline",
                whale && "overflow-hidden",
              )}
            >
              {/* Whale background — dark liquid metal at 25%, slow pan */}
              {whale && (
                <motion.div
                  aria-hidden
                  className="pointer-events-none absolute -inset-6 rounded-xl bg-cover bg-center opacity-25"
                  style={{ backgroundImage: "url(/pricing-whale-bg.png)" }}
                  animate={{ x: [0, 20, 0], y: [0, -12, 0] }}
                  transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
                />
              )}
              {popular && (
                <motion.span
                  animate={{ opacity: [0.75, 1, 0.75] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-g-brand px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-[0.18em] text-white"
                >
                  Most popular
                </motion.span>
              )}

              <div className={cn("relative", whale && "z-10")}>
                <p className="font-mono text-xs font-medium uppercase tracking-[0.2em] text-tmut">
                  {p.tier} — <span className={popular ? "text-violet" : whale ? "text-neon" : "text-tsec"}>{p.name}</span>
                </p>

                {/* Price */}
                <div className="mt-5 flex items-baseline gap-2">
                  {whale ? (
                    <>
                      <span className="tnum font-mono text-[44px] font-bold leading-none text-tpri">0.5 ETH</span>
                      <span className="font-mono text-sm text-tmut">/quarter</span>
                    </>
                  ) : (
                    <>
                      <Odometer
                        text={i === 0 ? "$0" : billing === "monthly" ? "$99" : "$79"}
                        className="tnum font-mono text-[44px] font-bold text-tpri"
                      />
                      <span className="font-mono text-sm text-tmut">{i === 0 ? "forever" : "/mo"}</span>
                    </>
                  )}
                </div>

                <p className="mt-3 text-[15px] text-tsec">{p.pitch}</p>
                <div className="my-6 h-px bg-hairline" />

                {/* Features */}
                <ul className="space-y-2.5">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-[14.5px] text-tsec">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-neon" />
                      {f}
                    </li>
                  ))}
                </ul>

                <ButtonLink to="/app" variant={p.variant} className="mt-8 w-full">
                  {p.cta}
                </ButtonLink>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
