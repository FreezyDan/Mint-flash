import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQS = [
  {
    q: "Is there a per-mint fee?",
    a: "Not on Pro or Whale — you pay the flat plan price and keep every wei of upside. Scout is free but takes 2% of the mint price per fill, so it pays for itself the moment you outgrow it.",
  },
  {
    q: "What does \"failed-gas reimbursement\" mean?",
    a: "When a mint transaction lands but doesn't fill — outbid in a gas war, sellout mid-flight, contract revert — the gas you burned is credited back to your MintDash balance automatically on Pro and Whale. No tickets, no claims.",
  },
  {
    q: "Can I pay in crypto?",
    a: "Yes. We accept ETH, SOL, and USDC. Quarterly Whale plans are billed in ETH directly from the wallet you connect — no card, no invoice.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Anytime, in one click. Your plan stays active until the end of the billing period and your tasks keep running until then. No lock-ins, no exit fees, no \"retention specialist\" emails.",
  },
  {
    q: "What happens to my tasks if I downgrade?",
    a: "Tasks beyond your new plan's limits are paused, never deleted — your contracts, gas settings, and copy configurations are preserved. Re-arm them anytime by upgrading again.",
  },
];

/** S5 pricing FAQ — accordion, rows stagger 60ms on entry. */
export default function PricingFAQ() {
  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-10"
      >
        <p className="eyebrow eyebrow-green">[ PRICING FAQ ]</p>
        <h2 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          No surprises in the fine print.
        </h2>
      </motion.div>

      <div className="card-base p-0 px-6">
        <Accordion type="single" collapsible>
          {FAQS.map((f, i) => (
            <motion.div
              key={f.q}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.4, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
            >
              <AccordionItem value={`item-${i}`} className="border-hairline">
                <AccordionTrigger className="py-5 text-left font-display text-[17px] font-semibold text-tpri hover:text-neon hover:no-underline [&[data-state=open]>svg]:rotate-180">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-[15px] leading-relaxed text-tsec">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
