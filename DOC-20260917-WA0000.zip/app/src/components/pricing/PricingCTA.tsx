import { motion } from "framer-motion";
import { ButtonLink } from "@/components/Button";

/** S6 pricing CTA band — variant copy; "Compare plans" scrolls to the table. */
export default function PricingCTA() {
  return (
    <section className="relative overflow-hidden border-t border-hairline">
      <div className="pointer-events-none absolute inset-0 bg-g-hero-glow" aria-hidden />
      <div className="container-x relative py-24 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="eyebrow eyebrow-violet mb-6">[ START SNIPING ]</p>
          <h2 className="mx-auto max-w-2xl text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
            Your first snipe is free.
          </h2>
          <p className="mx-auto mt-4 max-w-md text-[17px] text-tsec">
            Arm a Scout task in under two minutes. Upgrade only when the wins
            start stacking.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <ButtonLink to="/app">Start with Scout</ButtonLink>
            <button
              onClick={() => document.getElementById("compare")?.scrollIntoView({ behavior: "smooth" })}
              className="rounded-lg border border-hairline px-6 py-3 text-[15px] font-semibold text-tpri transition-all duration-150 hover:border-violet/60 hover:bg-white/5 active:scale-[0.97]"
            >
              Compare plans
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
