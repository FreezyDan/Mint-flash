import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Slider } from "@/components/ui/slider";
import { PRO_PRICE_USD } from "@contracts/plans";
import { cn } from "@/lib/utils";
import { RollingValue } from "./Odometer";

type PlanId = "free" | "pro";

const PLAN_CHIPS: { id: PlanId; label: string }[] = [
  { id: "free", label: "Free" },
  { id: "pro", label: "Pro" },
];

/**
 * S3 fee calculator — every output is plain arithmetic on numbers the user
 * enters plus the flat published plan price. No assumed win rates, no
 * example outcomes.
 */
export default function FeeCalculator() {
  const [mints, setMints] = useState(48);
  const [avgPrice, setAvgPrice] = useState(0.08);
  const [plan, setPlan] = useState<PlanId>("pro");

  const calc = useMemo(() => {
    const volume = mints * avgPrice; // ETH / month, from user inputs
    const costUsd = plan === "pro" ? PRO_PRICE_USD : 0;
    const perMintUsd = mints > 0 ? costUsd / mints : 0;
    return { volume, costUsd, perMintUsd };
  }, [mints, avgPrice, plan]);

  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 32 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-xl border border-hairline bg-panel p-8 md:p-10"
      >
        <div
          className="pointer-events-none absolute -right-40 -top-40 h-[480px] w-[480px] rounded-full bg-g-hero-glow opacity-50"
          aria-hidden
        />
        <div className="relative grid gap-10 lg:grid-cols-2">
          {/* Controls */}
          <div>
            <p className="eyebrow eyebrow-violet">[ FEE CALCULATOR ]</p>
            <h2 className="mt-4 text-[26px] font-bold leading-[1.1] tracking-[-0.025em] md:text-3xl">
              Run your numbers.
            </h2>

            <div className="mt-8 space-y-7">
              <div>
                <div className="mb-3 flex items-center justify-between">
                  <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
                    Mints per month
                  </span>
                  <RollingValue value={mints} format={(v) => String(Math.round(v))} className="font-mono text-sm text-tpri" />
                </div>
                <Slider value={[mints]} onValueChange={([v]) => setMints(v)} min={1} max={200} step={1} />
              </div>

              <div>
                <div className="mb-3 flex items-center justify-between">
                  <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
                    Avg mint price
                  </span>
                  <RollingValue value={avgPrice} format={(v) => `${v.toFixed(2)} ETH`} className="font-mono text-sm text-tpri" />
                </div>
                <Slider value={[avgPrice]} onValueChange={([v]) => setAvgPrice(v)} min={0.01} max={1} step={0.01} />
              </div>

              <div className="flex items-center justify-between">
                <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">Plan</span>
                <span className="flex gap-2">
                  {PLAN_CHIPS.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setPlan(p.id)}
                      className={cn(
                        "rounded-full border px-3.5 py-1.5 font-mono text-xs transition-colors duration-150",
                        plan === p.id
                          ? "border-violet bg-violet text-white"
                          : "border-hairline text-tmut hover:border-violet/40 hover:text-tsec",
                      )}
                    >
                      {p.label}
                    </button>
                  ))}
                </span>
              </div>
            </div>
          </div>

          {/* Readout */}
          <div className="flex flex-col justify-center rounded-xl border border-hairline bg-void/50 p-6 md:p-8">
            <div className="space-y-5">
              <div>
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
                  Est. monthly volume
                </p>
                <p className="mt-1 font-mono text-2xl font-bold text-tpri">
                  <RollingValue value={calc.volume} format={(v) => `${v.toFixed(2)} ETH`} />
                </p>
              </div>
              <div>
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
                  MintDash cost
                </p>
                <p className="mt-1 font-mono text-2xl font-bold text-tpri">
                  <RollingValue value={calc.costUsd} format={(v) => `$${Math.round(v)}`} />
                  <span className="ml-2 text-sm font-medium text-tmut">/ month, flat</span>
                </p>
              </div>
              <div>
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
                  Cost per mint
                </p>
                <p className="mt-1 font-mono text-2xl font-bold text-tpri">
                  <RollingValue value={calc.perMintUsd} format={(v) => `$${v.toFixed(2)}`} />
                </p>
              </div>
            </div>
            <div className="mt-6 border-t border-hairline pt-5">
              <p className="text-[15px] text-tpri">
                Pro is a flat ${PRO_PRICE_USD}/mo — no per-trade fees, no cut of your PnL. Gas is
                paid by your vault on every real transaction.
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
