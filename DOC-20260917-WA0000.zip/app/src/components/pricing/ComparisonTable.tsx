import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

type Cell = { kind: "check" } | { kind: "dash" } | { kind: "value"; v: string };

const check: Cell = { kind: "check" };
const dash: Cell = { kind: "dash" };
const val = (v: string): Cell => ({ kind: "value", v });

const GROUPS: { label: string; rows: { feature: string; cells: [Cell, Cell, Cell] }[] }[] = [
  {
    label: "Execution",
    rows: [
      { feature: "Active tasks", cells: [val("1"), val("Unlimited"), val("Unlimited")] },
      { feature: "Wallets per task", cells: [val("3"), val("25"), val("50")] },
      { feature: "Gas warfare", cells: [dash, check, val("God-mode")] },
      { feature: "Private mempool routing", cells: [dash, dash, check] },
      { feature: "Builder bundles", cells: [dash, dash, check] },
    ],
  },
  {
    label: "Copy trading",
    rows: [
      { feature: "Community snipers", cells: [check, check, check] },
      { feature: "Any verified sniper", cells: [dash, check, check] },
      { feature: "Mirror sells", cells: [dash, check, check] },
      { feature: "Stop-loss auto-unfollow", cells: [dash, check, check] },
    ],
  },
  {
    label: "Safety",
    rows: [
      { feature: "Basic risk scan", cells: [check, check, check] },
      { feature: "Full Anti-Rug Shield", cells: [dash, check, check] },
      { feature: "Failed-gas reimbursement", cells: [dash, check, check] },
    ],
  },
  {
    label: "Platform",
    rows: [
      { feature: "API access", cells: [dash, dash, check] },
      { feature: "Dedicated RPC", cells: [dash, dash, check] },
      { feature: "Support", cells: [val("community"), val("priority"), val("1-on-1")] },
    ],
  },
];

function CellView({ c }: { c: Cell }) {
  if (c.kind === "check") return <Check className="mx-auto h-4 w-4 text-neon" />;
  if (c.kind === "dash") return <span className="font-mono text-sm text-tmut">—</span>;
  return <span className="tnum font-mono text-sm text-tpri">{c.v}</span>;
}

/** S4 comparison table — sticky header, Sniper column tinted violet/5. */
export default function ComparisonTable() {
  return (
    <section id="compare" className="container-x scroll-mt-24 py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-10"
      >
        <p className="eyebrow eyebrow-green">[ COMPARE PLANS ]</p>
        <h2 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Every feature, side by side.
        </h2>
      </motion.div>

      <div className="card-base overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-left">
          <thead>
            <tr className="border-b border-hairline">
              <th className="sticky top-16 z-20 bg-panel px-6 py-4 font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-tmut">
                Feature
              </th>
              {["Scout", "Sniper", "Whale"].map((n, i) => (
                <th
                  key={n}
                  className={cn(
                    "sticky top-16 z-20 bg-panel px-4 py-4 text-center font-mono text-[11px] font-medium uppercase tracking-[0.14em]",
                    i === 1 ? "bg-violet/5 text-violet" : "text-tmut",
                  )}
                >
                  {n}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {GROUPS.map((g) => (
              <GroupRows key={g.label} label={g.label} rows={g.rows} />
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function GroupRows({
  label,
  rows,
}: {
  label: string;
  rows: { feature: string; cells: [Cell, Cell, Cell] }[];
}) {
  return (
    <>
      <tr className="border-b border-hairline/60 bg-void/40">
        <td colSpan={4} className="px-6 py-2.5 font-mono text-[11px] font-medium uppercase tracking-[0.18em] text-tmut">
          {label}
        </td>
      </tr>
      {rows.map((r, i) => (
        <motion.tr
          key={r.feature}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.35, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
          className="border-b border-hairline/60 transition-colors last:border-0 hover:bg-panel2"
        >
          <td className="px-6 py-3.5 text-sm text-tsec">{r.feature}</td>
          {r.cells.map((c, i) => (
            <td key={i} className={cn("px-4 py-3.5 text-center", i === 1 && "bg-violet/5")}>
              <CellView c={c} />
            </td>
          ))}
        </motion.tr>
      ))}
    </>
  );
}
