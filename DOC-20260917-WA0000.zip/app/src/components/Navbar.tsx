import { useState } from "react";
import { Link, NavLink } from "react-router";
import { AnimatePresence, motion } from "framer-motion";
import { LogOut, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { LOGIN_PATH } from "@/const";
import LivePulseDot from "./LivePulseDot";

/** Auth-aware account area — rewired from AUTH-SLOT to useAuth() in the backend graft. */
function AuthArea() {
  const { user, isLoading, logout } = useAuth();
  if (isLoading) {
    return <span className="hidden h-5 w-16 animate-pulse rounded bg-panel-2 sm:block" />;
  }
  if (!user) {
    return (
      <Link
        to={LOGIN_PATH}
        className="hidden text-sm font-medium text-tsec transition-colors hover:text-tpri sm:block"
      >
        Sign in
      </Link>
    );
  }
  return (
    <span className="hidden items-center gap-3 sm:flex">
      <span className="max-w-28 truncate font-mono text-xs text-tsec">
        {user.name || "Account"}
      </span>
      <button
        onClick={() => logout()}
        title="Sign out"
        className="text-tmut transition-colors hover:text-tpri"
      >
        <LogOut className="h-4 w-4" />
      </button>
    </span>
  );
}

/** Mobile menu variant of the auth area. */
function AuthAreaMobile({ onNavigate }: { onNavigate: () => void }) {
  const { user, isLoading, logout } = useAuth();
  if (isLoading) {
    return <span className="h-12 animate-pulse rounded-lg bg-panel-2" />;
  }
  if (!user) {
    return (
      <Link
        to={LOGIN_PATH}
        onClick={onNavigate}
        className="rounded-lg border border-hairline px-6 py-3 text-center text-[15px] font-semibold text-tpri"
      >
        Sign in
      </Link>
    );
  }
  return (
    <button
      onClick={() => {
        logout();
        onNavigate();
      }}
      className="flex items-center justify-center gap-2 rounded-lg border border-hairline px-6 py-3 text-[15px] font-semibold text-tpri"
    >
      <LogOut className="h-4 w-4" />
      Sign out {user.name ? `(${user.name})` : ""}
    </button>
  );
}

export const NAV_LINKS = [
  { to: "/features", label: "Features" },
  { to: "/copy-trading", label: "Copy Trading" },
  { to: "/leaderboard", label: "Leaderboard" },
  { to: "/trending", label: "Trending" },
  { to: "/pricing", label: "Pricing" },
  { to: "/docs", label: "Docs" },
];

/**
 * Global navbar — fixed h-16, backdrop-blur over bg-void/80.
 * Layout owns the matching pt-16 offset for page content.
 */
export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 h-16 border-b border-hairline bg-void/80 backdrop-blur-md">
        <div className="container-x flex h-full items-center justify-between gap-6">
          {/* Brand */}
          <Link to="/" className="flex shrink-0 items-center gap-2.5">
            <img src="/logo.svg" alt="MintDash" className="h-7 w-7" />
            <span className="font-display text-[15px] font-bold tracking-[0.18em] text-tpri">
              MINTDASH
            </span>
          </Link>

          {/* Center links */}
          <nav className="hidden items-center gap-7 lg:flex">
            {NAV_LINKS.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  cn(
                    "group relative text-sm font-medium transition-colors duration-200",
                    isActive ? "text-tpri" : "text-tsec hover:text-tpri",
                  )
                }
              >
                {l.label}
                <span className="absolute -bottom-1.5 left-0 h-0.5 w-0 bg-violet transition-all duration-200 group-hover:w-full" />
              </NavLink>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-5">
            <span className="hidden items-center gap-2 font-mono text-xs text-tmut xl:flex">
              <LivePulseDot />
              Live: 12,842 wallets tracked
            </span>
            <AuthArea />
            <Link
              to="/app"
              className="hidden rounded-lg bg-g-brand px-5 py-2 text-sm font-semibold text-white transition-all duration-150 hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97] sm:block"
            >
              Launch App
            </Link>
            <button
              className="text-tpri lg:hidden"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile full-screen overlay menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-[60] flex flex-col bg-void/95 backdrop-blur-lg lg:hidden"
          >
            <div className="container-x flex h-16 items-center justify-between">
              <span className="flex items-center gap-2.5">
                <img src="/logo.svg" alt="" className="h-7 w-7" />
                <span className="font-display text-[15px] font-bold tracking-[0.18em] text-tpri">
                  MINTDASH
                </span>
              </span>
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="text-tpri">
                <X className="h-6 w-6" />
              </button>
            </div>
            <nav className="container-x flex flex-1 flex-col justify-center gap-2">
              {NAV_LINKS.map((l, i) => (
                <motion.div
                  key={l.to}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.06 * i, duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                >
                  <Link
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className="block py-3 font-display text-3xl font-semibold text-tpri"
                  >
                    {l.label}
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.06 * NAV_LINKS.length, duration: 0.3 }}
                className="mt-6 flex flex-col gap-3"
              >
                <Link
                  to="/app"
                  onClick={() => setOpen(false)}
                  className="rounded-lg bg-g-brand px-6 py-3 text-center text-[15px] font-semibold text-white"
                >
                  Launch App
                </Link>
                <AuthAreaMobile onNavigate={() => setOpen(false)} />
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
