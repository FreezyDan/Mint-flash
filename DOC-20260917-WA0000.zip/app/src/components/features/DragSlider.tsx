import { useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface DragSliderProps {
  min: number;
  max: number;
  step: number;
  value: number;
  onChange: (v: number) => void;
  ariaLabel: string;
  className?: string;
}

function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}

/**
 * Pointer-drag slider with snap-to-step ("friction" feel) and a thumb that
 * scales to 1.1 while dragging. Used by the gas dial and copy-settings panel.
 */
export default function DragSlider({
  min,
  max,
  step,
  value,
  onChange,
  ariaLabel,
  className,
}: DragSliderProps) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const pct = ((value - min) / (max - min)) * 100;

  const setFromClientX = (clientX: number) => {
    const track = trackRef.current;
    if (!track) return;
    const rect = track.getBoundingClientRect();
    const ratio = clamp((clientX - rect.left) / rect.width, 0, 1);
    const raw = min + ratio * (max - min);
    const snapped = clamp(Math.round(raw / step) * step, min, max);
    // avoid float dust (e.g. 0.15000000000000002)
    onChange(Math.round(snapped * 1000) / 1000);
  };

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setDragging(true);
    setFromClientX(e.clientX);
  };
  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (dragging) setFromClientX(e.clientX);
  };
  const endDrag = () => setDragging(false);

  return (
    <div
      ref={trackRef}
      role="slider"
      aria-label={ariaLabel}
      aria-valuemin={min}
      aria-valuemax={max}
      aria-valuenow={value}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "ArrowRight" || e.key === "ArrowUp")
          onChange(clamp(Math.round((value + step) * 1000) / 1000, min, max));
        if (e.key === "ArrowLeft" || e.key === "ArrowDown")
          onChange(clamp(Math.round((value - step) * 1000) / 1000, min, max));
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      className={cn(
        "relative flex h-6 cursor-pointer touch-none items-center outline-none",
        className,
      )}
    >
      <div className="relative h-1.5 w-full rounded-full bg-hairline">
        <div
          className="absolute inset-y-0 left-0 rounded-full bg-g-profit"
          style={{ width: `${pct}%` }}
        />
      </div>
      <motion.div
        animate={{ scale: dragging ? 1.1 : 1 }}
        transition={{ type: "spring", stiffness: 500, damping: 25 }}
        className={cn(
          "absolute top-1/2 h-4 w-4 rounded-full border-2 border-neon bg-panel shadow-glow-green",
          dragging && "border-neon bg-neon",
        )}
        style={{ left: `${pct}%`, x: "-50%", y: "-50%" }}
      />
    </div>
  );
}
