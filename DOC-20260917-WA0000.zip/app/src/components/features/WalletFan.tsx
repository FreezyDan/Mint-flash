import { useState } from "react";
import { motion } from "framer-motion";

interface WalletChip {
  address: string;
  color: string;
}

const WALLETS: WalletChip[] = [
  { address: "0x7a3F…9e2B", color: "#7C5CFF" },
  { address: "0xB91c…44Fa", color: "#39FF8E" },
  { address: "0x5eD2…a0C1", color: "#41E6E0" },
  { address: "0x3f2A…c81D", color: "#FFB224" },
  { address: "0x8Ff1…7b3A", color: "#FF4D6A" },
  { address: "0xC4d8…02eF", color: "#7C5CFF" },
  { address: "0x21Bb…9c77", color: "#39FF8E" },
  { address: "0xD60e…5A19", color: "#41E6E0" },
];

// Layout geometry (fixed-size stage, scaled down responsively by the wrapper)
const CHIP_W = 136;
const CHIP_H = 44;
const GAP = 12;
const STAGE_W = CHIP_W * 4 + GAP * 3; // 580
const FAN_CX = STAGE_W / 2 - CHIP_W / 2;

function fanPos(i: number) {
  const o = i - 3.5;
  return { x: FAN_CX + o * 30, y: 56 + Math.abs(o) * 9, rotate: o * 7 };
}

function gridPos(i: number) {
  const col = i % 4;
  const row = Math.floor(i / 4);
  return { x: col * (CHIP_W + GAP), y: 28 + row * (CHIP_H + GAP), rotate: 0 };
}

/**
 * Showcase 05 visual — a fanned stack of 8 wallet chips that spreads into a
 * 4×2 grid on hover. Chips deal in like cards on entry (stagger 60ms,
 * back.out-ish spring); fan↔grid transitions are 350ms springs.
 */
export default function WalletFan() {
  const [spread, setSpread] = useState(false);

  return (
    <div className="rounded-xl border border-hairline bg-panel p-6">
      <div className="flex items-center justify-between">
        <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-tmut">
          task #0471 · rotation pool
        </p>
        <span className="rounded-full border border-neon/30 bg-neon/10 px-3 py-1 font-mono text-xs text-neon">
          50 wallets · 1 task
        </span>
      </div>

      <div
        className="mt-6 flex h-[220px] items-start justify-center overflow-hidden"
        onMouseEnter={() => setSpread(true)}
        onMouseLeave={() => setSpread(false)}
      >
        <div
          className="relative shrink-0 origin-top scale-[0.56] min-[420px]:scale-[0.68] sm:scale-[0.8] xl:scale-100"
          style={{ width: STAGE_W, height: 220 }}
        >
          {WALLETS.map((w, i) => {
            const pos = spread ? gridPos(i) : fanPos(i);
            return (
              <motion.div
                key={w.address}
                initial={{ opacity: 0, x: fanPos(i).x, y: fanPos(i).y + 30, rotate: -8 }}
                whileInView={{ opacity: 1, x: pos.x, y: pos.y, rotate: pos.rotate }}
                animate={{ x: pos.x, y: pos.y, rotate: pos.rotate }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ type: "spring", stiffness: 320, damping: 24, delay: i * 0.06 }}
                className="absolute flex items-center gap-2.5 rounded-lg border border-hairline bg-panel2 px-3.5 shadow-glow-violet"
                style={{ width: CHIP_W, height: CHIP_H, zIndex: spread ? 1 : i }}
              >
                <span
                  className="h-3 w-3 shrink-0 rounded-full"
                  style={{ backgroundColor: w.color, boxShadow: `0 0 8px ${w.color}66` }}
                />
                <span className="font-mono text-xs text-tpri">{w.address}</span>
              </motion.div>
            );
          })}
        </div>
      </div>

      <p className="mt-2 text-center font-mono text-[11px] text-tmut">
        hover to spread the rotation
      </p>
    </div>
  );
}
