import { motion } from "framer-motion";
import { trpc } from "@/providers/trpc";
import { truncateAddress } from "@/lib/chains";
import { cn } from "@/lib/utils";

type Tone = "dim" | "green" | "cyan";

interface FeedLine {
  id: number;
  text: string;
  tone: Tone;
  when: string;
}

const toneClass: Record<Tone, string> = {
  dim: "text-tsec",
  green: "text-neon",
  cyan: "text-cyan",
};

function fmtWhen(d: Date): string {
  const s = Math.max(0, Math.floor((Date.now() - d.getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

/**
 * Showcase 01 visual — live detection terminal. Lines come from the public
 * recent-signals endpoint (real on-chain detections, polled every 30s).
 * Empty state: a single honest line, never fabricated entries.
 */
export default function MintEngineTerminal() {
  const query = trpc.public.recentSignals.useQuery(undefined, { refetchInterval: 30_000 });

  const lines: FeedLine[] = (query.data ?? []).slice(0, 6).map((s) => ({
    id: s.id,
    text:
      `▸ ${s.type.toUpperCase().padEnd(8)} ${truncateAddress(s.contractAddress)}` +
      (s.collectionName ? ` · ${s.collectionName}` : "") +
      (s.priceEth && Number(s.priceEth) > 0 ? ` · ${Number(s.priceEth).toFixed(4)} ETH` : ""),
    tone: s.status === "mirrored" ? "green" : s.type === "mint" ? "cyan" : "dim",
    when: fmtWhen(new Date(s.detectedAt)),
  }));

  return (
    <div className="overflow-hidden rounded-xl border border-hairline bg-panel shadow-glow-green">
      {/* Chrome bar */}
      <div className="flex items-center gap-2 border-b border-hairline bg-panel2 px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-alarm/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-neon/80" />
        <span className="ml-3 font-mono text-xs text-tmut">mintdash — live detections</span>
      </div>
      {/* Body */}
      <div className="flex h-[300px] flex-col justify-end gap-2 p-5 font-mono text-[13px] leading-relaxed">
        {lines.length === 0 ? (
          <p className="text-tmut">
            live on-chain detections appear here as the engine scans
          </p>
        ) : (
          lines.map((line) => (
            <motion.div
              key={line.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
              className="-mx-2 flex items-baseline justify-between gap-4 rounded px-2"
            >
              <span className={cn("tnum truncate whitespace-nowrap", toneClass[line.tone])}>
                {line.text}
              </span>
              <span className="tnum shrink-0 text-xs text-cyan">{line.when}</span>
            </motion.div>
          ))
        )}
        <div className="flex items-baseline justify-between gap-4">
          <span className="whitespace-nowrap text-tpri">
            <span className="ml-0.5 inline-block h-3.5 w-2 translate-y-0.5 animate-caret-blink bg-neon" />
          </span>
        </div>
      </div>
    </div>
  );
}
