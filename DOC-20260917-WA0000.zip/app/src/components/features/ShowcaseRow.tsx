import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface ShowcaseRowProps {
  index: string;
  title: string;
  body: string;
  chips: string[];
  /** Visual on the left, copy on the right. */
  reversed?: boolean;
  children: ReactNode;
}

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

/**
 * Alternating showcase row — copy (45%) + visual (55%).
 * Copy slides in from its own side (x ∓32px, 500ms).
 */
export default function ShowcaseRow({
  index,
  title,
  body,
  chips,
  reversed = false,
  children,
}: ShowcaseRowProps) {
  const copy = (
    <motion.div
      initial={{ opacity: 0, x: reversed ? 32 : -32 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, amount: 0.35 }}
      transition={{ duration: 0.5, ease: EASE }}
      className="flex flex-col justify-center"
    >
      <p className="font-mono text-sm font-medium text-neon">{index}</p>
      <h3 className="mt-3 text-[26px] font-semibold leading-[1.15] tracking-[-0.02em] text-tpri md:text-[32px]">
        {title}
      </h3>
      <p className="mt-4 max-w-md text-[16px] leading-relaxed text-tsec">{body}</p>
      <div className="mt-6 flex flex-wrap gap-2">
        {chips.map((c) => (
          <span
            key={c}
            className="rounded-full border border-hairline px-3 py-1 font-mono text-xs text-tsec"
          >
            {c}
          </span>
        ))}
      </div>
    </motion.div>
  );

  const visual = (
    <motion.div
      initial={{ opacity: 0, x: reversed ? -32 : 32 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, amount: 0.35 }}
      transition={{ duration: 0.5, ease: EASE }}
      className="min-w-0"
    >
      {children}
    </motion.div>
  );

  return (
    <div
      className={cn(
        "grid items-center gap-10 lg:grid-cols-[45%_55%] lg:gap-12",
        reversed && "lg:[&>*:first-child]:order-2",
      )}
    >
      {copy}
      {visual}
    </div>
  );
}
