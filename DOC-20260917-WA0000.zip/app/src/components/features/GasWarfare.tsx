import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";
import DragSlider from "./DragSlider";

interface Preset {
  id: string;
  name: string;
  desc: string;
  inclusion: string;
  priority: number;
}

const PRESETS: Preset[] = [
  { id: "chill", name: "Chill", desc: "save gwei", inclusion: "~12 blocks", priority: 6 },
  { id: "degen", name: "Degen", desc: "balanced", inclusion: "~1 block", priority: 12 },
  { id: "god", name: "God-mode", desc: "builder bundles", inclusion: "next block — 99.1%", priority: 24 },
];

/**
 * Showcase 03 visual — interactive gas strategy dial. Preset cards with a
 * live "estimated inclusion" readout (odometer roll on hover) plus a
 * priority-fee slider driving a mono fee readout. Local state only.
 */
export default function GasWarfare() {
  const [selected, setSelected] = useState<Preset>(PRESETS[1]);
  const [hovered, setHovered] = useState<Preset | null>(null);
  const [priority, setPriority] = useState(12);

  const active = hovered ?? selected;
  const maxFee = 60 + priority * 2;

  return (
    <div className="rounded-xl border border-hairline bg-panel p-6">
      <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-tmut">
        gas strategy
      </p>

      {/* Preset cards */}
      <div className="mt-4 grid grid-cols-3 gap-3">
        {PRESETS.map((p, i) => (
          <motion.button
            key={p.id}
            type="button"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.45, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ y: -4 }}
            onMouseEnter={() => setHovered(p)}
            onMouseLeave={() => setHovered(null)}
            onFocus={() => setHovered(p)}
            onBlur={() => setHovered(null)}
            onClick={() => {
              setSelected(p);
              setPriority(p.priority);
            }}
            className={cn(
              "rounded-lg border p-3 text-left transition-colors duration-150",
              selected.id === p.id
                ? "border-violet/60 bg-panel2"
                : "border-hairline bg-panel2/40 hover:border-violet/35",
            )}
          >
            <p
              className={cn(
                "font-display text-sm font-semibold",
                selected.id === p.id ? "text-tpri" : "text-tsec",
              )}
            >
              {p.name}
            </p>
            <p className="mt-0.5 font-mono text-[11px] text-tmut">{p.desc}</p>
          </motion.button>
        ))}
      </div>

      {/* Estimated inclusion readout — odometer roll on swap */}
      <div className="mt-5 rounded-lg border border-hairline bg-panel2/60 px-4 py-3">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
          estimated inclusion
        </p>
        <div className="mt-1 h-7 overflow-hidden">
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.p
              key={active.inclusion}
              initial={{ y: 12, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -12, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className={cn(
                "tnum font-mono text-lg font-bold",
                active.id === "god" ? "text-neon" : "text-tpri",
              )}
            >
              {active.inclusion}
            </motion.p>
          </AnimatePresence>
        </div>
      </div>

      {/* Priority-fee slider */}
      <div className="mt-5">
        <div className="flex items-baseline justify-between">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
            priority fee
          </p>
          <p className="tnum font-mono text-xs text-cyan">
            maxFee {maxFee} gwei · priority {priority} gwei
          </p>
        </div>
        <DragSlider
          min={2}
          max={40}
          step={1}
          value={priority}
          onChange={setPriority}
          ariaLabel="Priority fee in gwei"
          className="mt-2"
        />
      </div>
    </div>
  );
}
