import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface Stage {
  label: string;
  sub: string;
  chipClass: string;
}

const STAGES: Stage[] = [
  { label: "MINTED", sub: "+3 NFTs", chipClass: "border-neon/40 bg-neon/10 text-neon" },
  { label: "LISTED @ 0.42 ETH", sub: "target 2.1×", chipClass: "border-violet/45 bg-violet/10 text-violet" },
  { label: "SOLD +0.31 ETH", sub: "same block", chipClass: "border-neon/40 bg-neon/10 text-neon" },
];

/** Marching-ants dashed connector (stroke-dashoffset, 20s loop). */
function Arrow({ vertical = false }: { vertical?: boolean }) {
  const dash = { strokeDasharray: "7 7" };
  const anim = {
    animate: { strokeDashoffset: [0, -280] },
    transition: { duration: 20, repeat: Infinity, ease: "linear" as const },
  };
  return vertical ? (
    <svg width="24" height="56" viewBox="0 0 24 56" className="shrink-0" aria-hidden>
      <motion.line x1="12" y1="2" x2="12" y2="46" stroke="#5A6274" strokeWidth="1.5" {...dash} {...anim} />
      <path d="M7 44 L12 52 L17 44" fill="none" stroke="#5A6274" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ) : (
    <svg width="72" height="24" viewBox="0 0 72 24" className="hidden shrink-0 sm:block" aria-hidden>
      <motion.line x1="2" y1="12" x2="62" y2="12" stroke="#5A6274" strokeWidth="1.5" {...dash} {...anim} />
      <path d="M60 7 L68 12 L60 17" fill="none" stroke="#5A6274" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/**
 * Showcase 06 visual — MINTED → LISTED → SOLD flow diagram. Stage chips pop
 * in sequence (scale 0.8→1, 200ms stagger, back.out); dashed arrows march.
 */
export default function SellDownFlow() {
  return (
    <div className="rounded-xl border border-hairline bg-panel p-6">
      <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-tmut">
        auto sell-down · task #0471
      </p>
      <div className="mt-8 flex flex-col items-center gap-2 sm:flex-row sm:justify-center sm:gap-0">
        {STAGES.map((s, i) => (
          <div key={s.label} className="flex flex-col items-center gap-2 sm:flex-row sm:gap-0">
            {i > 0 && (
              <>
                <Arrow />
                <span className="sm:hidden">
                  <Arrow vertical />
                </span>
              </>
            )}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{
                duration: 0.4,
                delay: i * 0.2,
                ease: [0.34, 1.56, 0.64, 1],
              }}
              className={cn(
                "flex flex-col items-center rounded-full border px-5 py-2.5",
                s.chipClass,
              )}
            >
              <span className="tnum whitespace-nowrap font-mono text-sm font-bold">
                {s.label}
              </span>
              <span className="font-mono text-[10px] opacity-70">{s.sub}</span>
            </motion.div>
          </div>
        ))}
      </div>
      <p className="mt-8 text-center font-mono text-[11px] text-tmut">
        fill → listing → realized PnL · one block, zero clicks
      </p>
    </div>
  );
}
