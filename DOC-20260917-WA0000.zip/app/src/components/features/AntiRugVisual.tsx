import { motion } from "framer-motion";
import { Check, TriangleAlert } from "lucide-react";
import { cn } from "@/lib/utils";

const CHECKS = [
  { label: "Honeypot transfer logic", status: "PASS", warn: false },
  { label: "Proxy upgrade trap", status: "PASS", warn: false },
  { label: "Dev wallet concentration", status: "PASS", warn: false },
  { label: "Owner-held mint pause", status: "WARNING", warn: true },
];

/**
 * Showcase 04 visual — features-anti-rug.png in a device-frame panel with a
 * scanline overlay, an HTML gauge arc that sweeps 0→12 over 1.2s, and a
 * floating checklist card (green checks stagger 90ms, warning row pulses).
 */
export default function AntiRugVisual() {
  return (
    <div className="relative pb-14">
      {/* Device frame */}
      <div className="relative overflow-hidden rounded-xl border border-hairline bg-panel shadow-glow-violet">
        <img
          src="/features-anti-rug.png"
          alt="Contract risk scan panel with a 12/100 risk score"
          className="block w-full"
          loading="lazy"
        />
        {/* Scanline overlay */}
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, rgba(255,255,255,0.03) 0px, rgba(255,255,255,0.03) 1px, transparent 1px, transparent 3px)",
          }}
          aria-hidden
        />
        {/* Gauge arc overlay — sweeps 0 → 12/100 on entry (image is 1000×800, gauge ≈ cx 795 cy 263 r 103) */}
        <svg
          viewBox="0 0 1000 800"
          className="pointer-events-none absolute inset-0 h-full w-full"
          aria-hidden
        >
          <motion.circle
            cx={795}
            cy={263}
            r={103}
            fill="none"
            stroke="#39FF8E"
            strokeWidth={12}
            strokeLinecap="round"
            transform="rotate(-90 795 263)"
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 0.12 }}
            viewport={{ once: true, amount: 0.4 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          />
        </svg>
      </div>

      {/* Floating HTML checklist card */}
      <div className="absolute bottom-0 left-4 right-4 rounded-xl border border-hairline bg-panel/95 p-4 shadow-glow-green backdrop-blur-sm sm:left-6 sm:right-auto sm:w-[340px]">
        <p className="mb-2.5 font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
          scan report · 0xA1B2…C3D4
        </p>
        <ul className="space-y-2">
          {CHECKS.map((c, i) => (
            <motion.li
              key={c.label}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.3, delay: 0.5 + i * 0.09, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-center justify-between gap-3"
            >
              <span className="flex items-center gap-2 text-[13px] text-tsec">
                <span
                  className={cn(
                    "flex h-5 w-5 items-center justify-center rounded-full",
                    c.warn ? "bg-alarm/15" : "bg-neon/15",
                  )}
                >
                  {c.warn ? (
                    <TriangleAlert className="h-2.5 w-2.5 text-alarm" />
                  ) : (
                    <Check className="h-2.5 w-2.5 text-neon" />
                  )}
                </span>
                {c.label}
              </span>
              {c.warn ? (
                <motion.span
                  initial={{ opacity: 0.6 }}
                  whileInView={{ opacity: [0.6, 1, 0.6] }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 1.4,
                    repeat: 1,
                    delay: 0.5 + i * 0.09,
                    times: [0, 0.5, 1],
                  }}
                  className="font-mono text-[11px] font-medium text-alarm"
                >
                  {c.status}
                </motion.span>
              ) : (
                <span className="font-mono text-[11px] font-medium text-neon">{c.status}</span>
              )}
            </motion.li>
          ))}
        </ul>
      </div>
    </div>
  );
}
