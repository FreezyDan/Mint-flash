import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface Bar {
  label: string;
  time: string;
  pct: number;
  highlight?: boolean;
  barClass: string;
}

const BARS: Bar[] = [
  { label: "MintDash", time: "412ms", pct: 16, highlight: true, barClass: "bg-g-profit" },
  { label: "Browser mint", time: "4.2s", pct: 38, barClass: "bg-white/25" },
  { label: "Mobile wallet", time: "6.8s", pct: 52, barClass: "bg-white/15" },
  { label: "Discord alert", time: "12s", pct: 78, barClass: "bg-white/10" },
  { label: "Email lol", time: "∞", pct: 100, barClass: "bg-white/5" },
];

/**
 * Showcase 02 visual — "latency race" horizontal bar chart. Bars grow from
 * 0 on entry (800ms power3.out, 80ms stagger); the MintDash bar keeps a
 * trailing glow pulse after landing. Uses scaleX (transform-only).
 */
export default function LatencyRace() {
  return (
    <div className="rounded-xl border border-hairline bg-panel p-6">
      <p className="mb-5 font-mono text-[11px] uppercase tracking-[0.18em] text-tmut">
        time-to-mint · same drop
      </p>
      <div className="space-y-4">
        {BARS.map((b, i) => (
          <div key={b.label} className="flex items-center gap-4">
            <span
              className={cn(
                "w-24 shrink-0 font-mono text-xs",
                b.highlight ? "font-medium text-neon" : "text-tmut",
              )}
            >
              {b.label}
            </span>
            <div className="h-8 min-w-0 flex-1">
              <motion.div
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{
                  duration: 0.8,
                  delay: i * 0.08,
                  ease: [0.215, 0.61, 0.355, 1],
                }}
                className={cn(
                  "relative flex h-full origin-left items-center justify-end rounded-md pr-2.5",
                  b.barClass,
                )}
                style={{ width: `${b.pct}%` }}
              >
                <motion.span
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + i * 0.08, duration: 0.3 }}
                  className={cn(
                    "tnum font-mono text-xs font-medium",
                    b.highlight ? "text-[#07080D]" : "text-tsec",
                  )}
                >
                  {b.time}
                </motion.span>
                {/* Trailing glow pulse on the MintDash bar */}
                {b.highlight && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    whileInView={{
                      opacity: [0, 1, 0.35],
                      boxShadow: [
                        "0 0 0px rgba(57,255,142,0)",
                        "0 0 22px rgba(57,255,142,0.55)",
                        "0 0 10px rgba(57,255,142,0.25)",
                      ],
                    }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.8 + i * 0.08, duration: 1.6, repeat: Infinity }}
                    className="pointer-events-none absolute inset-0 rounded-md"
                  />
                )}
              </motion.div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
