import { motion } from "framer-motion";
import { SUPPORTED_CHAINS } from "@/lib/chains";

/**
 * S8 Multi-chain strip — the seven chains the engines execute on. Static,
 * factual content only: chain names, ids, badges. No fabricated counters.
 */
export default function ChainStrip() {
  return (
    <section className="border-y border-hairline bg-panel">
      <div className="container-x py-16 text-center md:py-20">
        <motion.h3
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="text-[26px] font-semibold leading-[1.2] tracking-[-0.02em] text-tpri md:text-[30px]"
        >
          One terminal. Every chain.
        </motion.h3>
        <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-7">
          {SUPPORTED_CHAINS.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.45, delay: i * 0.09, ease: [0.16, 1, 0.3, 1] }}
              className="card-hover flex flex-col items-center rounded-xl border border-hairline bg-panel2/50 p-6"
            >
              <img src={c.badge} alt={`${c.name} logo`} className="h-10 w-10" loading="lazy" />
              <p className="mt-3 font-display text-[15px] font-semibold text-tpri">{c.name}</p>
              <p className="tnum mt-1 rounded px-1.5 py-0.5 font-mono text-xs text-tsec">
                chain id {c.id.toLocaleString()}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
