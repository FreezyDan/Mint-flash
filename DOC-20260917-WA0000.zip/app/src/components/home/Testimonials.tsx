import { motion } from "framer-motion";

const QUOTES = [
  {
    quote: "I copied 0x7a3F for one month and stopped staring at Discord mint channels forever. The bot just fills my wallet.",
    author: "degenfiend.eth",
    meta: "Copies since Mar 2024 · +31.7 ETH",
    avatar: "/sniper-avatar-6.png",
  },
  {
    quote: "412ms to inclusion. My old setup was 4 seconds and a prayer.",
    author: "0xMira",
    meta: "Pro user · 214 mints",
    avatar: "/sniper-avatar-7.png",
  },
  {
    quote: "The anti-rug shield saved me from two honeypots in a single week.",
    author: "snipegod.sol",
    meta: "Whale user · +58.2 ETH",
    avatar: "/sniper-avatar-8.png",
  },
];

/** S8 Testimonials — 3 cards with oversized violet quote marks. */
export default function Testimonials() {
  return (
    <section className="container-x py-16 md:py-24">
      <div className="grid gap-4 md:grid-cols-3">
        {QUOTES.map((q, i) => (
          <motion.figure
            key={q.author}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] }}
            className="card-base card-hover relative overflow-hidden"
          >
            <motion.span
              initial={{ scale: 0.6, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 + i * 0.12, ease: [0.34, 1.56, 0.64, 1] }}
              className="pointer-events-none absolute -top-4 right-4 select-none font-display text-[80px] font-bold leading-none text-violet/30"
              aria-hidden
            >
              &ldquo;
            </motion.span>
            <blockquote className="relative text-[17px] leading-relaxed text-tpri">
              {q.quote}
            </blockquote>
            <figcaption className="mt-6 flex items-center gap-3">
              <img src={q.avatar} alt="" className="h-9 w-9 rounded-lg" loading="lazy" />
              <div>
                <p className="text-sm font-semibold text-tpri">{q.author}</p>
                <p className="tnum font-mono text-[11px] text-tmut">{q.meta}</p>
              </div>
            </figcaption>
          </motion.figure>
        ))}
      </div>
    </section>
  );
}
