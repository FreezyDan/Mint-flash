import { useEffect, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

const COUNT = 1200;

// Generated once at module scope: Math.random is impure and must not run
// during render (react-hooks/purity); a stable field across remounts is fine.
function generateParticles() {
  const positions = new Float32Array(COUNT * 3);
  const colors = new Float32Array(COUNT * 3);
  const violet = new THREE.Color("#7C5CFF");
  const green = new THREE.Color("#39FF8E");
  const R = 2.3;
  const r = 0.95;
  for (let i = 0; i < COUNT; i++) {
    // Torus/grid hybrid: mostly torus surface, some grid-scattered points
    const u = Math.random() * Math.PI * 2;
    const v = Math.random() * Math.PI * 2;
    let x: number, y: number, z: number;
    if (i % 5 === 0) {
      // sparse grid scatter
      x = (Math.round(Math.random() * 8) - 4) * 0.8;
      y = (Math.round(Math.random() * 8) - 4) * 0.5;
      z = (Math.random() - 0.5) * 2;
    } else {
      x = (R + r * Math.cos(v)) * Math.cos(u);
      y = (R + r * Math.cos(v)) * Math.sin(u);
      z = r * Math.sin(v);
    }
    positions.set([x, y, z], i * 3);
    const c = Math.random() < 0.08 ? green : violet;
    const dim = 0.35 + Math.random() * 0.65;
    colors.set([c.r * dim, c.g * dim, c.b * dim], i * 3);
  }
  return { positions, colors };
}

const PARTICLES = generateParticles();

function ParticleField() {
  const groupRef = useRef<THREE.Group>(null);
  const matRef = useRef<THREE.PointsMaterial>(null);
  const mouse = useRef({ x: 0, y: 0 });
  const tilt = useRef({ x: 0, y: 0 });

  const { positions, colors } = PARTICLES;

  useFrame((_, delta) => {
    const g = groupRef.current;
    if (!g) return;
    // slow rotation
    g.rotation.z += delta * 0.05;
    g.rotation.y += delta * 0.03;
    // cursor parallax tilt ±8deg (lerped)
    const targetX = mouse.current.y * (Math.PI / 180) * 8;
    const targetY = mouse.current.x * (Math.PI / 180) * 8;
    tilt.current.x += (targetX - tilt.current.x) * 0.04;
    tilt.current.y += (targetY - tilt.current.y) * 0.04;
    g.rotation.x = tilt.current.x;
    // fade in opacity 0 -> 0.9 over ~800ms
    const m = matRef.current;
    if (m && m.opacity < 0.9) m.opacity = Math.min(0.9, m.opacity + delta * 1.1);
  });

  return (
    <group ref={groupRef} rotation={[0.6, 0, 0.2]}>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[positions, 3]} />
          <bufferAttribute attach="attributes-color" args={[colors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          ref={matRef}
          size={0.03}
          vertexColors
          transparent
          opacity={0}
          sizeAttenuation
          depthWrite={false}
        />
      </points>
      <MouseTracker mouse={mouse} />
    </group>
  );
}

function MouseTracker({ mouse }: { mouse: React.MutableRefObject<{ x: number; y: number }> }) {
  // window-level listener: canvas sits behind hero content, so canvas
  // pointer events only fire on exposed areas
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = -((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, [mouse]);
  return null;
}

/** Hero particle field — ~1200 points, violet torus with sparse green. */
export default function HeroParticles() {
  return (
    <Canvas
      camera={{ position: [0, 0, 5.2], fov: 55 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
    >
      <ParticleField />
    </Canvas>
  );
}
