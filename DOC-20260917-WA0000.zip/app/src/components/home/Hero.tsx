import { Suspense, lazy, useRef } from "react";
import { Link } from "react-router";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { ArrowUpRight } from "lucide-react";
import LivePulseDot from "@/components/LivePulseDot";
import TerminalCard from "@/components/TerminalCard";

gsap.registerPlugin(ScrollTrigger, useGSAP);

const HeroParticles = lazy(() => import("./HeroParticles"));

const H1_A = "Mint first.";
const H1_B = "Ask never.";

function SplitChars({ text, className }: { text: string; className?: string }) {
  return (
    <span className={className} aria-label={text}>
      {text.split("").map((c, i) => (
        <span
          key={i}
          aria-hidden
          className="hero-char inline-block will-change-transform"
          style={{ whiteSpace: c === " " ? "pre" : undefined }}
        >
          {c}
        </span>
      ))}
    </span>
  );
}

/**
 * S1 Hero — split layout, R3F particle torus behind, GSAP char-stagger
 * headline entrance, scroll parallax. Pure GSAP tree (no Framer Motion).
 */
export default function Hero() {
  const rootRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const particlesRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (reduced) return;

      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      tl.from(".hero-char", {
        y: "0.6em",
        rotate: 4,
        opacity: 0,
        duration: 0.5,
        stagger: 0.024,
      })
        .from(
          ".hero-fade",
          { y: 20, opacity: 0, duration: 0.5, stagger: 0.1 },
          "-=0.2",
        )
        .from(
          ".hero-terminal",
          { x: 60, opacity: 0, duration: 0.6 },
          "-=0.35",
        );

      // Scroll parallax: content 0.6x, particles 0.3x, hero fades to 40%
      gsap.to(contentRef.current, {
        yPercent: -30,
        ease: "none",
        scrollTrigger: { trigger: rootRef.current, start: "top top", end: "bottom top", scrub: true },
      });
      gsap.to(particlesRef.current, {
        yPercent: -15,
        ease: "none",
        scrollTrigger: { trigger: rootRef.current, start: "top top", end: "bottom top", scrub: true },
      });
      gsap.to(rootRef.current, {
        opacity: 0.4,
        ease: "none",
        scrollTrigger: { trigger: rootRef.current, start: "20% top", end: "80% top", scrub: true },
      });
    },
    { scope: rootRef },
  );

  return (
    <section
      ref={rootRef}
      className="cursor-crosshair-custom relative -mt-16 flex min-h-[100dvh] items-center overflow-hidden"
    >
      {/* Radial hero glow */}
      <div className="pointer-events-none absolute inset-0 bg-g-hero-glow" aria-hidden />
      {/* Three.js particle field (CSS fallback: the glow + grid above) */}
      <div ref={particlesRef} className="absolute inset-0" aria-hidden>
        <Suspense fallback={null}>
          <HeroParticles />
        </Suspense>
      </div>

      <div className="container-x relative z-10 grid items-center gap-12 pb-20 pt-32 lg:grid-cols-[55%_45%]">
        {/* Left: copy */}
        <div ref={contentRef}>
          <p className="hero-fade eyebrow eyebrow-green">
            <LivePulseDot />
            [ LIVE ON ETH · SOL · BASE · POLYGON ]
          </p>
          <h1 className="mt-6 font-display text-[40px] font-bold leading-[1.02] tracking-[-0.035em] md:text-[76px]">
            <SplitChars text={H1_A} className="block text-tpri" />
            <SplitChars text={H1_B} className="text-gradient-profit block" />
          </h1>
          <p className="hero-fade mt-6 max-w-md text-[17px] text-tsec">
            MintDash is the auto-mint bot that fires your transaction the
            millisecond a drop goes live — and copies the wallets of the most
            profitable NFT snipers on-chain, automatically.
          </p>
          <div className="hero-fade mt-8 flex flex-wrap items-center gap-4">
            <Link
              to="/app"
              className="inline-flex items-center gap-2 rounded-lg bg-g-brand px-6 py-3 text-[15px] font-semibold text-white transition-all duration-150 hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97]"
            >
              Launch the Bot
            </Link>
            <Link
              to="/leaderboard"
              className="group inline-flex items-center gap-2 rounded-lg border border-hairline px-6 py-3 text-[15px] font-semibold text-tpri transition-all duration-150 hover:border-violet/60 hover:bg-white/5 active:scale-[0.97]"
            >
              See live snipers
              <ArrowUpRight className="h-4 w-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </Link>
          </div>
          <p className="hero-fade tnum mt-8 font-mono text-xs text-tmut">
            real on-chain execution&nbsp;·&nbsp;your keys stay server-side&nbsp;·&nbsp;no profit guarantees
          </p>
        </div>

        {/* Right: live terminal card (hero-terminal.png is the static fallback asset) */}
        <div className="hero-terminal">
          <TerminalCard />
        </div>
      </div>
    </section>
  );
}
