import { useEffect, useRef } from "react";
import { animate, motion, useInView } from "framer-motion";
import { trpc } from "@/providers/trpc";

interface Stat {
  value: number;
  format: (v: number) => string;
  label: string;
}

function CountUp({ stat }: { stat: Stat }) {
  const ref = useRef<HTMLSpanElement>(null);
  const wrapRef = useRef<HTMLSpanElement>(null);
  const inView = useInView(wrapRef, { once: true, amount: 0.7 });

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, stat.value, {
      duration: 1.4,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => {
        if (ref.current) ref.current.textContent = stat.format(v);
      },
    });
    return () => controls.stop();
  }, [inView, stat]);

  return (
    <span ref={wrapRef} className="tnum font-mono text-[32px] font-bold leading-none text-tpri md:text-5xl">
      <span ref={ref}>{stat.format(0)}</span>
    </span>
  );
}

/**
 * S3 Stats band — real scan-coverage counters from the on-chain scanner
 * (public endpoint). Zeros are shown honestly until scans have run.
 */
export default function StatsBand() {
  const query = trpc.public.scanStats.useQuery(undefined, { refetchInterval: 60_000 });
  const s = query.data;

  const stats: Stat[] = [
    {
      value: s?.tradersScanned ?? 0,
      format: (v) => Math.round(v).toLocaleString("en-US"),
      label: "wallets scanned on-chain",
    },
    {
      value: s?.chainsScanned ?? 0,
      format: (v) => `${Math.round(v)} / 6`,
      label: "chains covered by scans",
    },
  ];

  return (
    <section className="container-x py-16 md:py-24">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-2">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.7 }}
            transition={{ duration: 0.5, delay: i * 0.09, ease: [0.16, 1, 0.3, 1] }}
            className="card-base flex flex-col gap-3"
          >
            <CountUp stat={stat} />
            <p className="text-[13px] font-medium text-tmut">{stat.label}</p>
          </motion.div>
        ))}
      </div>
      <p className="mt-4 font-mono text-[11px] text-tmut">
        {s?.lastScannedAt
          ? `last scan ${new Date(s.lastScannedAt).toLocaleString()}`
          : "no scan has run yet — counters stay at zero until the engine scans"}
      </p>
    </section>
  );
}
