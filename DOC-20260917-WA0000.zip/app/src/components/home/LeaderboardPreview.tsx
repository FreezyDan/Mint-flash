import { motion } from "framer-motion";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { chainMetaById, formatSignedEth, truncateAddress } from "@/lib/chains";
import { cn } from "@/lib/utils";

const RANK_STYLE: Record<number, string> = {
  1: "text-amber",
  2: "text-violet",
  3: "text-violet",
};

/**
 * S7 Leaderboard preview — top 5 rows of the real on-chain scanner
 * leaderboard (public data, polled every 60s). Honest empty state when no
 * scan has run yet.
 */
export default function LeaderboardPreview() {
  const query = trpc.public.leaderboard.useQuery(undefined, { refetchInterval: 60_000 });
  const rows = (query.data ?? []).slice(0, 5);

  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-10 flex flex-wrap items-end justify-between gap-4"
      >
        <h2 className="max-w-xl text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          The sharpest wallets on-chain
        </h2>
        <Link
          to="/leaderboard"
          className="group inline-flex items-center gap-1.5 text-[15px] font-medium text-cyan"
        >
          Full leaderboard
          <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
        </Link>
      </motion.div>

      <div className="card-base overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-left">
          <thead>
            <tr className="border-b border-hairline font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
              <th className="px-6 py-4 font-medium">Rank</th>
              <th className="px-4 py-4 font-medium">Wallet</th>
              <th className="px-4 py-4 font-medium">Chain</th>
              <th className="px-4 py-4 font-medium">Total PnL</th>
              <th className="px-4 py-4 font-medium">Win rate</th>
              <th className="px-4 py-4 font-medium">Flips</th>
              <th className="px-6 py-4" />
            </tr>
          </thead>
          <tbody>
            {rows.map((s, i) => {
              const total = Number(s.totalPnlEth);
              const chain = chainMetaById(s.chainId);
              return (
                <motion.tr
                  key={`${s.chainId}-${s.address}`}
                  initial={{ opacity: 0, x: 32 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ duration: 0.35, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                  className="group border-b border-hairline/60 transition-colors last:border-0 hover:bg-panel2"
                >
                  <td className={cn("tnum px-6 py-4 font-mono text-sm font-bold", RANK_STYLE[i + 1] ?? "text-tsec")}>
                    #{i + 1}
                  </td>
                  <td className="px-4 py-4">
                    <span className="font-mono text-sm text-tpri">{truncateAddress(s.address)}</span>
                  </td>
                  <td className="px-4 py-4">
                    {chain && (
                      <img src={chain.badge} alt={chain.name} title={chain.name} className="h-4 w-4 opacity-80" loading="lazy" />
                    )}
                  </td>
                  <td className="px-4 py-4">
                    <span
                      className={cn(
                        "tnum rounded px-1.5 py-0.5 font-mono text-sm font-medium",
                        total >= 0 ? "text-neon" : "text-alarm",
                      )}
                    >
                      {formatSignedEth(total)}
                    </span>
                  </td>
                  <td className="tnum px-4 py-4 font-mono text-sm text-tsec">
                    {Number(s.winRatePct).toFixed(0)}%
                  </td>
                  <td className="tnum px-4 py-4 font-mono text-sm text-tsec">{s.flips}</td>
                  <td className="px-6 py-4 text-right">
                    <Link
                      to="/copy-trading"
                      className="rounded-md bg-neon px-3.5 py-1.5 font-mono text-xs font-semibold text-[#07080D] opacity-0 transition-opacity duration-200 group-hover:opacity-100"
                    >
                      Copy
                    </Link>
                  </td>
                </motion.tr>
              );
            })}
            {!query.isLoading && rows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-14 text-center font-mono text-sm text-tmut">
                  No on-chain scan data yet — leaderboards populate as scans run.
                </td>
              </tr>
            )}
            {query.isLoading && (
              <tr>
                <td colSpan={7} className="px-6 py-14 text-center font-mono text-sm text-tmut">
                  Loading on-chain scan data…
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
