import { motion } from "framer-motion";
import { Link } from "react-router";
import { ArrowRight, Check } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { chainMetaById, formatSignedEth, truncateAddress } from "@/lib/chains";
import { cn } from "@/lib/utils";

const CHECKLIST = [
  "Verified on-chain track record",
  "Per-copy max spend & daily caps",
  "Stop-loss auto-unfollow",
  "Mirror sells too (optional)",
];

/** S5 Copy Trading Spotlight — copy left, top-3 scanner cards right. */
export default function CopySpotlight() {
  const query = trpc.public.leaderboard.useQuery(undefined, { refetchInterval: 60_000 });
  const top = (query.data ?? []).slice(0, 3);

  return (
    <section className="relative overflow-hidden py-16 md:py-24">
      <div className="pointer-events-none absolute inset-0 bg-g-green-glow opacity-60" aria-hidden />
      <div className="container-x relative grid items-center gap-12 lg:grid-cols-2">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            <p className="eyebrow eyebrow-violet">[ COPY TRADING ENGINE ]</p>
            <h2 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
              Ride the wallets that never miss.
            </h2>
            <p className="mt-4 max-w-md text-[17px] text-tsec">
              Every sniper on MintDash is ranked by verified on-chain PnL. Pick
              one, set your size, and their mints fire from your own vault
              wallet — with your risk limits on top.
            </p>
            <ul className="mt-6 space-y-3">
              {CHECKLIST.map((c) => (
                <li key={c} className="flex items-center gap-3 text-[15px] text-tpri">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-neon/15">
                    <Check className="h-3 w-3 text-neon" />
                  </span>
                  {c}
                </li>
              ))}
            </ul>
            <Link
              to="/leaderboard"
              className="group mt-7 inline-flex items-center gap-1.5 text-[15px] font-medium text-cyan"
            >
              Explore the leaderboard
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </div>

        <div className="flex flex-col items-start pl-2 md:pl-10">
          {top.length === 0 ? (
            <div className="card-base w-full max-w-[320px] p-6">
              <p className="font-mono text-xs leading-relaxed text-tmut">
                No on-chain scan data yet — top wallets appear here as the
                scanner runs.
              </p>
            </div>
          ) : (
            top.map((s, i) => {
              const total = Number(s.totalPnlEth);
              const chain = chainMetaById(s.chainId);
              return (
                <motion.div
                  key={`${s.chainId}-${s.address}`}
                  initial={{ opacity: 0, y: 40, rotate: 6 }}
                  whileInView={{ opacity: 1, y: 0, rotate: i === 0 ? -2 : i === 2 ? 2 : 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.55, delay: i * 0.12, ease: [0.34, 1.56, 0.64, 1] }}
                  whileHover={{ scale: 1.04, zIndex: 30 }}
                  className="card-base relative w-full max-w-[320px] shadow-glow-green"
                  style={{ marginTop: i === 0 ? 0 : -20, marginLeft: `${i * 24}px`, zIndex: i }}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex-1">
                      <p className="font-mono text-sm font-medium text-tpri">
                        {truncateAddress(s.address)}
                      </p>
                      <p className="font-mono text-[11px] text-tmut">{chain?.name ?? `chain ${s.chainId}`}</p>
                    </div>
                    <span className="rounded-full border border-violet/40 bg-violet/10 px-2 py-0.5 font-mono text-xs text-violet">
                      #{i + 1}
                    </span>
                  </div>
                  <div className="mt-4">
                    <p
                      className={cn(
                        "tnum font-mono text-2xl font-bold",
                        total >= 0 ? "text-neon" : "text-alarm",
                      )}
                    >
                      {formatSignedEth(total)}
                    </p>
                    <p className="mt-0.5 font-mono text-[11px] text-tmut">
                      total PnL · {Number(s.winRatePct).toFixed(0)}% win rate · {s.flips} flips
                    </p>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>
    </section>
  );
}
