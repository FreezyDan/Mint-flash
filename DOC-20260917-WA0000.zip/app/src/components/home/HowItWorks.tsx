import { useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { Check } from "lucide-react";
import TerminalCard from "@/components/TerminalCard";
import { cn } from "@/lib/utils";

gsap.registerPlugin(ScrollTrigger, useGSAP);

const STEPS = [
  {
    num: "01",
    title: "Point",
    desc: "Paste any contract or drop link.",
  },
  {
    num: "02",
    title: "Arm",
    desc: "Set gas strategy, wallets, and max spend. Or pick a sniper to copy.",
  },
  {
    num: "03",
    title: "Snipe",
    desc: "The bot fires the instant minting goes live. You watch the fills roll in.",
  },
];

function PanelPoint() {
  return (
    <div className="card-base flex h-full flex-col justify-center gap-5">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-tmut">New task</p>
      <div className="rounded-lg border border-hairline bg-void px-4 py-3 font-mono text-sm text-tsec">
        0x3f2a91bC04dE77f1A0e2…c81d
      </div>
      <div className="flex gap-2">
        {["ETH", "SOL", "Base"].map((c, i) => (
          <span
            key={c}
            className={cn(
              "rounded-full border px-3.5 py-1.5 font-mono text-xs",
              i === 0
                ? "border-neon/40 bg-neon/10 text-neon"
                : "border-hairline text-tsec",
            )}
          >
            {c}
          </span>
        ))}
      </div>
      <button className="rounded-lg bg-neon px-6 py-3 text-[15px] font-semibold text-[#07080D]">
        Watch drop
      </button>
    </div>
  );
}

function PanelArm() {
  return (
    <div className="card-base flex h-full flex-col justify-center gap-6">
      <div>
        <p className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-tmut">Gas strategy</p>
        <div className="grid grid-cols-3 gap-2">
          {["Chill", "Degen", "God-mode"].map((g, i) => (
            <span
              key={g}
              className={cn(
                "rounded-lg border py-2 text-center font-mono text-xs",
                i === 1
                  ? "border-violet/50 bg-violet/10 text-violet"
                  : "border-hairline text-tsec",
              )}
            >
              {g}
            </span>
          ))}
        </div>
      </div>
      <div className="flex items-center justify-between">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-tmut">Wallets</p>
        <div className="flex items-center gap-3 font-mono text-sm text-tpri">
          <span className="flex h-7 w-7 items-center justify-center rounded border border-hairline">−</span>
          <span className="tnum">12</span>
          <span className="flex h-7 w-7 items-center justify-center rounded border border-hairline">+</span>
        </div>
      </div>
      <div className="flex items-center gap-3 rounded-lg border border-hairline bg-void p-3">
        <img src="/sniper-avatar-1.png" alt="" className="h-9 w-9 rounded-lg" />
        <div className="flex-1">
          <p className="font-mono text-sm text-tpri">0x7a3F…9e2B</p>
          <p className="font-mono text-[11px] text-tmut">30d PnL <span className="text-neon">+84.2 ETH</span></p>
        </div>
        <Check className="h-4 w-4 text-neon" />
      </div>
    </div>
  );
}

function PanelSnipe() {
  return <TerminalCard title="mintdash — task #0471 — sniping" startDelay={300} className="h-full" />;
}

/**
 * S4 How It Works — pinned ScrollTrigger sequence (200vh of scroll).
 * Pure GSAP tree. Progress line fill synced to scroll (scrub).
 */
export default function HowItWorks() {
  const rootRef = useRef<HTMLElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const [reduced] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useGSAP(
    () => {
      if (reduced) return;
      const steps = gsap.utils.toArray<HTMLElement>(".hiw-step");
      const panels = gsap.utils.toArray<HTMLElement>(".hiw-panel");

      const setActive = (idx: number, progress: number) => {
        steps.forEach((s, i) => {
          const active = i === idx;
          gsap.set(s, { opacity: active ? 1 : 0.4 });
          s.classList.toggle("border-neon", active);
          s.classList.toggle("border-transparent", !active);
          const num = s.querySelector(".hiw-num");
          if (num) {
            num.classList.toggle("text-neon", active);
            num.classList.toggle("text-tmut", !active);
          }
        });
        panels.forEach((p, i) => {
          gsap.set(p, { opacity: i === idx ? 1 : 0, y: i === idx ? 0 : 12, pointerEvents: i === idx ? "auto" : "none" });
        });
        if (fillRef.current) gsap.set(fillRef.current, { scaleY: progress });
      };

      setActive(0, 0);

      ScrollTrigger.create({
        trigger: rootRef.current,
        start: "top top",
        end: "+=200%",
        pin: true,
        scrub: true,
        onUpdate: (self) => {
          const p = self.progress;
          const idx = Math.min(2, Math.floor(p * 3));
          setActive(idx, p);
        },
      });
    },
    { scope: rootRef },
  );

  const panels = [<PanelPoint key="p" />, <PanelArm key="a" />, <PanelSnipe key="s" />];

  return (
    <section ref={rootRef} className="relative flex min-h-[100dvh] items-center overflow-hidden py-16">
      <div className="container-x">
        <p className="eyebrow eyebrow-green mb-4">[ HOW IT WORKS ]</p>
        <h2 className="mb-12 max-w-xl text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Three steps. Zero missed mints.
        </h2>

        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Left: progress line + step list */}
          <div className="relative pl-8">
            <div className="absolute left-0 top-0 h-full w-0.5 bg-hairline">
              <div
                ref={fillRef}
                className="h-full w-full origin-top bg-neon"
                style={{ transform: reduced ? "scaleY(1)" : "scaleY(0)" }}
              />
            </div>
            <div className="flex flex-col gap-10">
              {STEPS.map((s) => (
                <div
                  key={s.num}
                  className="hiw-step border-l-2 border-transparent pl-6 transition-none"
                  style={{ opacity: reduced ? 1 : undefined }}
                >
                  <span className={cn("hiw-num font-mono text-sm font-medium", reduced && "text-neon")}>
                    {s.num}
                  </span>
                  <h3 className="mt-1 font-display text-[22px] font-semibold text-tpri">{s.title}</h3>
                  <p className="mt-1 max-w-sm text-[15px] text-tsec">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: crossfading device-frame panel */}
          <div className="relative h-[420px]">
            {panels.map((p, i) => (
              <div
                key={i}
                className={cn("hiw-panel", reduced ? "relative mb-4 h-auto" : "absolute inset-0")}
                style={reduced ? undefined : { opacity: i === 0 ? 1 : 0 }}
              >
                {p}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
