import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQS = [
  {
    q: "Is MintDash custodial?",
    a: "No. Your keys never leave your wallet or your client-side session. MintDash signs transactions locally and only broadcasts what you approve. We can't move funds, ever.",
  },
  {
    q: "Which chains are supported?",
    a: "EVM chains only: Ethereum, Base, Arbitrum, Polygon, Robinhood, and Ink. MintDash auto-detects the chain from the contract you paste and routes through chain-specific RPC infrastructure.",
  },
  {
    q: "What does copy trading cost?",
    a: "Copy trading is included on Pro and Whale plans. On top of that, copied snipers receive a small performance fee (5% of realized profit) — you only pay when the copy makes money.",
  },
  {
    q: "What happens if a mint fails?",
    a: "No-fill, no-fee. If the transaction doesn't land, you don't pay the mint price. On Pro and above, failed gas is reimbursed to your account balance automatically.",
  },
  {
    q: "Can I get banned from drops for botting?",
    a: "MintDash rotates wallets, randomizes timing jitter, and respects per-wallet limits, which makes tasks behave like fast humans. Some contracts explicitly block bots — the anti-rug shield flags those before you arm a task.",
  },
  {
    q: "Do I need to keep my browser open?",
    a: "No. Armed tasks run on MintDash infrastructure 24/7. Close the tab, go to sleep — fills, sells, and copy-trades keep firing and you get notified on Telegram or Discord.",
  },
];

/** S10 FAQ — accordion with hairline rows. */
export default function FAQ() {
  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-10"
      >
        <p className="eyebrow eyebrow-green">[ FAQ ]</p>
        <h2 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Questions, answered.
        </h2>
      </motion.div>

      <div className="card-base p-0 px-6">
        <Accordion type="single" collapsible>
          {FAQS.map((f, i) => (
            <motion.div
              key={f.q}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.4, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
            >
              <AccordionItem value={`item-${i}`} className="border-hairline">
                <AccordionTrigger className="py-5 text-left font-display text-[17px] font-semibold text-tpri hover:text-neon hover:no-underline [&[data-state=open]>svg]:rotate-180">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-[15px] leading-relaxed text-tsec">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            </motion.div>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
