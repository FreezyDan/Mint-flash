import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { ShieldCheck, ArrowRightLeft, Radio, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

interface Cell {
  title: string;
  desc: string;
  large?: boolean;
  visual: ReactNode;
}

function LatencyBars() {
  const bars = [
    { label: "mempool read", ms: "12ms", w: "12%", c: "bg-neon" },
    { label: "sim + sign", ms: "38ms", w: "32%", c: "bg-cyan" },
    { label: "to inclusion", ms: "412ms", w: "88%", c: "bg-violet" },
  ];
  return (
    <div className="mt-5 space-y-2.5 rounded-lg border border-hairline bg-void p-4 font-mono text-[11px]">
      {bars.map((b) => (
        <div key={b.label} className="flex items-center gap-3">
          <span className="w-20 shrink-0 text-tmut">{b.label}</span>
          <div className="h-1.5 flex-1 rounded-full bg-hairline/60">
            <div className={cn("h-full rounded-full", b.c)} style={{ width: b.w }} />
          </div>
          <span className="tnum w-12 text-right text-tsec">{b.ms}</span>
        </div>
      ))}
    </div>
  );
}

function GasDial() {
  return (
    <div className="mt-5 flex items-center gap-4">
      <svg width="72" height="44" viewBox="0 0 72 44" aria-hidden>
        <path d="M6 40 A30 30 0 0 1 66 40" fill="none" stroke="#1E2230" strokeWidth="6" strokeLinecap="round" />
        <path d="M6 40 A30 30 0 0 1 48 15" fill="none" stroke="#39FF8E" strokeWidth="6" strokeLinecap="round" />
        <circle cx="48" cy="15" r="4" fill="#39FF8E" />
      </svg>
      <div className="font-mono">
        <p className="tnum text-lg font-bold text-tpri">28 gwei</p>
        <p className="text-[11px] text-tmut">dynamic priority</p>
      </div>
    </div>
  );
}

function WalletStack() {
  return (
    <div className="mt-5 flex flex-wrap gap-1.5">
      {Array.from({ length: 8 }).map((_, i) => (
        <span
          key={i}
          className="rounded-md border border-hairline bg-void px-2 py-1 font-mono text-[10px] text-tmut"
          style={{ transform: `translateY(${(i % 3) * -2}px)` }}
        >
          W{String(i + 1).padStart(2, "0")}
        </span>
      ))}
      <span className="rounded-md border border-neon/30 bg-neon/10 px-2 py-1 font-mono text-[10px] text-neon">
        +42 more
      </span>
    </div>
  );
}

const CELLS: Cell[] = [
  {
    title: "Mempool Sniping",
    desc: "Reads pending transactions and contract state directly. Fires before the public mint button even renders.",
    large: true,
    visual: <LatencyBars />,
  },
  {
    title: "Gas Warfare",
    desc: "Dynamic priority fees tuned per drop. Win the block, not the bidding war.",
    visual: <GasDial />,
  },
  {
    title: "Anti-Rug Shield",
    desc: "Every watched contract is scanned for honeypots, proxy traps, and hidden mint functions.",
    visual: (
      <div className="mt-5 flex items-center gap-3">
        <ShieldCheck className="h-8 w-8 text-neon" />
        <span className="chip-profit tnum">12/100 RISK</span>
      </div>
    ),
  },
  {
    title: "Multi-Wallet Rotation",
    desc: "Spin up to 50 wallets per task to bypass per-wallet mint limits.",
    visual: <WalletStack />,
  },
  {
    title: "Copy Trading",
    desc: "Mirror top snipers mint-for-mint, with your own caps and stop-loss.",
    large: true,
    visual: (
      <div className="mt-5 flex items-center gap-3 rounded-lg border border-hairline bg-void p-4">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet/15">
          <Radio className="h-4 w-4 text-violet" />
        </span>
        <div className="h-px flex-1 bg-gradient-to-r from-violet to-neon" />
        <span className="font-mono text-[11px] text-tmut">mirror in 412ms</span>
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-neon/15">
          <Zap className="h-4 w-4 text-neon" />
        </span>
      </div>
    ),
  },
  {
    title: "Instant Sell-Down",
    desc: "Optional auto-list on marketplaces the moment your mint confirms.",
    visual: (
      <div className="mt-5 flex items-center gap-3 font-mono text-[11px]">
        <ArrowRightLeft className="h-4 w-4 text-cyan" />
        <span className="tnum chip-profit">listed @ 0.42 ETH</span>
      </div>
    ),
  },
];

/** S6 Feature grid — bento, 6 cells. */
export default function FeatureGrid() {
  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-12"
      >
        <p className="eyebrow eyebrow-green">[ THE ENGINE ]</p>
        <h2 className="mt-4 max-w-xl text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Built for the first block, not the second.
        </h2>
      </motion.div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {CELLS.map((c, i) => (
          <motion.div
            key={c.title}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.45, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "card-base card-hover group",
              c.large && "md:col-span-2",
            )}
          >
            <h3 className="relative inline-block font-display text-[22px] font-semibold text-tpri">
              {c.title}
              <span className="absolute -bottom-1 left-0 h-0.5 w-0 bg-neon transition-all duration-300 group-hover:w-full" />
            </h3>
            <p className="mt-2 text-sm text-tsec">{c.desc}</p>
            <div className="transition-transform duration-200 group-hover:scale-[1.03]">
              {c.visual}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
