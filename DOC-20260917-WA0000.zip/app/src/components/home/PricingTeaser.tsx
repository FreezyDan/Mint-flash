import { motion } from "framer-motion";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

const PLANS = [
  {
    name: "Free",
    price: "$0",
    lines: ["1 task", "3 wallets", "Community snipers"],
    cta: "Start free",
    popular: false,
  },
  {
    name: "Pro",
    price: "$99/mo",
    lines: ["Unlimited tasks", "25 wallets", "Copy any sniper", "Anti-rug shield"],
    cta: "Go Pro",
    popular: true,
  },
  {
    name: "Whale",
    price: "0.5 ETH/qtr",
    lines: ["God-mode gas", "50 wallets", "Private mempool routing", "Dedicated RPC"],
    cta: "Go Whale",
    popular: false,
  },
];

/** S9 Pricing teaser — compact 3-plan strip, middle elevated. */
export default function PricingTeaser() {
  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-12 text-center"
      >
        <p className="eyebrow eyebrow-violet">[ PRICING ]</p>
        <h2 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Pays for itself in one mint.
        </h2>
      </motion.div>

      <div className="grid items-stretch gap-4 md:grid-cols-3">
        {PLANS.map((p, i) => (
          <motion.div
            key={p.name}
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.5, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "card-base relative flex flex-col",
              p.popular
                ? "animate-glow-pulse border-violet/60 md:-translate-y-2"
                : "card-hover",
            )}
          >
            {p.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-g-brand px-3 py-1 font-mono text-[10px] font-medium uppercase tracking-[0.16em] text-white">
                Most popular
              </span>
            )}
            <h3 className="font-display text-[22px] font-semibold text-tpri">{p.name}</h3>
            <p className="tnum mt-3 font-mono text-[32px] font-bold text-tpri">{p.price}</p>
            <ul className="mt-4 flex-1 space-y-2">
              {p.lines.map((l) => (
                <li key={l} className="text-sm text-tsec">
                  {l}
                </li>
              ))}
            </ul>
            <Link
              to="/pricing"
              className={cn(
                "mt-6 rounded-lg px-6 py-3 text-center text-[15px] font-semibold transition-all duration-150 active:scale-[0.97]",
                p.popular
                  ? "bg-g-brand text-white hover:shadow-glow-violet hover:brightness-110"
                  : "border border-hairline text-tpri hover:border-violet/60 hover:bg-white/5",
              )}
            >
              {p.cta}
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 text-center">
        <Link
          to="/pricing"
          className="group inline-flex items-center gap-1.5 text-[15px] font-medium text-cyan"
        >
          Full comparison &amp; fee calculator
          <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
        </Link>
      </div>
    </section>
  );
}
