import { forwardRef } from "react";
import type { ReactNode } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import type { HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";

type Variant = "primary" | "success" | "ghost";

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-g-brand text-white hover:brightness-110 hover:shadow-glow-violet",
  success:
    "bg-neon text-[#07080D] hover:brightness-110 hover:shadow-glow-green",
  ghost:
    "border border-hairline text-tpri hover:border-violet/60 hover:bg-white/5",
};

const baseClasses =
  "inline-flex items-center justify-center gap-2 rounded-lg px-6 py-3 font-sans text-[15px] font-semibold transition-all duration-150 select-none";

interface ButtonProps extends Omit<HTMLMotionProps<"button">, "children"> {
  variant?: Variant;
  children: ReactNode;
}

/** Shared button with Framer Motion tap micro-interaction (scale 0.97). */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", className, children, ...props }, ref) => (
    <motion.button
      ref={ref}
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      className={cn(baseClasses, variantClasses[variant], className)}
      {...props}
    >
      {children}
    </motion.button>
  ),
);
Button.displayName = "Button";

interface ButtonLinkProps {
  to: string;
  variant?: Variant;
  className?: string;
  children: ReactNode;
}

/** Link styled as a Button (for CTAs that navigate). */
export function ButtonLink({ to, variant = "primary", className, children }: ButtonLinkProps) {
  return (
    <motion.div whileTap={{ scale: 0.97 }} className="inline-block">
      <Link to={to} className={cn(baseClasses, variantClasses[variant], className)}>
        {children}
      </Link>
    </motion.div>
  );
}

export default Button;
