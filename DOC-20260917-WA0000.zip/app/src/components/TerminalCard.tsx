import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type LineTone = "dim" | "green" | "cyan" | "amber" | "red";

interface TermLine {
  text: string;
  tone: LineTone;
}

const SCRIPT: TermLine[] = [
  { text: "▸ watching  0x3f2a…c81d  [Degen Apes S2]", tone: "dim" },
  { text: "▸ goLive detected — block 21,447,902", tone: "amber" },
  { text: "✓ MINT CONFIRMED  +3 NFTs  gas 0.0021 ETH  398ms", tone: "green" },
  { text: "▸ copying wallet 0x7a3F…9e2B (30d PnL +84.2 ETH)", tone: "cyan" },
  { text: "▸ mempool scan  14 pending  priority 28 gwei", tone: "dim" },
  { text: "✓ MINT CONFIRMED  +1 NFT  gas 0.0018 ETH  412ms", tone: "green" },
  { text: "▸ anti-rug scan  0x8fF1…7b3A  risk 12/100  PASS", tone: "dim" },
  { text: "✓ MINT CONFIRMED  +2 NFTs  gas 0.0024 ETH  377ms", tone: "green" },
  { text: "▸ mirroring sell  floor 0.42 ETH  auto-list ON", tone: "cyan" },
  { text: "✓ LISTED  +0.84 ETH realized  1,204ms total", tone: "green" },
];

const toneClass: Record<LineTone, string> = {
  dim: "text-tsec",
  green: "text-neon",
  cyan: "text-cyan",
  amber: "text-amber",
  red: "text-alarm",
};

interface TerminalCardProps {
  title?: string;
  className?: string;
  /** Delay before first line starts typing (ms). */
  startDelay?: number;
  maxLines?: number;
}

/**
 * Terminal card — chrome bar + live mono output. New lines append every
 * ~2s with an 18ms/char typewriter; old lines scroll up; capped visible.
 * Pure React timers — no GSAP/Framer inside.
 */
export default function TerminalCard({
  title = "mintdash — task #0471",
  className,
  startDelay = 700,
  maxLines = 8,
}: TerminalCardProps) {
  const [lines, setLines] = useState<TermLine[]>([]);
  const [typing, setTyping] = useState("");
  const state = useRef({ scriptIdx: 0, charIdx: 0, started: false });

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const step = () => {
      const s = state.current;
      const current = SCRIPT[s.scriptIdx % SCRIPT.length];
      if (s.charIdx < current.text.length) {
        s.charIdx += 1;
        setTyping(current.text.slice(0, s.charIdx));
        timer = setTimeout(step, 18);
      } else {
        setLines((prev) => [...prev.slice(-(maxLines - 1)), current]);
        setTyping("");
        s.charIdx = 0;
        s.scriptIdx += 1;
        timer = setTimeout(step, 1400);
      }
    };
    timer = setTimeout(step, startDelay);
    return () => clearTimeout(timer);
  }, [startDelay, maxLines]);

  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border border-hairline bg-panel shadow-glow-green",
        className,
      )}
    >
      {/* Chrome bar */}
      <div className="flex items-center gap-2 border-b border-hairline bg-panel2 px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-alarm/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-amber/80" />
        <span className="h-2.5 w-2.5 rounded-full bg-neon/80" />
        <span className="ml-3 font-mono text-xs text-tmut">{title}</span>
      </div>
      {/* Body */}
      <div className="flex h-[264px] flex-col justify-end gap-1.5 p-4 font-mono text-[13px] leading-relaxed">
        {lines.map((l, i) => (
          <p key={i} className={cn("tnum whitespace-nowrap", toneClass[l.tone])}>
            {l.text}
          </p>
        ))}
        <p className="whitespace-nowrap text-tpri">
          {typing}
          <span className="ml-0.5 inline-block h-3.5 w-2 translate-y-0.5 animate-caret-blink bg-neon" />
        </p>
      </div>
    </div>
  );
}
