import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, ChevronUp, Eye, Plus, Radar, Trash2, X } from "lucide-react";
import { Upload } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../api/router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import { parseWalletLink } from "@contracts/nftLinks";
import type { DiscoverScanResult } from "@contracts/discover";
import {
  CHAINS,
  ChainBadge,
  CopyAddr,
  EmptyState,
  FieldLabel,
  ServerError,
  chainById,
  chainByKey,
  inputCls,
  timeAgo,
  truncateAddr,
} from "./shared";
import { WalletProfileDrawer } from "./WalletProfileDrawer";
import { WalletLabels } from "./WalletLabels";
import { LockCard, useEntitlement } from "./plan";
import type { SectionKey } from "./shell";

const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;

/* ------------------------------------------------------------------ */
/* CSV bulk import (watchlist)                                          */
/* ------------------------------------------------------------------ */

const CSV_IMPORT_CAP = 100;

type CsvEntry = { address: string; label?: string };
type CsvParseResult = { entries: CsvEntry[]; errors: string[]; truncated: number };

/**
 * Parse `address[,label]` CSV lines client-side: tolerates a leading header
 * row, whitespace and quotes; validates 0x+40hex addresses; dedupes; caps at
 * CSV_IMPORT_CAP entries (extras are counted as truncated).
 */
function parseCsvText(text: string): CsvParseResult {
  const entries: CsvEntry[] = [];
  const errors: string[] = [];
  const seen = new Set<string>();
  let truncated = 0;
  let headerSkipped = false;
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  lines.forEach((raw, i) => {
    const line = raw.trim();
    if (!line) return;
    const cells = line
      .split(",")
      .map((c) => c.trim().replace(/^"(.*)"$/, "$1").trim());
    const address = (cells[0] ?? "").toLowerCase();
    if (!ADDR_RE.test(address)) {
      // A leading line whose first cell isn't an address at all is a header.
      if (!headerSkipped && entries.length === 0 && !address.startsWith("0x")) {
        headerSkipped = true;
        return;
      }
      errors.push(`line ${i + 1}: invalid address "${cells[0] ?? ""}"`);
      return;
    }
    if (seen.has(address)) return; // duplicate — the server would skip it anyway
    seen.add(address);
    if (entries.length >= CSV_IMPORT_CAP) {
      truncated += 1;
      return;
    }
    const label = cells[1];
    entries.push(label ? { address, label } : { address });
  });
  return { entries, errors, truncated };
}

/* ------------------------------------------------------------------ */
/* Shared formatting + chart primitives                                */
/* ------------------------------------------------------------------ */

/** Signed ETH, 4 decimals (+0.1234); em dash for null. */
export function fmtEth(v: string | number | null, digits = 4): string {
  if (v === null) return "—";
  const n = Number(v);
  return `${n >= 0 ? "+" : ""}${n.toFixed(digits)}`;
}

/** Signed ROI percent; em dash for null. */
function fmtRoi(v: string | number | null, digits = 1): string {
  if (v === null) return "—";
  const n = Number(v);
  return `${n >= 0 ? "+" : ""}${n.toFixed(digits)}%`;
}

/** Dark quant-terminal tooltip for all recharts charts. */
function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name?: string; value?: number | string }>;
  label?: string | number;
}) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="rounded-lg border border-white/10 bg-[#0D0F16] px-2.5 py-1.5 font-mono text-[10px] shadow-xl">
      {label !== undefined && label !== "" && (
        <p className="mb-0.5 uppercase tracking-widest text-[#8b8fa3]">{label}</p>
      )}
      {payload.map((p, i) => (
        <p key={i} className="text-tpri">
          {p.name ? `${p.name}: ` : ""}
          {typeof p.value === "number" ? fmtEth(p.value) : p.value}
        </p>
      ))}
    </div>
  );
}

const AXIS_TICK = { fill: "#8b8fa3", fontSize: 10, fontFamily: "JetBrains Mono, monospace" };
const GRID_STROKE = "#ffffff10";

/** Tiny hand-rolled 72×20 sparkline (watchlist equity curve). */
function Sparkline({ points }: { points: number[] }) {
  if (points.length < 2) return null;
  const W = 72;
  const H = 20;
  const PAD = 1.5;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const step = (W - PAD * 2) / (points.length - 1);
  const coords = points
    .map(
      (p, i) =>
        `${(PAD + i * step).toFixed(1)},${(H - PAD - ((p - min) / range) * (H - PAD * 2)).toFixed(1)}`,
    )
    .join(" ");
  const up = points[points.length - 1] >= points[0];
  const color = up ? "#39FF8E" : "#FF4D6A";
  return (
    <svg width={W} height={H} className="shrink-0" aria-hidden>
      <polyline
        points={coords}
        fill="none"
        stroke={color}
        strokeWidth={1.5}
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <circle
        cx={PAD + (points.length - 1) * step}
        cy={H - PAD - ((points[points.length - 1] - min) / range) * (H - PAD * 2)}
        r={1.6}
        fill={color}
      />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Watched wallet row                                                  */
/* ------------------------------------------------------------------ */

type WatchedRowData = inferRouterOutputs<AppRouter>["copy"]["list"][number];

function WatchedRow({
  wallet,
  index,
  pushToast,
  onProfile,
}: {
  wallet: WatchedRowData;
  index: number;
  pushToast: ToastFn;
  onProfile: (address: string) => void;
}) {
  const utils = trpc.useUtils();
  const [perTrade, setPerTrade] = useState(wallet.maxPerTradeEth);
  const [daily, setDaily] = useState(wallet.maxDailyEth);
  // Local state is seeded from props; the parent remounts this row (via key)
  // whenever the server-side values change, so no sync effect is needed.

  const invalidate = () =>
    Promise.all([utils.copy.list.invalidate(), utils.stats.overview.invalidate()]);

  const update = trpc.copy.update.useMutation({
    onSuccess: invalidate,
    onError: (e) => pushToast(e.message, "error"),
  });
  const toggle = trpc.copy.toggle.useMutation({
    onSuccess: async () => {
      pushToast(
        wallet.enabled ? `Paused copying ${wallet.label}` : `Copying ${wallet.label}`,
        "info",
      );
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });
  const remove = trpc.copy.remove.useMutation({
    onSuccess: async () => {
      pushToast(`Stopped watching ${wallet.label}`, "info");
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const saveCaps = () => {
    const data: { maxPerTradeEth?: string; maxDailyEth?: string } = {};
    if (perTrade !== wallet.maxPerTradeEth) data.maxPerTradeEth = perTrade;
    if (daily !== wallet.maxDailyEth) data.maxDailyEth = daily;
    if (Object.keys(data).length > 0) update.mutate({ id: wallet.id, data });
  };

  const chain = chainByKey(wallet.chain);

  return (
    <motion.tr
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.3 }}
      className={cn(
        "border-b border-hairline/60 transition-opacity",
        !wallet.enabled && "opacity-50",
      )}
    >
      <td className="py-3 pr-3">
        <div className="flex items-center gap-3">
          <img
            src={`/sniper-avatar-${(index % 8) + 1}.png`}
            alt=""
            className="h-8 w-8 rounded-full border border-hairline object-cover"
          />
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium text-tpri">{wallet.label}</p>
            <p className="flex items-center gap-1.5 font-mono text-[11px] text-tmut">
              {truncateAddr(wallet.address)}
              <CopyAddr value={wallet.address} />
            </p>
          </div>
          <Sparkline points={wallet.sparkline} />
        </div>
      </td>
      <td className="px-3 py-3">
        <span className="inline-flex items-center gap-1.5 font-mono text-[11px] text-tsec">
          <img src={chain.icon} alt="" className="h-3 w-3" />
          {chain.label}
        </span>
      </td>
      <td className="px-3 py-3">
        <div className="flex items-center gap-2 font-mono text-[11px]">
          <input
            className="w-16 rounded border border-hairline bg-void px-1.5 py-1 text-tpri focus:border-violet/60 focus:outline-none"
            value={perTrade}
            onChange={(e) => setPerTrade(e.target.value)}
            onBlur={saveCaps}
            title="Max ETH per trade"
          />
          <span className="text-tmut">/trade</span>
          <input
            className="w-16 rounded border border-hairline bg-void px-1.5 py-1 text-tpri focus:border-violet/60 focus:outline-none"
            value={daily}
            onChange={(e) => setDaily(e.target.value)}
            onBlur={saveCaps}
            title="Max ETH per day"
          />
          <span className="text-tmut">/day</span>
        </div>
      </td>
      <td className="px-3 py-3">
        <div className="flex items-center gap-3 font-mono text-[10px] text-tmut">
          <label className="flex items-center gap-1.5">
            <Switch
              className="scale-[0.8] data-[state=checked]:bg-neon"
              checked={wallet.copyMints}
              onCheckedChange={(v) => update.mutate({ id: wallet.id, data: { copyMints: v } })}
            />
            mints
          </label>
          <label className="flex items-center gap-1.5">
            <Switch
              className="scale-[0.8] data-[state=checked]:bg-neon"
              checked={wallet.copyBuys}
              onCheckedChange={(v) => update.mutate({ id: wallet.id, data: { copyBuys: v } })}
            />
            buys
          </label>
        </div>
      </td>
      <td className="py-3 pl-3">
        <div className="flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={() => onProfile(wallet.address)}
            title="All-time PnL from full OpenSea trade history"
            className="rounded-lg border border-violet/40 px-2 py-1 font-mono text-[10px] text-violet transition-colors hover:bg-violet/10 disabled:opacity-40 disabled:hover:bg-transparent"
          >
            All-time
          </button>
          <Switch
            className="data-[state=checked]:bg-neon"
            checked={wallet.enabled}
            onCheckedChange={() => toggle.mutate({ id: wallet.id })}
            title={wallet.enabled ? "Pause copying" : "Resume copying"}
          />
          <button
            onClick={() => remove.mutate({ id: wallet.id })}
            title="Remove"
            className="rounded p-1.5 text-tmut transition-colors hover:bg-alarm/10 hover:text-alarm"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </motion.tr>
  );
}

/* ------------------------------------------------------------------ */
/* Signals feed                                                        */
/* ------------------------------------------------------------------ */

const SIGNAL_STATUS_CLS: Record<string, string> = {
  detected: "border-amber/40 bg-amber/10 text-amber",
  mirrored: "border-neon/40 bg-neon/10 text-neon",
  skipped: "border-hairline bg-panel2 text-tmut",
  failed: "border-alarm/40 bg-alarm/10 text-alarm",
};

function SignalsFeed() {
  const signals = trpc.copy.signals.useQuery(undefined, { refetchInterval: 5000 });
  const rows = useMemo(() => signals.data ?? [], [signals.data]);
  const seenMax = useRef<number | null>(null);
  useEffect(() => {
    if (rows.length > 0 && seenMax.current === null) {
      seenMax.current = Math.max(...rows.map((r) => r.id));
    }
  }, [rows]);

  if (!signals.isLoading && rows.length === 0) {
    return (
      <EmptyState
        icon={<Eye className="h-5 w-5" />}
        title="No signals yet"
        body="When a watched sniper mints or buys, the signal shows up here — detected, mirrored, skipped or failed — usually within half a second."
      />
    );
  }

  return (
    <ul className="max-h-[420px] divide-y divide-hairline/60 overflow-y-auto">
      <AnimatePresence initial={false}>
        {/* Baseline max-id is written only in the effect after first paint;
            reading it during render is the mount-animation gate. */}
        {/* eslint-disable-next-line react-hooks/refs */}
        {rows.map((s) => {
          const isNew = seenMax.current !== null && s.id > seenMax.current;
          const pnl = s.pnlEth !== null ? Number(s.pnlEth) : null;
          return (
            <motion.li
              key={s.id}
              initial={isNew ? { opacity: 0, x: 24, backgroundColor: "rgba(57,255,142,0.10)" } : false}
              animate={{ opacity: 1, x: 0, backgroundColor: "rgba(57,255,142,0)" }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="flex items-center gap-3 px-4 py-2.5"
            >
              <span
                className={cn(
                  "shrink-0 rounded border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider",
                  s.type === "mint"
                    ? "border-violet/40 bg-violet/10 text-violet"
                    : "border-cyan/40 bg-cyan/10 text-cyan",
                )}
              >
                {s.type}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-mono text-xs text-tsec">
                  {s.collectionName ?? truncateAddr(s.contractAddress)}
                  {s.tokenId ? ` #${s.tokenId}` : ""}
                  {s.priceEth ? <span className="text-tmut"> · {s.priceEth} ETH</span> : null}
                </p>
                <p className="font-mono text-[10px] text-tmut">{timeAgo(s.createdAt)}</p>
              </div>
              {pnl !== null && pnl !== 0 && (
                <span className={pnl >= 0 ? "chip-profit" : "chip-loss"}>
                  {pnl >= 0 ? "+" : ""}
                  {pnl.toFixed(2)} ETH
                </span>
              )}
              <span
                className={cn(
                  "shrink-0 rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider",
                  SIGNAL_STATUS_CLS[s.status] ?? SIGNAL_STATUS_CLS.detected,
                )}
              >
                {s.status}
              </span>
            </motion.li>
          );
        })}
      </AnimatePresence>
    </ul>
  );
}

/* ------------------------------------------------------------------ */
/* Discover (on-chain) tab                                             */
/* ------------------------------------------------------------------ */

const METHODOLOGY_TEXT =
  "Source: Seaport OrderFulfilled events (OpenSea settlement) read directly from chain via your RPC. " +
  "Realized PnL = sell proceeds minus matching buy cost when BOTH trades appear in the scanned window. " +
  "Mint profits: mints are ERC-721 Transfer events from the zero address; mint cost = mint transaction " +
  "value ÷ quantity minted in that transaction (gas ignored). Free mints (zero value) have null ROI and " +
  "count as passing any ROI filter. " +
  "Blur/other marketplaces, older history, and non-ETH payments are not included — rankings are a " +
  "recency-weighted snapshot, not lifetime PnL.";

/** Approximate seconds per block (matches the scanner) for hold-time display. */
const SECONDS_PER_BLOCK: Record<number, number> = {
  1: 12,
  8453: 2,
  42161: 2,
  4663: 2,
  57073: 2,
  137: 2,
};

function holdHours(holdBlocks: number | null, chainId: number): string | null {
  if (holdBlocks === null) return null;
  const h = (holdBlocks * (SECONDS_PER_BLOCK[chainId] ?? 12)) / 3600;
  return h >= 100 ? h.toFixed(0) : h.toFixed(1);
}

/** Debounce a changing value (filter inputs apply-on-change). */
function useDebounced<T>(value: T, delayMs = 400): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(t);
  }, [value, delayMs]);
  return debounced;
}

type TraderRow = inferRouterOutputs<AppRouter>["discover"]["list"]["rows"][number];

function RoiCell({ roiPct, wins }: { roiPct: string | null; wins?: number }) {
  if (roiPct === null) {
    // Null ROI = free-mint-derived cost basis.
    return (
      <span className="font-mono text-[12px] text-neon">{(wins ?? 1) > 0 ? "∞ free" : "—"}</span>
    );
  }
  const roi = Number(roiPct);
  return (
    <span className={cn("font-mono text-[12px]", roi >= 0 ? "text-neon" : "text-alarm")}>
      {roi >= 0 ? "+" : ""}
      {roi.toFixed(0)}%
    </span>
  );
}

/* ------------------------- Drilldown drawer ------------------------- */

function TraderFlipsDrawer({
  chainId,
  trader,
  onClose,
}: {
  chainId: number;
  trader: TraderRow;
  onClose: () => void;
}) {
  const flipsQuery = trpc.discover.flips.useQuery(
    { chainId, address: trader.address, limit: 100 },
    { enabled: true },
  );
  const flips = flipsQuery.data?.rows ?? [];
  const openFlips = flips.filter((f) => f.status === "open");
  const closedFlips = flips.filter((f) => f.status !== "open");

  // Cumulative realized PnL over closed flips in exit order (row id asc ≈
  // scan/event order — no exit timestamps are stored on flips).
  const pnlCurve = [...closedFlips]
    .sort((a, b) => a.id - b.id)
    .reduce<Array<{ n: number; cum: number }>>((acc, f, i) => {
      const prev = acc.length > 0 ? acc[acc.length - 1].cum : 0;
      acc.push({ n: i + 1, cum: Number((prev + Number(f.pnlEth ?? 0)).toFixed(8)) });
      return acc;
    }, []);

  // Win/loss histogram: realized flip PnL bucketed into ≤10 buckets.
  const pnlHist = (() => {
    const vals = closedFlips.map((f) => Number(f.pnlEth ?? 0));
    if (vals.length === 0) return [] as Array<{ range: string; count: number; pos: boolean }>;
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const B = Math.min(10, vals.length);
    if (min === max) return [{ range: fmtEth(min, 3), count: vals.length, pos: min >= 0 }];
    const w = (max - min) / B;
    const buckets = Array.from({ length: B }, (_, i) => {
      const lo = min + i * w;
      return {
        range: `${fmtEth(lo, 3)}…${fmtEth(lo + w, 3)}`,
        count: 0,
        pos: lo + w / 2 >= 0,
      };
    });
    for (const v of vals) buckets[Math.min(B - 1, Math.floor((v - min) / w))].count += 1;
    return buckets;
  })();

  // Mint vs secondary split (realized) + open-position counts by origin.
  const mintPnl = closedFlips
    .filter((f) => f.kind === "mint")
    .reduce((s, f) => s + Number(f.pnlEth ?? 0), 0);
  const secondaryPnl = closedFlips
    .filter((f) => f.kind !== "mint")
    .reduce((s, f) => s + Number(f.pnlEth ?? 0), 0);
  const openMints = openFlips.filter((f) => f.kind === "mint").length;
  const openBuys = openFlips.length - openMints;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={onClose}
        className="fixed inset-0 z-[70] bg-void/70 backdrop-blur-sm"
      />
      <motion.aside
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-y-0 right-0 z-[71] flex w-full max-w-xl flex-col border-l border-hairline bg-panel shadow-2xl"
      >
        {/* Wallet header */}
        <div className="flex items-start justify-between gap-3 border-b border-hairline px-5 py-4">
          <div className="min-w-0">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
              P&L in detail
            </p>
            <p className="mt-1 flex items-center gap-2 font-mono text-[13px] text-tpri">
              <span className="truncate">{trader.address}</span>
              <CopyAddr value={trader.address} />
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              <ChainBadge chainId={chainId} />
              <WalletLabels labels={trader.labels} />
              <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5 font-mono text-[10px] text-tsec">
                {trader.flips} flips · {trader.wins} wins · {trader.winRatePct}% win
              </span>
              <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5 font-mono text-[10px] text-tsec">
                mint PnL {Number(trader.mintPnlEth) >= 0 ? "+" : ""}
                {Number(trader.mintPnlEth).toFixed(3)} ETH ({trader.mintFlips})
              </span>
              {trader.openPositions > 0 && (
                <span className="rounded-full border border-cyan/40 bg-cyan/10 px-2 py-0.5 font-mono text-[10px] text-cyan">
                  {trader.openPositions} open · unrealized {fmtEth(trader.unrealizedPnlEth, 3)} ETH
                </span>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            title="Close"
            className="rounded-lg border border-hairline bg-panel2 p-1.5 text-tmut transition-colors hover:text-tpri"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Per-flip detail + charts */}
        <div className="flex-1 overflow-y-auto">
          {flipsQuery.isLoading ? (
            <div className="space-y-3 p-5">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="h-10 animate-pulse rounded-lg bg-panel2" />
              ))}
            </div>
          ) : flips.length === 0 ? (
            <div className="p-5">
              <EmptyState
                icon={<Radar className="h-5 w-5" />}
                title="No flips or open positions recorded"
                body="This wallet has no completed mint→sell or buy→sell pairs and no unsold in-window acquisitions in the scanned window."
              />
            </div>
          ) : (
            <div>
              {/* Open positions (unsold in-window acquisitions) */}
              {openFlips.length > 0 && (
                <div className="border-b border-hairline">
                  <p className="px-5 pt-4 font-mono text-[10px] uppercase tracking-[0.16em] text-cyan">
                    Open positions ({openFlips.length})
                  </p>
                  <table className="mt-1 w-full">
                    <thead>
                      <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                        <th className="px-5 py-2 font-medium">Origin</th>
                        <th className="px-3 py-2 font-medium">NFT</th>
                        <th className="px-3 py-2 font-medium">Entry</th>
                        <th className="px-3 py-2 font-medium">Mark</th>
                        <th className="px-3 py-2 font-medium">Unrealized</th>
                        <th className="py-2 pl-3 pr-5 text-right font-medium">Age</th>
                      </tr>
                    </thead>
                    <tbody>
                      {openFlips.map((f) => {
                        const age = holdHours(f.holdBlocks, chainId);
                        return (
                          <tr key={f.id} className="border-b border-hairline/60">
                            <td className="px-5 py-2.5">
                              <span
                                className={cn(
                                  "rounded border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider",
                                  f.kind === "mint"
                                    ? "border-neon/40 bg-neon/10 text-neon"
                                    : "border-violet/40 bg-violet/10 text-violet",
                                )}
                              >
                                {f.kind === "mint" ? "MINT" : "BUY"}
                              </span>
                            </td>
                            <td className="px-3 py-2.5">
                              <p className="flex items-center gap-1 font-mono text-[11px] text-tsec">
                                {truncateAddr(f.contractAddress)}
                                <CopyAddr value={f.contractAddress} />
                              </p>
                              <p className="font-mono text-[10px] text-tmut">
                                <ChainBadge chainId={chainId} className="mr-1" />
                                {f.tokenId
                                  ? `#${f.tokenId.length > 10 ? `${f.tokenId.slice(0, 10)}…` : f.tokenId}`
                                  : ""}
                              </p>
                            </td>
                            <td className="px-3 py-2.5 font-mono text-[11px] text-tsec">
                              {f.buyPriceEth !== null ? Number(f.buyPriceEth).toFixed(4) : "—"}
                            </td>
                            <td className="px-3 py-2.5 font-mono text-[11px] text-tsec">
                              {f.markPriceEth !== null ? Number(f.markPriceEth).toFixed(4) : "—"}
                            </td>
                            <td className="px-3 py-2.5">
                              {f.unrealizedPnlEth !== null ? (
                                <span
                                  className={
                                    Number(f.unrealizedPnlEth) >= 0 ? "chip-profit" : "chip-loss"
                                  }
                                >
                                  {fmtEth(f.unrealizedPnlEth, 3)}
                                </span>
                              ) : (
                                <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
                                  unmarked
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 pl-3 pr-5 text-right font-mono text-[11px] text-tsec">
                              {age !== null ? `${age}h` : "—"}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              {closedFlips.length > 0 && (
                <div className="space-y-4 border-b border-hairline px-5 py-4">
                  {/* Cumulative realized PnL curve */}
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
                      Cumulative realized PnL
                    </p>
                    <div className="mt-2 h-[160px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={pnlCurve} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                          <defs>
                            <linearGradient id="pnlCurveFill" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#7C5CFF" stopOpacity={0.35} />
                              <stop offset="100%" stopColor="#7C5CFF" stopOpacity={0.02} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
                          <XAxis dataKey="n" tick={AXIS_TICK} tickLine={false} axisLine={false} />
                          <YAxis
                            tick={AXIS_TICK}
                            tickLine={false}
                            axisLine={false}
                            width={56}
                            tickFormatter={(v: number) => v.toFixed(3)}
                          />
                          <Tooltip content={<ChartTooltip />} />
                          <ReferenceLine y={0} stroke="#FF4D6A" strokeDasharray="4 4" />
                          <Area
                            type="monotone"
                            dataKey="cum"
                            name="cum PnL"
                            stroke="#7C5CFF"
                            strokeWidth={1.5}
                            fill="url(#pnlCurveFill)"
                            isAnimationActive={false}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Win/loss histogram */}
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
                      Flip PnL distribution
                    </p>
                    <div className="mt-2 h-[120px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={pnlHist} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                          <CartesianGrid stroke={GRID_STROKE} vertical={false} />
                          <XAxis dataKey="range" tick={false} tickLine={false} axisLine={false} />
                          <YAxis
                            tick={AXIS_TICK}
                            tickLine={false}
                            axisLine={false}
                            width={28}
                            allowDecimals={false}
                          />
                          <Tooltip content={<ChartTooltip />} cursor={{ fill: "#ffffff08" }} />
                          <Bar dataKey="count" name="flips" isAnimationActive={false}>
                            {pnlHist.map((b, i) => (
                              <Cell key={i} fill={b.pos ? "#39FF8E" : "#FF4D6A"} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Mint vs secondary split */}
                  <div className="flex flex-wrap gap-2">
                    <span className="rounded-full border border-neon/40 bg-neon/10 px-2.5 py-1 font-mono text-[10px] text-neon">
                      mints {fmtEth(mintPnl, 4)} ETH realized · {openMints} open
                    </span>
                    <span className="rounded-full border border-violet/40 bg-violet/10 px-2.5 py-1 font-mono text-[10px] text-violet">
                      buy &amp; flip {fmtEth(secondaryPnl, 4)} ETH realized · {openBuys} open
                    </span>
                  </div>
                </div>
              )}

              {/* Closed flips */}
              {closedFlips.length > 0 && (
                <p className="px-5 pt-4 font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
                  Closed flips ({closedFlips.length})
                </p>
              )}
              {closedFlips.length > 0 && (
            <table className="mt-1 w-full">
              <thead className="sticky top-0 bg-panel">
                <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                  <th className="px-5 py-2.5 font-medium">Kind</th>
                  <th className="px-3 py-2.5 font-medium">NFT</th>
                  <th className="px-3 py-2.5 font-medium">Buy</th>
                  <th className="px-3 py-2.5 font-medium">Sell</th>
                  <th className="px-3 py-2.5 font-medium">PnL</th>
                  <th className="px-3 py-2.5 font-medium">ROI</th>
                  <th className="py-2.5 pl-3 pr-5 text-right font-medium">Hold</th>
                </tr>
              </thead>
              <tbody>
                {closedFlips.map((f) => {
                  const pnl = f.pnlEth !== null ? Number(f.pnlEth) : null;
                  const hold = holdHours(f.holdBlocks, chainId);
                  return (
                    <tr key={f.id} className="border-b border-hairline/60">
                      <td className="px-5 py-2.5">
                        <span
                          className={cn(
                            "rounded border px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider",
                            f.kind === "mint"
                              ? "border-neon/40 bg-neon/10 text-neon"
                              : "border-violet/40 bg-violet/10 text-violet",
                          )}
                        >
                          {f.kind === "mint" ? "MINT" : "FLIP"}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <p className="flex items-center gap-1 font-mono text-[11px] text-tsec">
                          {truncateAddr(f.contractAddress)}
                          <CopyAddr value={f.contractAddress} />
                        </p>
                        {f.tokenId && (
                          <p className="font-mono text-[10px] text-tmut">
                            #{f.tokenId.length > 10 ? `${f.tokenId.slice(0, 10)}…` : f.tokenId}
                          </p>
                        )}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-tsec">
                        {f.buyPriceEth !== null ? `${Number(f.buyPriceEth).toFixed(4)}` : "—"}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-tsec">
                        {f.sellPriceEth !== null ? `${Number(f.sellPriceEth).toFixed(4)}` : "—"}
                      </td>
                      <td className="px-3 py-2.5">
                        {pnl !== null && (
                          <span className={pnl >= 0 ? "chip-profit" : "chip-loss"}>
                            {pnl >= 0 ? "+" : ""}
                            {pnl.toFixed(3)}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2.5">
                        <RoiCell roiPct={f.roiPct} wins={pnl !== null && pnl > 0 ? 1 : 0} />
                      </td>
                      <td className="py-2.5 pl-3 pr-5 text-right font-mono text-[11px] text-tsec">
                        {hold !== null ? `${hold}h` : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
              )}
            </div>
          )}
        </div>
        <p className="border-t border-hairline px-5 py-3 font-mono text-[10px] text-tmut">
          open positions first (best unrealized, unmarked last) · closed flips best PnL first · mint
          cost = mint tx value ÷ quantity minted · marks = latest in-window collection sale
        </p>
      </motion.aside>
    </>
  );
}

/* --------------------------- Discover panel -------------------------- */

function DiscoverPanel({
  pushToast,
  onProfile,
}: {
  pushToast: ToastFn;
  onProfile: (address: string) => void;
}) {
  const utils = trpc.useUtils();
  const [chainId, setChainId] = useState<number>(1);
  const [lastSummary, setLastSummary] = useState<DiscoverScanResult | null>(null);
  const [justAdded, setJustAdded] = useState<Set<string>>(new Set());
  const [mode, setMode] = useState<"all" | "mint">("mint");
  const [minPnlInput, setMinPnlInput] = useState("");
  const [minRoiInput, setMinRoiInput] = useState("200");
  const [selected, setSelected] = useState<TraderRow | null>(null);

  const debouncedPnl = useDebounced(minPnlInput);
  const debouncedRoi = useDebounced(minRoiInput);
  const parsedPnl = debouncedPnl.trim();
  const parsedRoi = Number(debouncedRoi);
  const minPnlEth = /^-?\d+(\.\d+)?$/.test(parsedPnl) ? parsedPnl : undefined;
  const minRoiPct =
    debouncedRoi.trim() !== "" && Number.isFinite(parsedRoi) ? parsedRoi : undefined;

  const chainsQuery = trpc.discover.chains.useQuery(undefined, { refetchInterval: 30_000 });
  const listQuery = trpc.discover.list.useQuery({ chainId, limit: 50, mode, minPnlEth, minRoiPct });
  const watchedQuery = trpc.copy.list.useQuery();

  const scan = trpc.discover.scan.useMutation({
    onSuccess: async (res) => {
      setLastSummary(res);
      if (res.cached) {
        pushToast("results fresh (<10m old) — showing cached scan", "info");
      } else {
        pushToast(
          `Scan complete: ${res.tradersStored} traders, ${res.mintFlips} mint flips, ${res.openPositions} open positions from ${res.logsFound} trades`,
          res.partial ? "info" : "success",
        );
      }
      await Promise.all([utils.discover.list.invalidate(), utils.discover.chains.invalidate()]);
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const addCopy = trpc.copy.add.useMutation({
    onSuccess: async (_r, vars) => {
      setJustAdded((prev) => new Set(prev).add(vars.address.toLowerCase()));
      pushToast(`Copying ${truncateAddr(vars.address)}`, "success");
      await Promise.all([utils.copy.list.invalidate(), utils.stats.overview.invalidate()]);
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const chainStats = new Map((chainsQuery.data ?? []).map((c) => [c.chainId, c]));
  const rows = useMemo(() => listQuery.data?.rows ?? [], [listQuery.data]);
  const lastScannedAt = listQuery.data?.lastScannedAt ?? null;
  const selectedChain = chainById(chainId);
  const [showTopChart, setShowTopChart] = useState(true);

  // Aggregate stat strip (client-side over the loaded rows).
  const aggStats = useMemo(() => {
    const rois = rows
      .map((r) => r.roiPct)
      .filter((v): v is string => v !== null)
      .map(Number)
      .sort((a, b) => a - b);
    const medianRoi =
      rois.length === 0
        ? null
        : rois.length % 2 === 1
          ? rois[(rois.length - 1) / 2]
          : (rois[rois.length / 2 - 1] + rois[rois.length / 2]) / 2;
    const realized = rows.reduce((s, r) => s + Number(r.realizedPnlEth), 0);
    const unrealized = rows.reduce((s, r) => s + Number(r.unrealizedPnlEth ?? 0), 0);
    const opens = rows.reduce((s, r) => s + r.openPositions, 0);
    return { medianRoi, realized, unrealized, opens };
  }, [rows]);

  // Top-10 traders by total PnL (realized + unrealized).
  const top10 = useMemo(
    () =>
      rows
        .map((r) => ({
          addr: truncateAddr(r.address),
          total: Number((Number(r.realizedPnlEth) + Number(r.unrealizedPnlEth ?? 0)).toFixed(8)),
        }))
        .sort((a, b) => b.total - a.total)
        .slice(0, 10),
    [rows],
  );

  const watchedAddrs = new Set(
    (watchedQuery.data ?? [])
      .filter((w) => w.chain === selectedChain.key)
      .map((w) => w.address.toLowerCase()),
  );

  const summaryChips = lastSummary
    ? lastSummary.cached
      ? [
          `cached scan ${lastSummary.scannedAt ? timeAgo(lastSummary.scannedAt) : ""}`.trim(),
          `${lastSummary.tradersStored} traders stored`,
          ...(lastSummary.fromBlock !== null && lastSummary.toBlock !== null
            ? [`blocks ${lastSummary.fromBlock}–${lastSummary.toBlock}`]
            : []),
        ]
      : [
          `${lastSummary.scannedBlocks} blocks scanned`,
          `${lastSummary.logsFound} trades found`,
          `${lastSummary.mintLogsFound} mint logs · ${lastSummary.txsFetched} mint txs`,
          `${lastSummary.mintFlips} mint flips`,
          `${lastSummary.tradersStored} traders stored`,
          `${(lastSummary.durationMs / 1000).toFixed(1)}s via ${lastSummary.endpointSource} rpc`,
        ]
    : [];

  return (
    <div className="card-base p-0">
      <AnimatePresence>
        {selected && (
          <TraderFlipsDrawer
            key={selected.address}
            chainId={chainId}
            trader={selected}
            onClose={() => setSelected(null)}
          />
        )}
      </AnimatePresence>
      <div className="border-b border-hairline px-5 py-4">
        <h3 className="font-display text-[15px] font-semibold text-tpri">
          Discover profitable traders
        </h3>
        <p className="mt-0.5 font-mono text-[11px] text-tmut">
          real on-chain OpenSea settlement scan — no API keys, no curated lists
        </p>
      </div>

      <div className="space-y-4 px-5 py-4">
        {/* Chain chips */}
        <div className="flex flex-wrap gap-2">
          {CHAINS.map((c) => {
            const stat = chainStats.get(c.id);
            return (
              <button
                key={c.key}
                type="button"
                onClick={() => setChainId(c.id)}
                className={cn(
                  "flex flex-col items-start gap-0.5 rounded-lg border px-3 py-1.5 font-mono text-[11px] transition-colors",
                  chainId === c.id
                    ? "border-violet/60 bg-violet/10 text-tpri"
                    : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                )}
              >
                <span className="flex items-center gap-1.5">
                  <img src={c.icon} alt="" className="h-3 w-3" />
                  {c.label}
                </span>
                <span className="text-[9px] uppercase tracking-wider opacity-70">
                  {stat?.lastScannedAt
                    ? `scanned ${timeAgo(stat.lastScannedAt)}`
                    : "never scanned"}
                </span>
              </button>
            );
          })}
        </div>

        {/* Scan button + summary */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            disabled={scan.isPending}
            onClick={() => scan.mutate({ chainId })}
            className="flex items-center gap-2 rounded-lg bg-g-brand px-4 py-2.5 text-[13px] font-semibold text-white transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
          >
            <Radar className={cn("h-4 w-4", scan.isPending && "animate-spin")} />
            {scan.isPending ? `Scanning ${selectedChain.label}… (up to 150s)` : "Scan chain now"}
          </button>
          {summaryChips.map((chip) => (
            <span
              key={chip}
              className="rounded-full border border-hairline bg-panel2 px-2.5 py-1 font-mono text-[10px] text-tsec"
            >
              {chip}
            </span>
          ))}
          {lastSummary && !lastSummary.cached && lastSummary.partial && (
            <span className="rounded-full border border-alarm/40 bg-alarm/10 px-2.5 py-1 font-mono text-[10px] text-alarm">
              partial — RPC budget/rate limits hit; add a private RPC for deeper scans
            </span>
          )}
          {lastSummary?.cached && (
            <span className="font-mono text-[10px] text-amber">
              results fresh (&lt;10m old) — showing cached scan
            </span>
          )}
        </div>

        {/* Mode chips + filters */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex gap-2">
            {(
              [
                { key: "all", label: "All flips" },
                { key: "mint", label: "Mint profits" },
              ] as const
            ).map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => {
                  setMode(m.key);
                  // Mint mode defaults the ROI floor to +200% (product default).
                  if (m.key === "mint" && minRoiInput === "") setMinRoiInput("200");
                  if (m.key === "all" && minRoiInput === "200") setMinRoiInput("");
                }}
                className={cn(
                  "rounded-full border px-3 py-1.5 font-mono text-[11px] transition-colors",
                  mode === m.key
                    ? m.key === "mint"
                      ? "border-neon/60 bg-neon/10 text-neon"
                      : "border-violet/60 bg-violet/10 text-tpri"
                    : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                )}
              >
                {m.label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] text-tmut">
            <label className="flex items-center gap-1.5">
              min PnL
              <input
                className="w-20 rounded border border-hairline bg-void px-1.5 py-1 text-tpri focus:border-violet/60 focus:outline-none"
                placeholder="0.0"
                value={minPnlInput}
                onChange={(e) => setMinPnlInput(e.target.value.trim())}
                title="Minimum PnL in ETH (mode column)"
              />
              ETH
            </label>
            <label className="flex items-center gap-1.5">
              min ROI
              <input
                className="w-16 rounded border border-hairline bg-void px-1.5 py-1 text-tpri focus:border-violet/60 focus:outline-none"
                placeholder="any"
                value={minRoiInput}
                onChange={(e) => setMinRoiInput(e.target.value.trim())}
                title="Minimum ROI % — free mints (∞) always pass"
              />
              %
            </label>
            {mode === "mint" && minRoiPct === 200 && (
              <span className="rounded-full border border-neon/40 bg-neon/10 px-2 py-0.5 text-[10px] text-neon">
                surfacing +200% mint profit wallets
              </span>
            )}
          </div>
        </div>

        {/* Methodology disclosure */}
        <div className="rounded-lg border border-hairline bg-panel2/60 px-4 py-3 font-mono text-[11px] leading-relaxed text-tmut">
          {METHODOLOGY_TEXT}
        </div>
      </div>

      {/* Results */}
      {listQuery.isLoading ? (
        <div className="space-y-3 p-5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <div className="p-5">
          <EmptyState
            icon={<Radar className="h-5 w-5" />}
            title={lastScannedAt === null ? "No scan yet — run one" : "No qualifying traders"}
            body={
              lastScannedAt === null
                ? "Pick a chain and hit Scan — MintDash reads Seaport OrderFulfilled events straight from the chain via your RPC."
                : "No qualifying traders in this window — try a longer window later. Some chains have no Seaport deployment, so zero trades is expected there."
            }
          />
        </div>
      ) : (
        <>
        {/* Aggregate stat strip */}
        <div className="space-y-3 border-b border-hairline px-5 py-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
            {[
              { label: "Traders scanned", value: String(rows.length), cls: "text-tpri" },
              {
                label: "Median ROI",
                value: aggStats.medianRoi === null ? "—" : fmtRoi(aggStats.medianRoi, 0),
                cls:
                  aggStats.medianRoi === null
                    ? "text-tmut"
                    : aggStats.medianRoi >= 0
                      ? "text-neon"
                      : "text-alarm",
              },
              {
                label: "Σ Realized PnL",
                value: `${fmtEth(aggStats.realized)} ETH`,
                cls: aggStats.realized >= 0 ? "text-neon" : "text-alarm",
              },
              {
                label: "Σ Unrealized PnL",
                value: `${fmtEth(aggStats.unrealized)} ETH`,
                cls: aggStats.unrealized >= 0 ? "text-neon" : "text-alarm",
              },
              { label: "Open positions", value: String(aggStats.opens), cls: "text-cyan" },
            ].map((c) => (
              <div key={c.label} className="rounded-lg border border-hairline bg-panel2/60 px-3 py-2">
                <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-tmut">
                  {c.label}
                </p>
                <p className={cn("tnum mt-1 font-mono text-sm font-bold", c.cls)}>{c.value}</p>
              </div>
            ))}
          </div>

          {/* Top-10 by total PnL (collapsible) */}
          <div className="rounded-lg border border-hairline bg-panel2/40">
            <button
              type="button"
              onClick={() => setShowTopChart((v) => !v)}
              className="flex w-full items-center justify-between px-3 py-2 font-mono text-[10px] uppercase tracking-[0.16em] text-tmut transition-colors hover:text-tsec"
            >
              Top 10 by total PnL (realized + unrealized)
              {showTopChart ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </button>
            {showTopChart && (
              <div className="h-[180px] px-2 pb-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={top10}
                    layout="vertical"
                    margin={{ top: 0, right: 12, bottom: 0, left: 4 }}
                  >
                    <CartesianGrid stroke={GRID_STROKE} horizontal={false} />
                    <XAxis
                      type="number"
                      tick={AXIS_TICK}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(v: number) => v.toFixed(2)}
                    />
                    <YAxis
                      type="category"
                      dataKey="addr"
                      tick={AXIS_TICK}
                      tickLine={false}
                      axisLine={false}
                      width={82}
                    />
                    <Tooltip content={<ChartTooltip />} cursor={{ fill: "#ffffff08" }} />
                    <Bar dataKey="total" name="total PnL" isAnimationActive={false} maxBarSize={12}>
                      {top10.map((t, i) => (
                        <Cell key={i} fill={t.total >= 0 ? "#39FF8E" : "#FF4D6A"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[1360px]">
            <thead>
              <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                <th className="px-5 py-2.5 font-medium">#</th>
                <th className="px-3 py-2.5 font-medium">Trader</th>
                <th className="px-3 py-2.5 font-medium">Labels</th>
                <th className="px-3 py-2.5 font-medium">
                  {mode === "mint" ? "Mint PnL" : "Realized PnL"}
                </th>
                <th className="px-3 py-2.5 font-medium">Unrealized</th>
                <th className="px-3 py-2.5 font-medium">Open</th>
                <th className="px-3 py-2.5 font-medium">Total</th>
                <th className="px-3 py-2.5 font-medium">ROI</th>
                <th className="px-3 py-2.5 font-medium">Win rate</th>
                <th className="px-3 py-2.5 font-medium">Avg PnL</th>
                <th className="px-3 py-2.5 font-medium">Best flip</th>
                <th className="px-3 py-2.5 font-medium">Avg hold</th>
                <th className="px-3 py-2.5 font-medium">Collections</th>
                <th className="px-3 py-2.5 font-medium">Volume</th>
                <th className="px-3 py-2.5 font-medium">All-time</th>
                <th className="py-2.5 pl-3 pr-5 text-right font-medium">Copy</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const pnl = Number(mode === "mint" ? r.mintPnlEth : r.realizedPnlEth);
                const total = Number(r.realizedPnlEth) + Number(r.unrealizedPnlEth ?? 0);
                const volume = Number(r.spendEth) + Number(r.proceedsEth);
                const addrKey = r.address.toLowerCase();
                const copying = watchedAddrs.has(addrKey) || justAdded.has(addrKey);
                return (
                  <motion.tr
                    key={r.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.03 * i, duration: 0.25 }}
                    onClick={() => setSelected(r)}
                    className="cursor-pointer border-b border-hairline/60 transition-colors hover:bg-panel2/40"
                  >
                    <td className="px-5 py-3 font-mono text-[11px] text-tmut">{i + 1}</td>
                    <td className="px-3 py-3">
                      <span className="flex items-center gap-1.5 font-mono text-[12px] text-tpri">
                        {truncateAddr(r.address)}
                        <CopyAddr value={r.address} />
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      {r.labels.length > 0 ? (
                        <WalletLabels labels={r.labels} />
                      ) : (
                        <span className="font-mono text-[11px] text-tmut">—</span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <span className={pnl >= 0 ? "chip-profit" : "chip-loss"}>
                        {pnl >= 0 ? "+" : ""}
                        {pnl.toFixed(3)} ETH
                      </span>
                    </td>
                    <td className="px-3 py-3 font-mono text-[12px]">
                      {r.unrealizedPnlEth === null ? (
                        <span className="text-tmut">—</span>
                      ) : (
                        <span
                          className={Number(r.unrealizedPnlEth) >= 0 ? "text-neon" : "text-alarm"}
                        >
                          {fmtEth(r.unrealizedPnlEth)}
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      {r.openPositions > 0 ? (
                        <span className="rounded-full border border-cyan/40 bg-cyan/10 px-2 py-0.5 font-mono text-[10px] text-cyan">
                          {r.openPositions}
                        </span>
                      ) : (
                        <span className="font-mono text-[12px] text-tmut">—</span>
                      )}
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={cn(
                          "font-mono text-[12px] font-bold",
                          total >= 0 ? "text-neon" : "text-alarm",
                        )}
                      >
                        {fmtEth(total)}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <RoiCell roiPct={r.roiPct} wins={r.wins} />
                    </td>
                    <td className="px-3 py-3 font-mono text-[12px] text-tsec">
                      {r.flips > 0 ? (
                        <>
                          {r.winRatePct}%
                          <span className="text-tmut">
                            {" "}
                            ({r.wins}/{r.flips})
                          </span>
                        </>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-3 py-3 font-mono text-[12px] text-tsec">
                      {r.flips > 0 ? `${Number(r.avgPnlEth).toFixed(3)}` : "—"}
                    </td>
                    <td className="px-3 py-3 font-mono text-[12px] text-tsec">
                      {r.flips > 0 ? `${Number(r.bestFlipEth).toFixed(3)}` : "—"}
                    </td>
                    <td className="px-3 py-3 font-mono text-[12px] text-tsec">
                      {r.avgHoldHours !== null ? `${Number(r.avgHoldHours).toFixed(1)}h` : "—"}
                    </td>
                    <td className="px-3 py-3 font-mono text-[12px] text-tsec">{r.collections}</td>
                    <td className="px-3 py-3 font-mono text-[12px] text-tsec">
                      {volume.toFixed(3)} ETH
                    </td>
                    <td className="px-3 py-3">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onProfile(r.address);
                        }}
                        title="All-time PnL from full OpenSea trade history"
                        className="rounded-lg border border-violet/40 px-2.5 py-1 font-mono text-[10px] text-violet transition-colors hover:bg-violet/10 disabled:opacity-40 disabled:hover:bg-transparent"
                      >
                        All-time
                      </button>
                    </td>
                    <td className="py-3 pl-3 pr-5 text-right">
                      {copying ? (
                        <span className="font-mono text-[11px] text-neon">Copying ✓</span>
                      ) : (
                        <button
                          disabled={addCopy.isPending}
                          onClick={(e) => {
                            e.stopPropagation();
                            addCopy.mutate({
                              address: r.address,
                              label: `discovered:${truncateAddr(r.address)}`,
                              chain: selectedChain.key,
                              copyMints: true,
                              copyBuys: true,
                              maxPerTradeEth: "0.1",
                              maxDailyEth: "1",
                            });
                          }}
                          className="rounded-lg border border-violet/40 bg-violet/10 px-3 py-1.5 font-mono text-[11px] text-violet transition-colors hover:bg-violet/20 disabled:opacity-40"
                        >
                          Copy
                        </button>
                      )}
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
          <p className="px-5 py-3 font-mono text-[10px] text-tmut">
            window blocks {rows[0]?.fromBlock}–{rows[0]?.toBlock}
            {lastScannedAt ? ` · scanned ${timeAgo(lastScannedAt)}` : ""} · click a row for P&L in
            detail
          </p>
        </div>
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Section                                                             */
/* ------------------------------------------------------------------ */

function CopyTradingInner({ pushToast }: { pushToast: ToastFn }) {
  const utils = trpc.useUtils();
  const list = trpc.copy.list.useQuery(undefined, { refetchInterval: 8000 });
  const stats = trpc.copy.copyStats.useQuery(undefined, { refetchInterval: 8000 });

  const [address, setAddress] = useState("");
  const [label, setLabel] = useState("");
  const [chain, setChain] = useState<(typeof CHAINS)[number]["key"]>("ethereum");
  const [formError, setFormError] = useState<string | null>(null);
  const [tab, setTab] = useState<"watchlist" | "discover">("watchlist");
  const [profileAddress, setProfileAddress] = useState<string | null>(null);

  // CSV bulk import state.
  const csvFileRef = useRef<HTMLInputElement>(null);
  const [csvPreview, setCsvPreview] = useState<CsvParseResult | null>(null);
  const [csvSkipped, setCsvSkipped] = useState<
    { address: string; reason: string }[] | null
  >(null);

  // The all-time profiler works out of the box — the server resolves an
  // OpenSea key for every user (own key or the platform's shared key).
  const add = trpc.copy.add.useMutation({
    onSuccess: async () => {
      pushToast(`Watching ${label}`, "success");
      setAddress("");
      setLabel("");
      setFormError(null);
      await Promise.all([utils.copy.list.invalidate(), utils.stats.overview.invalidate()]);
    },
    onError: (e) => setFormError(e.message),
  });

  const bulkAdd = trpc.copy.bulkAdd.useMutation({
    onSuccess: async (res) => {
      pushToast(
        `${res.added} added, ${res.skipped.length} skipped`,
        res.skipped.length > 0 ? "info" : "success",
      );
      setCsvPreview(null);
      setCsvSkipped(res.skipped);
      await utils.copy.list.invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const handleCsvFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file
    if (!file) return;
    const parsed = parseCsvText(await file.text());
    if (parsed.entries.length === 0) {
      pushToast("No valid addresses found in CSV", "error");
      setCsvPreview(parsed.errors.length > 0 ? parsed : null);
      return;
    }
    setCsvSkipped(null);
    setCsvPreview(parsed);
  };

  const wallets = list.data ?? [];
  const pnl = Number(stats.data?.pnlEth ?? 0);

  return (
    <div className="flex flex-col gap-6">
      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {[
          { label: "Watched snipers", value: String(wallets.length) },
          { label: "Mirrored fills", value: String(stats.data?.mirroredCount ?? 0) },
          {
            label: "Realized PnL",
            value: `${pnl >= 0 ? "+" : ""}${pnl.toFixed(3)} ETH`,
            cls: pnl >= 0 ? "text-neon" : "text-alarm",
          },
        ].map((c, i) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.07 * i, duration: 0.35 }}
            className="card-base p-5"
          >
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-tmut">{c.label}</p>
            <p className={cn("tnum mt-2 font-mono text-2xl font-bold text-tpri", c.cls)}>
              {c.value}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-hairline">
        {(
          [
            { key: "watchlist", label: "My watchlist", icon: Eye },
            { key: "discover", label: "Discover (on-chain)", icon: Radar },
          ] as const
        ).map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={cn(
              "flex items-center gap-2 border-b-2 px-4 py-2.5 font-mono text-[12px] uppercase tracking-wider transition-colors",
              tab === t.key
                ? "border-neon text-tpri"
                : "border-transparent text-tmut hover:text-tsec",
            )}
          >
            <t.icon className="h-3.5 w-3.5" />
            {t.label}
          </button>
        ))}
      </div>

      {tab === "discover" ? (
        <DiscoverPanel
          pushToast={pushToast}
          onProfile={setProfileAddress}
        />
      ) : (
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-5">
        {/* Watched wallets */}
        <div className="card-base p-0 xl:col-span-3">
          <div className="flex items-start justify-between gap-3 border-b border-hairline px-5 py-4">
            <div>
              <h3 className="font-display text-[15px] font-semibold text-tpri">Watched wallets</h3>
              <p className="mt-0.5 font-mono text-[11px] text-tmut">
                mirroring executes live on-chain from your bot vault — real funds, real risk
              </p>
            </div>
            <input
              ref={csvFileRef}
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={handleCsvFile}
            />
            <button
              type="button"
              onClick={() => csvFileRef.current?.click()}
              title="Bulk-add wallets from a CSV of address[,label] lines (max 100)"
              className="flex shrink-0 items-center gap-1.5 rounded-lg border border-violet/40 bg-violet/10 px-3 py-1.5 font-mono text-[11px] text-violet transition-colors hover:bg-violet/20"
            >
              <Upload className="h-3.5 w-3.5" /> Import CSV
            </button>
          </div>

          {/* Add form */}
          <div className="border-b border-hairline px-5 py-4">
            <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr_auto]">
              <div>
                <FieldLabel>Sniper address or profile link</FieldLabel>
                <input
                  className={inputCls}
                  placeholder="0x7a3F… or opensea.io/0x7a3F…"
                  value={address}
                  onChange={(e) => setAddress(e.target.value.trim())}
                />
              </div>
              <div>
                <FieldLabel>Label</FieldLabel>
                <input
                  className={inputCls}
                  placeholder="goblinmode"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                />
              </div>
              <div className="flex items-end">
                <button
                  disabled={add.isPending}
                  onClick={() => {
                    const parsed = parseWalletLink(address);
                    if (!parsed.ok) {
                      setFormError(parsed.reason);
                      return;
                    }
                    if (!ADDR_RE.test(parsed.address)) {
                      setFormError("Must be a valid 0x address");
                      return;
                    }
                    if (!label.trim()) {
                      setFormError("Label is required");
                      return;
                    }
                    add.mutate({ address: parsed.address, label: label.trim(), chain });
                  }}
                  className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-g-brand px-4 py-2.5 text-[13px] font-semibold text-white transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40 md:w-auto"
                >
                  <Plus className="h-4 w-4" /> Watch
                </button>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {CHAINS.map((c) => (
                <button
                  key={c.key}
                  type="button"
                  onClick={() => setChain(c.key)}
                  className={cn(
                    "flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[11px] transition-colors",
                    chain === c.key
                      ? "border-violet/60 bg-violet/10 text-tpri"
                      : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                  )}
                >
                  <img src={c.icon} alt="" className="h-3 w-3" />
                  {c.label}
                </button>
              ))}
            </div>
            <div className="mt-2">
              <ServerError message={formError} />
            </div>
          </div>

          {/* CSV import preview */}
          {csvPreview && (
            <div className="space-y-2 border-b border-hairline px-5 py-3">
              <p className="font-mono text-[11px] text-tsec">
                CSV preview:{" "}
                <span className="text-neon">{csvPreview.entries.length} valid</span>
                {csvPreview.errors.length > 0 && (
                  <span className="text-alarm"> · {csvPreview.errors.length} invalid</span>
                )}
                {csvPreview.truncated > 0 && (
                  <span className="text-amber">
                    {" "}
                    · {csvPreview.truncated} over the {CSV_IMPORT_CAP} cap ignored
                  </span>
                )}
              </p>
              {csvPreview.errors.length > 0 && (
                <ul className="space-y-0.5">
                  {csvPreview.errors.slice(0, 5).map((err) => (
                    <li key={err} className="font-mono text-[10px] text-alarm">
                      ✕ {err}
                    </li>
                  ))}
                  {csvPreview.errors.length > 5 && (
                    <li className="font-mono text-[10px] text-tmut">
                      …and {csvPreview.errors.length - 5} more
                    </li>
                  )}
                </ul>
              )}
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={bulkAdd.isPending || csvPreview.entries.length === 0}
                  onClick={() => bulkAdd.mutate({ entries: csvPreview.entries })}
                  className="rounded-lg bg-g-brand px-3.5 py-1.5 text-[12px] font-semibold text-white transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
                >
                  {bulkAdd.isPending
                    ? "Importing…"
                    : `Import ${csvPreview.entries.length} wallet${csvPreview.entries.length === 1 ? "" : "s"}`}
                </button>
                <button
                  type="button"
                  onClick={() => setCsvPreview(null)}
                  className="rounded-lg border border-hairline px-3.5 py-1.5 text-[12px] font-medium text-tsec hover:text-tpri"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Skipped entries from the last import */}
          {!csvPreview && csvSkipped && csvSkipped.length > 0 && (
            <div className="border-b border-hairline px-5 py-3">
              <details>
                <summary className="cursor-pointer font-mono text-[11px] text-amber">
                  {csvSkipped.length} skipped on last import — expand for reasons
                </summary>
                <ul className="mt-1.5 space-y-0.5">
                  {csvSkipped.map((s) => (
                    <li key={s.address} className="font-mono text-[10px] text-tmut">
                      {truncateAddr(s.address)} — {s.reason}
                    </li>
                  ))}
                </ul>
              </details>
            </div>
          )}

          {list.isLoading ? (
            <div className="space-y-3 p-5">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
              ))}
            </div>
          ) : wallets.length === 0 ? (
            <div className="p-5">
              <EmptyState
                icon={<Eye className="h-5 w-5" />}
                title="Not copying anyone yet"
                body="Add a profitable sniper address — MintDash mirrors their mints and buys into your wallets within ~412ms, under your caps."
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
                <thead>
                  <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                    <th className="px-5 py-2.5 font-medium">Sniper</th>
                    <th className="px-3 py-2.5 font-medium">Chain</th>
                    <th className="px-3 py-2.5 font-medium">Caps (ETH)</th>
                    <th className="px-3 py-2.5 font-medium">Copy</th>
                    <th className="py-2.5 pl-3 pr-5 text-right font-medium">Active</th>
                  </tr>
                </thead>
                <tbody className="px-5">
                  {wallets.map((w, i) => (
                    <WatchedRow
                      // Key includes the server values so local input state
                      // re-syncs by remount when they change (no effect sync).
                      key={`${w.id}:${w.maxPerTradeEth}:${w.maxDailyEth}`}
                      wallet={w}
                      index={i}
                      pushToast={pushToast}
                      onProfile={setProfileAddress}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Signals feed */}
        <div className="card-base self-start p-0 xl:col-span-2">
          <div className="flex items-center justify-between border-b border-hairline px-4 py-3.5">
            <h3 className="font-display text-[15px] font-semibold text-tpri">Mirror signals</h3>
            <span className="font-mono text-[10px] uppercase tracking-wider text-tmut">
              latest 100
            </span>
          </div>
          <SignalsFeed />
        </div>
      </div>
      )}

      <AnimatePresence>
        {profileAddress && (
          <WalletProfileDrawer
            key={profileAddress}
            address={profileAddress}
            onClose={() => setProfileAddress(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/**
 * Paywall gate: free-plan users see a lock card instead of the copy-trading
 * console (queries/mutations never mount). Pro/admin render straight through.
 */
export default function CopyTrading({
  pushToast,
  onNavigate,
}: {
  pushToast: ToastFn;
  onNavigate?: (s: SectionKey) => void;
}) {
  const entitlement = useEntitlement();
  if (entitlement && entitlement.plan === "free") {
    return (
      <LockCard
        title="Copy Trading & Sniper Discovery"
        lines={[
          "Mirror proven on-chain snipers the moment they mint or buy.",
          "Includes the discover scanner and all-time PnL wallet profiles.",
        ]}
        onUpgrade={() => onNavigate?.("upgrade")}
      />
    );
  }
  return <CopyTradingInner pushToast={pushToast} />;
}
