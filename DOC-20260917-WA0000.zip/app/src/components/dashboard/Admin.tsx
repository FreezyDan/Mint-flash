import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Check,
  ExternalLink,
  KeyRound,
  Receipt,
  Save,
  ShieldCheck,
  Users,
  Wallet,
  X,
} from "lucide-react";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../api/router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { PLANS, type Plan } from "@contracts/plans";
import { explorerTxUrl } from "@contracts/rpc";
import {
  ChainBadge,
  CopyAddr,
  EmptyState,
  FieldLabel,
  inputCls,
  timeAgo,
  truncateAddr,
} from "./shared";

type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;
type AdminUser = inferRouterOutputs<AppRouter>["admin"]["users"]["list"][number];

/** datetime-local input value from a Date; "" for null. */
function toLocalInput(d: Date | string | null): string {
  if (!d) return "";
  const date = d instanceof Date ? d : new Date(d);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(
    date.getHours(),
  )}:${pad(date.getMinutes())}`;
}

function UserRow({
  user,
  index,
  pushToast,
}: {
  user: AdminUser;
  index: number;
  pushToast: ToastFn;
}) {
  const utils = trpc.useUtils();
  const [plan, setPlan] = useState<Plan>(user.plan === "pro" ? "pro" : "free");
  const [expiry, setExpiry] = useState<string>(toLocalInput(user.planExpiresAt));

  useEffect(() => {
    setPlan(user.plan === "pro" ? "pro" : "free");
    setExpiry(toLocalInput(user.planExpiresAt));
  }, [user.plan, user.planExpiresAt]);

  const setPlanMutation = trpc.admin.users.setPlan.useMutation({
    onSuccess: async () => {
      pushToast(`${user.email ?? user.id} → ${plan.toUpperCase()}`, "success");
      await utils.admin.users.list.invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  /* ---- [password reset] admin-assisted temp password ---- */
  const [tempPassword, setTempPassword] = useState<string | null>(null);
  const resetPw = trpc.admin.users.resetPassword.useMutation({
    onSuccess: (data) => {
      setTempPassword(data.tempPassword);
      pushToast(`Temp password generated for ${user.email ?? user.id}`, "success");
    },
    onError: (e) => pushToast(e.message, "error"),
  });
  /* ---- [/password reset] ---- */

  const dirty =
    plan !== (user.plan === "pro" ? "pro" : "free") ||
    expiry !== toLocalInput(user.planExpiresAt);

  return (
    <motion.tr
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.03 * index, duration: 0.25 }}
      className="border-b border-hairline last:border-0"
    >
      <td className="py-2.5 pl-5 pr-3">
        <p className="text-[13px] font-medium text-tpri">{user.name || "—"}</p>
        <p className="font-mono text-[11px] text-tmut">{user.email ?? "—"}</p>
      </td>
      <td className="px-3 py-2.5">
        {user.admin ? (
          <span className="rounded-full border border-neon/50 bg-neon/10 px-2 py-0.5 font-mono text-[10px] tracking-wider text-neon">
            ADMIN
          </span>
        ) : (
          <select
            value={plan}
            onChange={(e) => setPlan(e.target.value as Plan)}
            className="rounded-lg border border-hairline bg-void px-2 py-1.5 font-mono text-[12px] text-tpri focus:border-violet/60 focus:outline-none"
          >
            {PLANS.map((p) => (
              <option key={p} value={p}>
                {p.toUpperCase()}
              </option>
            ))}
          </select>
        )}
      </td>
      <td className="px-3 py-2.5">
        <input
          type="datetime-local"
          value={expiry}
          disabled={user.admin}
          onChange={(e) => setExpiry(e.target.value)}
          className={cn(inputCls, "w-[190px] px-2 py-1.5 text-[11px] [color-scheme:dark]")}
          title="Empty = no expiry"
        />
      </td>
      <td className="tnum px-3 py-2.5 font-mono text-[12px] text-tsec">
        {user.trialDaysLeft === null ? "—" : `${user.trialDaysLeft}d`}
      </td>
      <td className="py-2.5 pl-3 pr-5 text-right">
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-1.5">
            {/* ---- [password reset] row action ---- */}
            <button
              type="button"
              disabled={user.admin || resetPw.isPending}
              onClick={() => resetPw.mutate({ userId: user.id })}
              title="Generate a temporary password (shown once)"
              className="inline-flex items-center gap-1 rounded-lg border border-amber/50 bg-amber/10 px-2.5 py-1.5 font-mono text-[11px] text-amber transition-colors hover:bg-amber/20 disabled:opacity-40"
            >
              <KeyRound className="h-3 w-3" />
              {resetPw.isPending ? "resetting…" : "Reset pw"}
            </button>
            {/* ---- [/password reset] ---- */}
            <button
              type="button"
              disabled={user.admin || !dirty || setPlanMutation.isPending}
              onClick={() =>
                setPlanMutation.mutate({
                  userId: user.id,
                  plan,
                  expiresAt: plan === "pro" && expiry ? new Date(expiry) : null,
                })
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-violet/50 bg-violet/10 px-3 py-1.5 font-mono text-[11px] text-violet transition-colors hover:bg-violet/20 disabled:opacity-40"
            >
              <Save className="h-3 w-3" />
              {setPlanMutation.isPending ? "saving…" : "save"}
            </button>
          </div>
          {/* ---- [password reset] one-time temp password display ---- */}
          {tempPassword && (
            <div className="rounded-lg border border-amber/40 bg-amber/5 p-2 text-left">
              <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-amber">
                temp password — shown once
              </p>
              <div className="mt-1 flex items-center gap-2 rounded border border-hairline bg-void px-2 py-1.5">
                <span className="font-mono text-[12px] text-tpri">{tempPassword}</span>
                <CopyAddr value={tempPassword} />
              </div>
            </div>
          )}
          {/* ---- [/password reset] ---- */}
        </div>
      </td>
    </motion.tr>
  );
}

/* ---- [crypto billing] payment claims panel (delimited section) ---------- */
type AdminClaim = inferRouterOutputs<AppRouter>["admin"]["billing"]["claims"][number];

function ClaimRow({
  claim,
  index,
  pushToast,
}: {
  claim: AdminClaim;
  index: number;
  pushToast: ToastFn;
}) {
  const utils = trpc.useUtils();
  const [note, setNote] = useState("");

  const review = trpc.admin.billing.reviewClaim.useMutation({
    onSuccess: async (_r, vars) => {
      pushToast(
        vars.approve
          ? `Claim approved — PRO granted to ${claim.userEmail ?? claim.userId}`
          : "Claim rejected",
        vars.approve ? "success" : "info",
      );
      await Promise.all([
        utils.admin.billing.claims.invalidate(),
        utils.admin.users.list.invalidate(),
      ]);
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const explorer = explorerTxUrl(claim.chainId, claim.txHash);

  return (
    <motion.tr
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.03 * index, duration: 0.25 }}
      className="border-b border-hairline last:border-0"
    >
      <td className="py-2.5 pl-5 pr-3">
        <p className="text-[13px] font-medium text-tpri">{claim.userName || "—"}</p>
        <p className="font-mono text-[11px] text-tmut">
          {claim.userEmail ?? `#${claim.userId}`}
        </p>
      </td>
      <td className="px-3 py-2.5">
        <ChainBadge chainId={claim.chainId} />
      </td>
      <td className="px-3 py-2.5">
        <a
          href={explorer ?? undefined}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1 font-mono text-[12px] text-violet transition-colors hover:text-tpri"
        >
          {truncateAddr(claim.txHash)}
          <ExternalLink className="h-3 w-3" />
        </a>
      </td>
      <td className="px-3 py-2.5 font-mono text-[11px] text-tmut">
        {timeAgo(claim.createdAt)}
      </td>
      <td className="px-3 py-2.5">
        <input
          className={cn(inputCls, "w-[160px] px-2 py-1.5 text-[11px]")}
          placeholder="note (optional)"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />
      </td>
      <td className="py-2.5 pl-3 pr-5">
        <div className="flex justify-end gap-1.5">
          <button
            type="button"
            disabled={review.isPending}
            onClick={() =>
              review.mutate({ claimId: claim.id, approve: true, note: note || undefined })
            }
            className="inline-flex items-center gap-1 rounded-lg border border-neon/50 bg-neon/10 px-2.5 py-1.5 font-mono text-[11px] text-neon transition-colors hover:bg-neon/20 disabled:opacity-40"
          >
            <Check className="h-3 w-3" />
            approve
          </button>
          <button
            type="button"
            disabled={review.isPending}
            onClick={() =>
              review.mutate({ claimId: claim.id, approve: false, note: note || undefined })
            }
            className="inline-flex items-center gap-1 rounded-lg border border-alarm/50 bg-alarm/10 px-2.5 py-1.5 font-mono text-[11px] text-alarm transition-colors hover:bg-alarm/20 disabled:opacity-40"
          >
            <X className="h-3 w-3" />
            reject
          </button>
        </div>
      </td>
    </motion.tr>
  );
}
/* ---- [/crypto billing] --------------------------------------------------- */

/* ---- [platform config] shared OpenSea key card (self-contained) --------- */
function SharedOpenseaKeyCard({ pushToast }: { pushToast: ToastFn }) {
  const utils = trpc.useUtils();
  const status = trpc.admin.platform.getSharedOpenseaKey.useQuery();
  const [draft, setDraft] = useState("");

  const invalidate = () => utils.admin.platform.getSharedOpenseaKey.invalidate();
  const save = trpc.admin.platform.setSharedOpenseaKey.useMutation({
    onSuccess: async (_r, vars) => {
      pushToast(
        vars.key ? "Shared OpenSea key override saved" : "Override cleared — built-in key active",
        "success",
      );
      setDraft("");
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const trimmed = draft.trim();
  const valid = /^[0-9a-f]{32}$/.test(trimmed);

  return (
    <div className="card-base p-5">
      <div className="flex items-center gap-2">
        <KeyRound className="h-4 w-4 text-violet" />
        <h3 className="font-display text-[15px] font-semibold text-tpri">
          Shared OpenSea API key
        </h3>
      </div>
      <p className="mt-1 font-mono text-[11px] leading-relaxed text-tmut">
        Platform key used when a user has no key of their own (floor sweeper, all-time
        profiler). Never displayed in full.{" "}
        {status.data?.usingBuiltin ? (
          <span className="text-amber">▸ built-in shared key active</span>
        ) : status.data?.isSet ? (
          <span className="text-neon">▸ custom override active ({status.data.stored})</span>
        ) : null}
      </p>
      <div className="mt-3 flex gap-2">
        <input
          className={inputCls}
          placeholder="32-char hex key — leave empty to clear"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          spellCheck={false}
          autoComplete="off"
        />
        <button
          type="button"
          disabled={!valid || save.isPending}
          onClick={() => save.mutate({ key: trimmed })}
          className="flex shrink-0 items-center gap-1.5 rounded-lg bg-g-brand px-4 py-2 font-mono text-[12px] font-semibold text-white transition-all hover:brightness-110 disabled:opacity-40"
        >
          <Save className="h-3.5 w-3.5" />
          {save.isPending ? "Saving…" : "Save"}
        </button>
        <button
          type="button"
          disabled={status.data?.usingBuiltin !== false || save.isPending}
          onClick={() => save.mutate({ key: null })}
          className="shrink-0 rounded-lg border border-hairline bg-panel2 px-4 py-2 font-mono text-[12px] text-tsec transition-colors hover:text-alarm disabled:opacity-40"
        >
          Clear
        </button>
      </div>
      {trimmed !== "" && !valid && (
        <p className="mt-2 font-mono text-[11px] text-alarm">
          ▸ must be exactly 32 lowercase hex chars
        </p>
      )}
    </div>
  );
}
/* ---- [/platform config] --------------------------------------------------- */

/** Admin console — user plan grants + the PRO pay-to-address billing. */
export default function Admin({ pushToast }: { pushToast: ToastFn }) {
  const utils = trpc.useUtils();
  const users = trpc.admin.users.list.useQuery(undefined, { refetchInterval: 15_000 });
  /* ---- [crypto billing] payment address + claims state ---- */
  const paymentAddress = trpc.admin.billing.getPaymentAddress.useQuery();
  const claims = trpc.admin.billing.claims.useQuery(undefined, {
    refetchInterval: 15_000,
  });
  const [addressDraft, setAddressDraft] = useState<string | null>(null);

  const saveAddress = trpc.admin.billing.setPaymentAddress.useMutation({
    onSuccess: async () => {
      pushToast("Payment address saved", "success");
      setAddressDraft(null);
      await Promise.all([
        utils.admin.billing.getPaymentAddress.invalidate(),
        utils.billing.paymentInfo.invalidate(),
      ]);
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const addressValue = addressDraft ?? paymentAddress.data?.effective ?? "";
  const addressDirty =
    addressDraft !== null && addressDraft !== (paymentAddress.data?.effective ?? "");
  const claimRows = claims.data ?? [];
  /* ---- [/crypto billing] ---- */

  const rows = users.data ?? [];

  return (
    <div className="flex flex-col gap-6">
      {/* ---- [crypto billing] payment address card ---- */}
      <div className="card-base p-5">
        <div className="flex items-center gap-2">
          <Wallet className="h-4 w-4 text-violet" />
          <h3 className="font-display text-[15px] font-semibold text-tpri">
            PRO payment address
          </h3>
        </div>
        <p className="mt-1 font-mono text-[11px] leading-relaxed text-tmut">
          EVM address buyers pay into for PRO. Shown on the Upgrade page; saving an
          override replaces the built-in default.{" "}
          {paymentAddress.data?.isDefault ? (
            <span className="text-amber">
              ▸ showing built-in default {truncateAddr(paymentAddress.data.effective)}
            </span>
          ) : (
            <span className="text-neon">▸ custom override active</span>
          )}
        </p>
        <div className="mt-3 flex gap-2">
          <input
            className={inputCls}
            placeholder="0x…"
            value={addressValue}
            onChange={(e) => setAddressDraft(e.target.value)}
            spellCheck={false}
          />
          <button
            type="button"
            disabled={!addressDirty || saveAddress.isPending}
            onClick={() =>
              saveAddress.mutate({ address: addressValue.trim() || null })
            }
            className="flex shrink-0 items-center gap-1.5 rounded-lg bg-g-brand px-4 py-2 font-mono text-[12px] font-semibold text-white transition-all hover:brightness-110 disabled:opacity-40"
          >
            <Save className="h-3.5 w-3.5" />
            {saveAddress.isPending ? "Saving…" : "Save"}
          </button>
        </div>
      </div>

      {/* ---- [crypto billing] payment claims panel ---- */}
      <div className="card-base p-0">
        <div className="flex items-center justify-between border-b border-hairline px-5 py-4">
          <div className="flex items-center gap-2">
            <Receipt className="h-4 w-4 text-violet" />
            <h3 className="font-display text-[15px] font-semibold text-tpri">
              Payment claims
            </h3>
          </div>
          <span className="tnum font-mono text-[10px] text-tmut">
            {claimRows.length} pending
          </span>
        </div>

        {claims.isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1].map((i) => (
              <div key={i} className="h-10 animate-pulse rounded-lg bg-panel2" />
            ))}
          </div>
        ) : claimRows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Receipt className="h-5 w-5" />}
              title="No pending claims"
              body="When users submit payment tx hashes from the Upgrade page they show up here for review."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px]">
              <thead>
                <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                  <th className="py-2.5 pl-5 pr-3 font-medium">User</th>
                  <th className="px-3 py-2.5 font-medium">Chain</th>
                  <th className="px-3 py-2.5 font-medium">Tx hash</th>
                  <th className="px-3 py-2.5 font-medium">Age</th>
                  <th className="px-3 py-2.5 font-medium">Note</th>
                  <th className="py-2.5 pl-3 pr-5 text-right font-medium">Review</th>
                </tr>
              </thead>
              <tbody>
                {claimRows.map((c, i) => (
                  <ClaimRow key={c.id} claim={c} index={i} pushToast={pushToast} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {/* ---- [/crypto billing] ---- */}

      {/* ---- [platform config] shared OpenSea key ---- */}
      <SharedOpenseaKeyCard pushToast={pushToast} />
      {/* ---- [/platform config] ---- */}

      {/* Users */}
      <div className="card-base p-0">
        <div className="flex items-center justify-between border-b border-hairline px-5 py-4">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-violet" />
            <h3 className="font-display text-[15px] font-semibold text-tpri">Users</h3>
          </div>
          <span className="tnum font-mono text-[10px] text-tmut">
            {rows.length} account{rows.length === 1 ? "" : "s"}
          </span>
        </div>

        {users.isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-10 animate-pulse rounded-lg bg-panel2" />
            ))}
          </div>
        ) : users.error ? (
          <div className="p-5">
            <EmptyState
              icon={<ShieldCheck className="h-5 w-5" />}
              title="Admin access required"
              body={users.error.message}
            />
          </div>
        ) : rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Users className="h-5 w-5" />}
              title="No users yet"
              body="Registered accounts will show up here for plan management."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px]">
              <thead>
                <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                  <th className="py-2.5 pl-5 pr-3 font-medium">User</th>
                  <th className="px-3 py-2.5 font-medium">Plan</th>
                  <th className="px-3 py-2.5 font-medium">PRO expiry</th>
                  <th className="px-3 py-2.5 font-medium">Trial left</th>
                  <th className="py-2.5 pl-3 pr-5 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((u, i) => (
                  <UserRow key={u.id} user={u} index={i} pushToast={pushToast} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="rounded-lg border border-hairline bg-panel2/60 px-4 py-3 font-mono text-[11px] leading-relaxed text-tmut">
        <FieldLabel>How PRO activation works</FieldLabel>
        Buyer sends $15 in native token to the payment address on a supported EVM chain and
        submits the tx hash → approve the claim above to grant 30 days of PRO automatically
        (or set a plan manually below). The admin account always has full access and is never
        editable.
      </div>
    </div>
  );
}
