import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { AlertTriangle, Gauge, KeyRound, Save, ShieldCheck } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import type { RpcRaceResult } from "@contracts/rpc";
import { CHAINS, FieldLabel, ServerError, inputCls } from "./shared";

type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;

/** Self-serve password change (credential accounts; OAuth gets a friendly server error). */
function ChangePasswordCard({ pushToast }: { pushToast: ToastFn }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const change = trpc.creds.changePassword.useMutation({
    onSuccess: () => {
      setError(null);
      setCurrentPassword("");
      setNewPassword("");
      pushToast("Password changed", "success");
    },
    onError: (e) => setError(e.message),
  });

  const submit = () => {
    setError(null);
    if (!currentPassword) {
      setError("Current password is required");
      return;
    }
    if (newPassword.length < 8) {
      setError("New password must be at least 8 characters");
      return;
    }
    change.mutate({ currentPassword, newPassword });
  };

  return (
    <div className="card-base">
      <div className="flex items-center gap-2">
        <KeyRound className="h-4 w-4 text-violet" />
        <h3 className="font-display text-[15px] font-semibold text-tpri">Change password</h3>
      </div>
      <p className="mt-1 font-mono text-[11px] text-tmut">
        ▸ email/password accounts only — Google sign-in accounts have no password
      </p>
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <FieldLabel>Current password</FieldLabel>
          <input
            type="password"
            className={inputCls}
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            autoComplete="current-password"
          />
        </div>
        <div>
          <FieldLabel>New password (min 8 chars)</FieldLabel>
          <input
            type="password"
            className={inputCls}
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            autoComplete="new-password"
          />
        </div>
      </div>
      <ServerError message={error} />
      <button
        disabled={change.isPending}
        onClick={submit}
        className="mt-4 rounded-lg border border-violet/50 bg-violet/10 px-4 py-2 font-mono text-xs text-violet transition-colors hover:bg-violet/20 disabled:opacity-40"
      >
        {change.isPending ? "Changing…" : "Change password"}
      </button>
    </div>
  );
}

export default function Settings({ pushToast }: { pushToast: ToastFn }) {
  const utils = trpc.useUtils();
  const settings = trpc.settings.get.useQuery();

  const [rpcUrl, setRpcUrl] = useState("");
  const [rpcAuto, setRpcAuto] = useState(true);
  const [chainId, setChainId] = useState<number>(1);
  const [maxGasGwei, setMaxGasGwei] = useState("500");
  const [openseaApiKey, setOpenseaApiKey] = useState("");
  const [mevProtection, setMeProtection] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [raceResults, setRaceResults] = useState<RpcRaceResult[] | null>(null);
  const [racing, setRacing] = useState(false);
  const [raceError, setRaceError] = useState<string | null>(null);

  const currentRpc = trpc.rpc.current.useQuery(undefined, { enabled: rpcAuto });

  // Hydrate form from server once loaded.
  useEffect(() => {
    const s = settings.data;
    if (!s) return;
    setRpcUrl(s.rpcUrl ?? "");
    setRpcAuto(s.rpcAuto);
    setChainId(s.chainId);
    setMaxGasGwei(String(s.maxGasGwei));
    setOpenseaApiKey(s.openseaApiKey ?? "");
    setMeProtection(s.mevProtection ?? true);
  }, [settings.data]);

  const update = trpc.settings.update.useMutation({
    onSuccess: async () => {
      setError(null);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
      pushToast("Settings saved", "success");
      await utils.settings.get.invalidate();
      await utils.rpc.current.invalidate();
    },
    onError: (e) => {
      setError(e.message);
    },
  });

  const save = () => {
    setError(null);
    update.mutate({
      rpcUrl: rpcUrl.trim() === "" ? null : rpcUrl.trim(),
      rpcAuto,
      chainId,
      maxGasGwei: Number(maxGasGwei) || 500,
      openseaApiKey: openseaApiKey.trim() === "" ? null : openseaApiKey.trim(),
      mevProtection,
    });
  };

  const raceNow = async () => {
    setRacing(true);
    setRaceError(null);
    try {
      const results = await utils.rpc.race.fetch({ chainId });
      setRaceResults(results);
      await utils.rpc.current.invalidate();
    } catch (e) {
      setRaceError((e as Error).message);
    } finally {
      setRacing(false);
    }
  };

  if (settings.isLoading) {
    return (
      <div className="flex flex-col gap-4">
        {[0, 1].map((i) => (
          <div key={i} className="h-48 animate-pulse rounded-xl border border-hairline bg-panel" />
        ))}
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="flex max-w-2xl flex-col gap-6"
    >
      {/* Connection */}
      <div className="card-base">
        <h3 className="font-display text-[15px] font-semibold text-tpri">Connection</h3>
        <div className="mt-4 flex flex-col gap-4">
          <label className="flex items-center justify-between rounded-lg border border-hairline bg-panel2 px-3.5 py-3">
            <span className="flex items-center gap-2.5 text-[13px] text-tsec">
              <Gauge className="h-4 w-4 text-neon" />
              <span>
                Auto-select fastest RPC{" "}
                <span className="font-mono text-[11px] text-tmut">(recommended)</span>
              </span>
            </span>
            <Switch
              checked={rpcAuto}
              onCheckedChange={(v) => {
                setRpcAuto(v);
                if (!v) setRaceResults(null);
              }}
            />
          </label>

          {rpcAuto ? (
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={racing}
                  onClick={raceNow}
                  className="rounded-lg border border-violet/50 bg-violet/10 px-4 py-2 font-mono text-xs text-violet transition-colors hover:bg-violet/20 disabled:opacity-40"
                >
                  {racing ? "Racing…" : "Race endpoints now"}
                </button>
                <p className="font-mono text-[11px] text-tmut">
                  ▸ pings every public endpoint for{" "}
                  {CHAINS.find((x) => x.id === chainId)?.label} and keeps the fastest
                </p>
              </div>
              {currentRpc.data && (
                <p className="font-mono text-[11px] text-tsec">
                  currently using:{" "}
                  <span className="text-neon">{currentRpc.data.url}</span>{" "}
                  <span className="text-tmut">({currentRpc.data.source})</span>
                </p>
              )}
              <ServerError message={raceError} />
              {raceResults && (
                <ul className="flex flex-col gap-1.5">
                  {raceResults.map((r, i) => (
                    <li
                      key={r.url}
                      className="flex items-center justify-between rounded-lg border border-hairline bg-void px-3 py-2 font-mono text-[11px]"
                    >
                      <span className="truncate text-tsec">
                        <span className="mr-2 text-tmut">#{i + 1}</span>
                        {r.url}
                      </span>
                      <span
                        className={cn(
                          "ml-3 shrink-0 rounded-full border px-2 py-0.5",
                          !r.ok || r.latencyMs === null
                            ? "border-alarm/40 bg-alarm/10 text-alarm"
                            : r.latencyMs < 300
                              ? "border-neon/40 bg-neon/10 text-neon"
                              : r.latencyMs < 800
                                ? "border-amber/40 bg-amber/10 text-amber"
                                : "border-alarm/40 bg-alarm/10 text-alarm",
                        )}
                      >
                        {r.ok && r.latencyMs !== null ? `${r.latencyMs}ms` : "timeout"}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ) : (
            <div>
              <FieldLabel>Custom RPC URL</FieldLabel>
              <input
                className={inputCls}
                placeholder="https://eth-mainnet.g.alchemy.com/v2/…"
                value={rpcUrl}
                onChange={(e) => setRpcUrl(e.target.value)}
              />
              <p className="mt-1.5 font-mono text-[11px] text-tmut">
                ▸ required before live execution; a fast private endpoint shaves 100ms+ off detection
              </p>
            </div>
          )}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <FieldLabel>Chain</FieldLabel>
              <div className="flex flex-wrap gap-2">
                {CHAINS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setChainId(c.id)}
                    className={cn(
                      "flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[11px] transition-colors",
                      chainId === c.id
                        ? "border-violet/60 bg-violet/10 text-tpri"
                        : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                    )}
                  >
                    <img src={c.icon} alt="" className="h-3 w-3" />
                    {c.label}
                  </button>
                ))}
              </div>
              {!rpcAuto && (
                <p className="mt-1.5 font-mono text-[11px] text-tmut">
                  ▸ public RPC available —{" "}
                  <button
                    type="button"
                    onClick={() => {
                      const c = CHAINS.find((x) => x.id === chainId);
                      if (c) setRpcUrl(c.rpc);
                    }}
                    className="text-violet underline decoration-dotted underline-offset-2 transition-colors hover:text-tpri"
                  >
                    autofill {CHAINS.find((x) => x.id === chainId)?.label} endpoint
                  </button>
                </p>
              )}
            </div>
            <div>
              <FieldLabel>Max gas ceiling (gwei)</FieldLabel>
              <input
                className={inputCls}
                inputMode="numeric"
                value={maxGasGwei}
                onChange={(e) => setMaxGasGwei(e.target.value)}
              />
              <p className="mt-1.5 font-mono text-[11px] text-tmut">
                ▸ tasks pause themselves above this
              </p>
            </div>
          </div>

          <div>
            <FieldLabel>OpenSea API key (optional — overrides the built-in shared key)</FieldLabel>
            <input
              type="password"
              className={inputCls}
              placeholder="••••••••••••"
              value={openseaApiKey}
              onChange={(e) => setOpenseaApiKey(e.target.value)}
              autoComplete="off"
            />
            <p className="mt-1.5 font-mono text-[11px] text-tmut">
              ▸ leave empty to use the platform's shared key — set your own (free at
              docs.opensea.io) for a dedicated rate limit
            </p>
          </div>
        </div>
      </div>

      {/* MEV protection */}
      <div className="card-base">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-neon" />
            <h3 className="font-display text-[15px] font-semibold text-tpri">MEV protection</h3>
          </div>
          <Switch checked={mevProtection} onCheckedChange={setMeProtection} />
        </div>
        <p className="mt-2 text-[13px] leading-relaxed text-tsec">
          Route Ethereum mainnet transactions through the{" "}
          <span className="font-mono text-[12px] text-violet">Flashbots Protect</span> private
          mempool — hides snipes from sandwich bots. Other chains unaffected.
        </p>
        <p className="mt-1.5 font-mono text-[11px] text-tmut">
          ▸ {mevProtection ? "on (default) — mainnet broadcasts go to the private mempool" : "off — mainnet broadcasts go to the public mempool"}
        </p>
      </div>

      {/* Password (credential accounts) */}
      <ChangePasswordCard pushToast={pushToast} />

      {/* Live execution disclosure */}
      <div className="card-base">
        <h3 className="font-display text-[15px] font-semibold text-tpri">Execution</h3>
        <div className="mt-4 flex items-start gap-3 rounded-lg border border-alarm/40 bg-alarm/10 p-4">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-alarm" />
          <p className="text-[13px] leading-relaxed text-tsec">
            <span className="font-medium text-alarm">Live execution only.</span> Every armed task
            and mirrored signal executes a real on-chain transaction from your bot vault — real
            funds, real risk. Failed transactions still burn gas, and profits are never
            guaranteed. Keep your vault funded and your caps sized accordingly.
          </p>
        </div>
      </div>

      <ServerError message={error} />

      <div className="flex items-center gap-3">
        <button
          disabled={update.isPending}
          onClick={save}
          className="flex items-center gap-2 rounded-lg bg-g-brand px-5 py-2.5 text-sm font-semibold text-white transition-all hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
        >
          <Save className="h-4 w-4" />
          {update.isPending ? "Saving…" : "Save settings"}
        </button>
        {saved && <span className="font-mono text-xs text-neon">✓ saved</span>}
      </div>
    </motion.div>
  );
}
