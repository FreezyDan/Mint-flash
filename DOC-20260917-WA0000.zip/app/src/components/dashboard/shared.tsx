import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TaskStatus } from "@contracts/bot";

/* ------------------------------------------------------------------ */
/* Chains                                                              */
/* ------------------------------------------------------------------ */

export const CHAINS = [
  { id: 1, key: "ethereum", label: "Ethereum", icon: "/chain-eth.svg", rpc: "https://ethereum-rpc.publicnode.com" },
  { id: 8453, key: "base", label: "Base", icon: "/chain-base.svg", rpc: "https://mainnet.base.org" },
  { id: 137, key: "polygon", label: "Polygon", icon: "/chain-poly.svg", rpc: "https://polygon.drpc.org" },
  { id: 42161, key: "arbitrum", label: "Arbitrum", icon: "/chain-eth.svg", rpc: "https://arb1.arbitrum.io/rpc" },
  { id: 4663, key: "robinhood", label: "Robinhood", icon: "/chain-robinhood.svg", rpc: "https://rpc.mainnet.chain.robinhood.com" },
  { id: 57073, key: "ink", label: "Ink", icon: "/chain-ink.svg", rpc: "https://rpc-qnd.inkonchain.com" },
  { id: 5042, key: "arc", label: "Arc", icon: "/chain-arc.svg", rpc: "https://rpc.mainnet.arc.io" },
] as const;

export function chainById(id: number) {
  return CHAINS.find((c) => c.id === id) ?? CHAINS[0];
}

export function chainByKey(key: string) {
  return CHAINS.find((c) => c.key === key) ?? CHAINS[0];
}

export function ChainBadge({ chainId, className }: { chainId: number; className?: string }) {
  const c = chainById(chainId);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-hairline bg-panel2 px-2 py-0.5 font-mono text-[11px] text-tsec",
        className,
      )}
    >
      <img src={c.icon} alt="" className="h-3 w-3" />
      {c.label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Formatting helpers                                                  */
/* ------------------------------------------------------------------ */

export function truncateAddr(addr: string): string {
  if (addr.length <= 12) return addr;
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}

export function timeAgo(date: Date | string): string {
  const d = date instanceof Date ? date : new Date(date);
  const s = Math.max(0, Math.floor((Date.now() - d.getTime()) / 1000));
  if (s < 5) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

/** Re-render on an interval — drives countdowns / relative timestamps. */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function fmtCountdown(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

/* ------------------------------------------------------------------ */
/* Status pill                                                         */
/* ------------------------------------------------------------------ */

const STATUS_STYLE: Record<TaskStatus, { label: string; cls: string; pulse?: boolean }> = {
  draft: { label: "DRAFT", cls: "border-hairline bg-panel2 text-tmut" },
  armed: { label: "ARMED", cls: "border-amber/40 bg-amber/10 text-amber", pulse: true },
  firing: { label: "LIVE-FIRING", cls: "border-neon/40 bg-neon/10 text-neon", pulse: true },
  done: { label: "DONE", cls: "border-neon/30 bg-neon/5 text-neon" },
  failed: { label: "FAILED", cls: "border-alarm/40 bg-alarm/10 text-alarm" },
  cancelled: { label: "CANCELLED", cls: "border-hairline bg-panel2 text-tmut" },
};

export function TaskStatusChip({ status }: { status: TaskStatus }) {
  const s = STATUS_STYLE[status] ?? STATUS_STYLE.draft;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-medium tracking-[0.14em]",
        s.cls,
      )}
    >
      <span className="relative flex h-1.5 w-1.5">
        {s.pulse && (
          <span className="absolute inset-0 animate-ping rounded-full bg-current opacity-60" />
        )}
        <span className="relative h-1.5 w-1.5 rounded-full bg-current" />
      </span>
      {s.label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Copy-to-clipboard icon                                              */
/* ------------------------------------------------------------------ */

export function CopyAddr({ value, className }: { value: string; className?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      title={copied ? "Copied" : "Copy address"}
      onClick={() => {
        navigator.clipboard?.writeText(value).catch(() => {});
        setCopied(true);
        setTimeout(() => setCopied(false), 1200);
      }}
      className={cn("text-tmut transition-colors hover:text-tpri", className)}
    >
      {copied ? <Check className="h-3.5 w-3.5 text-neon" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Empty state                                                         */
/* ------------------------------------------------------------------ */

export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-hairline bg-panel/60 px-6 py-14 text-center">
      <span className="flex h-11 w-11 items-center justify-center rounded-lg border border-hairline bg-panel2 text-tmut">
        {icon}
      </span>
      <p className="font-display text-[17px] font-semibold text-tpri">{title}</p>
      <p className="max-w-sm text-sm text-tsec">{body}</p>
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Toasts                                                              */
/* ------------------------------------------------------------------ */

export type Toast = { id: number; message: string; tone: "success" | "error" | "info" };

export function useToasts() {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);
  const push = (message: string, tone: Toast["tone"] = "info") => {
    const id = ++idRef.current;
    setToasts((prev) => [...prev, { id, message, tone }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 3200);
  };
  return { toasts, push };
}

export function ToastStack({ toasts }: { toasts: Toast[] }) {
  return (
    <div className="pointer-events-none fixed bottom-5 left-1/2 z-[80] flex w-full max-w-md -translate-x-1/2 flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className={cn(
              "pointer-events-auto flex items-center gap-2 rounded-lg border bg-panel2 px-4 py-2.5 font-mono text-xs shadow-lg",
              t.tone === "success" && "border-neon/40 text-neon",
              t.tone === "error" && "border-alarm/40 text-alarm",
              t.tone === "info" && "border-hairline text-tsec",
            )}
          >
            {t.message}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Shared form bits                                                    */
/* ------------------------------------------------------------------ */

export function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="mb-1.5 block font-mono text-[11px] uppercase tracking-[0.16em] text-tmut">
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-lg border border-hairline bg-void px-3 py-2.5 font-mono text-[13px] text-tpri placeholder:text-tmut focus:border-violet/60 focus:outline-none focus:ring-1 focus:ring-violet/40 transition-colors";

export function ServerError({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p className="rounded-lg border border-alarm/40 bg-alarm/10 px-3 py-2 font-mono text-xs leading-relaxed text-alarm">
      {message}
    </p>
  );
}
