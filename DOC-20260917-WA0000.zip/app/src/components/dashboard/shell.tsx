import { Link } from "react-router";
import { motion } from "framer-motion";
import {
  Activity,
  Bell,
  Brush,
  Copy as CopyIcon,
  Crown,
  LayoutDashboard,
  Briefcase,
  LogOut,
  Plus,
  Rocket,
  Settings as SettingsIcon,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { OctagonPause, Play } from "lucide-react";

/**
 * Emergency kill switch — halts/resumes ALL execution (snipe, copy, sweep,
 * sells) for the account. Red STOP in the top bar; a global banner shows
 * while halted.
 */
function EmergencyStop() {
  const utils = trpc.useUtils();
  const settings = trpc.settings.get.useQuery(undefined, { refetchInterval: 10_000 });
  const update = trpc.settings.update.useMutation({
    onSettled: () => utils.settings.get.invalidate(),
  });
  const halted = settings.data?.halted === true;

  if (halted) {
    return (
      <button
        onClick={() => update.mutate({ halted: false })}
        disabled={update.isPending}
        title="Resume all execution"
        className="flex items-center gap-1.5 rounded-lg border border-neon/50 bg-neon/10 px-3 py-1.5 font-mono text-[11px] font-semibold tracking-wider text-neon transition-all hover:bg-neon/20 active:scale-[0.97]"
      >
        <Play className="h-3.5 w-3.5" />
        RESUME
      </button>
    );
  }
  return (
    <button
      onClick={() => {
        if (
          window.confirm(
            "EMERGENCY STOP\n\nHalt ALL execution immediately — snipes, copy trades, sweeps and take-profit/stop-loss sells. Nothing will be broadcast until you resume.",
          )
        ) {
          update.mutate({ halted: true });
        }
      }}
      disabled={update.isPending}
      title="Emergency stop — halt all execution"
      className="flex items-center gap-1.5 rounded-lg border border-alarm/40 bg-alarm/10 px-3 py-1.5 font-mono text-[11px] font-semibold tracking-wider text-alarm transition-all hover:bg-alarm/20 active:scale-[0.97]"
    >
      <OctagonPause className="h-3.5 w-3.5" />
      STOP
    </button>
  );
}

/** Global banner shown across the dashboard while the kill switch is on. */
function HaltBanner() {
  const settings = trpc.settings.get.useQuery(undefined, { refetchInterval: 10_000 });
  if (settings.data?.halted !== true) return null;
  return (
    <div className="mb-5 flex items-center gap-3 rounded-xl border border-alarm/40 bg-alarm/10 px-4 py-3">
      <OctagonPause className="h-4 w-4 shrink-0 text-alarm" />
      <p className="font-mono text-[12px] text-alarm">
        EMERGENCY STOP ACTIVE — no transactions will be broadcast (snipe, copy, sweep, sells).
        Press RESUME in the top bar to re-enable execution.
      </p>
    </div>
  );
}

import type { User } from "@contracts/types";
import { PlanBadge, TrialChip, useEntitlement } from "./plan";

export type SectionKey =
  | "overview"
  | "tasks"
  | "copy"
  | "sweeper"
  | "positions"
  | "wallets"
  | "activity"
  | "settings"
  | "upgrade"
  | "admin";

export const SECTIONS: { key: SectionKey; label: string; icon: typeof Rocket }[] = [
  { key: "overview", label: "Overview", icon: LayoutDashboard },
  { key: "tasks", label: "Mint Tasks", icon: Rocket },
  { key: "copy", label: "Copy Trading", icon: CopyIcon },
  { key: "sweeper", label: "Floor Sweeper", icon: Brush },
  { key: "positions", label: "Positions", icon: Briefcase },
  { key: "wallets", label: "Wallets", icon: Wallet },
  { key: "activity", label: "Activity", icon: Activity },
  { key: "settings", label: "Settings", icon: SettingsIcon },
];

export const SECTION_TITLES: Record<SectionKey, string> = {
  overview: "Overview",
  tasks: "Mint Tasks",
  copy: "Copy Trading",
  sweeper: "Floor Sweeper",
  positions: "Positions",
  wallets: "Wallets",
  activity: "Activity",
  settings: "Settings",
  upgrade: "Upgrade Plan",
  admin: "Admin Console",
};

interface ShellProps {
  active: SectionKey;
  onNavigate: (s: SectionKey) => void;
  onNewTask: () => void;
  user: User;
  logout: () => void;
  tasksTotal: number;
  walletsTotal: number;
  children: React.ReactNode;
}

/** Dashboard app shell — fixed sidebar + slim topbar + main canvas. */
export default function DashboardShell({
  active,
  onNavigate,
  onNewTask,
  user,
  logout,
  tasksTotal,
  walletsTotal,
  children,
}: ShellProps) {
  const entitlement = useEntitlement();
  const usagePct = Math.min(100, Math.round((walletsTotal / 25) * 100));

  // Upgrade is visible to every non-admin; the Admin console is admin-only.
  const navSections = [
    ...SECTIONS,
    ...(entitlement && !entitlement.admin
      ? [{ key: "upgrade" as SectionKey, label: "Upgrade", icon: Crown }]
      : []),
    ...(entitlement?.admin
      ? [{ key: "admin" as SectionKey, label: "Admin", icon: ShieldCheck }]
      : []),
  ];

  return (
    <div className="min-h-[100dvh] bg-void">
      <div className="bg-grid-layer pointer-events-none fixed inset-0 z-0" aria-hidden />

      {/* Sidebar — icon rail below lg, full width above */}
      <motion.aside
        initial={{ opacity: 0, x: -12 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed inset-y-0 left-0 z-40 flex w-14 flex-col border-r border-hairline bg-panel lg:w-60"
      >
        <Link to="/" className="flex h-14 items-center gap-2.5 border-b border-hairline px-3 lg:px-5">
          <img src="/logo.svg" alt="MintDash" className="h-6 w-6 shrink-0" />
          <span className="hidden font-display text-[13px] font-bold tracking-[0.18em] text-tpri lg:block">
            MINTDASH
          </span>
        </Link>

        <nav className="flex flex-1 flex-col gap-1 px-2 py-4 lg:px-3">
          {navSections.map((s, i) => {
            const Icon = s.icon;
            const isActive = active === s.key;
            return (
              <motion.button
                key={s.key}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.04 * i, duration: 0.25 }}
                onClick={() => onNavigate(s.key)}
                className={cn(
                  "relative flex items-center gap-3 rounded-lg px-2.5 py-2.5 text-left text-sm font-medium transition-colors lg:px-3",
                  isActive
                    ? "bg-panel2 text-tpri"
                    : "text-tmut hover:bg-panel2/60 hover:text-tsec",
                )}
              >
                {isActive && (
                  <span className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-full bg-violet" />
                )}
                <Icon className="h-4 w-4 shrink-0" />
                <span className="hidden lg:block">{s.label}</span>
              </motion.button>
            );
          })}
        </nav>

        {/* Bottom: plan chip + usage + user */}
        <div className="border-t border-hairline p-3">
          <div className="mb-3 hidden rounded-lg border border-violet/40 bg-violet/5 p-3 lg:block">
            <div className="flex items-center justify-between">
              {entitlement ? (
                <PlanBadge entitlement={entitlement} />
              ) : (
                <span className="font-mono text-[10px] font-medium tracking-[0.18em] text-tmut">
                  …
                </span>
              )}
              <span className="font-mono text-[10px] text-tmut">
                {usagePct}%
              </span>
            </div>
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-hairline">
              <div className="h-full rounded-full bg-neon" style={{ width: `${usagePct}%` }} />
            </div>
            <p className="mt-2 font-mono text-[10px] text-tmut">
              Tasks {tasksTotal}
              {entitlement?.plan === "free" ? "/3 pending" : "/∞"} · Wallets {walletsTotal}/25
            </p>
            {entitlement?.plan === "free" && !entitlement.admin && (
              <button
                type="button"
                onClick={() => onNavigate("upgrade")}
                className="mt-2 w-full rounded-md border border-violet/50 bg-violet/10 py-1 font-mono text-[10px] uppercase tracking-widest text-violet transition-colors hover:bg-violet/20"
              >
                Upgrade to PRO
              </button>
            )}
          </div>
          <div className="flex items-center gap-2.5">
            <img
              src={user.avatar || "/sniper-avatar-7.png"}
              alt=""
              className="h-8 w-8 shrink-0 rounded-full border border-hairline object-cover"
            />
            <div className="hidden min-w-0 flex-1 lg:block">
              <p className="truncate text-[13px] font-medium text-tpri">
                {user.name || "degen"}
              </p>
              <p className="truncate font-mono text-[10px] text-tmut">connected</p>
            </div>
            <button
              onClick={() => logout()}
              title="Disconnect"
              className="ml-auto text-tmut transition-colors hover:text-alarm"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </motion.aside>

      {/* Topbar */}
      <motion.header
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed inset-x-0 top-0 z-30 flex h-14 items-center justify-between border-b border-hairline bg-void/80 pl-16 pr-4 backdrop-blur-md lg:pl-[17rem] lg:pr-6"
      >
        <h1 className="font-display text-lg font-semibold text-tpri">
          {SECTION_TITLES[active]}
        </h1>
        <div className="flex items-center gap-4">
          <EmergencyStop />
          {entitlement && (
            <span className="flex items-center gap-2">
              <PlanBadge entitlement={entitlement} />
              <TrialChip entitlement={entitlement} />
            </span>
          )}
          <button className="relative text-tmut transition-colors hover:text-tpri" title="Notifications">
            <Bell className="h-4 w-4" />
            <span className="absolute -right-0.5 -top-0.5 h-1.5 w-1.5 rounded-full bg-neon" />
          </button>
          <button
            onClick={onNewTask}
            className="rounded-lg bg-g-brand px-3.5 py-1.5 text-[13px] font-semibold text-white transition-all duration-150 hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97]"
          >
            <span className="hidden sm:inline">New Task</span>
            <Plus className="h-4 w-4 sm:hidden" />
          </button>
        </div>
      </motion.header>

      {/* Main canvas */}
      <main className="relative z-10 pl-14 pt-14 lg:pl-60">
        <div className="mx-auto w-full max-w-[1180px] px-4 py-6 lg:px-8 lg:py-8">
          <HaltBanner />
          {children}
        </div>
      </main>
    </div>
  );
}
