import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { RefreshCw, TrendingUp, X } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../api/router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { ChainBadge, CopyAddr, timeAgo, truncateAddr } from "./shared";
import { fmtEth } from "./CopyTrading";

type ProfileResult = inferRouterOutputs<AppRouter>["profile"]["get"];
type Profile = ProfileResult["profile"];
type Flip = Profile["flips"][number];
type Holding = NonNullable<Profile["holdings"]>[number];
type PeriodKey = "all" | "week3" | "week1";

const PERIODS: Array<{ key: PeriodKey; label: string; days: number | null }> = [
  { key: "all", label: "ALL TIME", days: null },
  { key: "week3", label: "3W", days: 21 },
  { key: "week1", label: "1W", days: 7 },
];

const AXIS_TICK = { fill: "#8b8fa3", fontSize: 10, fontFamily: "JetBrains Mono, monospace" };
const GRID_STROKE = "#ffffff10";

function fmtDate(tsSeconds: number): string {
  return new Date(tsSeconds * 1000).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "2-digit",
  });
}

/** Unsigned ETH, 4 decimals; em dash for null. */
function fmtEthPlain(v: string | null, digits = 4): string {
  return v === null ? "—" : Number(v).toFixed(digits);
}

function PnlChip({ value, className }: { value: string | null; className?: string }) {
  if (value === null) return <span className="font-mono text-[11px] text-tmut">—</span>;
  return <span className={cn(Number(value) >= 0 ? "chip-profit" : "chip-loss", className)}>{fmtEth(value)}</span>;
}

/** Dark quant-terminal tooltip for the equity curve. */
function EquityTooltip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ payload?: { ts: number; pnl: number } }>;
}) {
  const point = payload?.[0]?.payload;
  if (!active || !point) return null;
  return (
    <div className="rounded-lg border border-white/10 bg-[#0D0F16] px-2.5 py-1.5 font-mono text-[10px] shadow-xl">
      <p className="mb-0.5 uppercase tracking-widest text-[#8b8fa3]">{fmtDate(point.ts)}</p>
      <p className={point.pnl >= 0 ? "text-neon" : "text-alarm"}>cum PnL: {fmtEth(point.pnl)}</p>
    </div>
  );
}

function StatCell({ label, value, cls, bold }: { label: string; value: string; cls?: string; bold?: boolean }) {
  return (
    <div className="rounded-lg border border-hairline bg-panel2/60 px-3 py-2">
      <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-tmut">{label}</p>
      <p className={cn("tnum mt-1 font-mono text-sm", bold ? "font-bold" : "", cls ?? "text-tpri")}>
        {value}
      </p>
    </div>
  );
}

/** One top-holdings card: image (or initial tile), name, chain, count, floor, est. value. */
function HoldingCard({ holding }: { holding: Holding }) {
  return (
    <div className="min-w-0 rounded-lg border border-hairline bg-panel2/40 p-2">
      {holding.imageUrl !== null ? (
        <img
          src={holding.imageUrl}
          alt={holding.name}
          loading="lazy"
          className="aspect-square w-full rounded-md border border-hairline/60 object-cover"
        />
      ) : (
        <div className="flex aspect-square w-full items-center justify-center rounded-md border border-violet/30 bg-violet/10">
          <span className="font-display text-2xl font-semibold text-violet">
            {holding.name.charAt(0).toUpperCase()}
          </span>
        </div>
      )}
      <p className="mt-2 truncate font-mono text-[11px] text-tsec" title={holding.name}>
        {holding.name}
      </p>
      <div className="mt-1 flex items-center gap-1.5">
        <ChainBadge chainId={holding.chainId} className="px-1.5 text-[9px]" />
        <span className="rounded-full border border-hairline bg-panel2 px-1.5 py-px font-mono text-[9px] text-tsec">
          ×{holding.count}
        </span>
      </div>
      <p className="mt-1.5 font-mono text-[9px] text-tmut">
        floor {fmtEthPlain(holding.floorEth)}
      </p>
      <p className={cn("tnum font-mono text-[11px]", holding.valueEth === null ? "text-tmut" : "text-neon")}>
        {holding.valueEth === null ? "—" : `≈ ${fmtEthPlain(holding.valueEth)} ETH`}
      </p>
    </div>
  );
}

function FlipRow({ flip }: { flip: Flip }) {
  const tokenPayment =
    flip.pricedWith !== "native" &&
    flip.paymentSymbol !== null &&
    flip.paymentSymbol !== "ETH" &&
    flip.paymentSymbol !== "WETH";
  return (
    <li className="flex items-center gap-2 border-b border-hairline/60 px-3 py-2">
      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-1.5 truncate font-mono text-[11px] text-tsec">
          <span className="truncate">
            {flip.name ?? flip.collectionSlug ?? truncateAddr(flip.contract)}
            {flip.tokenId ? (
              <span className="text-tmut"> #{flip.tokenId.length > 10 ? `${flip.tokenId.slice(0, 10)}…` : flip.tokenId}</span>
            ) : null}
          </span>
          {tokenPayment && (
            <span
              className={cn(
                "shrink-0 rounded border px-1 py-px font-mono text-[8px] uppercase tracking-wider",
                flip.pricedWith === "oracle"
                  ? "border-amber/50 text-amber"
                  : "border-white/15 text-tmut",
              )}
              title={
                flip.pricedWith === "oracle"
                  ? `${flip.paymentAmount ?? ""} ${flip.paymentSymbol} — ${
                      flip.approxPrice
                        ? "converted at nearest available rate"
                        : "converted at historical rate"
                    }`
                  : "token price unavailable — excluded from PnL"
              }
            >
              {flip.paymentSymbol}
            </span>
          )}
        </p>
        <p className="font-mono text-[10px] text-tmut">
          {flip.approxPrice ? "≈ " : ""}
          {fmtEthPlain(flip.buyEth)} → {flip.approxPrice ? "≈ " : ""}
          {fmtEthPlain(flip.sellEth)} ETH ·{" "}
          {flip.buyTs !== null ? fmtDate(flip.buyTs) : "—"} → {fmtDate(flip.sellTs)}
        </p>
      </div>
      {flip.unmatchedSell ? (
        <span className="shrink-0 rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-amber">
          no-cost-basis
        </span>
      ) : flip.pricedWith === "unpriced" ? (
        <span className="shrink-0 rounded-full border border-white/15 bg-white/5 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-tmut">
          unpriced
        </span>
      ) : (
        <PnlChip value={flip.pnlEth} />
      )}
    </li>
  );
}

/**
 * All-time wallet PnL drawer — complete OpenSea (Seaport) trade history,
 * buys↔sells paired FIFO, open positions marked at the current floor.
 * Follows the TraderFlipsDrawer slide-over pattern.
 */
export function WalletProfileDrawer({
  address,
  onClose,
}: {
  address: string;
  onClose: () => void;
}) {
  const utils = trpc.useUtils();
  const [result, setResult] = useState<ProfileResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<PeriodKey>("all");

  const load = useCallback(
    async (forceRefresh: boolean) => {
      setLoading(true);
      setError(null);
      try {
        setResult(await utils.profile.get.fetch({ address, forceRefresh }));
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to load wallet profile");
      } finally {
        setLoading(false);
      }
    },
    [address, utils],
  );

  useEffect(() => {
    void load(false);
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const profile = result?.profile ?? null;
  const stats = profile?.periods[period] ?? null;
  const periodDays = PERIODS.find((p) => p.key === period)?.days ?? null;
  // Windows are anchored at fetch time server-side; mirror that anchor here
  // for filtering the flips/positions lists.
  const fetchedSec = profile ? Date.parse(profile.fetchedAt) / 1000 : 0;
  const windowStart = periodDays === null ? null : fetchedSec - periodDays * 86400;
  const inWindow = (ts: number) => windowStart === null || ts >= windowStart;

  const windowFlips = profile?.flips.filter((f) => inWindow(f.sellTs)) ?? [];
  const matched = windowFlips.filter((f) => !f.unmatchedSell && f.pnlEth !== null);
  const best3 = matched.slice(0, 3);
  const worst3 = matched.length > 3 ? matched.slice(-3).reverse() : [];
  const excluded = windowFlips
    .filter((f) => f.unmatchedSell || f.pricedWith === "unpriced")
    .slice(0, 5);
  const windowOpens = profile?.openPositions.filter((p) => inWindow(p.entryTs)) ?? [];
  const equityData = stats?.equityCurve.map((e) => ({ ts: e.ts, pnl: Number(e.pnlEth) })) ?? [];
  const chainRows = Object.entries(stats?.chains ?? {})
    .filter(([, c]) => c.totalBuys + c.totalSells + c.openCount > 0)
    .sort(
      (a, b) => Math.abs(Number(b[1].realizedPnlEth)) - Math.abs(Number(a[1].realizedPnlEth)),
    );
  const totalPnl =
    stats === null
      ? null
      : Number(stats.realizedPnlEth) +
        (stats.unrealizedPnlEth === null ? 0 : Number(stats.unrealizedPnlEth));

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={onClose}
        className="fixed inset-0 z-[70] bg-void/70 backdrop-blur-sm"
      />
      <motion.aside
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-y-0 right-0 z-[71] flex w-full max-w-xl flex-col border-l border-hairline bg-panel shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3 border-b border-hairline px-5 py-4">
          <div className="min-w-0">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
              All-time profile · OpenSea trade history
            </p>
            <p className="mt-1 flex items-center gap-2 font-mono text-[13px] text-tpri">
              <span className="truncate">{truncateAddr(address)}</span>
              <CopyAddr value={address} />
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-1.5">
              {result && (
                <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5 font-mono text-[10px] text-tsec">
                  {result.cached
                    ? `cached · refreshed ${timeAgo(profile!.fetchedAt)}`
                    : "fresh · just now"}
                </span>
              )}
              {profile && profile.truncated && (
                <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[10px] text-amber">
                  history truncated at {profile.eventsScanned} events
                </span>
              )}
              <button
                type="button"
                disabled={loading}
                onClick={() => void load(true)}
                className="flex items-center gap-1 rounded-full border border-violet/40 bg-violet/10 px-2 py-0.5 font-mono text-[10px] text-violet transition-colors hover:bg-violet/20 disabled:opacity-40"
                title="Force-refresh from OpenSea (rate-limited)"
              >
                <RefreshCw className={cn("h-3 w-3", loading && "animate-spin")} />
                Refresh
              </button>
            </div>
          </div>
          <button
            onClick={onClose}
            title="Close"
            className="rounded-lg border border-hairline bg-panel2 p-1.5 text-tmut transition-colors hover:text-tpri"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          {loading && !result ? (
            <div className="space-y-3 p-5">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {[0, 1, 2, 3].map((i) => (
                  <div key={i} className="h-14 animate-pulse rounded-lg bg-panel2" />
                ))}
              </div>
              <div className="h-[180px] animate-pulse rounded-lg bg-panel2" />
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-10 animate-pulse rounded-lg bg-panel2" />
              ))}
              <p className="text-center font-mono text-[10px] text-tmut">
                paging full OpenSea history — can take up to a minute…
              </p>
            </div>
          ) : error && !result ? (
            <div className="p-5">
              <div className="rounded-lg border border-amber/40 bg-amber/10 px-4 py-3 font-mono text-xs leading-relaxed text-amber">
                {error}
              </div>
              <button
                type="button"
                onClick={() => void load(false)}
                className="mt-3 rounded-lg border border-violet/40 bg-violet/10 px-4 py-2 font-mono text-[11px] text-violet transition-colors hover:bg-violet/20"
              >
                Retry
              </button>
            </div>
          ) : profile && stats ? (
            <div>
              {/* Period selector */}
              <div className="flex items-center gap-1.5 border-b border-hairline px-5 py-3">
                {PERIODS.map((p) => (
                  <button
                    key={p.key}
                    type="button"
                    onClick={() => setPeriod(p.key)}
                    className={cn(
                      "rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.14em] transition-colors",
                      period === p.key
                        ? "border-violet/60 bg-violet/15 text-violet"
                        : "border-hairline bg-panel2/60 text-tmut hover:text-tsec",
                    )}
                  >
                    {p.label}
                  </button>
                ))}
                <span className="ml-auto font-mono text-[9px] uppercase tracking-widest text-tmut">
                  {period === "all" ? "full history" : `sells in last ${periodDays}d · entries in window`}
                </span>
              </div>

              {/* Stat strip */}
              <div className="grid grid-cols-2 gap-2 border-b border-hairline px-5 py-4 sm:grid-cols-4">
                <StatCell
                  label="Realized PnL"
                  value={`${fmtEth(stats.realizedPnlEth)} ETH`}
                  cls={Number(stats.realizedPnlEth) >= 0 ? "text-neon" : "text-alarm"}
                />
                <StatCell
                  label="Unrealized (floor)"
                  value={stats.unrealizedPnlEth === null ? "—" : `${fmtEth(stats.unrealizedPnlEth)} ETH`}
                  cls={
                    stats.unrealizedPnlEth === null
                      ? "text-tmut"
                      : Number(stats.unrealizedPnlEth) >= 0
                        ? "text-neon"
                        : "text-alarm"
                  }
                />
                <StatCell
                  label="Total PnL"
                  value={`${fmtEth(totalPnl ?? 0)} ETH`}
                  cls={(totalPnl ?? 0) >= 0 ? "text-neon" : "text-alarm"}
                  bold
                />
                <StatCell
                  label="Win rate"
                  value={stats.wins + stats.losses > 0 ? `${stats.winRatePct}% (${stats.wins}/${stats.wins + stats.losses})` : "—"}
                />
                <StatCell label="Volume" value={`${Number(stats.volumeEth).toFixed(3)} ETH`} />
                <StatCell label="Buys / Sells" value={`${stats.buys} / ${stats.sells}`} />
                <StatCell
                  label="Open positions"
                  value={
                    period === "all" && profile.unpricedOpenCount > 0
                      ? `${stats.openCount} (${profile.unpricedOpenCount} unpriced)`
                      : String(stats.openCount)
                  }
                  cls="text-cyan"
                />
                <StatCell label="Events scanned" value={String(profile.eventsScanned)} />
              </div>

              {/* Top holdings — current wallet contents, not period-bound.
                  Absent on cached payloads written before this field existed. */}
              {profile.holdings != null && (
                <div className="border-b border-hairline px-5 py-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
                    Top holdings
                  </p>
                  {profile.holdingsSkipped ? (
                    <p className="mt-2 font-mono text-[10px] uppercase tracking-widest text-tmut">
                      holdings fetch skipped (time budget)
                    </p>
                  ) : profile.holdings.length === 0 ? (
                    <p className="mt-2 font-mono text-[10px] uppercase tracking-widest text-tmut">
                      no current holdings found via OpenSea
                    </p>
                  ) : (
                    <div className="mt-2 grid grid-cols-1 gap-2 min-[480px]:grid-cols-3">
                      {profile.holdings.map((h) => (
                        <HoldingCard key={`${h.chainId}:${h.collectionSlug}`} holding={h} />
                      ))}
                    </div>
                  )}
                  {!profile.holdingsSkipped && profile.holdingsTotals != null && (
                    <p className="mt-2 flex items-center gap-2 font-mono text-[9px] uppercase tracking-widest text-tmut">
                      <span>
                        {profile.holdingsTotals.nftCount} NFTs across{" "}
                        {profile.holdingsTotals.collectionCount} collections on{" "}
                        {profile.holdingsTotals.chainsScanned} chains
                      </span>
                      {profile.holdingsPartial && (
                        <span className="rounded-full border border-amber/40 bg-amber/10 px-1.5 py-px text-[8px] text-amber">
                          partial
                        </span>
                      )}
                    </p>
                  )}
                </div>
              )}

              {/* Oracle conversion disclosure */}
              {(profile.oraclePricedCount > 0 || profile.unpricedSales > 0) && (
                <p className="border-b border-hairline px-5 py-2 font-mono text-[9px] uppercase tracking-widest text-tmut">
                  {profile.oraclePricedCount > 0 && (
                    <span className="text-amber">
                      {profile.oraclePricedCount} token sale{profile.oraclePricedCount === 1 ? "" : "s"} converted
                      at historical rates
                      {(profile.approxPricedCount ?? 0) > 0 &&
                        ` · ${profile.approxPricedCount} at nearest current rate ≈`}
                    </span>
                  )}
                  {profile.oraclePricedCount > 0 && profile.unpricedSales > 0 && " · "}
                  {profile.unpricedSales > 0 && (
                    <span>{profile.unpricedSales} unpriced (excluded)</span>
                  )}
                </p>
              )}

              {/* Cumulative realized PnL over real time */}
              <div className="border-b border-hairline px-5 py-4">
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
                  Cumulative realized PnL — {period === "all" ? "all time" : period === "week3" ? "3 weeks" : "1 week"}
                </p>
                {equityData.length === 0 ? (
                  <div className="mt-2 flex h-[100px] items-center justify-center rounded-lg border border-dashed border-hairline bg-panel2/40">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-tmut">
                      no realized trades in this window
                    </p>
                  </div>
                ) : (
                  <div className="mt-2 h-[180px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={equityData} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
                        <defs>
                          <linearGradient id="walletEquityFill" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#7C5CFF" stopOpacity={0.35} />
                            <stop offset="100%" stopColor="#7C5CFF" stopOpacity={0.02} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid stroke={GRID_STROKE} vertical={false} />
                        <XAxis
                          dataKey="ts"
                          type="number"
                          domain={["dataMin", "dataMax"]}
                          tick={AXIS_TICK}
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(v: number) => fmtDate(v)}
                        />
                        <YAxis
                          tick={AXIS_TICK}
                          tickLine={false}
                          axisLine={false}
                          width={56}
                          tickFormatter={(v: number) => v.toFixed(3)}
                        />
                        <Tooltip content={<EquityTooltip />} />
                        <ReferenceLine y={0} stroke="#FF4D6A" strokeDasharray="4 4" />
                        <Area
                          type="monotone"
                          dataKey="pnl"
                          name="cum PnL"
                          stroke="#7C5CFF"
                          strokeWidth={1.5}
                          fill="url(#walletEquityFill)"
                          isAnimationActive={false}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Per-chain breakdown */}
              {chainRows.length > 0 && (
                <div className="border-b border-hairline px-5 py-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
                    Per-chain breakdown
                  </p>
                  <div className="mt-2 space-y-1.5">
                    {chainRows.map(([chainId, c]) => (
                      <div
                        key={chainId}
                        className="flex items-center gap-2 rounded-lg border border-hairline bg-panel2/40 px-3 py-1.5"
                      >
                        <ChainBadge chainId={Number(chainId)} />
                        <span className="font-mono text-[10px] text-tmut">
                          {c.totalBuys + c.totalSells} trades · {c.flips} flips
                          {c.unmatchedSells > 0 ? ` · ${c.unmatchedSells} no-cost` : ""}
                          {c.openCount > 0 ? ` · ${c.openCount} open` : ""}
                        </span>
                        <span className="ml-auto flex items-center gap-2 font-mono text-[11px]">
                          <span className={Number(c.realizedPnlEth) >= 0 ? "text-neon" : "text-alarm"}>
                            {fmtEth(c.realizedPnlEth)}
                          </span>
                          <span className="text-tmut">/</span>
                          <span
                            className={
                              c.unrealizedPnlEth === null
                                ? "text-tmut"
                                : Number(c.unrealizedPnlEth) >= 0
                                  ? "text-neon"
                                  : "text-alarm"
                            }
                          >
                            {c.unrealizedPnlEth === null ? "—" : fmtEth(c.unrealizedPnlEth)}
                          </span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Best / worst flips */}
              {(best3.length > 0 || worst3.length > 0) && (
                <div className="grid grid-cols-1 gap-3 border-b border-hairline px-5 py-4 sm:grid-cols-2">
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-neon">
                      Best flips
                    </p>
                    <ul className="mt-2 rounded-lg border border-hairline bg-panel2/40">
                      {best3.map((f, i) => (
                        <FlipRow key={`b${i}`} flip={f} />
                      ))}
                    </ul>
                  </div>
                  {worst3.length > 0 && (
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-alarm">
                        Worst flips
                      </p>
                      <ul className="mt-2 rounded-lg border border-hairline bg-panel2/40">
                        {worst3.map((f, i) => (
                          <FlipRow key={`w${i}`} flip={f} />
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              {/* Sells excluded from PnL: no cost basis or unpriced token */}
              {excluded.length > 0 && (
                <div className="border-b border-hairline px-5 py-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-amber">
                    Sells excluded from PnL — no cost basis / unpriced
                  </p>
                  <ul className="mt-2 rounded-lg border border-hairline bg-panel2/40">
                    {excluded.map((f, i) => (
                      <FlipRow key={`u${i}`} flip={f} />
                    ))}
                  </ul>
                </div>
              )}

              {/* Open positions at current floor (entries inside the window) */}
              {windowOpens.length > 0 && (
                <div className="border-b border-hairline px-5 py-4">
                  <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-cyan">
                    Open positions ({stats.openCount}) · marked at current floor
                  </p>
                  <table className="mt-2 w-full">
                    <thead>
                      <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                        <th className="py-2 pr-3 font-medium">NFT</th>
                        <th className="px-3 py-2 font-medium">Entry</th>
                        <th className="px-3 py-2 font-medium">Floor</th>
                        <th className="py-2 pl-3 text-right font-medium">Unrealized</th>
                      </tr>
                    </thead>
                    <tbody>
                      {windowOpens.map((p, i) => (
                        <tr key={i} className="border-b border-hairline/60">
                          <td className="py-2.5 pr-3">
                            <p className="flex items-center gap-1 font-mono text-[11px] text-tsec">
                              <ChainBadge chainId={p.chainId} className="mr-1" />
                              {p.name ?? p.collectionSlug ?? truncateAddr(p.contract)}
                            </p>
                            <p className="font-mono text-[10px] text-tmut">
                              {p.tokenId ? `#${p.tokenId.length > 10 ? `${p.tokenId.slice(0, 10)}…` : p.tokenId}` : ""}
                              {` · ${fmtDate(p.entryTs)}`}
                            </p>
                          </td>
                          <td className="px-3 py-2.5 font-mono text-[11px] text-tsec">
                            {fmtEthPlain(p.costEth)}
                          </td>
                          <td className="px-3 py-2.5 font-mono text-[11px] text-tsec">
                            {fmtEthPlain(p.floorEth)}
                          </td>
                          <td className="py-2.5 pl-3 text-right">
                            {p.unrealizedPnlEth !== null ? (
                              <PnlChip value={p.unrealizedPnlEth} />
                            ) : (
                              <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
                                no floor data
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {matched.length === 0 && windowOpens.length === 0 && excluded.length === 0 && (
                <div className="p-5">
                  <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-hairline bg-panel/60 px-6 py-10 text-center">
                    <TrendingUp className="h-5 w-5 text-tmut" />
                    <p className="font-display text-[15px] font-semibold text-tpri">
                      {period === "all" ? "No OpenSea trade history" : "No activity in this window"}
                    </p>
                    <p className="max-w-sm text-sm text-tsec">
                      {period === "all"
                        ? "This wallet has no sale events indexed by OpenSea across the 6 supported chains."
                        : "No flips closed and no positions entered inside this period."}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </div>

        <p className="border-t border-hairline px-5 py-3 font-mono text-[10px] leading-relaxed text-tmut">
          All-time PnL from this wallet's OpenSea (Seaport) trade history across 6 chains. Sales
          acquired off-OpenSea lack a cost basis and are excluded from realized PnL. Unrealized =
          current collection floor − entry. Token-denominated sales (USDC, etc.) are converted to
          ETH at historical rates (DefiLlama); when history is missing (e.g. some Robinhood
          tokens) the nearest current rate is used and marked ≈. Unpriced sales are excluded
          from PnL, never counted as zero.
        </p>
      </motion.aside>
    </>
  );
}
