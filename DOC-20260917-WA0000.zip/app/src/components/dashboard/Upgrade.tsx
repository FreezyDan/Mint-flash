import { useState } from "react";
import { motion } from "framer-motion";
import { Check, CheckCircle2, Crown, Send } from "lucide-react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { FREE_LIMITS, PRO_PRICE_USD } from "@contracts/plans";
import { useEntitlement } from "./plan";
import { CHAINS, CopyAddr, inputCls, ServerError } from "./shared";

const FREE_FEATURES = [
  `NFT snipe bot — ${FREE_LIMITS.trialDays}-day trial`,
  `up to ${FREE_LIMITS.maxPendingSnipes} pending snipe orders`,
  `up to ${FREE_LIMITS.maxSnipeWallets} wallets per snipe`,
  "live on-chain execution from your bot vault",
];

const PRO_FEATURES = [
  "unlimited snipe orders, no trial clock",
  "multi-wallet sniping — all your bot wallets",
  "copy trading + on-chain sniper discovery",
  "all-time PnL wallet profiles",
  "floor sweeper with live execution",
  "all 7 EVM chains",
];

const PAY_STEPS = [
  "Send the payment to the address above on any supported EVM chain.",
  "Paste the transaction hash below and submit your claim.",
  "The admin confirms it on-chain and activates PRO — usually within hours.",
];

const CLAIM_STATUS_STYLE: Record<string, { label: string; cls: string }> = {
  pending: { label: "PENDING", cls: "border-amber/40 bg-amber/10 text-amber" },
  approved: { label: "APPROVED", cls: "border-neon/40 bg-neon/10 text-neon" },
  rejected: { label: "REJECTED", cls: "border-alarm/40 bg-alarm/10 text-alarm" },
};

function ClaimStatusChip({ status }: { status: string }) {
  const s = CLAIM_STATUS_STYLE[status] ?? CLAIM_STATUS_STYLE.pending;
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-medium tracking-[0.14em]",
        s.cls,
      )}
    >
      {s.label}
    </span>
  );
}

/** Pay-to-address + claim submission for non-PRO users. */
function PaymentSection() {
  const utils = trpc.useUtils();
  const paymentInfo = trpc.billing.paymentInfo.useQuery(undefined, {
    staleTime: 60_000,
  });
  const myClaims = trpc.billing.myClaims.useQuery(undefined, {
    refetchInterval: 15_000,
  });

  const [chainId, setChainId] = useState<number>(1);
  const [txHash, setTxHash] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = trpc.billing.submitClaim.useMutation({
    onSuccess: async () => {
      setSubmitted(true);
      setError(null);
      setTxHash("");
      await utils.billing.myClaims.invalidate();
    },
    onError: (e) => {
      setSubmitted(false);
      setError(e.message);
    },
  });

  const address = paymentInfo.data?.address ?? null;
  const priceUsd = paymentInfo.data?.priceUsd ?? PRO_PRICE_USD;
  const claims = myClaims.data ?? [];

  return (
    <div className="flex flex-col gap-6">
      {/* Pay-to-address card */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12, duration: 0.3 }}
        className="card-base p-5"
      >
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-violet">
          Pay to address
        </p>
        <div className="mt-3 flex items-center gap-2 rounded-lg border border-hairline bg-void px-3 py-2.5">
          <code className="flex-1 break-all font-mono text-[13px] text-tpri">
            {address ?? "…"}
          </code>
          {address && <CopyAddr value={address} className="shrink-0" />}
        </div>
        <p className="mt-3 text-[13px] leading-relaxed text-tsec">
          Send ${priceUsd} worth of ETH/native token on any supported EVM chain —
          Ethereum · Base · Arbitrum · Polygon · Robinhood · Ink · Arc
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {CHAINS.map((c) => (
            <span
              key={c.id}
              className="inline-flex items-center gap-1.5 rounded-full border border-hairline bg-panel2 px-2 py-0.5 font-mono text-[11px] text-tsec"
            >
              <img src={c.icon} alt="" className="h-3 w-3" />
              {c.label}
            </span>
          ))}
        </div>
        <ol className="mt-4 flex flex-col gap-2">
          {PAY_STEPS.map((step, i) => (
            <li key={step} className="flex items-start gap-2.5 text-[13px] text-tsec">
              <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-violet/50 font-mono text-[10px] text-violet">
                {i + 1}
              </span>
              {step}
            </li>
          ))}
        </ol>
      </motion.div>

      {/* Submit your payment */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.18, duration: 0.3 }}
        className="card-base p-5"
      >
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-violet">
          Submit your payment
        </p>

        {submitted ? (
          <div className="mt-4 flex items-start gap-3 rounded-lg border border-neon/30 bg-neon/5 px-4 py-3">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-neon" />
            <div>
              <p className="font-mono text-[12px] text-neon">Claim received</p>
              <p className="mt-1 text-[13px] leading-relaxed text-tsec">
                We'll activate PRO after confirming your payment on-chain — usually
                within a few hours. Track the status below.
              </p>
              <button
                type="button"
                onClick={() => setSubmitted(false)}
                className="mt-2 font-mono text-[11px] text-violet transition-colors hover:text-tpri"
              >
                submit another payment →
              </button>
            </div>
          </div>
        ) : (
          <form
            className="mt-4 flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              setError(null);
              submit.mutate({ chainId, txHash: txHash.trim() });
            }}
          >
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-[180px_1fr]">
              <select
                value={chainId}
                onChange={(e) => setChainId(Number(e.target.value))}
                className="rounded-lg border border-hairline bg-void px-3 py-2.5 font-mono text-[13px] text-tpri focus:border-violet/60 focus:outline-none"
              >
                {CHAINS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
              <input
                className={inputCls}
                placeholder="0x… transaction hash"
                value={txHash}
                onChange={(e) => setTxHash(e.target.value)}
                spellCheck={false}
                required
              />
            </div>
            <ServerError message={error} />
            <button
              type="submit"
              disabled={submit.isPending}
              className="flex items-center justify-center gap-2 rounded-lg bg-g-brand px-5 py-2.5 font-mono text-[12px] font-semibold uppercase tracking-widest text-white transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
            >
              <Send className="h-3.5 w-3.5" />
              {submit.isPending ? "Submitting…" : "Submit claim"}
            </button>
          </form>
        )}

        {/* Claim history */}
        {claims.length > 0 && (
          <div className="mt-5 border-t border-hairline pt-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
              Your claims
            </p>
            <ul className="mt-3 flex flex-col gap-2">
              {claims.map((c) => (
                <li
                  key={c.id}
                  className="flex flex-wrap items-center gap-2 rounded-lg border border-hairline bg-panel2/60 px-3 py-2"
                >
                  <ClaimStatusChip status={c.status} />
                  <span className="font-mono text-[11px] text-tsec">
                    {CHAINS.find((x) => x.id === c.chainId)?.label ?? `chain ${c.chainId}`}
                  </span>
                  <code className="font-mono text-[11px] text-tmut">
                    {c.txHash.slice(0, 10)}…{c.txHash.slice(-6)}
                  </code>
                  <span className="ml-auto font-mono text-[10px] text-tmut">
                    {new Date(c.createdAt).toLocaleDateString()}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </motion.div>
    </div>
  );
}

/** Upgrade section — FREE vs PRO cards + crypto pay-to-address flow. */
export default function Upgrade() {
  const entitlement = useEntitlement();
  const me = trpc.auth.me.useQuery(undefined, { staleTime: 60_000, retry: false });

  const isPro = !!entitlement && entitlement.plan === "pro";
  const planExpiresAt = me.data?.planExpiresAt
    ? new Date(me.data.planExpiresAt)
    : null;

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {/* FREE */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className={cn(
            "card-base flex flex-col p-6",
            !isPro && "border-amber/40",
          )}
        >
          <div className="flex items-center justify-between">
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-amber">
              FREE
            </p>
            {!isPro && (
              <span className="rounded-full border border-amber/50 px-2.5 py-0.5 font-mono text-[10px] tracking-wider text-amber">
                current plan
              </span>
            )}
          </div>
          <p className="tnum mt-3 font-mono text-3xl font-bold text-tpri">
            $0
            <span className="ml-1 font-mono text-xs font-normal text-tmut">/ forever</span>
          </p>
          <ul className="mt-4 flex flex-col gap-2">
            {FREE_FEATURES.map((f) => (
              <li key={f} className="flex items-start gap-2 text-[13px] text-tsec">
                <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber" />
                {f}
              </li>
            ))}
          </ul>
          <p className="mt-auto pt-4 font-mono text-[10px] leading-relaxed text-tmut">
            trial starts at signup — when it ends, sniping locks until you upgrade
          </p>
        </motion.div>

        {/* PRO */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08, duration: 0.3 }}
          className={cn(
            "card-base flex flex-col border-violet/50 p-6 shadow-glow-violet",
            isPro && "border-neon/40",
          )}
        >
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.22em] text-violet">
              <Crown className="h-3.5 w-3.5" /> PRO
            </p>
            {isPro && (
              <span className="rounded-full border border-neon/50 bg-neon/10 px-2.5 py-0.5 font-mono text-[10px] tracking-wider text-neon">
                current plan
              </span>
            )}
          </div>
          <p className="tnum mt-3 font-mono text-3xl font-bold text-tpri">
            ${PRO_PRICE_USD}
            <span className="ml-1 font-mono text-xs font-normal text-tmut">/ month</span>
          </p>
          <ul className="mt-4 flex flex-col gap-2">
            {PRO_FEATURES.map((f) => (
              <li key={f} className="flex items-start gap-2 text-[13px] text-tsec">
                <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-neon" />
                {f}
              </li>
            ))}
          </ul>

          {isPro && (
            <div className="mt-auto pt-5">
              <p className="rounded-lg border border-neon/30 bg-neon/5 px-3 py-2 font-mono text-[11px] text-neon">
                ✓ PRO active
                {entitlement?.admin
                  ? " — admin access, never expires"
                  : planExpiresAt
                    ? ` — renews/expires ${planExpiresAt.toLocaleDateString()}`
                    : " — no expiry set"}
              </p>
            </div>
          )}
        </motion.div>
      </div>

      {!isPro && <PaymentSection />}

      <p className="text-center font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
        No profit guarantees. NFT trading involves risk.
      </p>
      <p className="flex items-center justify-center gap-4 font-mono text-[10px] uppercase tracking-[0.18em]">
        <Link to="/terms" className="text-tmut transition-colors hover:text-tpri">
          Terms
        </Link>
        <Link to="/risk" className="text-tmut transition-colors hover:text-tpri">
          Risk disclosure
        </Link>
        <Link to="/privacy" className="text-tmut transition-colors hover:text-tpri">
          Privacy
        </Link>
      </p>
    </div>
  );
}
