/**
 * Wallet behavior label chips (GMGN-style tags) for discovered traders.
 * Tiny mono uppercase chips with a tooltip explaining the rule that fired.
 * Unknown/future labels render in a muted fallback style.
 */
import { WALLET_LABELS, type WalletLabel } from "@contracts/discover";
import { cn } from "@/lib/utils";

type LabelMeta = {
  /** Tooltip explaining the rule that produced the label. */
  tip: string;
  /** Chip colors (border/bg/text). */
  cls: string;
};

const LABEL_META: Record<WalletLabel, LabelMeta> = {
  "smart-money": {
    tip: "smart money — win rate ≥60% · ≥10 flips · positive realized PnL",
    cls: "border-[#39FF8E]/50 bg-[#39FF8E]/10 text-[#39FF8E]",
  },
  sniper: {
    tip: "sniper — ≥60% of flips are mint flips (≥5 flips)",
    cls: "border-[#7C5CFF]/50 bg-[#7C5CFF]/10 text-[#7C5CFF]",
  },
  whale: {
    tip: "whale — ≥25 ETH total volume in the scanned window",
    cls: "border-[#41E6E0]/50 bg-[#41E6E0]/10 text-[#41E6E0]",
  },
  fresh: {
    tip: "fresh wallet — first observed activity <30 days before scan end",
    cls: "border-[#FFB224]/50 bg-[#FFB224]/10 text-[#FFB224]",
  },
  flipper: {
    tip: "flipper — avg hold <24h across ≥3 flips",
    cls: "border-[#41E6E0]/25 bg-[#41E6E0]/5 text-[#41E6E0]/60",
  },
  diamond: {
    tip: "diamond hands — avg hold >30d across ≥2 flips",
    cls: "border-[#7C5CFF]/25 bg-[#7C5CFF]/5 text-[#7C5CFF]/60",
  },
  bagholder: {
    tip: "bagholder — ≥5 open positions with negative unrealized PnL",
    cls: "border-[#FF4D6A]/50 bg-[#FF4D6A]/10 text-[#FF4D6A]",
  },
};

const FALLBACK_META: LabelMeta = {
  tip: "wallet behavior label",
  cls: "border-hairline bg-panel2 text-tmut",
};

// Importance order for display (matches the scanner's ordering).
const ORDER = new Map<string, number>(WALLET_LABELS.map((l, i) => [l, i]));

export function WalletLabels({
  labels,
  className,
}: {
  labels: string[] | null | undefined;
  className?: string;
}) {
  const sorted = (labels ?? [])
    .filter((l): l is string => typeof l === "string" && l.length > 0)
    .slice()
    .sort((a, b) => (ORDER.get(a) ?? 99) - (ORDER.get(b) ?? 99));
  if (sorted.length === 0) return null;
  return (
    <span className={cn("inline-flex flex-wrap items-center gap-1", className)}>
      {sorted.map((label) => {
        const meta = (LABEL_META as Record<string, LabelMeta>)[label] ?? FALLBACK_META;
        return (
          <span
            key={label}
            title={meta.tip}
            className={cn(
              "rounded border px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-widest",
              meta.cls,
            )}
          >
            {label}
          </span>
        );
      })}
    </span>
  );
}
