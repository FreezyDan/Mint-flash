import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Briefcase,
  Eye,
  EyeOff,
  KeyRound,
  Plus,
  ShieldAlert,
  Trash2,
  Vault,
  Wallet as WalletIcon,
} from "lucide-react";
import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../../api/router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { WalletProfileDrawer } from "./WalletProfileDrawer";
import { fmtEth } from "./CopyTrading";
import {
  ChainBadge,
  CopyAddr,
  EmptyState,
  FieldLabel,
  ServerError,
  chainById,
  inputCls,
  timeAgo,
  truncateAddr,
} from "./shared";

const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;

type ProfileResult = inferRouterOutputs<AppRouter>["profile"]["get"];

/** Compact stat cell for the vault portfolio strip. */
function PortfolioStat({
  label,
  value,
  cls,
}: {
  label: string;
  value: string;
  cls?: string;
}) {
  return (
    <div className="rounded-lg border border-hairline bg-void px-2.5 py-2">
      <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-tmut">{label}</p>
      <p className={cn("tnum mt-1 font-mono text-[12px]", cls ?? "text-tpri")}>{value}</p>
    </div>
  );
}

/**
 * VAULT PORTFOLIO — on-demand OpenSea PnL snapshot for the managed vault
 * address (profile.get, shared OpenSea key). Loads only on request; the
 * "full profile" button opens the full WalletProfileDrawer.
 */
function VaultPortfolio({ address }: { address: string }) {
  const utils = trpc.useUtils();
  const [result, setResult] = useState<ProfileResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      setResult(await utils.profile.get.fetch({ address }));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load vault portfolio");
    } finally {
      setLoading(false);
    }
  };

  const profile = result?.profile ?? null;
  const noActivity =
    profile !== null &&
    profile.eventsScanned === 0 &&
    profile.openCount === 0 &&
    (profile.holdings?.length ?? 0) === 0;

  return (
    <div className="mt-4">
      <div className="flex items-center justify-between gap-2">
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
          Vault portfolio
        </p>
        {profile && (
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className="flex items-center gap-1 rounded-full border border-violet/40 bg-violet/10 px-2.5 py-1 font-mono text-[10px] text-violet transition-colors hover:bg-violet/20"
          >
            <Briefcase className="h-3 w-3" />
            full profile
          </button>
        )}
      </div>

      {loading ? (
        <div className="mt-2">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
            ))}
          </div>
          <p className="mt-2 font-mono text-[10px] text-tmut">
            ▸ scanning OpenSea trade history — can take up to a minute…
          </p>
        </div>
      ) : error ? (
        <div className="mt-2 rounded-lg border border-alarm/40 bg-alarm/10 px-3 py-2.5">
          <p className="font-mono text-[11px] leading-relaxed text-alarm">{error}</p>
          <button
            type="button"
            onClick={() => void load()}
            className="mt-2 rounded-lg border border-violet/40 bg-violet/10 px-3 py-1.5 font-mono text-[11px] text-violet transition-colors hover:bg-violet/20"
          >
            Retry
          </button>
        </div>
      ) : profile === null ? (
        <button
          type="button"
          onClick={() => void load()}
          className="mt-2 flex items-center gap-1.5 rounded-lg border border-hairline bg-panel2 px-3 py-2 font-mono text-[11px] text-tsec transition-colors hover:border-violet/45 hover:text-tpri"
        >
          <Briefcase className="h-3.5 w-3.5 text-violet" />
          Load portfolio
        </button>
      ) : noActivity ? (
        <p className="mt-2 font-mono text-[11px] uppercase tracking-widest text-tmut/70">
          no on-chain activity yet
        </p>
      ) : (
        <div className="mt-2">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <PortfolioStat
              label="Total PnL"
              value={`${fmtEth(profile.totalPnlEth)} ETH`}
              cls={Number(profile.totalPnlEth) >= 0 ? "text-neon" : "text-alarm"}
            />
            <PortfolioStat
              label="Realized"
              value={`${fmtEth(profile.realizedPnlEth)} ETH`}
              cls={Number(profile.realizedPnlEth) >= 0 ? "text-neon" : "text-alarm"}
            />
            <PortfolioStat
              label="Win rate"
              value={
                profile.wins + profile.losses > 0
                  ? `${profile.winRatePct}% (${profile.wins}/${profile.wins + profile.losses})`
                  : "—"
              }
            />
            <PortfolioStat label="Open positions" value={String(profile.openCount)} cls="text-cyan" />
          </div>

          {profile.holdings != null && profile.holdings.length > 0 && (
            <div className="mt-2 grid grid-cols-3 gap-2">
              {profile.holdings.slice(0, 3).map((h) => (
                <div
                  key={`${h.chainId}:${h.collectionSlug}`}
                  className="min-w-0 rounded-lg border border-hairline bg-void p-2"
                >
                  {h.imageUrl !== null ? (
                    <img
                      src={h.imageUrl}
                      alt={h.name}
                      loading="lazy"
                      className="aspect-square w-full rounded-md border border-hairline/60 object-cover"
                    />
                  ) : (
                    <div className="flex aspect-square w-full items-center justify-center rounded-md border border-violet/30 bg-violet/10">
                      <span className="font-display text-xl font-semibold text-violet">
                        {h.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                  <p className="mt-1.5 truncate font-mono text-[10px] text-tsec" title={h.name}>
                    {h.name}
                  </p>
                  <div className="mt-1 flex items-center gap-1">
                    <ChainBadge chainId={h.chainId} className="px-1.5 text-[9px]" />
                    <span className="rounded-full border border-hairline bg-panel2 px-1.5 py-px font-mono text-[9px] text-tsec">
                      ×{h.count}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
          <p className="mt-2 font-mono text-[9px] uppercase tracking-widest text-tmut">
            {result?.cached ? "cached snapshot" : "fresh from OpenSea"} · PnL across 6 chains
          </p>
        </div>
      )}

      <AnimatePresence>
        {drawerOpen && (
          <WalletProfileDrawer
            key={address}
            address={address}
            onClose={() => setDrawerOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/** Below this native balance a chain is flagged as underfunded for gas. */
const LOW_BALANCE_ETH = 0.005;

/** Per-chain native balances of the managed vault with funding guidance. */
function VaultBalances() {
  const balances = trpc.wallets.vaultBalances.useQuery(undefined, {
    refetchInterval: 30_000,
  });

  if (balances.isLoading) {
    return (
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="h-9 animate-pulse rounded-lg bg-panel2" />
        ))}
      </div>
    );
  }

  const rows = balances.data ?? [];
  if (rows.length === 0) return null;

  const resolved = rows.filter((r) => r.balanceEth !== null);
  const allZero =
    resolved.length > 0 && resolved.every((r) => Number(r.balanceEth) === 0);
  const anyLow = rows.some(
    (r) => r.balanceEth !== null && Number(r.balanceEth) < LOW_BALANCE_ETH,
  );

  return (
    <div className="mt-3">
      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
        Vault balances
      </p>
      <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {rows.map((r) => {
          const chain = chainById(r.chainId);
          const low =
            r.balanceEth !== null && Number(r.balanceEth) < LOW_BALANCE_ETH;
          return (
            <div
              key={r.chainId}
              className="flex items-center justify-between rounded-lg border border-hairline bg-void px-2.5 py-2"
            >
              <span className="flex items-center gap-1.5 font-mono text-[11px] text-tsec">
                <img src={chain.icon} alt="" className="h-3 w-3" />
                {chain.label}
              </span>
              <span className="flex items-center gap-1.5">
                <span className="tnum font-mono text-[11px] text-tpri">
                  {r.balanceEth ?? "—"}
                </span>
                {low && (
                  <span className="rounded-full border border-amber/40 bg-amber/10 px-1.5 py-px font-mono text-[9px] uppercase tracking-wider text-amber">
                    low
                  </span>
                )}
              </span>
            </div>
          );
        })}
      </div>

      {allZero ? (
        <div className="mt-3 flex items-start gap-2.5 rounded-lg border border-amber/40 bg-amber/10 px-3 py-2.5">
          <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber" />
          <p className="text-[12px] leading-relaxed text-tsec">
            <span className="font-medium text-amber">Your vault is empty</span> — deposit
            native tokens (ETH etc.) to the address above on the chains you'll snipe/sweep
            on. Snipes fail without gas.
          </p>
        </div>
      ) : (
        anyLow && (
          <p className="mt-2 font-mono text-[11px] text-tmut">
            ▸ fund your vault on this chain so the bot can pay gas
          </p>
        )
      )}
    </div>
  );
}

/** Auto-created managed vault card with two-step private-key reveal. */
function VaultCard({ pushToast }: { pushToast: ToastFn }) {
  const managed = trpc.wallets.managed.useQuery();
  const reveal = trpc.wallets.reveal.useMutation({
    onError: (e) => pushToast(e.message, "error"),
  });
  const [confirming, setConfirming] = useState(false);
  const [revealedKey, setRevealedKey] = useState<string | null>(null);

  if (managed.isLoading) {
    return <div className="h-40 animate-pulse rounded-xl border border-hairline bg-panel" />;
  }
  if (!managed.data) {
    return (
      <div className="card-base">
        <ServerError message="Bot vault could not be loaded — it will be retried on next visit." />
      </div>
    );
  }

  const vault = managed.data;

  return (
    <div className="card-base border-violet/35">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-violet/40 bg-violet/10">
            <Vault className="h-4 w-4 text-violet" />
          </span>
          <div>
            <h3 className="font-display text-[15px] font-semibold text-tpri">Bot vault</h3>
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-violet">
              Auto-created on sign-up
            </p>
          </div>
        </div>
        <p className="font-mono text-[10px] text-tmut">created {timeAgo(vault.createdAt)}</p>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-lg border border-hairline bg-void px-3 py-2.5">
        <span className="font-mono text-[12px] text-tpri">{vault.address}</span>
        <CopyAddr value={vault.address} />
      </div>
      <p className="mt-2 font-mono text-[11px] leading-relaxed text-tmut">
        Same address on every EVM chain — fund it with ETH on the chain your task targets.
      </p>

      <VaultBalances />

      <VaultPortfolio address={vault.address} />

      <p className="mt-3 text-[13px] leading-relaxed text-tsec">
        This is the wallet the bot uses for live sniping and copy-trading execution. In live mode
        the vault is the primary signer; any wallets in the server's{" "}
        <span className="font-mono text-[12px] text-violet">BOT_PRIVATE_KEYS</span> env var run as
        extras.
      </p>

      {/* Reveal flow */}
      {revealedKey ? (
        <div className="mt-4 rounded-lg border border-alarm/40 bg-alarm/5 p-3">
          <div className="flex items-center justify-between gap-2">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-alarm">
              Private key — do not share
            </p>
            <button
              onClick={() => {
                setRevealedKey(null);
                setConfirming(false);
              }}
              className="flex items-center gap-1 rounded px-2 py-1 font-mono text-[11px] text-tmut transition-colors hover:bg-panel2 hover:text-tpri"
            >
              <EyeOff className="h-3.5 w-3.5" /> hide
            </button>
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-2 rounded-lg border border-hairline bg-void px-3 py-2.5">
            <span className="break-all font-mono text-[12px] text-tpri">{revealedKey}</span>
            <CopyAddr value={revealedKey} />
          </div>
        </div>
      ) : confirming ? (
        <div className="mt-4 rounded-lg border border-alarm/40 bg-alarm/5 p-3">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-alarm" />
            <div className="text-[12px] leading-relaxed text-tsec">
              <p className="font-medium text-alarm">Revealing your vault key is dangerous.</p>
              <p className="mt-1">
                Anyone with this key controls the funds in your vault. Never share it, never paste
                it into a website, and make sure no one can see your screen.
              </p>
              <div className="mt-3 flex gap-2">
                <button
                  disabled={reveal.isPending}
                  onClick={() =>
                    reveal.mutate(undefined, {
                      onSuccess: (data) => {
                        setRevealedKey(data.privateKey);
                        setConfirming(false);
                        pushToast("Vault key revealed — keep it secret", "info");
                      },
                    })
                  }
                  className="flex items-center gap-1.5 rounded-lg border border-alarm/50 bg-alarm/15 px-3 py-1.5 font-mono text-[11px] font-medium text-alarm transition-all hover:bg-alarm/25 disabled:opacity-40"
                >
                  <Eye className="h-3.5 w-3.5" />
                  {reveal.isPending ? "Revealing…" : "I understand — reveal"}
                </button>
                <button
                  onClick={() => setConfirming(false)}
                  className="rounded-lg border border-hairline bg-panel2 px-3 py-1.5 font-mono text-[11px] text-tsec transition-colors hover:text-tpri"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setConfirming(true)}
          className="mt-4 flex items-center gap-1.5 rounded-lg border border-hairline bg-panel2 px-3 py-2 font-mono text-[11px] text-tsec transition-colors hover:border-alarm/40 hover:text-alarm"
        >
          <KeyRound className="h-3.5 w-3.5" /> Reveal private key
        </button>
      )}
    </div>
  );
}

export default function Wallets({ pushToast }: { pushToast: ToastFn }) {
  const utils = trpc.useUtils();
  const list = trpc.wallets.list.useQuery(undefined, { refetchInterval: 10_000 });
  const [label, setLabel] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState<string | null>(null);

  const invalidate = () =>
    Promise.all([utils.wallets.list.invalidate(), utils.stats.overview.invalidate()]);

  const add = trpc.wallets.add.useMutation({
    onSuccess: async () => {
      pushToast(`Wallet "${label.trim()}" added`, "success");
      setLabel("");
      setAddress("");
      setError(null);
      await invalidate();
    },
    onError: (e) => setError(e.message),
  });
  const remove = trpc.wallets.remove.useMutation({
    onSuccess: async () => {
      pushToast("Wallet removed", "info");
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  // The managed "Auto vault" has its own card above — keep it out of the
  // manual list so it can't be accidentally deleted.
  const wallets = (list.data ?? []).filter((w) => !w.managed);

  return (
    <div className="flex flex-col gap-6">
      {/* Managed vault */}
      <VaultCard pushToast={pushToast} />

      {/* Server-side key note */}
      <div className="flex items-start gap-3 rounded-xl border border-violet/30 bg-violet/5 p-4">
        <KeyRound className="mt-0.5 h-4 w-4 shrink-0 text-violet" />
        <p className="text-[13px] leading-relaxed text-tsec">
          <span className="font-medium text-tpri">Keys stay server-side.</span> Your bot vault's
          private key is stored encrypted on the server (AES-256-GCM) and is only ever decrypted to
          sign live transactions or when you explicitly reveal it. Manually-added wallets below are
          public addresses only — their keys live exclusively in the server's{" "}
          <span className="font-mono text-[12px] text-violet">BOT_PRIVATE_KEYS</span> environment
          variable.
        </p>
      </div>

      {/* Add form */}
      <div className="card-base">
        <h3 className="font-display text-[15px] font-semibold text-tpri">Add bot wallet</h3>
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr_auto]">
          <div>
            <FieldLabel>Label</FieldLabel>
            <input
              className={inputCls}
              placeholder="sniper-04"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Public address</FieldLabel>
            <input
              className={inputCls}
              placeholder="0x…"
              value={address}
              onChange={(e) => setAddress(e.target.value.trim())}
            />
          </div>
          <div className="flex items-end">
            <button
              disabled={add.isPending}
              onClick={() => {
                if (!label.trim()) {
                  setError("Label is required");
                  return;
                }
                if (!ADDR_RE.test(address)) {
                  setError("Must be a valid 0x address");
                  return;
                }
                add.mutate({ label: label.trim(), address });
              }}
              className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-g-brand px-4 py-2.5 text-[13px] font-semibold text-white transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40 md:w-auto"
            >
              <Plus className="h-4 w-4" /> Add wallet
            </button>
          </div>
        </div>
        <div className="mt-3">
          <ServerError message={error} />
        </div>
      </div>

      {/* List */}
      {list.isLoading ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-20 animate-pulse rounded-xl border border-hairline bg-panel" />
          ))}
        </div>
      ) : wallets.length === 0 ? (
        <EmptyState
          icon={<WalletIcon className="h-5 w-5" />}
          title="No manual bot wallets"
          body="Your auto-created vault above is ready to mint with. Add extra funded wallets here if you want multi-wallet firepower — the matching keys stay in the server environment."
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {wallets.map((w, i) => (
            <motion.div
              key={w.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.04 * i, duration: 0.3 }}
              className="group flex items-center gap-3 rounded-xl border border-hairline bg-panel p-4 transition-colors hover:border-violet/45"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-hairline bg-panel2">
                <WalletIcon className="h-4 w-4 text-neon" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium text-tpri">{w.label}</p>
                <p className="flex items-center gap-1.5 font-mono text-[11px] text-tmut">
                  {truncateAddr(w.address)}
                  <CopyAddr value={w.address} />
                </p>
                <p className="font-mono text-[10px] text-tmut">added {timeAgo(w.createdAt)}</p>
              </div>
              <button
                onClick={() => remove.mutate({ id: w.id })}
                title="Remove wallet"
                className="rounded p-1.5 text-tmut opacity-0 transition-all hover:bg-alarm/10 hover:text-alarm group-hover:opacity-100"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
