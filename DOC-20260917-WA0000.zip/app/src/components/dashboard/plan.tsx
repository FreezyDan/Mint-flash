import { Lock } from "lucide-react";
import { motion } from "framer-motion";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { FREE_LIMITS, PRO_PRICE_USD, type Entitlement } from "@contracts/plans";

/** Entitlement from auth.me (shares the react-query cache with useAuth). */
export function useEntitlement(): Entitlement | null {
  const me = trpc.auth.me.useQuery(undefined, { staleTime: 60_000, retry: false });
  return me.data?.entitlement ?? null;
}

/** FREE amber outline / PRO violet filled / ADMIN green filled. */
export function PlanBadge({ entitlement }: { entitlement: Entitlement }) {
  const base =
    "inline-flex items-center rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-semibold tracking-[0.18em]";
  if (entitlement.admin) {
    return <span className={cn(base, "border-neon/50 bg-neon/15 text-neon")}>ADMIN</span>;
  }
  if (entitlement.plan === "pro") {
    return <span className={cn(base, "border-violet/60 bg-violet/20 text-violet")}>PRO</span>;
  }
  return <span className={cn(base, "border-amber/50 bg-transparent text-amber")}>FREE</span>;
}

/** Mono countdown chip for free users; red once the trial is over. */
export function TrialChip({ entitlement }: { entitlement: Entitlement }) {
  if (entitlement.plan !== "free" || entitlement.admin) return null;
  if (entitlement.trialExpired) {
    return (
      <span className="inline-flex items-center rounded-full border border-alarm/50 bg-alarm/10 px-2.5 py-0.5 font-mono text-[10px] tracking-wider text-alarm">
        trial expired
      </span>
    );
  }
  if (entitlement.trialDaysLeft === null) return null;
  return (
    <span className="tnum inline-flex items-center rounded-full border border-hairline bg-panel2 px-2.5 py-0.5 font-mono text-[10px] tracking-wider text-tsec">
      trial: {entitlement.trialDaysLeft}d left
    </span>
  );
}

/** Centered paywall card that replaces a locked section's content. */
export function LockCard({
  title,
  lines,
  onUpgrade,
}: {
  title: string;
  lines: [string, string];
  onUpgrade: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col items-center justify-center gap-4 rounded-xl border border-violet/40 bg-panel px-6 py-16 text-center shadow-glow-violet"
    >
      <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-violet/50 bg-violet/10 text-violet">
        <Lock className="h-5 w-5" />
      </span>
      <div>
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-violet">
          PRO feature
        </p>
        <p className="mt-2 font-display text-xl font-semibold text-tpri">{title}</p>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-tsec">
          {lines[0]}
          <br />
          {lines[1]}
        </p>
      </div>
      <button
        type="button"
        onClick={onUpgrade}
        className="mt-1 rounded-lg bg-g-brand px-6 py-2.5 font-mono text-[12px] font-semibold uppercase tracking-widest text-white transition-all hover:brightness-110 active:scale-[0.97]"
      >
        Upgrade — ${PRO_PRICE_USD}/mo
      </button>
      <p className="font-mono text-[10px] text-tmut">
        free plan: snipe bot · {FREE_LIMITS.trialDays}-day trial ·{" "}
        {FREE_LIMITS.maxPendingSnipes} pending orders · {FREE_LIMITS.maxSnipeWallets} wallets
        per snipe
      </p>
    </motion.div>
  );
}
