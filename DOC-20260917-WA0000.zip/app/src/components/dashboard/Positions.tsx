import { useState } from "react";
import { motion } from "framer-motion";
import {
  Briefcase,
  Check,
  ExternalLink,
  History,
  Loader2,
  Target,
  X,
} from "lucide-react";
import type { inferRouterOutputs } from "@trpc/server";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import type { AppRouter } from "../../../api/router";
import { useEntitlement } from "./plan";
import { nativeSymbol } from "@contracts/rpc";
import {
  ChainBadge,
  CopyAddr,
  EmptyState,
  timeAgo,
  truncateAddr,
} from "./shared";

type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;
type Position = inferRouterOutputs<AppRouter>["positions"]["list"][number];

const DISCLOSURE_TEXT =
  "Exits execute on-chain from your bot vault: the engine polls the best OpenSea collection " +
  "offer every ~75s and sells when your take-profit / stop-loss triggers, when a copied wallet " +
  "sells (mirror exit, PRO), or when you hit Sell now. Failed sells leave the position open and " +
  "retry next cycle. Real funds, real risk.";

/* ------------------------------------------------------------------ */
/* Badges + chips                                                      */
/* ------------------------------------------------------------------ */

const SOURCE_STYLE: Record<string, { label: string; cls: string }> = {
  snipe: { label: "SNIPE", cls: "border-violet/40 bg-violet/10 text-violet" },
  copy: { label: "COPY", cls: "border-cyan/40 bg-cyan/10 text-cyan" },
  sweep: { label: "SWEEP", cls: "border-neon/40 bg-neon/10 text-neon" },
};

function SourceBadge({ source }: { source: string }) {
  const s = SOURCE_STYLE[source] ?? SOURCE_STYLE.snipe;
  return (
    <span
      className={cn(
        "rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider",
        s.cls,
      )}
    >
      {s.label}
    </span>
  );
}

const REASON_STYLE: Record<string, { label: string; cls: string }> = {
  take_profit: { label: "TAKE PROFIT", cls: "border-neon/40 bg-neon/10 text-neon" },
  stop_loss: { label: "STOP LOSS", cls: "border-alarm/40 bg-alarm/10 text-alarm" },
  mirror_sell: { label: "MIRROR", cls: "border-cyan/40 bg-cyan/10 text-cyan" },
  manual: { label: "MANUAL", cls: "border-violet/40 bg-violet/10 text-violet" },
};

function ReasonChip({ reason }: { reason: string | null }) {
  const r = REASON_STYLE[reason ?? ""] ?? {
    label: (reason ?? "closed").replace("_", " ").toUpperCase(),
    cls: "border-hairline bg-panel2 text-tmut",
  };
  return (
    <span
      className={cn(
        "rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider",
        r.cls,
      )}
    >
      {r.label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Stat strip                                                          */
/* ------------------------------------------------------------------ */

function StatCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone?: "neon" | "alarm";
}) {
  return (
    <div className="card-base flex flex-col gap-1 px-4 py-3.5">
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">{label}</p>
      <p
        className={cn(
          "tnum font-mono text-lg font-semibold",
          tone === "neon" ? "text-neon" : tone === "alarm" ? "text-alarm" : "text-tpri",
        )}
      >
        {value}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* TP/SL inline editor                                                 */
/* ------------------------------------------------------------------ */

function ExitEditor({
  position,
  field,
  max,
  pushToast,
}: {
  position: Position;
  field: "tpPct" | "slPct";
  max: number;
  pushToast: ToastFn;
}) {
  const utils = trpc.useUtils();
  const current = position[field];
  const [value, setValue] = useState(current === null ? "" : String(current));
  const dirty = value !== (current === null ? "" : String(current));

  const save = trpc.positions.setExit.useMutation({
    onSuccess: async () => {
      pushToast(
        `${field === "tpPct" ? "Take-profit" : "Stop-loss"} ${
          value.trim() === "" ? "disabled" : `set to ${value.trim()}%`
        }`,
        "success",
      );
      await utils.positions.list.invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  const submit = () => {
    const trimmed = value.trim();
    if (trimmed === "") {
      save.mutate({ positionId: position.id, [field]: null });
      return;
    }
    const n = Number(trimmed);
    if (!Number.isInteger(n) || n < 1 || n > max) {
      pushToast(`Must be a whole % between 1 and ${max} (empty = off)`, "error");
      return;
    }
    save.mutate({ positionId: position.id, [field]: n });
  };

  return (
    <span className="inline-flex items-center gap-1">
      <input
        value={value}
        inputMode="numeric"
        placeholder="off"
        onChange={(e) => setValue(e.target.value.trim())}
        onKeyDown={(e) => {
          if (e.key === "Enter" && dirty) submit();
        }}
        className="w-12 rounded border border-hairline bg-void px-1.5 py-0.5 text-right font-mono text-[11px] text-tpri placeholder:text-tmut focus:border-violet/60 focus:outline-none"
      />
      <span className="font-mono text-[10px] text-tmut">%</span>
      {dirty && (
        <button
          onClick={submit}
          disabled={save.isPending}
          title="Save"
          className="rounded p-0.5 text-neon transition-colors hover:bg-neon/10 disabled:opacity-40"
        >
          {save.isPending ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <Check className="h-3 w-3" />
          )}
        </button>
      )}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Rarity cell (manual check — one fetch per position per drawer-open) */
/* ------------------------------------------------------------------ */

type RarityResult = inferRouterOutputs<AppRouter>["positions"]["rarity"];

function rarityTooltip(r: RarityResult): string {
  const lines: string[] = [];
  if (r.kind === "rank" && r.rank !== null) lines.push(`OpenRarity rank #${r.rank}`);
  if (r.kind === "score" && r.score !== null)
    lines.push(`local rarity score ${r.score.toFixed(2)} (rank not computed yet)`);
  if (r.kind === "unknown")
    lines.push("rarity not available yet (rank not computed / no trait data)");
  if (r.topTraits) {
    for (const t of r.topTraits) lines.push(`${t.type}: ${t.value} — ${t.pct}% of collection`);
  }
  return lines.join("\n");
}

function RarityCell({ positionId }: { positionId: number }) {
  const query = trpc.positions.rarity.useQuery(
    { positionId },
    {
      enabled: false, // manual Check button only — no polling
      staleTime: Infinity,
      retry: false,
    },
  );
  const r = query.data;

  if (!r && !query.isFetching) {
    return (
      <button
        onClick={() => void query.refetch()}
        title="Check rarity via OpenSea (OpenRarity rank or local trait score)"
        className="inline-flex items-center gap-1 rounded-md border border-violet/40 bg-violet/5 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-violet transition-colors hover:bg-violet/15"
      >
        <Check className="h-3 w-3" />
        Check
      </button>
    );
  }
  if (query.isFetching || !r) {
    return <Loader2 className="h-3.5 w-3.5 animate-spin text-violet" />;
  }
  if (query.isError) {
    return (
      <button
        onClick={() => void query.refetch()}
        title="Rarity check failed — click to retry"
        className="rounded-md border border-alarm/40 bg-alarm/10 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-alarm"
      >
        retry
      </button>
    );
  }

  const tip = rarityTooltip(r);
  if (r.kind === "rank" && r.rank !== null) {
    const tone =
      r.rank <= 100
        ? "border-neon/40 bg-neon/10 text-neon"
        : r.rank <= 1000
          ? "border-cyan/40 bg-cyan/10 text-cyan"
          : "border-hairline bg-panel2 text-tmut";
    return (
      <span
        title={tip}
        className={cn(
          "rounded-full border px-2 py-0.5 font-mono text-[10px] tracking-wider",
          tone,
        )}
      >
        #{r.rank}
      </span>
    );
  }
  if (r.kind === "score" && r.score !== null) {
    return (
      <span
        title={tip}
        className="rounded-full border border-violet/40 bg-violet/10 px-2 py-0.5 font-mono text-[10px] tracking-wider text-violet"
      >
        score {r.score.toFixed(1)}
      </span>
    );
  }
  return (
    <span
      title={tip}
      className="rounded-full border border-amber/30 bg-amber/5 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber/60"
    >
      unknown
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Open position row                                                   */
/* ------------------------------------------------------------------ */

function PositionRow({
  position,
  index,
  exitsPaused,
  pushToast,
}: {
  position: Position;
  index: number;
  exitsPaused: boolean;
  pushToast: ToastFn;
}) {
  const utils = trpc.useUtils();
  const [confirming, setConfirming] = useState(false);
  const invalidate = () => utils.positions.list.invalidate();

  const sellNow = trpc.positions.sellNow.useMutation({
    onSuccess: async (res) => {
      pushToast(`Sold @ ${res.sellEth} ETH — tx ${res.txHash.slice(0, 10)}…`, "success");
      setConfirming(false);
      await invalidate();
    },
    onError: (e) => {
      pushToast(e.message, "error");
      setConfirming(false);
    },
  });
  const close = trpc.positions.close.useMutation({
    onSuccess: async () => {
      pushToast("Position closed (no sale recorded)", "info");
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });

  return (
    <motion.tr
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.3 }}
      className={cn("border-b border-hairline/60", exitsPaused && "opacity-50")}
    >
      <td className="py-3 pl-5 pr-3">
        <div className="flex items-center gap-2">
          <SourceBadge source={position.source} />
          {exitsPaused && (
            <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
              PRO exits paused
            </span>
          )}
        </div>
      </td>
      <td className="px-3 py-3">
        <ChainBadge chainId={position.chainId} />
      </td>
      <td className="px-3 py-3">
        <p className="flex items-center gap-1.5 font-mono text-[11px] text-tsec">
          {truncateAddr(position.contractAddress)}
          <CopyAddr value={position.contractAddress} />
        </p>
        <p className="font-mono text-[10px] text-tmut">
          {position.tokenId ? `#${position.tokenId}` : "any token"}
          {position.qty > 1 ? ` ×${position.qty}` : ""}
        </p>
      </td>
      <td className="tnum px-3 py-3 font-mono text-[12px] text-tsec">
        {position.entryEth !== null ? `${Number(position.entryEth).toFixed(4)} ${nativeSymbol(position.chainId)}` : "—"}
      </td>
      <td className="px-3 py-3">
        <ExitEditor position={position} field="tpPct" max={1000} pushToast={pushToast} />
      </td>
      <td className="px-3 py-3">
        <ExitEditor position={position} field="slPct" max={99} pushToast={pushToast} />
      </td>
      <td className="px-3 py-3 font-mono text-[11px] text-tmut">
        {timeAgo(position.openedAt)}
      </td>
      <td className="px-3 py-3">
        <RarityCell positionId={position.id} />
      </td>
      <td className="py-3 pl-3 pr-5">
        <div className="flex items-center justify-end gap-2">
          {sellNow.isPending ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin text-neon" />
          ) : confirming ? (
            <>
              <button
                onClick={() => sellNow.mutate({ positionId: position.id })}
                className="rounded-md border border-neon/50 bg-neon/10 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-neon transition-colors hover:bg-neon/20"
              >
                Confirm
              </button>
              <button
                onClick={() => setConfirming(false)}
                className="rounded-md border border-hairline px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-tmut transition-colors hover:text-tsec"
              >
                Cancel
              </button>
            </>
          ) : (
            <button
              onClick={() => setConfirming(true)}
              disabled={exitsPaused}
              title={exitsPaused ? "PRO required for copy/sweep exits" : "Sell into best offer now"}
              className="rounded-md border border-neon/40 bg-neon/5 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-neon transition-colors hover:bg-neon/15 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Sell now
            </button>
          )}
          <button
            onClick={() => close.mutate({ positionId: position.id })}
            disabled={close.isPending}
            title="Close without selling (sold/transferred elsewhere)"
            className="rounded p-1.5 text-tmut transition-colors hover:bg-alarm/10 hover:text-alarm disabled:opacity-40"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </motion.tr>
  );
}

/* ------------------------------------------------------------------ */
/* Section                                                             */
/* ------------------------------------------------------------------ */

export default function Positions({ pushToast }: { pushToast: ToastFn }) {
  const entitlement = useEntitlement();
  const list = trpc.positions.list.useQuery(undefined, { refetchInterval: 15_000 });
  const positions = list.data ?? [];

  const open = positions.filter((p) => p.status === "open");
  const sold = positions.filter((p) => p.status === "sold").slice(0, 20);

  const sumEntry = open.reduce(
    (sum, p) => sum + (p.entryEth !== null ? Number(p.entryEth) : 0),
    0,
  );
  const realized = positions
    .filter((p) => p.status === "sold")
    .reduce((sum, p) => sum + (p.realizedPnlEth !== null ? Number(p.realizedPnlEth) : 0), 0);
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const sellsToday = positions.filter(
    (p) => p.status === "sold" && p.soldAt && new Date(p.soldAt) >= startOfToday,
  ).length;

  // Free plan: snipe exits run during the trial; copy/sweep exits are PRO-only.
  const isFree = entitlement?.plan === "free" && !entitlement.admin;
  const exitsPausedFor = (p: Position) => isFree && p.source !== "snipe";

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Open positions" value={String(open.length)} />
        <StatCard label="Σ Entry (known)" value={`${sumEntry.toFixed(4)} ETH`} />
        <StatCard
          label="Σ Realized PnL"
          value={`${realized >= 0 ? "+" : ""}${realized.toFixed(4)} ETH`}
          tone={realized > 0 ? "neon" : realized < 0 ? "alarm" : undefined}
        />
        <StatCard label="Sells today" value={String(sellsToday)} />
      </div>

      <div className="card-base p-0">
        <div className="flex items-center justify-between border-b border-hairline px-5 py-4">
          <div>
            <h3 className="font-display text-[15px] font-semibold text-tpri">Open positions</h3>
            <p className="mt-0.5 font-mono text-[11px] text-tmut">
              exits checked against the best collection offer every ~75s
            </p>
          </div>
          <span className="font-mono text-[10px] text-tmut">refresh 15s</span>
        </div>

        {list.isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
            ))}
          </div>
        ) : open.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Briefcase className="h-5 w-5" />}
              title="No open positions"
              body="NFTs the bot acquires — sniped mints, mirrored copy buys, swept floors — land here. Set a take-profit / stop-loss and the engine exits for you."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1060px]">
              <thead>
                <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                  <th className="py-2.5 pl-5 pr-3 font-medium">Source</th>
                  <th className="px-3 py-2.5 font-medium">Chain</th>
                  <th className="px-3 py-2.5 font-medium">Contract / Token</th>
                  <th className="px-3 py-2.5 font-medium">Entry</th>
                  <th className="px-3 py-2.5 font-medium">TP</th>
                  <th className="px-3 py-2.5 font-medium">SL</th>
                  <th className="px-3 py-2.5 font-medium">Age</th>
                  <th className="px-3 py-2.5 font-medium">Rarity</th>
                  <th className="py-2.5 pl-3 pr-5 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {open.map((p, i) => (
                  <PositionRow
                    key={p.id}
                    position={p}
                    index={i}
                    exitsPaused={exitsPausedFor(p)}
                    pushToast={pushToast}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card-base p-0">
        <div className="border-b border-hairline px-5 py-4">
          <h3 className="font-display text-[15px] font-semibold text-tpri">Exit history</h3>
          <p className="mt-0.5 font-mono text-[11px] text-tmut">last 20 sold positions</p>
        </div>

        {list.isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
            ))}
          </div>
        ) : sold.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<History className="h-5 w-5" />}
              title="No exits yet"
              body="Sold positions show up here with the exit reason, entry → sell price and realized PnL."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead>
                <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                  <th className="py-2.5 pl-5 pr-3 font-medium">Reason</th>
                  <th className="px-3 py-2.5 font-medium">Source</th>
                  <th className="px-3 py-2.5 font-medium">Contract / Token</th>
                  <th className="px-3 py-2.5 font-medium">Entry → Sell</th>
                  <th className="px-3 py-2.5 font-medium">Realized PnL</th>
                  <th className="px-3 py-2.5 font-medium">Sold</th>
                  <th className="py-2.5 pl-3 pr-5 text-right font-medium">Tx</th>
                </tr>
              </thead>
              <tbody>
                {sold.map((p, i) => {
                  const pnl = p.realizedPnlEth !== null ? Number(p.realizedPnlEth) : null;
                  return (
                    <motion.tr
                      key={p.id}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.04 * i, duration: 0.3 }}
                      className="border-b border-hairline/60"
                    >
                      <td className="py-3 pl-5 pr-3">
                        <ReasonChip reason={p.sellReason} />
                      </td>
                      <td className="px-3 py-3">
                        <SourceBadge source={p.source} />
                      </td>
                      <td className="px-3 py-3">
                        <p className="flex items-center gap-1.5 font-mono text-[11px] text-tsec">
                          {truncateAddr(p.contractAddress)}
                          <CopyAddr value={p.contractAddress} />
                        </p>
                        <p className="font-mono text-[10px] text-tmut">
                          {p.tokenId ? `#${p.tokenId}` : "any token"}
                        </p>
                      </td>
                      <td className="tnum px-3 py-3 font-mono text-[12px] text-tsec">
                        {p.entryEth !== null ? Number(p.entryEth).toFixed(4) : "—"}
                        <span className="text-tmut"> → </span>
                        {p.sellEth !== null ? `${Number(p.sellEth).toFixed(4)} ${nativeSymbol(p.chainId)}` : "—"}
                      </td>
                      <td
                        className={cn(
                          "tnum px-3 py-3 font-mono text-[12px] font-medium",
                          pnl === null ? "text-tmut" : pnl >= 0 ? "text-neon" : "text-alarm",
                        )}
                      >
                        {pnl === null
                          ? "—"
                          : `${pnl >= 0 ? "+" : ""}${pnl.toFixed(4)} ${nativeSymbol(p.chainId)}`}
                      </td>
                      <td className="px-3 py-3 font-mono text-[11px] text-tmut">
                        {p.soldAt ? timeAgo(p.soldAt) : "—"}
                      </td>
                      <td className="py-3 pl-3 pr-5 text-right">
                        {p.explorerUrl && p.sellTxHash ? (
                          <a
                            href={p.explorerUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 font-mono text-[11px] text-cyan transition-colors hover:text-tpri"
                          >
                            {p.sellTxHash.slice(0, 8)}…
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        ) : (
                          <span className="font-mono text-[11px] text-tmut">—</span>
                        )}
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="rounded-lg border border-hairline bg-panel2/60 px-4 py-3 font-mono text-[11px] leading-relaxed text-tmut">
        <Target className="mr-1.5 inline h-3.5 w-3.5 align-[-2px] text-neon" />
        {DISCLOSURE_TEXT}
      </div>
    </div>
  );
}
