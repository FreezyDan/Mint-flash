import { motion } from "framer-motion";
import { AlertTriangle, Copy, Pencil, Play, Rocket, Square, Trash2, Zap } from "lucide-react";
import { trpc } from "@/providers/trpc";
import type { MintTask } from "@contracts/types";
import type { TaskStatus } from "@contracts/bot";
import { useEntitlement } from "./plan";
import { nativeSymbol } from "@contracts/rpc";
import {
  ChainBadge,
  CopyAddr,
  EmptyState,
  TaskStatusChip,
  fmtCountdown,
  truncateAddr,
  useNow,
} from "./shared";

type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;

function TriggerReadout({ task }: { task: MintTask }) {
  const now = useNow(1000);
  if (task.triggerMode === "time" && task.openTime) {
    const open = task.openTime instanceof Date ? task.openTime : new Date(task.openTime);
    const ms = open.getTime() - now;
    if (task.status === "armed" && ms > 0) {
      return (
        <span className="tnum font-mono text-sm text-amber">
          go-live in {fmtCountdown(ms)}
        </span>
      );
    }
    return (
      <span className="tnum font-mono text-sm text-tmut">
        go-live {open.toLocaleString()}
      </span>
    );
  }
  if (task.triggerMode === "poll") {
    return (
      <span className="font-mono text-sm text-tsec">
        poll <span className="text-cyan">{task.flagMethod}()</span> every {task.pollIntervalMs}ms
      </span>
    );
  }
  return (
    <span className="font-mono text-sm text-tsec">
      on event <span className="text-cyan">{task.eventName ?? "—"}</span>
    </span>
  );
}

/**
 * Compact per-task mint-progress monitor — polls public.mintProgress (10s)
 * for the task's contract: on-chain supply + the watcher's live velocity.
 */
function MintProgress({ task }: { task: MintTask }) {
  const progress = trpc.public.mintProgress.useQuery(
    { chainId: task.chainId, contractAddress: task.contractAddress },
    { refetchInterval: 10_000 },
  );
  const d = progress.data;
  const hasActivity = d != null && (d.m5 !== null || d.m15 !== null || d.total !== null);

  return (
    <div className="mt-4 rounded-lg border border-hairline bg-panel2/50 px-3.5 py-3">
      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
        Mint progress
      </p>
      {progress.isLoading ? (
        <div className="mt-2 h-4 animate-pulse rounded bg-panel2" />
      ) : !hasActivity ? (
        <p className="mt-1.5 font-mono text-xs text-tmut/70">
          no mint activity detected yet
        </p>
      ) : (
        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2">
          {d!.max !== null && d!.pct !== null ? (
            <span className="flex min-w-44 flex-1 items-center gap-2">
              <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-hairline">
                <span
                  className="block h-full rounded-full bg-violet transition-all duration-500"
                  style={{ width: `${Math.min(100, d!.pct)}%` }}
                />
              </span>
              <span className="tnum font-mono text-xs text-violet">
                {d!.pct.toFixed(2)}%
              </span>
              <span className="tnum font-mono text-[11px] text-tmut">
                {d!.total ?? 0}/{d!.max}
              </span>
            </span>
          ) : d!.total !== null ? (
            <span className="tnum font-mono text-xs text-tsec">
              {d!.total} minted
            </span>
          ) : null}
          {(d!.m5 !== null || d!.m15 !== null) && (
            <span className="flex items-center gap-1.5 font-mono text-[11px] text-tmut">
              <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5">
                5m: <span className="text-neon">{d!.m5 ?? 0}</span>
              </span>
              <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5">
                15m: <span className="text-neon">{d!.m15 ?? 0}</span>
              </span>
              <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5">
                minters: <span className="text-cyan">{d!.uniqueMinters15m ?? 0}</span>
              </span>
            </span>
          )}
        </div>
      )}
    </div>
  );
}

function TaskCard({
  task,
  index,
  pushToast,
  locked,
}: {
  task: MintTask;
  index: number;
  pushToast: ToastFn;
  /** Trial expired — arm/start/duplicate are disabled. */
  locked: boolean;
}) {
  const utils = trpc.useUtils();
  const invalidate = async () => {
    await Promise.all([utils.tasks.list.invalidate(), utils.stats.overview.invalidate()]);
  };
  const onErr = (e: { message: string }) => pushToast(e.message, "error");

  const arm = trpc.tasks.arm.useMutation({
    onSuccess: async () => {
      pushToast(`Task "${task.name}" armed`, "success");
      await invalidate();
    },
    onError: onErr,
  });
  const start = trpc.tasks.start.useMutation({
    onSuccess: async () => {
      pushToast(`Task "${task.name}" firing`, "success");
      await invalidate();
    },
    onError: onErr,
  });
  const stop = trpc.tasks.stop.useMutation({
    onSuccess: async () => {
      pushToast(`Task "${task.name}" stopped`, "info");
      await invalidate();
    },
    onError: onErr,
  });
  const del = trpc.tasks.delete.useMutation({
    onSuccess: async () => {
      pushToast(`Task "${task.name}" deleted`, "info");
      await invalidate();
    },
    onError: onErr,
  });
  const duplicate = trpc.tasks.create.useMutation({
    onSuccess: async () => {
      pushToast(`Duplicated "${task.name}" as a new draft`, "success");
      await invalidate();
    },
    onError: onErr,
  });

  const busy = arm.isPending || start.isPending || stop.isPending || del.isPending;
  const status = task.status as TaskStatus;
  const mintArgs = Array.isArray(task.mintArgs) ? (task.mintArgs as unknown[]) : [];
  const qty = typeof mintArgs[0] === "number" ? mintArgs[0] : 1;
  const firing = status === "firing";

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.06 * index, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="card-base overflow-hidden p-0"
    >
      {firing && (
        <div className="h-[3px] w-full bg-hairline">
          <motion.div
            className="h-full bg-neon"
            initial={{ width: "8%" }}
            animate={{ width: ["8%", "64%", "38%", "81%"] }}
            transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
      )}
      <div className="p-5">
        {/* Header */}
        <div className="flex flex-wrap items-center gap-3">
          <TaskStatusChip status={status} />
          <h3 className="font-display text-[17px] font-semibold text-tpri">{task.name}</h3>
          <span className="flex items-center gap-1.5 font-mono text-xs text-tmut">
            {truncateAddr(task.contractAddress)}
            <CopyAddr value={task.contractAddress} />
          </span>
          <span className="ml-auto flex items-center gap-2">
            <ChainBadge chainId={task.chainId} />
          </span>
        </div>

        {/* Body */}
        <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2">
          <TriggerReadout task={task} />
          <span className="font-mono text-xs text-tmut">
            call <span className="text-tsec">{task.mintFunction}({qty})</span>
          </span>
          <span className="font-mono text-xs text-tmut">
            price <span className="text-tsec">{task.mintValueEth} {nativeSymbol(task.chainId)}</span>
          </span>
          <span className="rounded-full border border-hairline bg-panel2 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-tsec">
            gas {task.startMaxFeeGwei}→{task.maxMaxFeeGwei} gwei
          </span>
        </div>

        {/* Live mint progress (supply + watcher velocity) */}
        <MintProgress task={task} />

        {/* Footer actions */}
        <div className="mt-4 flex items-center gap-2 border-t border-hairline pt-4">
          {status === "draft" && (
            <button
              disabled={busy || locked}
              title={locked ? "Trial expired — upgrade to PRO to keep sniping" : undefined}
              onClick={() => arm.mutate({ id: task.id })}
              className="flex items-center gap-1.5 rounded-lg bg-amber/90 px-3.5 py-1.5 text-[12px] font-semibold text-void transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
            >
              <Zap className="h-3.5 w-3.5" /> Arm
            </button>
          )}
          {status === "armed" && (
            <button
              disabled={busy || locked}
              title={locked ? "Trial expired — upgrade to PRO to keep sniping" : undefined}
              onClick={() => start.mutate({ id: task.id })}
              className="flex items-center gap-1.5 rounded-lg bg-neon px-3.5 py-1.5 text-[12px] font-semibold text-void transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
            >
              <Play className="h-3.5 w-3.5" /> Start now
            </button>
          )}
          {(status === "armed" || status === "firing") && (
            <button
              disabled={busy}
              onClick={() => stop.mutate({ id: task.id })}
              className="flex items-center gap-1.5 rounded-lg border border-hairline px-3.5 py-1.5 text-[12px] font-medium text-tsec transition-colors hover:text-tpri disabled:opacity-40"
            >
              <Square className="h-3.5 w-3.5" /> Stop
            </button>
          )}
          <div className="ml-auto flex items-center gap-1">
            <button
              disabled={busy || duplicate.isPending || locked}
              title={locked ? "Trial expired — upgrade to PRO to keep sniping" : "Duplicate as draft"}
              onClick={() =>
                duplicate.mutate({
                  name: `${task.name} (copy)`,
                  contractAddress: task.contractAddress,
                  chainId: task.chainId,
                  mintFunction: task.mintFunction,
                  mintArgs: mintArgs as (string | number | boolean)[],
                  mintValueEth: task.mintValueEth,
                  gasLimit: task.gasLimit,
                  triggerMode: task.triggerMode as "time" | "poll" | "event",
                  openTime: task.openTime ? new Date(task.openTime) : null,
                  flagMethod: task.flagMethod,
                  pollIntervalMs: task.pollIntervalMs,
                  eventName: task.eventName,
                  startMaxFeeGwei: task.startMaxFeeGwei,
                  startPriorityGwei: task.startPriorityGwei,
                  gasBumpGwei: task.gasBumpGwei,
                  maxMaxFeeGwei: task.maxMaxFeeGwei,
                  maxRetries: task.maxRetries,
                  walletCount: task.walletCount,
                })
              }
              className="rounded-lg p-2 text-tmut transition-colors hover:bg-panel2 hover:text-tpri disabled:opacity-40"
            >
              <Copy className="h-4 w-4" />
            </button>
            <button
              disabled
              title="Editing lands soon — duplicate to iterate"
              className="cursor-not-allowed rounded-lg p-2 text-tmut/50"
            >
              <Pencil className="h-4 w-4" />
            </button>
            <button
              disabled={busy}
              title="Delete task"
              onClick={() => del.mutate({ id: task.id })}
              className="rounded-lg p-2 text-tmut transition-colors hover:bg-alarm/10 hover:text-alarm disabled:opacity-40"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );
}

export default function Tasks({
  onNewTask,
  pushToast,
}: {
  onNewTask: () => void;
  pushToast: ToastFn;
}) {
  const tasks = trpc.tasks.list.useQuery(undefined, { refetchInterval: 6000 });
  const entitlement = useEntitlement();
  const trialExpired = !!entitlement?.trialExpired;
  const list = tasks.data ?? [];

  const expiredBanner = trialExpired ? (
    <div className="mb-4 flex items-start gap-3 rounded-lg border border-amber/40 bg-amber/10 px-4 py-3">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber" />
      <p className="text-[13px] leading-relaxed text-tsec">
        <span className="font-medium text-amber">
          Your 7-day free trial has ended
        </span>{" "}
        — upgrade to PRO to keep sniping. Head to the Upgrade tab to activate.
      </p>
    </div>
  ) : null;

  if (!tasks.isLoading && list.length === 0) {
    return (
      <div>
        {expiredBanner}
        <EmptyState
          icon={<Rocket className="h-5 w-5" />}
          title="No mint tasks yet"
          body='This is where "Degen Apes S2" would be counting down. Create a task, arm it, and let the engine snipe the drop in milliseconds.'
          action={
            <button
              onClick={onNewTask}
              disabled={trialExpired}
              title={trialExpired ? "Trial expired — upgrade to PRO" : undefined}
              className="rounded-lg bg-g-brand px-5 py-2.5 text-sm font-semibold text-white transition-all hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
            >
              Arm your first task
            </button>
          }
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {expiredBanner}
      <div className="flex items-center justify-between">
        <p className="font-mono text-xs text-tmut">
          {list.length} task{list.length === 1 ? "" : "s"} ·{" "}
          {list.filter((t) => t.status === "armed" || t.status === "firing").length} active
        </p>
        <button
          onClick={onNewTask}
          disabled={trialExpired}
          title={trialExpired ? "Trial expired — upgrade to PRO" : undefined}
          className="rounded-lg border border-hairline px-3.5 py-1.5 text-[12px] font-medium text-tsec transition-colors hover:border-violet/45 hover:text-tpri disabled:cursor-not-allowed disabled:opacity-40"
        >
          + New task
        </button>
      </div>
      {tasks.isLoading ? (
        <div className="flex flex-col gap-4">
          {[0, 1].map((i) => (
            <div key={i} className="h-40 animate-pulse rounded-xl border border-hairline bg-panel" />
          ))}
        </div>
      ) : (
        list.map((t, i) => (
          <TaskCard key={t.id} task={t} index={i} pushToast={pushToast} locked={trialExpired} />
        ))
      )}
    </div>
  );
}
