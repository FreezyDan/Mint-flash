import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Activity as ActivityIcon, AlertTriangle, CheckCircle2, Copy as CopyIcon, XCircle, Zap } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { ActivitySources } from "@contracts/bot";
import type { ActivitySource } from "@contracts/bot";
import { EmptyState, timeAgo, useNow } from "./shared";

const SOURCE_FILTERS: { key: ActivitySource | "all"; label: string }[] = [
  { key: "all", label: "All" },
  ...ActivitySources.map((s) => ({ key: s, label: s })),
];

function LevelIcon({ level, source }: { level: string; source: string }) {
  if (level === "success") return <CheckCircle2 className="h-3.5 w-3.5 text-neon" />;
  if (level === "warn") return <AlertTriangle className="h-3.5 w-3.5 text-amber" />;
  if (level === "error") return <XCircle className="h-3.5 w-3.5 text-alarm" />;
  if (source === "copy") return <CopyIcon className="h-3.5 w-3.5 text-cyan" />;
  return <Zap className="h-3.5 w-3.5 text-violet" />;
}

export default function Activity() {
  useNow(5000);
  const [source, setSource] = useState<ActivitySource | "all">("all");
  const query = trpc.activity.list.useQuery(
    source === "all" ? undefined : { source },
    { refetchInterval: 4000 },
  );
  const rows = useMemo(() => query.data ?? [], [query.data]);

  // Only flash-animate rows that arrive after the first loaded batch.
  const seenMax = useRef<number | null>(null);
  useEffect(() => {
    if (rows.length > 0 && seenMax.current === null) {
      seenMax.current = Math.max(...rows.map((r) => r.id));
    }
  }, [rows]);
  useEffect(() => {
    seenMax.current = null;
  }, [source]);

  return (
    <div className="card-base p-0">
      <div className="flex flex-wrap items-center gap-2 border-b border-hairline px-5 py-4">
        <h3 className="mr-auto font-display text-[15px] font-semibold text-tpri">Activity feed</h3>
        {SOURCE_FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setSource(f.key)}
            className={cn(
              "rounded-full border px-3 py-1 font-mono text-[11px] uppercase tracking-wider transition-colors",
              source === f.key
                ? "border-violet/60 bg-violet/10 text-tpri"
                : "border-hairline bg-panel2 text-tmut hover:text-tsec",
            )}
          >
            {f.label}
          </button>
        ))}
        <span className="font-mono text-[10px] text-tmut">polling 4s</span>
      </div>

      {query.isLoading ? (
        <div className="space-y-2.5 p-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-6 animate-pulse rounded bg-panel2" />
          ))}
        </div>
      ) : rows.length === 0 ? (
        <div className="p-5">
          <EmptyState
            icon={<ActivityIcon className="h-5 w-5" />}
            title="The tape is quiet"
            body={
              source === "all"
                ? "Fills, task fires, gas warnings and copy mirrors will stream in here the moment your bot does anything."
                : `No ${source} events yet — try the All filter.`
            }
          />
        </div>
      ) : (
        <ul className="max-h-[560px] divide-y divide-hairline/60 overflow-y-auto">
          <AnimatePresence initial={false}>
            {/* Baseline max-id is written only in effects after first paint;
                reading it during render is the mount-animation gate. */}
            {/* eslint-disable-next-line react-hooks/refs */}
            {rows.map((r) => {
              const isNew = seenMax.current !== null && r.id > seenMax.current;
              return (
                <motion.li
                  key={r.id}
                  initial={
                    isNew
                      ? { opacity: 0, x: 20, backgroundColor: "rgba(57,255,142,0.10)" }
                      : false
                  }
                  animate={{ opacity: 1, x: 0, backgroundColor: "rgba(57,255,142,0)" }}
                  transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  className="group flex items-center gap-3 px-5 py-2.5"
                >
                  <LevelIcon level={r.level} source={r.source} />
                  <span className="min-w-0 flex-1 truncate font-mono text-[12.5px] text-tsec">
                    {r.message}
                  </span>
                  <span className="shrink-0 rounded border border-hairline bg-panel2 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-tmut">
                    {r.source}
                  </span>
                  <span className="tnum w-16 shrink-0 text-right font-mono text-[10px] text-tmut">
                    {timeAgo(r.createdAt)}
                  </span>
                </motion.li>
              );
            })}
          </AnimatePresence>
        </ul>
      )}
    </div>
  );
}
