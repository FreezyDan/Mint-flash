import { useState } from "react";
import { motion } from "framer-motion";
import { Brush, RefreshCw, Trash2, Zap } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import type { SectionKey } from "./shell";
import { LockCard, useEntitlement } from "./plan";
import { parseNftLink } from "@contracts/nftLinks";
import type { SweepRule } from "@contracts/types";
import { nativeSymbol } from "@contracts/rpc";
import {
  CHAINS,
  ChainBadge,
  CopyAddr,
  EmptyState,
  FieldLabel,
  ServerError,
  inputCls,
  timeAgo,
  truncateAddr,
} from "./shared";

const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
const ETH_RE = /^\d+(\.\d+)?$/;

type ToastFn = (msg: string, tone?: "success" | "error" | "info") => void;
type SweepMode = "below" | "above";

const DISCLOSURE_TEXT =
  "Floor data + execution: OpenSea API v2 (Seaport orderbook — listings live off-chain until " +
  "filled). Polls every ~45s. Every triggered rule executes a real on-chain transaction from " +
  "your bot vault — real funds, real risk. Below = buy when floor ≤ threshold; Above = buy when " +
  "floor rises ≥ threshold (momentum entry).";

/* ------------------------------------------------------------------ */
/* Create-rule card                                                    */
/* ------------------------------------------------------------------ */

function CreateRuleCard({ pushToast }: { pushToast: ToastFn }) {
  const utils = trpc.useUtils();
  const [link, setLink] = useState("");
  const [contractAddress, setContractAddress] = useState("");
  const [collectionName, setCollectionName] = useState("");
  const [chainId, setChainId] = useState<number>(1);
  const [mode, setMode] = useState<SweepMode>("below");
  const [thresholdEth, setThresholdEth] = useState("");
  const [maxBuys, setMaxBuys] = useState("1");
  const [maxSpendEth, setMaxSpendEth] = useState("1");
  const [maxRarityRank, setMaxRarityRank] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const [linkNote, setLinkNote] = useState<string | null>(null);

  const create = trpc.sweep.create.useMutation({
    onSuccess: async () => {
      pushToast(`Sweep rule armed for ${truncateAddr(contractAddress)}`, "success");
      setLink("");
      setContractAddress("");
      setCollectionName("");
      setThresholdEth("");
      setMaxRarityRank("");
      setFormError(null);
      await utils.sweep.list.invalidate();
    },
    onError: (e) => setFormError(e.message),
  });

  const parseLink = (value: string) => {
    setLink(value);
    setLinkNote(null);
    if (value.trim() === "") return;
    const parsed = parseNftLink(value);
    if (!parsed.ok) {
      setLinkNote(parsed.reason);
      return;
    }
    setContractAddress(parsed.contractAddress);
    if (parsed.chainId !== null) setChainId(parsed.chainId);
    setLinkNote(`parsed via ${parsed.source}`);
  };

  const submit = () => {
    setFormError(null);
    if (!ADDR_RE.test(contractAddress)) {
      setFormError("Must be a valid 0x contract address");
      return;
    }
    if (!ETH_RE.test(thresholdEth) || Number(thresholdEth) <= 0) {
      setFormError("Threshold must be a positive decimal ETH amount like 0.5");
      return;
    }
    if (!ETH_RE.test(maxSpendEth) || Number(maxSpendEth) <= 0) {
      setFormError("Max spend must be a positive decimal ETH amount like 1");
      return;
    }
    const buys = Number(maxBuys);
    if (!Number.isInteger(buys) || buys < 1 || buys > 50) {
      setFormError("Max buys must be an integer between 1 and 50");
      return;
    }
    const rarityTrimmed = maxRarityRank.trim();
    let rarity: number | null = null;
    if (rarityTrimmed !== "") {
      const n = Number(rarityTrimmed);
      if (!Number.isInteger(n) || n < 1 || n > 100000) {
        setFormError("Max rarity rank must be a whole number between 1 and 100000 (empty = off)");
        return;
      }
      rarity = n;
    }
    create.mutate({
      chainId,
      contractAddress,
      ...(collectionName.trim() ? { collectionName: collectionName.trim() } : {}),
      mode,
      thresholdEth,
      maxBuys: buys,
      maxSpendEth,
      maxRarityRank: rarity,
    });
  };

  return (
    <div className="card-base p-0">
      <div className="border-b border-hairline px-5 py-4">
        <h3 className="font-display text-[15px] font-semibold text-tpri">New sweep rule</h3>
        <p className="mt-0.5 font-mono text-[11px] text-tmut">
          watches a collection floor and buys the cheapest listing when your trigger hits
        </p>
      </div>

      <div className="flex flex-col gap-4 px-5 py-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div>
            <FieldLabel>Paste collection link</FieldLabel>
            <input
              className={inputCls}
              placeholder="opensea.io/assets/… or blur.io/collection/…"
              value={link}
              onChange={(e) => parseLink(e.target.value)}
            />
            {linkNote && (
              <p className="mt-1.5 font-mono text-[11px] text-tmut">▸ {linkNote}</p>
            )}
          </div>
          <div>
            <FieldLabel>Contract address</FieldLabel>
            <input
              className={inputCls}
              placeholder="0x…"
              value={contractAddress}
              onChange={(e) => setContractAddress(e.target.value.trim())}
            />
          </div>
        </div>

        <div>
          <FieldLabel>Chain</FieldLabel>
          <div className="flex flex-wrap gap-2">
            {CHAINS.map((c) => (
              <button
                key={c.key}
                type="button"
                onClick={() => setChainId(c.id)}
                className={cn(
                  "flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[11px] transition-colors",
                  chainId === c.id
                    ? "border-violet/60 bg-violet/10 text-tpri"
                    : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                )}
              >
                <img src={c.icon} alt="" className="h-3 w-3" />
                {c.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <FieldLabel>Trigger mode</FieldLabel>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setMode("below")}
              className={cn(
                "rounded-lg border p-3.5 text-left transition-colors",
                mode === "below"
                  ? "border-neon/50 bg-neon/5"
                  : "border-hairline bg-panel2 hover:border-neon/30",
              )}
            >
              <p className="font-mono text-xs font-medium uppercase tracking-wider text-neon">
                Below
              </p>
              <p className="mt-1 text-[12px] leading-snug text-tmut">
                Buy the moment the floor drops to your threshold or lower — sweep cheap listings.
              </p>
            </button>
            <button
              type="button"
              onClick={() => setMode("above")}
              className={cn(
                "rounded-lg border p-3.5 text-left transition-colors",
                mode === "above"
                  ? "border-amber/50 bg-amber/5"
                  : "border-hairline bg-panel2 hover:border-amber/30",
              )}
            >
              <p className="font-mono text-xs font-medium uppercase tracking-wider text-amber">
                Above
              </p>
              <p className="mt-1 text-[12px] leading-snug text-tmut">
                Buy once the floor climbs to your threshold or higher — ride the momentum.
              </p>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
          <div>
            <FieldLabel>Name (optional)</FieldLabel>
            <input
              className={inputCls}
              placeholder="pixel penguins"
              value={collectionName}
              onChange={(e) => setCollectionName(e.target.value)}
            />
          </div>
          <div>
            <FieldLabel>Threshold (ETH)</FieldLabel>
            <input
              className={inputCls}
              inputMode="decimal"
              placeholder="0.5"
              value={thresholdEth}
              onChange={(e) => setThresholdEth(e.target.value.trim())}
            />
          </div>
          <div>
            <FieldLabel>Max buys</FieldLabel>
            <input
              className={inputCls}
              inputMode="numeric"
              placeholder="1"
              value={maxBuys}
              onChange={(e) => setMaxBuys(e.target.value.trim())}
            />
          </div>
          <div>
            <FieldLabel>Max spend (ETH)</FieldLabel>
            <input
              className={inputCls}
              inputMode="decimal"
              placeholder="1"
              value={maxSpendEth}
              onChange={(e) => setMaxSpendEth(e.target.value.trim())}
            />
          </div>
          <div>
            <FieldLabel>Max rarity rank (optional)</FieldLabel>
            <input
              className={inputCls}
              inputMode="numeric"
              placeholder="e.g. 500"
              value={maxRarityRank}
              onChange={(e) => setMaxRarityRank(e.target.value.trim())}
            />
            <p className="mt-1.5 font-mono text-[11px] text-tmut">
              ▸ only buy floor listings ranked ≤ N (OpenRarity); leave empty to buy any
            </p>
          </div>
        </div>

        <ServerError message={formError} />

        <div>
          <button
            disabled={create.isPending}
            onClick={submit}
            className="flex items-center gap-2 rounded-lg bg-g-brand px-5 py-2.5 text-sm font-semibold text-white transition-all hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
          >
            <Zap className="h-4 w-4" />
            {create.isPending ? "Arming…" : "Arm sweep rule"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Rules table                                                         */
/* ------------------------------------------------------------------ */

function RuleRow({
  rule,
  index,
  pushToast,
}: {
  rule: SweepRule;
  index: number;
  pushToast: ToastFn;
}) {
  const utils = trpc.useUtils();
  const [checking, setChecking] = useState(false);

  const invalidate = () => utils.sweep.list.invalidate();

  const toggle = trpc.sweep.toggle.useMutation({
    onSuccess: async () => {
      pushToast(rule.enabled ? "Sweep rule paused" : "Sweep rule resumed", "info");
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });
  const remove = trpc.sweep.remove.useMutation({
    onSuccess: async () => {
      pushToast("Sweep rule removed", "info");
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
  });
  const floorNow = trpc.sweep.floorNow.useMutation({
    onSuccess: async (res) => {
      pushToast(
        res.floor ? `Floor now: ${res.floor.priceEth} ${nativeSymbol(rule.chainId)}` : "No asks on this collection right now",
        res.floor ? "success" : "info",
      );
      await invalidate();
    },
    onError: (e) => pushToast(e.message, "error"),
    onSettled: () => setChecking(false),
  });

  const floor = rule.lastFloorEth !== null ? Number(rule.lastFloorEth) : null;
  const triggered =
    floor !== null &&
    (rule.mode === "below" ? floor <= Number(rule.thresholdEth) : floor >= Number(rule.thresholdEth));
  const spent = Number(rule.spentEth);

  return (
    <motion.tr
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.3 }}
      className={cn("border-b border-hairline/60 transition-opacity", !rule.enabled && "opacity-50")}
    >
      <td className="py-3 pl-5 pr-3">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-tpri">
            {rule.collectionName ?? "Unnamed collection"}
          </p>
          <p className="flex items-center gap-1.5 font-mono text-[11px] text-tmut">
            {truncateAddr(rule.contractAddress)}
            <CopyAddr value={rule.contractAddress} />
          </p>
        </div>
      </td>
      <td className="px-3 py-3">
        <ChainBadge chainId={rule.chainId} />
      </td>
      <td className="px-3 py-3">
        <span
          className={cn(
            "rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider",
            rule.mode === "below"
              ? "border-neon/40 bg-neon/10 text-neon"
              : "border-amber/40 bg-amber/10 text-amber",
          )}
        >
          {rule.mode}
        </span>
      </td>
      <td className="px-3 py-3 font-mono text-[12px] text-tsec">
        {rule.mode === "below" ? "≤" : "≥"} {rule.thresholdEth} ETH
        {rule.maxRarityRank !== null && (
          <span
            title={`Rarity gate: only buy listings ranked ≤ #${rule.maxRarityRank} (OpenRarity)`}
            className="ml-1.5 rounded-full border border-violet/40 bg-violet/10 px-2 py-0.5 font-mono text-[10px] tracking-wider text-violet"
          >
            ≤ #{rule.maxRarityRank}
          </span>
        )}
      </td>
      <td className="px-3 py-3">
        <p
          className={cn(
            "tnum font-mono text-[12px]",
            floor === null ? "text-tmut" : triggered ? "text-neon" : "text-tsec",
          )}
        >
          {floor === null ? "—" : `${rule.lastFloorEth} ${nativeSymbol(rule.chainId)}`}
        </p>
        <p className="font-mono text-[10px] text-tmut">
          {rule.lastCheckedAt ? timeAgo(rule.lastCheckedAt) : "never checked"}
        </p>
      </td>
      <td className="px-3 py-3 font-mono text-[11px] text-tsec">
        <span className="tnum">
          {rule.boughtCount}/{rule.maxBuys} buys
        </span>
        <span className="text-tmut"> · </span>
        <span className="tnum">
          {spent.toFixed(4)}/{rule.maxSpendEth} ETH
        </span>
      </td>
      <td className="py-3 pl-3 pr-5">
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => {
              setChecking(true);
              floorNow.mutate({ id: rule.id });
            }}
            disabled={checking}
            title="Check floor now"
            className="rounded p-1.5 text-tmut transition-colors hover:bg-violet/10 hover:text-violet disabled:opacity-40"
          >
            <RefreshCw className={cn("h-3.5 w-3.5", checking && "animate-spin")} />
          </button>
          <Switch
            className="data-[state=checked]:bg-neon"
            checked={rule.enabled}
            onCheckedChange={() => toggle.mutate({ id: rule.id })}
            title={rule.enabled ? "Pause rule" : "Resume rule"}
          />
          <button
            onClick={() => remove.mutate({ id: rule.id })}
            title="Remove"
            className="rounded p-1.5 text-tmut transition-colors hover:bg-alarm/10 hover:text-alarm"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </td>
    </motion.tr>
  );
}

/* ------------------------------------------------------------------ */
/* Section                                                             */
/* ------------------------------------------------------------------ */

function SweeperInner({
  pushToast,
}: {
  pushToast: ToastFn;
  onNavigate?: (s: SectionKey) => void;
}) {
  const list = trpc.sweep.list.useQuery(undefined, { refetchInterval: 15_000 });
  const rules = list.data ?? [];

  return (
    <div className="flex flex-col gap-6">
      <CreateRuleCard pushToast={pushToast} />

      <div className="card-base p-0">
        <div className="flex items-center justify-between border-b border-hairline px-5 py-4">
          <div>
            <h3 className="font-display text-[15px] font-semibold text-tpri">Sweep rules</h3>
            <p className="mt-0.5 font-mono text-[11px] text-tmut">
              polling the aggregated floor every ~45s per rule
            </p>
          </div>
          <span className="font-mono text-[10px] text-tmut">refresh 15s</span>
        </div>

        {list.isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
            ))}
          </div>
        ) : rules.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Brush className="h-5 w-5" />}
              title="No sweep rules yet"
              body="Paste a collection link above, set a floor trigger and caps — the bot watches the aggregated orderbook floor and buys when your condition hits."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead>
                <tr className="border-b border-hairline text-left font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">
                  <th className="py-2.5 pl-5 pr-3 font-medium">Collection</th>
                  <th className="px-3 py-2.5 font-medium">Chain</th>
                  <th className="px-3 py-2.5 font-medium">Mode</th>
                  <th className="px-3 py-2.5 font-medium">Threshold</th>
                  <th className="px-3 py-2.5 font-medium">Last floor</th>
                  <th className="px-3 py-2.5 font-medium">Progress</th>
                  <th className="py-2.5 pl-3 pr-5 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rules.map((r, i) => (
                  <RuleRow key={r.id} rule={r} index={i} pushToast={pushToast} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="rounded-lg border border-hairline bg-panel2/60 px-4 py-3 font-mono text-[11px] leading-relaxed text-tmut">
        {DISCLOSURE_TEXT}
      </div>
    </div>
  );
}

/** Paywall gate: the floor sweeper is a PRO feature. */
export default function Sweeper(props: {
  pushToast: ToastFn;
  onNavigate?: (s: SectionKey) => void;
}) {
  const entitlement = useEntitlement();
  if (entitlement && entitlement.plan === "free") {
    return (
      <LockCard
        title="Floor Sweeper"
        lines={[
          "Watch any collection's orderbook floor and buy the cheapest listing",
          "the moment your threshold hits — executed live on-chain from your vault.",
        ]}
        onUpgrade={() => props.onNavigate?.("upgrade")}
      />
    );
  }
  return <SweeperInner {...props} />;
}
