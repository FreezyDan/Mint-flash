import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronLeft, ChevronRight, Link2, ScanSearch, ShieldCheck } from "lucide-react";
import { AlertTriangle, ShieldAlert } from "lucide-react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { parseNftLink } from "@contracts/nftLinks";
import { FREE_LIMITS } from "@contracts/plans";
import { useEntitlement } from "./plan";
import { CHAINS, FieldLabel, ServerError, inputCls, truncateAddr } from "./shared";
import type { MintPhase, TriggerMode } from "@contracts/bot";
import { nativeSymbol } from "@contracts/rpc";

type InspectResult = {
  isContract: boolean;
  saleActive?: boolean;
  mintPriceEth?: string;
  maxPerWallet?: number;
  suggestedMintFunction: string | null;
  suggestedGasLimit?: number;
  notes: string[];
};

const ADDR_RE = /^0x[0-9a-fA-F]{40}$/;
const ETH_RE = /^\d+(\.\d+)?$/;
const BYTES32_RE = /^0x[0-9a-fA-F]{64}$/;

/**
 * Parse the merkle-proofs textarea into a map keyed by lowercase address.
 * Accepts line form `0xWallet: 0xproof1,0xproof2,…` (one per line) or a
 * pasted JSON map `{ "0x…": ["0x…","0x…"] }`. Every proof element must be
 * bytes32 (0x + 64 hex). Empty input → empty map, no error.
 */
function parseProofsText(
  text: string,
): { map: Record<string, string[]>; error: null } | { map: null; error: string } {
  const trimmed = text.trim();
  if (!trimmed) return { map: {}, error: null };
  const fail = (error: string) => ({ map: null, error });

  const checkEntry = (addr: string, proofs: unknown, where: string) => {
    if (!ADDR_RE.test(addr)) return `${where}: invalid wallet address "${addr.slice(0, 24)}"`;
    if (!Array.isArray(proofs) || proofs.length === 0) return `${where}: proof must be an array`;
    for (const p of proofs) {
      if (typeof p !== "string" || !BYTES32_RE.test(p)) {
        return `${where}: each proof element must be bytes32 (0x + 64 hex)`;
      }
    }
    return null;
  };

  if (trimmed.startsWith("{")) {
    let obj: unknown;
    try {
      obj = JSON.parse(trimmed);
    } catch {
      return fail('Invalid JSON — paste a map like {"0x…": ["0x…","0x…"]}');
    }
    if (typeof obj !== "object" || obj === null || Array.isArray(obj)) {
      return fail("JSON must be an object mapping wallet → proof array");
    }
    const map: Record<string, string[]> = {};
    for (const [addr, proofs] of Object.entries(obj)) {
      const err = checkEntry(addr, proofs, `entry ${addr.slice(0, 10)}…`);
      if (err) return fail(err);
      map[addr.toLowerCase()] = proofs as string[];
    }
    return { map, error: null };
  }

  const map: Record<string, string[]> = {};
  const lines = trimmed.split(/\n+/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const colon = line.indexOf(":");
    if (colon <= 0) return fail(`line ${i + 1}: expected "0xWallet: 0xproof1,0xproof2,…"`);
    const addr = line.slice(0, colon).trim();
    const proofs = line
      .slice(colon + 1)
      .split(/[\s,]+/)
      .filter(Boolean);
    const err = checkEntry(addr, proofs, `line ${i + 1}`);
    if (err) return fail(err);
    map[addr.toLowerCase()] = proofs as string[];
  }
  return { map, error: null };
}

/**
 * Live contract-safety panel (anti-rug guard). Queries tasks.guardPreview for
 * the entered address/chain and renders each check with an ok/warn/danger
 * icon; a danger report gets a red border and a "creation will be blocked"
 * note (the server enforces the block on tasks.create).
 */
function ContractSafetyPanel({
  chainId,
  contractAddress,
}: {
  chainId: number;
  contractAddress: string;
}) {
  const guardQuery = trpc.tasks.guardPreview.useQuery(
    { chainId, contractAddress },
    { staleTime: 60_000, retry: false },
  );
  const report = guardQuery.data;
  const danger = report?.level === "danger";

  return (
    <div
      className={cn(
        "rounded-lg border px-3 py-2.5",
        danger ? "border-alarm/60 bg-alarm/5" : "border-hairline bg-panel2/60",
      )}
    >
      <p className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-tmut">
        <ShieldCheck className="h-3 w-3 text-violet" />
        Contract safety
        {guardQuery.isFetching && <span className="normal-case tracking-normal">· checking…</span>}
      </p>
      {report ? (
        <ul className="mt-1.5 space-y-1">
          {report.checks.map((c) => (
            <li key={c.name} className="flex items-start gap-1.5 font-mono text-[10px] leading-snug">
              {c.level === "ok" ? (
                <ShieldCheck className="mt-px h-3 w-3 shrink-0 text-neon" />
              ) : c.level === "warn" ? (
                <AlertTriangle className="mt-px h-3 w-3 shrink-0 text-amber" />
              ) : (
                <ShieldAlert className="mt-px h-3 w-3 shrink-0 text-alarm" />
              )}
              <span
                className={
                  c.level === "danger"
                    ? "text-alarm"
                    : c.level === "warn"
                      ? "text-amber"
                      : "text-tsec"
                }
              >
                {c.detail}
              </span>
            </li>
          ))}
        </ul>
      ) : guardQuery.isError ? (
        <p className="mt-1.5 font-mono text-[10px] text-tmut">
          safety check unavailable — the guard re-runs on create
        </p>
      ) : (
        <div className="mt-2 space-y-1.5">
          {[0, 1].map((i) => (
            <div key={i} className="h-3.5 animate-pulse rounded bg-panel2" />
          ))}
        </div>
      )}
      {danger && (
        <p className="mt-2 border-t border-alarm/30 pt-1.5 font-mono text-[10px] font-semibold uppercase tracking-widest text-alarm">
          danger level — task creation will be blocked
        </p>
      )}
    </div>
  );
}

const GAS_PRESETS = [
  {
    key: "chill",
    label: "Chill",
    desc: "Patient. Cheapest, may lose gas wars.",
    startMaxFeeGwei: 40,
    startPriorityGwei: 2,
    gasBumpGwei: 5,
    maxMaxFeeGwei: 200,
  },
  {
    key: "degen",
    label: "Degen",
    desc: "Balanced. Competitive on hyped drops.",
    startMaxFeeGwei: 60,
    startPriorityGwei: 3,
    gasBumpGwei: 10,
    maxMaxFeeGwei: 500,
  },
  {
    key: "god",
    label: "God",
    desc: "Max aggression. Wins wars, pays for it.",
    startMaxFeeGwei: 150,
    startPriorityGwei: 8,
    gasBumpGwei: 25,
    maxMaxFeeGwei: 1000,
  },
] as const;

interface WizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pushToast: (msg: string, tone?: "success" | "error" | "info") => void;
  /** Called after a task is created/armed so the app can jump to the task list. */
  onCreated?: () => void;
}

/** 3-step New Task wizard — contract/config → trigger → gas + review. */
export default function TaskWizard({ open, onOpenChange, pushToast, onCreated }: WizardProps) {
  const utils = trpc.useUtils();
  const entitlement = useEntitlement();
  const walletsQuery = trpc.wallets.list.useQuery(undefined, { staleTime: 30_000 });
  const tasksQuery = trpc.tasks.list.useQuery(undefined, { staleTime: 15_000 });
  const [step, setStep] = useState(0);
  const [createdId, setCreatedId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Multi-snipe wallet selection (ids of bot_wallets rows).
  const [selectedWallets, setSelectedWallets] = useState<number[]>([]);

  const isFree = !!entitlement && entitlement.plan === "free" && !entitlement.admin;
  const trialExpired = !!entitlement?.trialExpired;
  const walletCap = isFree ? FREE_LIMITS.maxSnipeWallets : Infinity;
  const botWallets = walletsQuery.data ?? [];
  const pendingUsed = (tasksQuery.data ?? []).filter(
    (t) => t.status === "draft" || t.status === "armed",
  ).length;

  const toggleWallet = (id: number) => {
    setSelectedWallets((prev) => {
      if (prev.includes(id)) return prev.filter((w) => w !== id);
      if (prev.length >= walletCap) return prev; // free cap — button is disabled too
      return [...prev, id];
    });
  };

  // Step 1 — target + mint config
  const [name, setName] = useState("");
  const [contractAddress, setContractAddress] = useState("");
  const [chainId, setChainId] = useState<number>(1);
  const [mintFunction, setMintFunction] = useState("mint");
  const [quantity, setQuantity] = useState("1");
  const [mintValueEth, setMintValueEth] = useState("0");
  const [gasLimit, setGasLimit] = useState("200000");

  // Step 1 — whitelist/allowlist minting
  const [mintPhase, setMintPhase] = useState<MintPhase>("auto");
  const [proofsText, setProofsText] = useState("");
  const parsedProofs = useMemo(() => parseProofsText(proofsText), [proofsText]);
  const proofCount = parsedProofs.map ? Object.keys(parsedProofs.map).length : 0;

  // Step 1 — link import + contract auto-inspect
  const [dropLink, setDropLink] = useState("");
  const [linkSource, setLinkSource] = useState<string | null>(null);
  const [linkError, setLinkError] = useState<string | null>(null);
  const [inspectResult, setInspectResult] = useState<InspectResult | null>(null);
  const [inspectError, setInspectError] = useState<string | null>(null);
  const [inspecting, setInspecting] = useState(false);

  // Step 2 — trigger
  const [triggerMode, setTriggerMode] = useState<TriggerMode>("time");
  const [openTime, setOpenTime] = useState("");
  const [flagMethod, setFlagMethod] = useState("saleActive");
  const [pollIntervalMs, setPollIntervalMs] = useState("1000");
  const [eventName, setEventName] = useState("");

  // Step 3 — gas + safety
  const [preset, setPreset] = useState<(typeof GAS_PRESETS)[number]["key"]>("degen");
  const [startMaxFeeGwei, setStartMaxFeeGwei] = useState("60");
  const [startPriorityGwei, setStartPriorityGwei] = useState("3");
  const [gasBumpGwei, setGasBumpGwei] = useState("10");
  const [maxMaxFeeGwei, setMaxMaxFeeGwei] = useState("500");
  const [maxRetries, setMaxRetries] = useState("8");
  const [simulateFirst, setSimulateFirst] = useState(true);

  const applyPreset = (key: (typeof GAS_PRESETS)[number]["key"]) => {
    const p = GAS_PRESETS.find((g) => g.key === key)!;
    setPreset(key);
    setStartMaxFeeGwei(String(p.startMaxFeeGwei));
    setStartPriorityGwei(String(p.startPriorityGwei));
    setGasBumpGwei(String(p.gasBumpGwei));
    setMaxMaxFeeGwei(String(p.maxMaxFeeGwei));
  };

  const reset = () => {
    setStep(0);
    setCreatedId(null);
    setError(null);
    setSelectedWallets([]);
    setName("");
    setContractAddress("");
    setChainId(1);
    setMintFunction("mint");
    setQuantity("1");
    setMintValueEth("0");
    setGasLimit("200000");
    setMintPhase("auto");
    setProofsText("");
    setSimulateFirst(true);
    setDropLink("");
    setLinkSource(null);
    setLinkError(null);
    setInspectResult(null);
    setInspectError(null);
    setInspecting(false);
    setTriggerMode("time");
    setOpenTime("");
    setFlagMethod("saleActive");
    setPollIntervalMs("1000");
    setEventName("");
    applyPreset("degen");
    setMaxRetries("8");
  };

  const stepError = useMemo(() => {
    if (step === 0) {
      if (!name.trim()) return "Give the task a name.";
      if (!ADDR_RE.test(contractAddress)) return "Contract must be a valid 0x address (42 chars).";
      if (!mintFunction.trim()) return "Mint function is required.";
      const q = Number(quantity);
      if (!Number.isInteger(q) || q < 1 || q > 100) return "Quantity must be an integer 1–100.";
      if (!ETH_RE.test(mintValueEth)) return "Price must be a decimal amount like 0.08.";
    }
    if (step === 1) {
      if (triggerMode === "time") {
        if (!openTime) return "Pick a go-live time.";
        if (new Date(openTime).getTime() <= Date.now()) return "Go-live must be in the future.";
      }
      if (triggerMode === "poll") {
        if (!flagMethod.trim()) return "Flag method is required for poll triggers.";
        const p = Number(pollIntervalMs);
        if (!Number.isInteger(p) || p < 50 || p > 3_600_000)
          return "Poll interval must be 50–3,600,000 ms.";
      }
      if (triggerMode === "event" && !eventName.trim())
        return "Event name is required for event triggers.";
    }
    return null;
  }, [step, name, contractAddress, mintFunction, quantity, mintValueEth, triggerMode, openTime, flagMethod, pollIntervalMs, eventName]);

  /** Client-side drop-link parse — instant, no server call. */
  const parseDropLink = () => {
    setInspectResult(null);
    setInspectError(null);
    const parsed = parseNftLink(dropLink);
    if (!parsed.ok) {
      setLinkError(parsed.reason);
      setLinkSource(null);
      return;
    }
    setLinkError(null);
    setLinkSource(parsed.source);
    setContractAddress(parsed.contractAddress);
    if (parsed.chainId !== null) setChainId(parsed.chainId);
  };

  /** Server-side contract inspect — prefill mint config from on-chain probes. */
  const autoDetect = async () => {
    setInspecting(true);
    setInspectError(null);
    setInspectResult(null);
    try {
      const r = await utils.tasks.inspect.fetch({ chainId, contractAddress });
      setInspectResult(r);
      if (r.suggestedMintFunction) setMintFunction(r.suggestedMintFunction);
      if (r.mintPriceEth !== undefined) setMintValueEth(r.mintPriceEth);
      if (r.suggestedGasLimit !== undefined) setGasLimit(String(r.suggestedGasLimit));
    } catch (e) {
      setInspectError((e as Error).message);
    } finally {
      setInspecting(false);
    }
  };

  const createTask = trpc.tasks.create.useMutation({
    onSuccess: async (task) => {
      if (!task) return;
      setCreatedId(task.id);
      setError(null);
      await utils.tasks.list.invalidate();
      await utils.stats.overview.invalidate();
    },
    onError: (e) => setError(e.message),
  });

  const armTask = trpc.tasks.arm.useMutation({
    onSuccess: async () => {
      pushToast("Task armed — it will fire on trigger", "success");
      await utils.tasks.list.invalidate();
      await utils.stats.overview.invalidate();
      onOpenChange(false);
      onCreated?.();
      reset();
    },
    onError: (e) => setError(e.message),
  });

  const submit = () => {
    setError(null);
    const qty = Math.max(1, Math.floor(Number(quantity) || 1));
    createTask.mutate({
      name: name.trim(),
      contractAddress,
      chainId,
      mintFunction: mintFunction.trim(),
      mintArgs: [qty],
      mintValueEth,
      gasLimit: Number(gasLimit) || 200000,
      triggerMode,
      openTime: triggerMode === "time" && openTime ? new Date(openTime) : null,
      flagMethod: flagMethod.trim() || "saleActive",
      pollIntervalMs: Number(pollIntervalMs) || 1000,
      eventName: triggerMode === "event" ? eventName.trim() : null,
      startMaxFeeGwei: Number(startMaxFeeGwei) || 60,
      startPriorityGwei: Number(startPriorityGwei) || 3,
      gasBumpGwei: Number(gasBumpGwei) || 10,
      maxMaxFeeGwei: Number(maxMaxFeeGwei) || 500,
      maxRetries: Number(maxRetries) || 8,
      walletCount: Math.max(1, selectedWallets.length),
      mintPhase,
      merkleProofs: parsedProofs.map && proofCount > 0 ? parsedProofs.map : null,
      simulateFirst,
    });
  };

  const estCost = (Number(mintValueEth) || 0) * (Number(quantity) || 0);
  const estGas = ((Number(startMaxFeeGwei) || 0) * 200000) / 1e9;

  return (
    <DialogPrimitive.Root
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) setTimeout(reset, 200);
      }}
    >
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-[70] bg-void/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=open]:fade-in-0" />
        <DialogPrimitive.Content className="fixed left-1/2 top-1/2 z-[70] w-full max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-xl border border-hairline bg-panel p-6 shadow-glow-violet outline-none data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95">
          <DialogPrimitive.Title className="sr-only">New mint task</DialogPrimitive.Title>

          {createdId === null ? (
            <>
              {/* Stepper header */}
              <div className="flex items-center justify-between">
                <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-violet">
                  Step {step + 1}/3 — {["Target", "Trigger", "Gas & Review"][step]}
                </p>
                <DialogPrimitive.Close className="font-mono text-xs text-tmut hover:text-tpri">
                  esc
                </DialogPrimitive.Close>
              </div>
              <div className="mt-3 h-1 overflow-hidden rounded-full bg-hairline">
                <motion.div
                  className="h-full rounded-full bg-violet"
                  animate={{ width: `${((step + 1) / 3) * 100}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>

              <div className="mt-5 min-h-[300px]">
                <AnimatePresence mode="wait" initial={false}>
                  {step === 0 && (
                    <motion.div
                      key="s0"
                      initial={{ opacity: 0, x: 40 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -40 }}
                      transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
                      className="flex flex-col gap-4"
                    >
                      <div>
                        <FieldLabel>Paste drop link</FieldLabel>
                        <div className="flex gap-2">
                          <input
                            className={inputCls}
                            placeholder="opensea.io/assets/… · blur.io · magiceden.io · 0x…"
                            value={dropLink}
                            onChange={(e) => setDropLink(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                e.preventDefault();
                                parseDropLink();
                              }
                            }}
                          />
                          <button
                            type="button"
                            onClick={parseDropLink}
                            className="flex shrink-0 items-center gap-1.5 rounded-lg border border-violet/50 bg-violet/10 px-3.5 font-mono text-xs text-violet transition-colors hover:bg-violet/20"
                          >
                            <Link2 className="h-3.5 w-3.5" /> Parse
                          </button>
                        </div>
                        {linkSource && (
                          <p className="mt-1.5 font-mono text-[11px] text-neon">
                            ✓ parsed from {linkSource}
                          </p>
                        )}
                        {linkError && (
                          <p className="mt-1.5 font-mono text-[11px] text-alarm">✕ {linkError}</p>
                        )}
                      </div>
                      <div>
                        <FieldLabel>Task name</FieldLabel>
                        <input
                          className={inputCls}
                          placeholder="Degen Apes S2"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                        />
                      </div>
                      <div>
                        <FieldLabel>Contract address</FieldLabel>
                        <div className="relative">
                          <input
                            className={cn(inputCls, "pr-9")}
                            placeholder="0x…"
                            value={contractAddress}
                            onChange={(e) => setContractAddress(e.target.value.trim())}
                          />
                          {ADDR_RE.test(contractAddress) && (
                            <motion.span
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 500, damping: 18 }}
                              className="absolute right-3 top-1/2 -translate-y-1/2"
                            >
                              <Check className="h-4 w-4 text-neon" />
                            </motion.span>
                          )}
                        </div>
                        {ADDR_RE.test(contractAddress) && (
                          <p className="mt-1.5 font-mono text-[11px] text-neon">
                            ✓ valid EVM address · {chainByIdLabel(chainId)}
                          </p>
                        )}
                      </div>
                      {ADDR_RE.test(contractAddress) && (
                        <ContractSafetyPanel chainId={chainId} contractAddress={contractAddress} />
                      )}
                      <div>
                        <FieldLabel>Chain</FieldLabel>
                        <div className="flex flex-wrap gap-2">
                          {CHAINS.map((c) => (
                            <button
                              key={c.id}
                              type="button"
                              onClick={() => setChainId(c.id)}
                              className={cn(
                                "flex items-center gap-1.5 rounded-full border px-3 py-1.5 font-mono text-xs transition-colors",
                                chainId === c.id
                                  ? "border-violet/60 bg-violet/10 text-tpri"
                                  : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                              )}
                            >
                              <img src={c.icon} alt="" className="h-3.5 w-3.5" />
                              {c.label}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <FieldLabel>Snipe wallets (multi-snipe)</FieldLabel>
                        {isFree && (
                          <p className="tnum mb-1.5 font-mono text-[11px] text-amber">
                            free plan: {pendingUsed}/{FREE_LIMITS.maxPendingSnipes} pending
                            orders · max {FREE_LIMITS.maxSnipeWallets} wallets per snipe
                          </p>
                        )}
                        {botWallets.length === 0 ? (
                          <p className="font-mono text-[11px] text-tmut">
                            ▸ no bot wallets yet — the task fires with your vault wallet
                          </p>
                        ) : (
                          <div className="flex flex-wrap gap-2">
                            {botWallets.map((w) => {
                              const selected = selectedWallets.includes(w.id);
                              const capped =
                                isFree && !selected && selectedWallets.length >= walletCap;
                              return (
                                <button
                                  key={w.id}
                                  type="button"
                                  disabled={capped}
                                  title={
                                    capped
                                      ? "PRO unlocks unlimited wallets"
                                      : `${w.label} · ${w.address}`
                                  }
                                  onClick={() => toggleWallet(w.id)}
                                  className={cn(
                                    "flex items-center gap-1.5 rounded-full border px-3 py-1.5 font-mono text-xs transition-colors",
                                    selected
                                      ? "border-neon/60 bg-neon/10 text-tpri"
                                      : "border-hairline bg-panel2 text-tmut hover:text-tsec",
                                    capped && "cursor-not-allowed opacity-40 hover:text-tmut",
                                  )}
                                >
                                  {selected && <Check className="h-3 w-3 text-neon" />}
                                  {w.label}
                                </button>
                              );
                            })}
                          </div>
                        )}
                        <p className="mt-1.5 font-mono text-[10px] text-tmut">
                          ▸{" "}
                          {selectedWallets.length === 0
                            ? "1 wallet (default)"
                            : `${selectedWallets.length} wallet${selectedWallets.length === 1 ? "" : "s"}`}{" "}
                          will fire on this task
                          {isFree &&
                            selectedWallets.length >= FREE_LIMITS.maxSnipeWallets &&
                            " · PRO unlocks unlimited wallets"}
                        </p>
                      </div>
                      <div>
                        <button
                          type="button"
                          disabled={!ADDR_RE.test(contractAddress) || inspecting}
                          onClick={autoDetect}
                          className="flex items-center gap-2 rounded-lg border border-cyan/40 bg-cyan/10 px-4 py-2 font-mono text-xs text-cyan transition-colors hover:bg-cyan/20 disabled:opacity-40"
                        >
                          <ScanSearch className="h-3.5 w-3.5" />
                          {inspecting ? "Inspecting contract…" : "Auto-detect from contract"}
                        </button>
                        {inspectError && (
                          <p className="mt-2 font-mono text-[11px] text-alarm">✕ {inspectError}</p>
                        )}
                        {inspectResult && (
                          <div className="mt-2 flex flex-col gap-1.5">
                            <div className="flex flex-wrap gap-1.5">
                              {inspectResult.saleActive !== undefined && (
                                <span
                                  className={cn(
                                    "rounded-full border px-2 py-0.5 font-mono text-[10px]",
                                    inspectResult.saleActive
                                      ? "border-neon/40 bg-neon/10 text-neon"
                                      : "border-amber/40 bg-amber/10 text-amber",
                                  )}
                                >
                                  {inspectResult.saleActive ? "sale OPEN" : "sale closed"}
                                </span>
                              )}
                              {inspectResult.mintPriceEth !== undefined && (
                                <span className="rounded-full border border-neon/40 bg-neon/10 px-2 py-0.5 font-mono text-[10px] text-neon">
                                  {inspectResult.mintPriceEth} {nativeSymbol(chainId)}
                                </span>
                              )}
                              {inspectResult.maxPerWallet !== undefined && (
                                <span className="rounded-full border border-amber/40 bg-amber/10 px-2 py-0.5 font-mono text-[10px] text-amber">
                                  max {inspectResult.maxPerWallet}/wallet
                                </span>
                              )}
                              {inspectResult.suggestedMintFunction && (
                                <span className="rounded-full border border-neon/40 bg-neon/10 px-2 py-0.5 font-mono text-[10px] text-neon">
                                  fn {inspectResult.suggestedMintFunction}()
                                </span>
                              )}
                            </div>
                            <ul className="flex flex-col gap-0.5">
                              {inspectResult.notes.map((n, i) => (
                                <li key={i} className="font-mono text-[10px] leading-snug text-tmut">
                                  ▸ {n}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <FieldLabel>Mint fn</FieldLabel>
                          <input
                            className={inputCls}
                            value={mintFunction}
                            onChange={(e) => setMintFunction(e.target.value)}
                          />
                        </div>
                        <div>
                          <FieldLabel>Qty / wallet</FieldLabel>
                          <input
                            className={inputCls}
                            inputMode="numeric"
                            value={quantity}
                            onChange={(e) => setQuantity(e.target.value)}
                          />
                        </div>
                        <div>
                          <FieldLabel>Price ({nativeSymbol(chainId)})</FieldLabel>
                          <input
                            className={inputCls}
                            inputMode="decimal"
                            placeholder="0.08"
                            value={mintValueEth}
                            onChange={(e) => setMintValueEth(e.target.value)}
                          />
                        </div>
                      </div>
                      <div>
                        <FieldLabel>Mint phase</FieldLabel>
                        <div className="grid grid-cols-3 gap-2">
                          {(
                            [
                              { key: "auto", label: "Auto-detect", desc: "probe the contract" },
                              { key: "public", label: "Public", desc: "open sale mint" },
                              { key: "whitelist", label: "Whitelist", desc: "allowlist + proof" },
                            ] as const
                          ).map((p) => (
                            <button
                              key={p.key}
                              type="button"
                              onClick={() => setMintPhase(p.key)}
                              className={cn(
                                "rounded-lg border px-3 py-2 text-left transition-colors",
                                mintPhase === p.key
                                  ? "border-violet/60 bg-violet/10"
                                  : "border-hairline bg-panel2 hover:border-violet/30",
                              )}
                            >
                              <p className="font-mono text-xs font-medium text-tpri">{p.label}</p>
                              <p className="mt-0.5 text-[10px] text-tmut">{p.desc}</p>
                            </button>
                          ))}
                        </div>
                      </div>
                      {mintPhase !== "public" && (
                        <div>
                          <FieldLabel>Merkle proofs (whitelist mints)</FieldLabel>
                          <textarea
                            rows={3}
                            className={cn(inputCls, "resize-y leading-relaxed")}
                            placeholder={
                              "0xWalletAddress: 0xproof1,0xproof2,…\n" +
                              'or paste JSON: {"0x…": ["0x…","0x…"]}'
                            }
                            value={proofsText}
                            onChange={(e) => setProofsText(e.target.value)}
                            spellCheck={false}
                          />
                          <p className="mt-1.5 font-mono text-[10px] text-tmut">
                            ▸ find your proof on the project's allowlist page / merkle tree — the
                            proof is appended to your mint args (or replaces a "$proof" element)
                          </p>
                          {parsedProofs.error ? (
                            <p className="mt-1.5 font-mono text-[11px] text-alarm">
                              ✕ {parsedProofs.error}
                            </p>
                          ) : (
                            proofCount > 0 && (
                              <p className="mt-1.5 font-mono text-[11px] text-neon">
                                ✓ {proofCount} wallet proof{proofCount === 1 ? "" : "s"} loaded
                              </p>
                            )
                          )}
                        </div>
                      )}
                    </motion.div>
                  )}

                  {step === 1 && (
                    <motion.div
                      key="s1"
                      initial={{ opacity: 0, x: 40 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -40 }}
                      transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
                      className="flex flex-col gap-4"
                    >
                      <div>
                        <FieldLabel>Trigger mode</FieldLabel>
                        <div className="grid grid-cols-3 gap-2">
                          {(
                            [
                              { key: "time", label: "Timed", desc: "fire at go-live" },
                              { key: "poll", label: "Poll", desc: "watch a flag fn" },
                              { key: "event", label: "Event", desc: "listen on-chain" },
                            ] as const
                          ).map((t) => (
                            <button
                              key={t.key}
                              type="button"
                              onClick={() => setTriggerMode(t.key)}
                              className={cn(
                                "rounded-lg border px-3 py-2.5 text-left transition-colors",
                                triggerMode === t.key
                                  ? "border-violet/60 bg-violet/10"
                                  : "border-hairline bg-panel2 hover:border-violet/30",
                              )}
                            >
                              <p className="font-mono text-xs font-medium text-tpri">{t.label}</p>
                              <p className="mt-0.5 text-[11px] text-tmut">{t.desc}</p>
                            </button>
                          ))}
                        </div>
                      </div>

                      {triggerMode === "time" && (
                        <div>
                          <FieldLabel>Go-live time</FieldLabel>
                          <input
                            type="datetime-local"
                            className={cn(inputCls, "[color-scheme:dark]")}
                            value={openTime}
                            onChange={(e) => setOpenTime(e.target.value)}
                          />
                          <p className="mt-1.5 font-mono text-[11px] text-tmut">
                            ▸ the engine pre-warms txs ~2 blocks before this time
                          </p>
                        </div>
                      )}
                      {triggerMode === "poll" && (
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <FieldLabel>Flag method</FieldLabel>
                            <input
                              className={inputCls}
                              value={flagMethod}
                              onChange={(e) => setFlagMethod(e.target.value)}
                            />
                          </div>
                          <div>
                            <FieldLabel>Poll interval (ms)</FieldLabel>
                            <input
                              className={inputCls}
                              inputMode="numeric"
                              value={pollIntervalMs}
                              onChange={(e) => setPollIntervalMs(e.target.value)}
                            />
                          </div>
                        </div>
                      )}
                      {triggerMode === "event" && (
                        <div>
                          <FieldLabel>Event name</FieldLabel>
                          <input
                            className={inputCls}
                            placeholder="SaleActivated"
                            value={eventName}
                            onChange={(e) => setEventName(e.target.value)}
                          />
                          <p className="mt-1.5 font-mono text-[11px] text-tmut">
                            ▸ fires the moment this event hits the mempool
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}

                  {step === 2 && (
                    <motion.div
                      key="s2"
                      initial={{ opacity: 0, x: 40 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -40 }}
                      transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
                      className="flex flex-col gap-4"
                    >
                      <div>
                        <FieldLabel>Gas preset</FieldLabel>
                        <div className="grid grid-cols-3 gap-2">
                          {GAS_PRESETS.map((g) => (
                            <button
                              key={g.key}
                              type="button"
                              onClick={() => applyPreset(g.key)}
                              className={cn(
                                "rounded-lg border px-3 py-2.5 text-left transition-colors",
                                preset === g.key
                                  ? "border-neon/50 bg-neon/5"
                                  : "border-hairline bg-panel2 hover:border-neon/30",
                              )}
                            >
                              <p className="font-mono text-xs font-medium uppercase tracking-wider text-tpri">
                                {g.label}
                              </p>
                              <p className="mt-0.5 text-[10px] leading-snug text-tmut">{g.desc}</p>
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="grid grid-cols-4 gap-2.5">
                        {(
                          [
                            ["Start fee", startMaxFeeGwei, setStartMaxFeeGwei],
                            ["Priority", startPriorityGwei, setStartPriorityGwei],
                            ["Bump", gasBumpGwei, setGasBumpGwei],
                            ["Max fee", maxMaxFeeGwei, setMaxMaxFeeGwei],
                          ] as const
                        ).map(([label, val, set]) => (
                          <div key={label}>
                            <FieldLabel>{label}</FieldLabel>
                            <input
                              className={inputCls}
                              inputMode="numeric"
                              value={val}
                              onChange={(e) => set(e.target.value)}
                            />
                          </div>
                        ))}
                      </div>
                      <div className="grid grid-cols-2 items-end gap-3">
                        <div>
                          <FieldLabel>Max retries</FieldLabel>
                          <input
                            className={inputCls}
                            inputMode="numeric"
                            value={maxRetries}
                            onChange={(e) => setMaxRetries(e.target.value)}
                          />
                        </div>
                        <p className="flex items-center gap-2 rounded-lg border border-hairline bg-panel2 px-3 py-2.5 text-[13px] text-tsec">
                          <ShieldCheck className="h-4 w-4 shrink-0 text-neon" />
                          Executes live on-chain from your bot vault — real funds, real risk
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSimulateFirst((v) => !v)}
                        className={cn(
                          "flex items-center gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors",
                          simulateFirst
                            ? "border-neon/40 bg-neon/5"
                            : "border-hairline bg-panel2 hover:border-neon/30",
                        )}
                      >
                        <span
                          className={cn(
                            "flex h-5 w-9 shrink-0 items-center rounded-full border px-0.5 transition-colors",
                            simulateFirst ? "justify-end border-neon/60 bg-neon/20" : "justify-start border-hairline bg-void",
                          )}
                        >
                          <span
                            className={cn(
                              "h-3.5 w-3.5 rounded-full",
                              simulateFirst ? "bg-neon" : "bg-tmut",
                            )}
                          />
                        </span>
                        <span>
                          <span className="block font-mono text-xs font-medium text-tpri">
                            Pre-flight simulation {simulateFirst ? "· on" : "· off"}
                          </span>
                          <span className="mt-0.5 block text-[11px] leading-snug text-tmut">
                            Simulate every mint with eth_call before broadcasting — a would-be
                            revert holds fire instead of burning gas.
                          </span>
                        </span>
                      </button>

                      {/* Summary */}
                      <div className="rounded-lg border border-hairline bg-void p-3.5 font-mono text-[12px] leading-relaxed">
                        <p className="text-tmut">// review</p>
                        <p className="text-tsec">
                          <span className="text-violet">target</span> {truncateAddr(contractAddress) || "—"} ·{" "}
                          {chainByIdLabel(chainId)}
                        </p>
                        <p className="text-tsec">
                          <span className="text-violet">call</span> {mintFunction}({quantity}) payable{" "}
                          {mintValueEth} {nativeSymbol(chainId)}
                        </p>
                        <p className="text-tsec">
                          <span className="text-violet">trigger</span> {triggerMode}
                          {triggerMode === "time" && openTime
                            ? ` @ ${new Date(openTime).toLocaleString()}`
                            : ""}
                          {triggerMode === "poll" ? ` ${flagMethod}() every ${pollIntervalMs}ms` : ""}
                          {triggerMode === "event" ? ` on ${eventName || "—"}` : ""}
                        </p>
                        <p className="text-tsec">
                          <span className="text-violet">wallets</span>{" "}
                          {Math.max(1, selectedWallets.length)} firing ·{" "}
                          <span className="text-violet">phase</span> {mintPhase}
                          {proofCount > 0 ? ` (${proofCount} proofs)` : ""} ·{" "}
                          <span className="text-violet">simulate</span>{" "}
                          {simulateFirst ? "on" : "off"}
                        </p>
                        <p className="mt-1.5 border-t border-hairline pt-1.5 text-cyan">
                          est. max cost {estCost.toFixed(3)} {nativeSymbol(chainId)} + gas ≤ {estGas.toFixed(3)} {nativeSymbol(chainId)}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {trialExpired && (
                <p className="mt-2 font-mono text-[11px] text-alarm">
                  ✕ Your 7-day free trial has ended — upgrade to PRO to keep sniping.
                </p>
              )}
              {stepError && <p className="mt-2 font-mono text-[11px] text-amber">▲ {stepError}</p>}
              <ServerError message={error} />

              {/* Footer buttons */}
              <div className="mt-5 flex items-center justify-between">
                <button
                  type="button"
                  disabled={step === 0}
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  className="flex items-center gap-1 rounded-lg border border-hairline px-4 py-2 text-[13px] font-medium text-tsec transition-colors hover:text-tpri disabled:opacity-40"
                >
                  <ChevronLeft className="h-4 w-4" /> Back
                </button>
                {step < 2 ? (
                  <button
                    type="button"
                    disabled={!!stepError}
                    onClick={() => setStep((s) => s + 1)}
                    className="flex items-center gap-1 rounded-lg bg-g-brand px-5 py-2 text-[13px] font-semibold text-white transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
                  >
                    Next <ChevronRight className="h-4 w-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={!!stepError || createTask.isPending || trialExpired}
                    title={trialExpired ? "Trial expired — upgrade to PRO" : undefined}
                    onClick={submit}
                    className="rounded-lg bg-neon px-5 py-2 text-[13px] font-semibold text-void transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
                  >
                    {createTask.isPending ? "Creating…" : "Create task"}
                  </button>
                )}
              </div>
            </>
          ) : (
            /* Success state */
            <div className="flex flex-col items-center gap-4 py-6 text-center">
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 320, damping: 16 }}
                className="flex h-14 w-14 items-center justify-center rounded-full border border-neon/40 bg-neon/10"
              >
                <Check className="h-7 w-7 text-neon" />
              </motion.span>
              <div>
                <p className="font-display text-lg font-semibold text-tpri">
                  Task #{String(createdId).padStart(4, "0")} created
                </p>
                <p className="mt-1 font-mono text-xs text-tmut">
                  saved as draft — arm it when you're ready
                </p>
              </div>
              <ServerError message={error} />
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    onOpenChange(false);
                    onCreated?.();
                    reset();
                  }}
                  className="rounded-lg border border-hairline px-4 py-2 text-[13px] font-medium text-tsec hover:text-tpri"
                >
                  View in tasks
                </button>
                <button
                  type="button"
                  disabled={armTask.isPending}
                  onClick={() => armTask.mutate({ id: createdId })}
                  className="rounded-lg bg-neon px-5 py-2 text-[13px] font-semibold text-void transition-all hover:brightness-110 active:scale-[0.97] disabled:opacity-40"
                >
                  {armTask.isPending ? "Arming…" : "Arm now"}
                </button>
              </div>
            </div>
          )}
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

function chainByIdLabel(id: number): string {
  return CHAINS.find((c) => c.id === id)?.label ?? "Ethereum";
}
