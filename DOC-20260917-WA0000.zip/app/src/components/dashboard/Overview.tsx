import { motion } from "framer-motion";
import { Activity, Copy as CopyIcon, Plus, Rocket, Wallet } from "lucide-react";
import LivePulseDot from "@/components/LivePulseDot";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { CHAINS, EmptyState, timeAgo, useNow } from "./shared";
import type { SectionKey } from "./shell";

/** Live per-chain gas prices (gwei), polled every 15s from public.gasNow. */
function GasWidget() {
  const gas = trpc.public.gasNow.useQuery(undefined, { refetchInterval: 15_000 });
  const rows = gas.data ?? [];
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.36, duration: 0.4 }}
      className="card-base px-5 py-4"
    >
      <div className="flex items-center justify-between">
        <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-tmut">
          Network gas · live
        </p>
        <LivePulseDot />
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {CHAINS.map((c) => {
          const g = rows.find((r) => r.chainId === c.id)?.gwei ?? null;
          const tone =
            g === null
              ? "border-hairline text-tmut"
              : g < 50
                ? "border-neon/30 text-neon"
                : g < 200
                  ? "border-amber/30 text-amber"
                  : "border-alarm/30 text-alarm";
          return (
            <span
              key={c.id}
              className={cn(
                "tnum inline-flex items-center gap-1.5 rounded-full border bg-panel2 px-2.5 py-1 font-mono text-[11px]",
                tone,
              )}
              title={`${c.label} gas price`}
            >
              <img src={c.icon} alt="" className="h-3 w-3" />
              {c.label} · {g === null ? "—" : `${g} gwei`}
            </span>
          );
        })}
      </div>
    </motion.div>
  );
}

interface OverviewProps {
  onNavigate: (s: SectionKey) => void;
  onNewTask: () => void;
}

export default function Overview({ onNavigate, onNewTask }: OverviewProps) {
  useNow(4000);
  const stats = trpc.stats.overview.useQuery(undefined, { refetchInterval: 8000 });
  const activity = trpc.activity.list.useQuery(undefined, { refetchInterval: 4000 });

  const s = stats.data;
  const pnl = Number(s?.pnlEth ?? 0);

  const cards = [
    {
      label: "Realized PnL",
      value: `${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)} ETH`,
      delta: `${s?.mirroredCount ?? 0} mirrored`,
      tone: "green" as const,
    },
    {
      label: "Active tasks",
      value: String(s?.tasksArmed ?? 0),
      delta: `${s?.tasksTotal ?? 0} total`,
      tone: "amber" as const,
    },
    {
      label: "Copying",
      value: `${s?.walletsTracked ?? 0} snipers`,
      delta: `${s?.signalsToday ?? 0} signals today`,
      tone: "green" as const,
    },
    {
      label: "Signals today",
      value: String(s?.signalsToday ?? 0),
      delta: "live feed",
      tone: "violet" as const,
    },
  ];

  const recent = (activity.data ?? []).slice(0, 7);

  const actions = [
    { icon: Rocket, label: "New mint task", onClick: onNewTask },
    { icon: Wallet, label: "Add bot wallet", onClick: () => onNavigate("wallets") },
    { icon: CopyIcon, label: "Watch a sniper", onClick: () => onNavigate("copy") },
    { icon: Activity, label: "Open activity", onClick: () => onNavigate("activity") },
  ];

  return (
    <div className="flex flex-col gap-6">
      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c, i) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 * i, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="card-base p-5"
          >
            <div className="flex items-center justify-between">
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-tmut">
                {c.label}
              </p>
              <LivePulseDot />
            </div>
            <p className="tnum mt-2 font-mono text-[28px] font-bold leading-none text-tpri">
              {stats.isLoading ? "—" : c.value}
            </p>
            <div className="mt-3 flex items-center justify-between gap-2">
              <span
                className={cn(
                  "chip-profit",
                  c.tone === "amber" && "bg-amber/10 text-amber",
                  c.tone === "violet" && "bg-violet/10 text-violet",
                )}
              >
                {c.delta}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      <GasWidget />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        {/* Recent activity */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.32, duration: 0.4 }}
          className="card-base p-0 xl:col-span-2"
        >
          <div className="flex items-center justify-between border-b border-hairline px-5 py-4">
            <h3 className="flex items-center gap-2 font-display text-[15px] font-semibold text-tpri">
              <LivePulseDot /> Recent activity
            </h3>
            <button
              onClick={() => onNavigate("activity")}
              className="font-mono text-xs text-cyan hover:underline"
            >
              view all ↗
            </button>
          </div>
          {recent.length === 0 ? (
            <div className="p-5">
              <EmptyState
                icon={<Activity className="h-5 w-5" />}
                title="Nothing on the tape yet"
                body="Arm your first task or watch a sniper — every fill, fire and skip lands here in real time."
                action={
                  <button
                    onClick={onNewTask}
                    className="rounded-lg bg-neon px-4 py-2 text-[13px] font-semibold text-void transition-all hover:brightness-110 active:scale-[0.97]"
                  >
                    Arm your first task
                  </button>
                }
              />
            </div>
          ) : (
            <ul className="divide-y divide-hairline/60">
              {recent.map((row) => (
                <li key={row.id} className="flex items-center gap-3 px-5 py-2.5">
                  <span
                    className={cn(
                      "h-1.5 w-1.5 shrink-0 rounded-full",
                      row.level === "success" && "bg-neon",
                      row.level === "info" && "bg-violet",
                      row.level === "warn" && "bg-amber",
                      row.level === "error" && "bg-alarm",
                    )}
                  />
                  <span className="min-w-0 flex-1 truncate font-mono text-xs text-tsec">
                    {row.message}
                  </span>
                  <span className="shrink-0 font-mono text-[10px] uppercase tracking-wider text-tmut">
                    {row.source}
                  </span>
                  <span className="tnum w-16 shrink-0 text-right font-mono text-[10px] text-tmut">
                    {timeAgo(row.createdAt)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </motion.div>

        {/* Quick actions */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.4 }}
          className="card-base"
        >
          <h3 className="font-display text-[15px] font-semibold text-tpri">Quick actions</h3>
          <div className="mt-4 grid grid-cols-1 gap-2.5">
            {actions.map((a) => (
              <button
                key={a.label}
                onClick={a.onClick}
                className="group flex items-center gap-3 rounded-lg border border-hairline bg-panel2/50 px-4 py-3 text-left text-sm font-medium text-tsec transition-all duration-200 hover:border-violet/45 hover:text-tpri"
              >
                <a.icon className="h-4 w-4 text-violet" />
                {a.label}
                <Plus className="ml-auto h-3.5 w-3.5 text-tmut transition-transform group-hover:rotate-90" />
              </button>
            ))}
          </div>
          <p className="mt-4 rounded-lg border border-hairline bg-void px-3 py-2 font-mono text-[11px] leading-relaxed text-tmut">
            ▸ live execution only — tasks fire real on-chain transactions from your
            bot vault. Real funds, real risk; fund your vault in Wallets.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
