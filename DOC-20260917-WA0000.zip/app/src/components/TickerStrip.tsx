import { trpc } from "@/providers/trpc";
import { truncateAddress } from "@/lib/chains";

export interface MintItem {
  collection: string;
  detail: string;
  ago: string;
}

function ago(d: Date): string {
  const s = Math.max(0, Math.floor((Date.now() - d.getTime()) / 1000));
  if (s < 5) return "now";
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

function TickerEntry({ item }: { item: MintItem }) {
  return (
    <div className="flex shrink-0 items-center gap-2.5 px-6">
      <span className="text-[13px] font-medium text-tpri">{item.collection}</span>
      <span className="font-mono text-xs text-cyan">{item.detail}</span>
      <span className="font-mono text-xs text-tmut">{item.ago} ago</span>
    </div>
  );
}

/**
 * Shared live detection ticker strip — infinite marquee of the engine's real
 * on-chain detections (public recent-signals endpoint, polled every 30s).
 * When nothing has been detected yet, one honest static line is shown.
 */
export default function TickerStrip() {
  const query = trpc.public.recentSignals.useQuery(undefined, { refetchInterval: 30_000 });

  const items: MintItem[] = (query.data ?? []).map((s) => ({
    collection: s.collectionName ?? truncateAddress(s.contractAddress),
    detail:
      `${s.type}${s.priceEth && Number(s.priceEth) > 0 ? ` · ${Number(s.priceEth).toFixed(4)} ETH` : ""}` +
      (s.txHash ? ` · ${truncateAddress(s.txHash)}` : ""),
    ago: ago(new Date(s.detectedAt)),
  }));

  if (items.length === 0) {
    return (
      <div className="relative h-14 w-full overflow-hidden border-y border-hairline bg-panel">
        <div className="flex h-full items-center justify-center">
          <p className="font-mono text-xs text-tmut">
            live on-chain detections appear here as the engine scans
          </p>
        </div>
      </div>
    );
  }

  const doubled = [...items, ...items];

  return (
    <div className="relative h-14 w-full overflow-hidden border-y border-hairline bg-panel">
      <div className="mask-fade-x flex h-full items-center overflow-hidden">
        <div className="flex w-max animate-marquee items-center hover:[animation-play-state:paused]">
          {doubled.map((item, i) => (
            <TickerEntry key={i} item={item} />
          ))}
        </div>
      </div>
    </div>
  );
}
