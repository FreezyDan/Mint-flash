import { motion } from "framer-motion";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { ButtonLink } from "./Button";

/**
 * Shared CTA band — bottom of home, features, copy-trading, pricing.
 * Violet radial glow + "Stop clicking. Start sniping."
 */
export default function CTABand() {
  return (
    <section className="relative overflow-hidden border-t border-hairline">
      <div className="pointer-events-none absolute inset-0 bg-g-hero-glow" aria-hidden />
      <div className="container-x relative py-24 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="eyebrow eyebrow-violet mb-6">[ DEPLOY YOUR BOT ]</p>
          <h2 className="mx-auto max-w-2xl text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
            Stop clicking. Start sniping.
          </h2>
          <p className="mx-auto mt-4 max-w-md text-[17px] text-tsec">
            Your next mint is already live somewhere. MintDash fires in 412ms —
            before the public mint button even renders.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <ButtonLink to="/app">Launch App</ButtonLink>
            <Link
              to="/docs"
              className="group inline-flex items-center gap-1.5 text-[15px] font-medium text-tsec transition-colors hover:text-tpri"
            >
              View docs
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
