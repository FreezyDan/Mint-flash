import { cn } from "@/lib/utils";

/**
 * Live pulse dot — 8px neon-green circle with an expanding ring.
 * Signature motif for everything "live".
 */
export default function LivePulseDot({ className }: { className?: string }) {
  return (
    <span className={cn("relative inline-flex h-2 w-2 shrink-0", className)}>
      <span className="absolute inset-0 rounded-full bg-neon animate-pulse-ring" />
      <span className="relative inline-flex h-2 w-2 rounded-full bg-neon" />
    </span>
  );
}
