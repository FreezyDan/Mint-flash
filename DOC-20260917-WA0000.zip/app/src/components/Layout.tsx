import { useEffect } from "react";
import { Outlet, useLocation } from "react-router";
import Lenis from "lenis";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Navbar from "./Navbar";
import Footer from "./Footer";
import CTABand from "./CTABand";

gsap.registerPlugin(ScrollTrigger);

/** Routes that show the shared CTA band above the footer. */
const CTA_ROUTES = ["/", "/features", "/copy-trading"];

/**
 * Marketing layout — nested-route pattern (renders <Outlet/>).
 * Owns the pt-16 content offset for the fixed navbar; page agents
 * must NOT add their own nav-height compensation. Full-bleed heroes
 * opt out inside the page with `-mt-16` + internal top padding.
 *
 * The dashboard at /app renders WITHOUT this layout (own sidebar shell).
 */
export default function Layout() {
  const { pathname } = useLocation();

  // Lenis smooth scroll, synced with GSAP ScrollTrigger. Disabled for reduced motion.
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const lenis = new Lenis({ lerp: 0.09, wheelMultiplier: 1.0 });
    lenis.on("scroll", ScrollTrigger.update);
    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);
    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
    };
  }, []);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="relative min-h-[100dvh] bg-void">
      {/* Global grid + noise background layers, behind everything */}
      <div className="bg-grid-layer pointer-events-none fixed inset-0 z-0" aria-hidden />
      <div className="bg-noise-layer pointer-events-none fixed inset-0 z-0" aria-hidden />

      <Navbar />
      <main className="relative z-10 pt-16">
        <Outlet />
        {CTA_ROUTES.includes(pathname) && <CTABand />}
      </main>
      <div className="relative z-10">
        <Footer />
      </div>
    </div>
  );
}
