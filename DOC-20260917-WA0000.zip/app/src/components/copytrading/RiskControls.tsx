import { motion } from "framer-motion";
import Reveal from "@/components/Reveal";

/** Stroke-drawn duotone icons (red outline + green accent), drawn on entry. */
function DrawnIcon({ paths }: { paths: { d: string; green?: boolean }[] }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className="h-6 w-6" aria-hidden>
      {paths.map((p, i) => (
        <motion.path
          key={i}
          d={p.d}
          stroke={p.green ? "#39FF8E" : "#FF4D6A"}
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          whileInView={{ pathLength: 1 }}
          viewport={{ once: true, amount: 0.6 }}
          transition={{ duration: 0.8, delay: 0.25 + i * 0.15, ease: [0.16, 1, 0.3, 1] }}
        />
      ))}
    </svg>
  );
}

const CARDS = [
  {
    title: "Verified-only leaderboard",
    body: "PnL is computed from chain data. No wallet gets listed without 30+ days of history and 50+ mints.",
    icon: (
      <DrawnIcon
        paths={[
          { d: "M12 3l7 3v5c0 4.4-3 7.6-7 9-4-1.4-7-4.6-7-9V6l7-3z" },
          { d: "M9 11.5l2 2 4-4.5", green: true },
        ]}
      />
    ),
  },
  {
    title: "Your keys, your rules",
    body: "Non-custodial. MintDash can only execute the exact task scope you sign. Revoke anytime in one click.",
    icon: (
      <DrawnIcon
        paths={[
          { d: "M14.5 3.5a5 5 0 105 5" },
          { d: "M13 11L3.5 20.5" },
          { d: "M6.5 17.5l2 2M9 15l2 2", green: true },
        ]}
      />
    ),
  },
  {
    title: "Automatic circuit breakers",
    body: "Sniper's 7d PnL goes negative past your stop-loss? Auto-unfollow, funds never leave your wallet.",
    icon: (
      <DrawnIcon
        paths={[
          { d: "M4 7h7M17 7h3M4 17h3M13 17h7" },
          { d: "M13 4.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5zM8 14.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5z", green: true },
        ]}
      />
    ),
  },
];

/**
 * S5 — Risk controls. The only red-accented section on the page:
 * subtle rgba(255,77,106,0.06) radial glow + red→green duotone icons.
 */
export default function RiskControls() {
  return (
    <section className="relative overflow-hidden border-y border-hairline">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, rgba(255,77,106,0.06) 0%, transparent 65%)",
        }}
        aria-hidden
      />
      <div className="container-x relative py-16 md:py-24">
        <Reveal className="mb-12 max-w-2xl">
          <p className="eyebrow rounded-full border border-alarm/30 px-3 py-1 text-alarm">
            [ RISK CONTROLS ]
          </p>
          <h2 className="mt-5 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
            Copy trading without the clown risks.
          </h2>
        </Reveal>

        <div className="grid gap-6 md:grid-cols-3">
          {CARDS.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="card-base card-hover"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-lg border border-alarm/25 bg-alarm/10">
                {c.icon}
              </span>
              <h3 className="mt-5 text-[22px] font-semibold leading-[1.25] text-tpri">
                {c.title}
              </h3>
              <p className="mt-2.5 text-[15px] leading-relaxed text-tsec">{c.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
