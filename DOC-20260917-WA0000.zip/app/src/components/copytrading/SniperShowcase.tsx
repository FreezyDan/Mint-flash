import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Copy } from "lucide-react";
import Reveal from "@/components/Reveal";
import { trpc } from "@/providers/trpc";
import type { PublicLeaderboardRow } from "@contracts/discover";
import { chainMetaById, formatSignedEth, truncateAddress } from "@/lib/chains";
import { cn } from "@/lib/utils";

const RANK_CHIP: Record<number, string> = {
  1: "border-amber/40 bg-amber/10 text-amber",
  2: "border-violet/40 bg-violet/10 text-violet",
  3: "border-violet/40 bg-violet/10 text-violet",
};

function FeaturedCard({ row, i }: { row: PublicLeaderboardRow; i: number }) {
  const [copiedAddr, setCopiedAddr] = useState(false);
  const chain = chainMetaById(row.chainId);

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(row.address);
    } catch {
      /* clipboard unavailable — cosmetic only */
    }
    setCopiedAddr(true);
    setTimeout(() => setCopiedAddr(false), 1200);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 36, rotate: 3 }}
      whileInView={{ opacity: 1, y: 0, rotate: 0 }}
      viewport={{ once: true, amount: 0.25 }}
      transition={{
        duration: 0.55,
        delay: i * 0.14,
        ease: [0.34, 1.3, 0.64, 1],
      }}
      className="card-base card-hover flex flex-col"
    >
      {/* Header: address + rank */}
      <div className="flex items-center gap-3">
        <div className="min-w-0 flex-1">
          <button
            type="button"
            onClick={copyAddress}
            className="group flex items-center gap-1.5 font-mono text-sm text-tsec transition-colors hover:text-tpri"
            title="Copy address"
          >
            {truncateAddress(row.address)}
            {copiedAddr ? (
              <Check className="h-3 w-3 text-neon" />
            ) : (
              <Copy className="h-3 w-3 opacity-0 transition-opacity duration-150 group-hover:opacity-100" />
            )}
          </button>
          <p className="mt-0.5 font-mono text-[11px] text-tmut">{chain?.name ?? `chain ${row.chainId}`}</p>
        </div>
        <span
          className={cn(
            "tnum rounded-full border px-2.5 py-0.5 font-mono text-xs font-bold",
            RANK_CHIP[i + 1],
          )}
        >
          #{i + 1}
        </span>
      </div>

      {/* PnL */}
      <div className="mt-5 flex items-baseline gap-3">
        <p
          className={cn(
            "tnum font-mono text-[36px] font-bold leading-none",
            Number(row.totalPnlEth) >= 0 ? "text-neon" : "text-alarm",
          )}
        >
          {formatSignedEth(Number(row.totalPnlEth))}
        </p>
        <p className="font-mono text-xs text-tmut">total</p>
      </div>

      {/* Stats grid — all from the on-chain scan */}
      <div className="mt-5 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-hairline bg-hairline">
        {[
          ["Win rate", `${Number(row.winRatePct).toFixed(0)}%`],
          ["Flips", `${row.flips}`],
          ["Open positions", `${row.openPositions}`],
          [
            "Unrealized",
            row.unrealizedPnlEth === null ? "—" : formatSignedEth(Number(row.unrealizedPnlEth)),
          ],
        ].map(([k, v]) => (
          <div key={k} className="bg-panel2/60 px-3.5 py-2.5">
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-tmut">{k}</p>
            <p className="tnum mt-0.5 font-mono text-sm font-medium text-tpri">{v}</p>
          </div>
        ))}
      </div>

      <p className="mt-5 font-mono text-[10px] text-tmut">
        scanned {new Date(row.scannedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })} ·
        public chain data
      </p>
    </motion.div>
  );
}

/**
 * S3 — top-3 wallets from the real on-chain scanner leaderboard. Honest
 * empty state when no scan has run yet.
 */
export default function SniperShowcase() {
  const query = trpc.public.leaderboard.useQuery(undefined, { refetchInterval: 60_000 });
  const top = (query.data ?? []).slice(0, 3);

  return (
    <section className="container-x py-16 md:py-24">
      <Reveal className="mb-12 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow eyebrow-green">[ VERIFIED ON-CHAIN ]</p>
          <h2 className="mt-5 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
            The sharpest on-chain
          </h2>
        </div>
        <p className="max-w-sm text-[15px] text-tsec">
          Ranked by total PnL from the MintDash chain scanner — public chain
          data only.
        </p>
      </Reveal>

      {top.length === 0 ? (
        <div className="card-base p-10 text-center">
          <p className="font-mono text-sm text-tmut">
            No on-chain scan data yet — leaderboards populate as scans run.
          </p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-3">
          {top.map((row, i) => (
            <FeaturedCard key={`${row.chainId}-${row.address}`} row={row} i={i} />
          ))}
        </div>
      )}
    </section>
  );
}
