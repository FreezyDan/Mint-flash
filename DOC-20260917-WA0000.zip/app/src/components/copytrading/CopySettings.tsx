import { useState } from "react";
import { motion } from "framer-motion";
import DragSlider from "@/components/features/DragSlider";
import { cn } from "@/lib/utils";

const SIZE_PRESETS = [0.05, 0.1, 0.25];

const CHAIN_OPTS = [
  { id: "eth", label: "ETH", badge: "/chain-eth.svg" },
  { id: "sol", label: "SOL", badge: "/chain-sol.svg" },
  { id: "base", label: "Base", badge: "/chain-base.svg" },
  { id: "poly", label: "Polygon", badge: "/chain-poly.svg" },
];

const BULLETS = [
  {
    title: "Size every fill",
    body: "Fixed ETH per mirrored mint. Whale or minnow, your size never scales with theirs.",
  },
  {
    title: "Caps & stop-loss",
    body: "Daily caps and stop-loss hard-stop the engine. Hit a limit and mirroring pauses automatically.",
  },
  {
    title: "Mirror their exits",
    body: "Sells optional. Ride their exits or hold your own thesis — configured per sniper.",
  },
  {
    title: "Only the chains you fund",
    body: "EVM chains only: Ethereum, Base, Arbitrum, Polygon, Robinhood, Ink. No funded wallet on a chain, no mirroring there.",
  },
];

/** Green snap toggle (150ms). */
function Toggle({
  on,
  onToggle,
  label,
}: {
  on: boolean;
  onToggle: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onToggle}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full border transition-colors duration-150",
        on ? "border-neon/50 bg-neon/25" : "border-hairline bg-panel2",
      )}
    >
      <motion.span
        layout
        transition={{ type: "spring", stiffness: 700, damping: 35 }}
        className={cn(
          "absolute top-1 h-4 w-4 rounded-full",
          on ? "left-[22px] bg-neon shadow-glow-green" : "left-1 bg-tmut",
        )}
      />
    </button>
  );
}

/**
 * S4 — interactive copy-settings panel + anchored explainer bullets that
 * highlight as the matching control is hovered or changed. All local state.
 */
export default function CopySettings() {
  const [size, setSize] = useState(0.1);
  const [customSize, setCustomSize] = useState("");
  const [cap, setCap] = useState(1.5);
  const [mirrorSells, setMirrorSells] = useState(true);
  const [stopLoss, setStopLoss] = useState(true);
  const [chains, setChains] = useState<string[]>(["eth", "sol"]);
  const [hovered, setHovered] = useState<number | null>(null);
  const [lastChanged, setLastChanged] = useState<number>(0);

  const activeBullet = hovered ?? lastChanged;
  const change = (b: number) => setLastChanged(b);

  // est. mints derived from cap ÷ size (matches "1.50 ETH · est. 6–14 mints" at 0.1)
  const hi = Math.max(1, Math.round(cap / Math.max(size, 0.01)) - 1);
  const lo = Math.max(1, Math.round(hi * 0.45));

  const hl = (b: number) => ({
    onMouseEnter: () => setHovered(b),
    onMouseLeave: () => setHovered(null),
  });

  return (
    <section className="container-x py-16 md:py-24">
      <div className="grid items-start gap-10 lg:grid-cols-2 lg:gap-16">
        {/* Interactive panel */}
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="card-base"
        >
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-tmut">
            copy settings · goblinmode
          </p>

          {/* Copy size per mint */}
          <div className="mt-6" {...hl(0)}>
            <div className="flex items-baseline justify-between">
              <p className="text-sm font-medium text-tpri">Copy size per mint</p>
              <p className="tnum font-mono text-sm text-neon">{size.toFixed(2)} ETH</p>
            </div>
            <div className="mt-2.5 flex flex-wrap items-center gap-2">
              {SIZE_PRESETS.map((v) => (
                <motion.button
                  key={v}
                  type="button"
                  whileTap={{ scale: 0.92 }}
                  transition={{ duration: 0.08 }}
                  onClick={() => {
                    setSize(v);
                    setCustomSize("");
                    change(0);
                  }}
                  className={cn(
                    "tnum rounded-md border px-3.5 py-1.5 font-mono text-xs transition-colors duration-150",
                    size === v && customSize === ""
                      ? "border-violet/60 bg-violet/15 text-tpri"
                      : "border-hairline text-tsec hover:border-violet/35 hover:text-tpri",
                  )}
                >
                  {v.toFixed(2)}
                </motion.button>
              ))}
              <input
                type="number"
                min={0.01}
                step={0.01}
                placeholder="custom"
                value={customSize}
                onChange={(e) => {
                  setCustomSize(e.target.value);
                  const v = parseFloat(e.target.value);
                  if (!Number.isNaN(v) && v > 0) setSize(v);
                  change(0);
                }}
                onFocus={() => change(0)}
                className="tnum w-24 rounded-md border border-hairline bg-panel2 px-3 py-1.5 font-mono text-xs text-tpri outline-none transition-colors placeholder:text-tmut focus:border-violet/60"
              />
            </div>
          </div>

          {/* Daily cap */}
          <div className="mt-7" {...hl(1)}>
            <div className="flex items-baseline justify-between">
              <p className="text-sm font-medium text-tpri">Daily cap</p>
              <p className="tnum font-mono text-sm text-neon">{cap.toFixed(2)} ETH/day</p>
            </div>
            <DragSlider
              min={0}
              max={5}
              step={0.05}
              value={cap}
              onChange={(v) => {
                setCap(v);
                change(1);
              }}
              ariaLabel="Daily cap in ETH"
              className="mt-2.5"
            />
          </div>

          {/* Mirror sells + stop-loss */}
          <div className="mt-7 space-y-4">
            <div className="flex items-center justify-between gap-4" {...hl(2)}>
              <p className="text-sm font-medium text-tpri">Mirror sells</p>
              <Toggle
                on={mirrorSells}
                onToggle={() => {
                  setMirrorSells((v) => !v);
                  change(2);
                }}
                label="Mirror sells"
              />
            </div>
            <div className="flex items-center justify-between gap-4" {...hl(1)}>
              <div>
                <p className="text-sm font-medium text-tpri">Stop-loss</p>
                {stopLoss && (
                  <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className="tnum mt-1 font-mono text-[11px] text-amber"
                  >
                    -20% PnL → auto-unfollow
                  </motion.p>
                )}
              </div>
              <Toggle
                on={stopLoss}
                onToggle={() => {
                  setStopLoss((v) => !v);
                  change(1);
                }}
                label="Stop-loss"
              />
            </div>
          </div>

          {/* Chains to mirror */}
          <div className="mt-7" {...hl(3)}>
            <p className="text-sm font-medium text-tpri">Chains to mirror</p>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {CHAIN_OPTS.map((c) => {
                const on = chains.includes(c.id);
                return (
                  <motion.button
                    key={c.id}
                    type="button"
                    whileTap={{ scale: 0.94 }}
                    transition={{ duration: 0.08 }}
                    onClick={() => {
                      setChains((prev) =>
                        on ? prev.filter((x) => x !== c.id) : [...prev, c.id],
                      );
                      change(3);
                    }}
                    className={cn(
                      "flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 font-mono text-xs transition-colors duration-150",
                      on
                        ? "border-violet/60 bg-violet/20 text-white"
                        : "border-hairline text-tsec hover:border-violet/35 hover:text-tpri",
                    )}
                  >
                    <img src={c.badge} alt="" className="h-3.5 w-3.5" loading="lazy" />
                    {c.label}
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Live summary bar */}
          <div className="mt-7 rounded-lg border border-hairline bg-panel2/60 px-4 py-3">
            <p className="tnum font-mono text-xs text-cyan">
              Max daily exposure: {cap.toFixed(2)} ETH · est. {lo}–{hi} mints
            </p>
          </div>
        </motion.div>

        {/* Anchored explainer bullets */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="eyebrow eyebrow-green">[ YOUR RULES WIN ]</p>
          <h2 className="mt-5 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
            Set it once. It obeys forever.
          </h2>
          <p className="mt-4 max-w-md text-[17px] text-tsec">
            Every control on the left maps to a hard guarantee. Touch one —
            watch what it does.
          </p>
          <ul className="mt-8 space-y-5">
            {BULLETS.map((b, i) => (
              <li
                key={b.title}
                className={cn(
                  "border-l-2 py-1 pl-4 transition-all duration-200",
                  activeBullet === i ? "border-neon" : "border-hairline",
                )}
              >
                <p
                  className={cn(
                    "font-display text-[17px] font-semibold transition-colors duration-200",
                    activeBullet === i ? "text-tpri" : "text-tsec",
                  )}
                >
                  {b.title}
                </p>
                <p
                  className={cn(
                    "mt-1 text-[15px] leading-relaxed transition-colors duration-200",
                    activeBullet === i ? "text-tsec" : "text-tmut",
                  )}
                >
                  {b.body}
                </p>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
}
