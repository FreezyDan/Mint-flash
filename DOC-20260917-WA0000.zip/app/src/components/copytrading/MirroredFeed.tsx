import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import LivePulseDot from "@/components/LivePulseDot";
import { trpc } from "@/providers/trpc";
import { truncateAddress } from "@/lib/chains";

const MAX_ROWS = 6;

function ago(ts: number, now: number) {
  const s = Math.max(0, Math.floor((now - ts) / 1000));
  if (s < 5) return "now";
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

/**
 * S6 — live on-chain detections feed. Polls the public recent-signals
 * endpoint every 30s and renders the newest detections; when the engine
 * hasn't detected anything yet, an honest static line is shown instead.
 */
export default function MirroredFeed() {
  const query = trpc.public.recentSignals.useQuery(undefined, { refetchInterval: 30_000 });
  const [now, setNow] = useState(() => Date.now());

  // 1s clock for relative times
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const rows = (query.data ?? []).slice(0, MAX_ROWS);

  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="mb-10"
      >
        <p className="flex items-center gap-2.5 font-mono text-xs font-medium uppercase tracking-[0.2em] text-neon">
          <LivePulseDot />
          Live
        </p>
        <h2 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Right now, on MintDash
        </h2>
      </motion.div>

      <div className="card-base overflow-hidden p-2 sm:p-3">
        {rows.length === 0 ? (
          <p className="px-4 py-10 text-center font-mono text-sm text-tmut">
            live on-chain detections appear here as the engine scans
          </p>
        ) : (
          <AnimatePresence initial={false}>
            {rows.map((r) => {
              const ts = new Date(r.detectedAt).getTime();
              return (
                <motion.div
                  key={r.id}
                  layout="position"
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, height: 0, marginTop: 0, marginBottom: 0 }}
                  transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <div className="flex items-center gap-3 rounded-lg px-3 py-2.5 sm:gap-4">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-medium text-tpri">
                        {r.collectionName ?? truncateAddress(r.contractAddress)}{" "}
                        {r.tokenId && (
                          <span className="tnum font-mono text-xs text-tsec">#{r.tokenId}</span>
                        )}
                      </p>
                      <p className="truncate font-mono text-[11px] text-cyan">
                        {r.type} detected on-chain
                        {r.txHash && <> · tx {truncateAddress(r.txHash)}</>}
                      </p>
                    </div>
                    {r.priceEth && Number(r.priceEth) > 0 && (
                      <span className="chip-profit tnum hidden shrink-0 sm:inline-flex">
                        {Number(r.priceEth).toFixed(4)} ETH
                      </span>
                    )}
                    <span className="tnum w-10 shrink-0 text-right font-mono text-xs text-tmut">
                      {ago(ts, now)}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>
    </section>
  );
}
