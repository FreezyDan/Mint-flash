import { motion } from "framer-motion";
import Reveal from "@/components/Reveal";

const STEPS = [
  {
    num: "01",
    title: "Pick a sniper",
    body: "Filter by chain, PnL, win rate, and style. Every stat is computed from public chain data — no screenshots, no self-reported nonsense.",
  },
  {
    num: "02",
    title: "Set your rules",
    body: "Copy size per mint, daily ETH cap, chains to mirror, stop-loss. Your rules override everything — the sniper never touches your limits.",
  },
  {
    num: "03",
    title: "Mirror in milliseconds",
    body: "When they mint, you mint. When they dump, you can auto-dump. Fills, fees, and PnL stream into your dashboard live.",
  },
];

/**
 * S2 — "How mirroring works" 3-step cards with a connecting dashed line
 * that draws left→right (1.2s) as the cards land. Number chips get a
 * one-time green glow pulse on scroll-through.
 */
export default function HowItMirrors() {
  return (
    <section className="container-x py-16 md:py-24">
      <Reveal className="mb-12 text-center">
        <p className="eyebrow eyebrow-violet">[ HOW MIRRORING WORKS ]</p>
        <h2 className="mt-5 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] md:text-[44px]">
          Three steps. Zero babysitting.
        </h2>
      </Reveal>

      <div className="relative">
        {/* Connecting dashed line — desktop only, draws as cards land */}
        <svg
          className="pointer-events-none absolute left-0 right-0 top-10 hidden h-px w-full lg:block"
          viewBox="0 0 100 1"
          preserveAspectRatio="none"
          aria-hidden
        >
          <motion.line
            x1="4"
            y1="0.5"
            x2="96"
            y2="0.5"
            stroke="#1E2230"
            strokeWidth="1"
            strokeDasharray="3 3"
            vectorEffect="non-scaling-stroke"
            initial={{ pathLength: 0 }}
            whileInView={{ pathLength: 1 }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 1.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          />
        </svg>

        <div className="grid gap-6 md:grid-cols-3">
          {STEPS.map((s, i) => (
            <motion.div
              key={s.num}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.5, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="card-base card-hover relative"
            >
              <motion.span
                initial={{ boxShadow: "0 0 0px rgba(57,255,142,0)" }}
                whileInView={{
                  boxShadow: [
                    "0 0 0px rgba(57,255,142,0)",
                    "0 0 24px rgba(57,255,142,0.45)",
                    "0 0 0px rgba(57,255,142,0)",
                  ],
                }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ duration: 1.2, delay: 0.4 + i * 0.1 }}
                className="tnum inline-flex h-10 w-10 items-center justify-center rounded-full border border-neon/30 bg-neon/10 font-mono text-sm font-bold text-neon"
              >
                {s.num}
              </motion.span>
              <h3 className="mt-5 text-[22px] font-semibold leading-[1.25] text-tpri">
                {s.title}
              </h3>
              <p className="mt-2.5 text-[15px] leading-relaxed text-tsec">{s.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
