import { motion } from "framer-motion";
import { Button } from "@/components/Button";

/** S5 "Get Listed" band — two-column panel with violet glow. */
export default function GetListed() {
  return (
    <section className="container-x py-16 md:py-24">
      <motion.div
        initial={{ opacity: 0, scale: 0.97 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.4 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-xl border border-hairline bg-panel p-8 md:p-10"
      >
        {/* violet radial glow, blooms in */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="pointer-events-none absolute -left-32 top-1/2 h-[420px] w-[420px] -translate-y-1/2 rounded-full bg-g-hero-glow"
          aria-hidden
        />
        <div className="relative grid items-center gap-8 md:grid-cols-[1.4fr_1fr]">
          <div>
            <h3 className="font-display text-[22px] font-semibold leading-[1.25] text-tpri md:text-2xl">
              Think your wallet belongs here?
            </h3>
            <p className="mt-3 max-w-lg text-[15px] text-tsec">
              Connect read-only and MintDash will verify your on-chain track record
              automatically. 30 days of history, 50+ mints, positive expectancy —
              you're in.
            </p>
          </div>
          <div className="flex flex-col items-start gap-3 md:items-end">
            <Button variant="ghost">Verify my wallet</Button>
            <span className="font-mono text-[11px] text-tmut">
              read-only · revocable · no signing of txs
            </span>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
