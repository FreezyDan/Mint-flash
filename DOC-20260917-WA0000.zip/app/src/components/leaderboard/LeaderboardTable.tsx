import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUp, Check, Copy } from "lucide-react";
import type { PublicLeaderboardRow } from "@contracts/discover";
import { chainMetaById, formatSignedEth, truncateAddress } from "@/lib/chains";
import { cn } from "@/lib/utils";

type SortKey = "totalPnl" | "winRate" | "flips" | "openPositions";

const RANK_CHIP: Record<number, string> = {
  1: "bg-amber/10 text-amber border-amber/30",
  2: "bg-[#C7CCDA]/10 text-[#C7CCDA] border-[#C7CCDA]/30",
  3: "bg-[#C98A4B]/10 text-[#C98A4B] border-[#C98A4B]/30",
};

function AddressCell({ address }: { address: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <span className="group/addr flex items-center gap-1.5">
      <span className="font-mono text-xs text-tsec">{truncateAddress(address)}</span>
      <button
        aria-label="Copy address"
        onClick={(e) => {
          e.stopPropagation();
          navigator.clipboard?.writeText(address).catch(() => {});
          setCopied(true);
          setTimeout(() => setCopied(false), 900);
        }}
        className="text-tmut opacity-0 transition-opacity duration-150 hover:text-tpri group-hover/addr:opacity-100"
      >
        {copied ? <Check className="h-3 w-3 text-neon" /> : <Copy className="h-3 w-3" />}
      </button>
    </span>
  );
}

interface LeaderboardTableProps {
  rows: PublicLeaderboardRow[];
}

/** Ranked on-chain trader table — real scanner output, sortable columns. */
export default function LeaderboardTable({ rows }: LeaderboardTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>("totalPnl");
  const [sortAsc, setSortAsc] = useState(false);

  const sorted = useMemo(() => {
    const val = (t: PublicLeaderboardRow) =>
      sortKey === "totalPnl"
        ? Number(t.totalPnlEth)
        : sortKey === "winRate"
          ? Number(t.winRatePct)
          : sortKey === "flips"
            ? t.flips
            : t.openPositions;
    return [...rows].sort((a, b) => (sortAsc ? val(a) - val(b) : val(b) - val(a)));
  }, [rows, sortKey, sortAsc]);

  const toggleSort = (k: SortKey) => {
    if (k === sortKey) setSortAsc((v) => !v);
    else {
      setSortKey(k);
      setSortAsc(false);
    }
  };

  const headers: { label: string; key?: SortKey; className?: string }[] = [
    { label: "Rank", className: "pl-6" },
    { label: "Wallet" },
    { label: "Chain" },
    { label: "Total PnL", key: "totalPnl" },
    { label: "Win rate", key: "winRate" },
    { label: "Flips", key: "flips" },
    { label: "Open", key: "openPositions" },
    { label: "", className: "pr-6" },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[860px] text-left">
        <thead>
          <tr className="border-b border-hairline font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
            {headers.map((h, i) => (
              <th key={i} className={cn("px-4 py-3 font-medium", h.className)}>
                {h.key ? (
                  <button
                    onClick={() => toggleSort(h.key!)}
                    className={cn(
                      "group/th inline-flex items-center gap-1 uppercase tracking-[0.14em] transition-colors hover:text-tsec",
                      sortKey === h.key && "text-tpri",
                    )}
                  >
                    {h.label}
                    <ArrowUp
                      className={cn(
                        "h-3 w-3 transition-transform duration-200",
                        sortKey === h.key ? "opacity-100" : "opacity-0 group-hover/th:opacity-40",
                        sortKey === h.key && !sortAsc && "rotate-180",
                      )}
                    />
                  </button>
                ) : (
                  h.label
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sorted.map((t, i) => {
            const total = Number(t.totalPnlEth);
            const chain = chainMetaById(t.chainId);
            return (
              <motion.tr
                key={`${t.chainId}-${t.address}`}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.3,
                  delay: i * 0.035,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="group h-14 border-b border-hairline/60 transition-colors last:border-0 hover:bg-panel2"
              >
                {/* Rank */}
                <td className="pl-6 pr-4">
                  <span
                    className={cn(
                      "tnum inline-flex min-w-9 items-center justify-center rounded-md border px-1.5 py-0.5 font-mono text-xs font-bold",
                      RANK_CHIP[i + 1] ?? "border-transparent text-tmut",
                    )}
                  >
                    #{i + 1}
                  </span>
                </td>
                {/* Wallet */}
                <td className="px-4 py-3">
                  <AddressCell address={t.address} />
                </td>
                {/* Chain */}
                <td className="px-4 py-3">
                  {chain && (
                    <span className="flex items-center gap-1.5">
                      <img
                        src={chain.badge}
                        alt={chain.name}
                        title={chain.name}
                        className="h-4 w-4 opacity-80"
                        loading="lazy"
                      />
                      <span className="font-mono text-xs text-tmut">{chain.name}</span>
                    </span>
                  )}
                </td>
                {/* Total PnL */}
                <td className="px-4 py-3">
                  <span
                    className={cn(
                      "tnum rounded px-1.5 py-0.5 font-mono text-[15px] font-medium",
                      total >= 0 ? "text-neon" : "text-alarm",
                    )}
                  >
                    {formatSignedEth(total)}
                  </span>
                </td>
                {/* Win rate */}
                <td className="px-4 py-3">
                  <span className="flex items-center gap-2">
                    <span className="tnum font-mono text-sm text-tsec">
                      {Number(t.winRatePct).toFixed(0)}%
                    </span>
                    <span className="h-1 w-6 overflow-hidden rounded-full bg-hairline">
                      <span
                        className="block h-full rounded-full bg-neon"
                        style={{ width: `${Math.min(100, Number(t.winRatePct))}%` }}
                      />
                    </span>
                  </span>
                </td>
                {/* Flips */}
                <td className="tnum px-4 py-3 font-mono text-sm text-tsec">{t.flips}</td>
                {/* Open positions */}
                <td className="tnum px-4 py-3 font-mono text-sm text-tsec">{t.openPositions}</td>
                <td className="py-3 pl-4 pr-6" />
              </motion.tr>
            );
          })}
          {sorted.length === 0 && (
            <tr>
              <td colSpan={8} className="px-6 py-16 text-center">
                <p className="font-mono text-sm text-tmut">
                  No on-chain scan data yet — leaderboards populate as scans run.
                </p>
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
