/**
 * Landing-page chain metadata — static facts only (names, ids, badge assets).
 * Mirror of the server-side ChainKeyToId map in @contracts/rpc.
 */
import { nativeSymbol } from "@contracts/rpc";
export interface ChainMeta {
  id: number;
  key: string;
  name: string;
  badge: string;
}

/** The seven chains the engines support. */
export const SUPPORTED_CHAINS: ChainMeta[] = [
  { id: 1, key: "ethereum", name: "Ethereum", badge: "/chain-eth.svg" },
  { id: 8453, key: "base", name: "Base", badge: "/chain-base.svg" },
  { id: 137, key: "polygon", name: "Polygon", badge: "/chain-poly.svg" },
  { id: 42161, key: "arbitrum", name: "Arbitrum", badge: "/chain-eth.svg" },
  { id: 4663, key: "robinhood", name: "Robinhood", badge: "/chain-robinhood.svg" },
  { id: 57073, key: "ink", name: "Ink", badge: "/chain-ink.svg" },
  { id: 5042, key: "arc", name: "Arc", badge: "/chain-arc.svg" },
];

export function chainMetaById(id: number): ChainMeta | undefined {
  return SUPPORTED_CHAINS.find((c) => c.id === id);
}

export function truncateAddress(a: string): string {
  return a.length <= 12 ? a : `${a.slice(0, 6)}…${a.slice(-4)}`;
}

/** "+1.23 ETH" / "−0.40 ETH" formatting for PnL values. */
export function formatSignedEth(v: number, digits = 2): string {
  const sign = v >= 0 ? "+" : "−";
  return `${sign}${Math.abs(v).toFixed(digits)} ETH`;
}

/**
 * Chain-aware variant: on Arc the native token is USDC ($1-pegged), so
 * per-chain amounts render as "USDC" there and "ETH" everywhere else.
 * Cross-chain aggregates should keep formatSignedEth (mixed units).
 */
export function formatSignedNative(v: number, chainId: number, digits = 2): string {
  const sign = v >= 0 ? "+" : "−";
  return `${sign}${Math.abs(v).toFixed(digits)} ${nativeSymbol(chainId)}`;
}
