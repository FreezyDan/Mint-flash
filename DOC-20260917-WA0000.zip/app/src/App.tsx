import { Routes, Route } from 'react-router'
import Layout from './components/Layout'
import Home from './pages/Home'
import Login from './pages/Login'
import NotFound from './pages/NotFound'
import Dashboard from './pages/Dashboard'
import Features from './pages/Features'
import CopyTrading from './pages/CopyTrading'
import Leaderboard from './pages/Leaderboard'
import Trending from './pages/Trending'
import Pricing from './pages/Pricing'
import Docs from './pages/Docs'
import Terms from './pages/legal/Terms'
import Risk from './pages/legal/Risk'
import Privacy from './pages/legal/Privacy'

export default function App() {
  return (
    <Routes>
      {/* Marketing pages — shared Layout (navbar + CTA band + footer) */}
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/features" element={<Features />} />
        <Route path="/copy-trading" element={<CopyTrading />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="/trending" element={<Trending />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/docs" element={<Docs />} />
        {/* Legal documents */}
        <Route path="/terms" element={<Terms />} />
        <Route path="/risk" element={<Risk />} />
        <Route path="/privacy" element={<Privacy />} />
      </Route>
      {/* Dashboard uses its own sidebar shell — no marketing Layout */}
      <Route path="/app" element={<Dashboard />} />
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
