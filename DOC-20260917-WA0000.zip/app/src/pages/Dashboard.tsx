import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import DashboardShell, { type SectionKey } from "@/components/dashboard/shell";
import Overview from "@/components/dashboard/Overview";
import Tasks from "@/components/dashboard/Tasks";
import TaskWizard from "@/components/dashboard/TaskWizard";
import CopyTrading from "@/components/dashboard/CopyTrading";
import Sweeper from "@/components/dashboard/Sweeper";
import Positions from "@/components/dashboard/Positions";
import Wallets from "@/components/dashboard/Wallets";
import Activity from "@/components/dashboard/Activity";
import Settings from "@/components/dashboard/Settings";
import Upgrade from "@/components/dashboard/Upgrade";
import Admin from "@/components/dashboard/Admin";
import { useEntitlement } from "@/components/dashboard/plan";
import { ToastStack, useToasts } from "@/components/dashboard/shared";

/** Full-screen skeleton while the session resolves. */
function DashboardSkeleton() {
  return (
    <div className="min-h-[100dvh] bg-void">
      <div className="fixed inset-y-0 left-0 w-14 border-r border-hairline bg-panel lg:w-60" />
      <div className="fixed inset-x-0 top-0 h-14 border-b border-hairline bg-void/80" />
      <div className="pl-14 pt-14 lg:pl-60">
        <div className="mx-auto flex max-w-[1180px] flex-col gap-4 px-4 py-8 lg:px-8">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-28 animate-pulse rounded-xl border border-hairline bg-panel" />
            ))}
          </div>
          <div className="h-72 animate-pulse rounded-xl border border-hairline bg-panel" />
        </div>
      </div>
    </div>
  );
}

/**
 * /app — the live bot UI. Auth-gated; renders without the marketing Layout.
 */
export default function Dashboard() {
  const { user, isLoading, logout } = useAuth({ redirectOnUnauthenticated: true });
  const entitlement = useEntitlement();
  const [section, setSection] = useState<SectionKey>("overview");
  const [wizardOpen, setWizardOpen] = useState(false);
  const { toasts, push } = useToasts();

  const stats = trpc.stats.overview.useQuery(undefined, {
    enabled: !!user,
    refetchInterval: 10_000,
  });

  if (isLoading || !user) return <DashboardSkeleton />;

  return (
    <DashboardShell
      active={section}
      onNavigate={setSection}
      onNewTask={() => setWizardOpen(true)}
      user={user}
      logout={logout}
      tasksTotal={stats.data?.tasksTotal ?? 0}
      walletsTotal={stats.data?.walletsTracked ?? 0}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={section}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        >
          {section === "overview" && (
            <Overview onNavigate={setSection} onNewTask={() => setWizardOpen(true)} />
          )}
          {section === "tasks" && (
            <Tasks onNewTask={() => setWizardOpen(true)} pushToast={push} />
          )}
          {section === "copy" && <CopyTrading pushToast={push} onNavigate={setSection} />}
          {section === "sweeper" && <Sweeper pushToast={push} onNavigate={setSection} />}
          {section === "positions" && <Positions pushToast={push} />}
          {section === "wallets" && <Wallets pushToast={push} />}
          {section === "activity" && <Activity />}
          {section === "settings" && <Settings pushToast={push} />}
          {section === "upgrade" && <Upgrade />}
          {section === "admin" && entitlement?.admin && <Admin pushToast={push} />}
        </motion.div>
      </AnimatePresence>

      <TaskWizard
        open={wizardOpen}
        onOpenChange={setWizardOpen}
        pushToast={push}
        onCreated={() => setSection("tasks")}
      />
      <ToastStack toasts={toasts} />
    </DashboardShell>
  );
}
