import Hero from "@/components/home/Hero";
import TickerStrip from "@/components/TickerStrip";
import StatsBand from "@/components/home/StatsBand";
import HowItWorks from "@/components/home/HowItWorks";
import CopySpotlight from "@/components/home/CopySpotlight";
import FeatureGrid from "@/components/home/FeatureGrid";
import LeaderboardPreview from "@/components/home/LeaderboardPreview";
import Testimonials from "@/components/home/Testimonials";
import PricingTeaser from "@/components/home/PricingTeaser";
import FAQ from "@/components/home/FAQ";

/**
 * Landing page (`/`). CTA band + footer are rendered by the marketing Layout.
 */
export default function Home() {
  return (
    <>
      <Hero />
      <TickerStrip />
      <StatsBand />
      <HowItWorks />
      <CopySpotlight />
      <FeatureGrid />
      <LeaderboardPreview />
      <Testimonials />
      <PricingTeaser />
      <FAQ />
    </>
  );
}
