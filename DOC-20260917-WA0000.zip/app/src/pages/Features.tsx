import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import ShowcaseRow from "@/components/features/ShowcaseRow";
import MintEngineTerminal from "@/components/features/MintEngineTerminal";
import LatencyRace from "@/components/features/LatencyRace";
import GasWarfare from "@/components/features/GasWarfare";
import AntiRugVisual from "@/components/features/AntiRugVisual";
import WalletFan from "@/components/features/WalletFan";
import SellDownFlow from "@/components/features/SellDownFlow";
import ChainStrip from "@/components/features/ChainStrip";

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

/** Word-level split for the page H1 (staggered on load). */
function Words({ text, className, delay = 0 }: { text: string; className?: string; delay?: number }) {
  return (
    <span className={className} aria-label={text}>
      {text.split(" ").map((w, i) => (
        <motion.span
          key={i}
          aria-hidden
          className="inline-block will-change-transform"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: delay + i * 0.05, ease: EASE }}
          style={{ whiteSpace: "pre" }}
        >
          {w + (i < text.split(" ").length - 1 ? " " : "")}
        </motion.span>
      ))}
    </span>
  );
}

/**
 * `/features` — deep-dive product page. CTA band + footer come from Layout.
 */
export default function Features() {
  return (
    <>
      {/* S1 — Page header */}
      <section className="relative overflow-hidden pb-20 pt-40 text-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="pointer-events-none absolute inset-0 bg-g-hero-glow"
          aria-hidden
        />
        <div className="container-x relative">
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="eyebrow eyebrow-green"
          >
            [ THE ENGINE ]
          </motion.p>
          <h1 className="mx-auto mt-6 max-w-3xl text-[40px] font-bold leading-[1.05] tracking-[-0.03em] md:text-[60px]">
            <Words text="Built for the first block." delay={0.1} />
            <br />
            <Words text="Every block." delay={0.35} className="text-gradient-profit" />
          </h1>
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.55, ease: EASE }}
            className="mx-auto mt-5 max-w-xl text-[17px] text-tsec"
          >
            Six systems working in parallel so your transaction lands before the
            crowd knows the mint is live.
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.9 }}
            className="mt-14 flex flex-col items-center gap-1 font-mono text-[11px] uppercase tracking-[0.2em] text-tmut"
          >
            scroll
            <motion.span
              animate={{ y: [0, 6, 0] }}
              transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
            >
              <ChevronDown className="h-4 w-4" />
            </motion.span>
          </motion.div>
        </div>
      </section>

      {/* S2 — 01 Auto-Mint Engine */}
      <section className="container-x py-12 md:py-20">
        <ShowcaseRow
          index="01"
          title="The Auto-Mint Engine"
          body="Point MintDash at any ERC-721/1155, Candy Machine, or fair-launch contract. We read mint state directly from the chain — not the project's website — and pre-build your transaction so it's signed and ready to fire."
          chips={["pre-signed tx", "block-subscription", "auto-retry 3×", "reorg detection"]}
        >
          <MintEngineTerminal />
        </ShowcaseRow>
      </section>

      {/* S3 — 02 Mempool Sniping */}
      <section className="container-x py-12 md:py-20">
        <ShowcaseRow
          index="02"
          title="Mempool Sniping"
          body="MintDash subscribes to pending blocks and contract events across private relay networks. When a mint function flips active — a timestamp, a block number, an owner transaction — your tx is already in flight. Frontends are for collectors. You're a sniper."
          chips={["private relays", "mempool watch", "event triggers", "flashbots-style bundles"]}
          reversed
        >
          <LatencyRace />
        </ShowcaseRow>
      </section>

      {/* S4 — 03 Gas Warfare */}
      <section className="container-x py-12 md:py-20">
        <ShowcaseRow
          index="03"
          title="Gas Warfare, Automated"
          body="Stop guessing gwei. MintDash models each drop's competition in real time and sets just enough priority fee to win inclusion without overpaying. God-mode routes through builder bundles when the block is contested."
          chips={["dynamic priority", "bundle routing", "overpay guard", "per-drop profiles"]}
        >
          <GasWarfare />
        </ShowcaseRow>
      </section>

      {/* S5 — 04 Anti-Rug Shield */}
      <section className="container-x py-12 md:py-20">
        <ShowcaseRow
          index="04"
          title="Anti-Rug Shield"
          body="Before a single wei moves, every watched contract is decompiled and scored: hidden mint functions, proxy upgrade traps, honeypot transfer logic, dev wallet concentration. Score above your threshold and the task auto-aborts — with a full report."
          chips={["honeypot detect", "proxy trap scan", "dev concentration", "auto-abort"]}
          reversed
        >
          <AntiRugVisual />
        </ShowcaseRow>
      </section>

      {/* S6 — 05 Multi-Wallet Rotation */}
      <section className="container-x py-12 md:py-20">
        <ShowcaseRow
          index="05"
          title="Multi-Wallet Rotation"
          body="Per-wallet mint limits are a suggestion, not a rule. Spin up to 50 funded wallets per task; MintDash distributes mints, randomizes timing within your window, and consolidates proceeds back to your vault wallet automatically."
          chips={["50 wallets/task", "timing jitter", "auto-consolidate", "vault sweep"]}
        >
          <WalletFan />
        </ShowcaseRow>
      </section>

      {/* S7 — 06 Instant Sell-Down */}
      <section className="container-x py-12 md:py-20">
        <ShowcaseRow
          index="06"
          title="Instant Sell-Down"
          body="Minting is half the trade. Optionally auto-list your fills on major marketplaces at your target multiple or trailing floor, the same block they confirm. Take profit while everyone else is still refreshing metadata."
          chips={["auto-list", "target multiple", "trailing floor", "same-block"]}
          reversed
        >
          <SellDownFlow />
        </ShowcaseRow>
      </section>

      {/* S8 — Multi-chain strip */}
      <ChainStrip />
    </>
  );
}
