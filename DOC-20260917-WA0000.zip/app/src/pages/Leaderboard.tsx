import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import CTABand from "@/components/CTABand";
import LivePulseDot from "@/components/LivePulseDot";
import LeaderboardTable from "@/components/leaderboard/LeaderboardTable";
import GetListed from "@/components/leaderboard/GetListed";
import { trpc } from "@/providers/trpc";

const headerItem = (i: number) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
});

/** `/leaderboard` — top on-chain traders from the scanner snapshot. */
export default function Leaderboard() {
  const [search, setSearch] = useState("");
  const query = trpc.public.leaderboard.useQuery(undefined, { refetchInterval: 60_000 });
  const rows = query.data ?? [];

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((t) => t.address.toLowerCase().includes(q));
  }, [rows, search]);

  const lastScannedAt = rows[0]?.scannedAt ? new Date(rows[0].scannedAt) : null;

  return (
    <>
      {/* S1 — page header */}
      <section className="container-x pb-10 pt-32">
        <motion.p {...headerItem(0)} className="eyebrow eyebrow-green">
          [ SNIPER LEADERBOARD ]
          <LivePulseDot />
        </motion.p>
        <motion.h1
          {...headerItem(1)}
          className="mt-6 max-w-3xl text-[40px] font-bold leading-[1.05] tracking-[-0.03em] md:text-5xl"
        >
          The sharpest wallets on-chain.
        </motion.h1>
        <motion.p {...headerItem(2)} className="mt-4 max-w-xl text-[17px] text-tsec">
          Every wallet below is ranked by the MintDash on-chain scanner from
          public chain data — realized plus unrealized PnL across detected
          flips. No self-reporting, no screenshots.
        </motion.p>
        <motion.div
          {...headerItem(3)}
          className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-xs text-tmut"
        >
          <span>
            {lastScannedAt
              ? `Last scan: ${lastScannedAt.toLocaleString()}`
              : "No scan has run yet"}
          </span>
          <span aria-hidden>·</span>
          <span>{rows.length} wallets ranked</span>
        </motion.div>
        <motion.div {...headerItem(4)} className="relative mt-6 max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-tmut" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by address…"
            className="w-full rounded-lg border border-hairline bg-panel py-2.5 pl-9 pr-3 font-mono text-[13px] text-tpri placeholder:text-tmut focus:border-violet/60 focus:outline-none"
          />
        </motion.div>
      </section>

      {/* S2 — ranked table */}
      <section className="container-x pt-2">
        <div className="card-base p-0">
          {query.isLoading ? (
            <div className="flex flex-col gap-2 p-6">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
              ))}
            </div>
          ) : (
            <LeaderboardTable rows={filtered} />
          )}
        </div>
      </section>

      {/* S3 — get listed band */}
      <GetListed />

      {/* S4 — shared CTA band (Layout only auto-renders it for other routes) */}
      <CTABand />
    </>
  );
}
