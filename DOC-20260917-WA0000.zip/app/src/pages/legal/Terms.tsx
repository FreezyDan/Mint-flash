import LegalDoc from "./LegalDoc";

/** Terms of Service — software-as-a-tool terms for MintDash. */
export default function Terms() {
  return (
    <LegalDoc
      eyebrow="LEGAL / TERMS"
      title="Terms of Service"
      updated="September 2026"
      intro="These Terms of Service govern your use of MintDash, an automation terminal for EVM-chain NFT minting, copy trading, and wallet analytics. By creating an account or using the service you agree to these terms."
      sections={[
        {
          title: "Software as a tool",
          body: (
            <p>
              MintDash is software — a terminal that helps you configure and execute
              on-chain transactions from wallets you control. MintDash is not a broker,
              exchange, custodian, investment advisor, or fund. Nothing in the product,
              documentation, leaderboards, or support channels constitutes financial,
              investment, legal, or tax advice, and nothing is a recommendation to buy,
              sell, or hold any asset.
            </p>
          ),
        },
        {
          title: "No profit guarantees",
          body: (
            <p>
              NFT and crypto-asset trading involves substantial risk, including the total
              loss of funds. Historical performance shown on leaderboards, wallet
              profiles, or copy-trading stats does not predict future results. MintDash
              makes no representation that any task, sniper, or strategy will be
              profitable. You trade entirely at your own risk.
            </p>
          ),
        },
        {
          title: "Your keys, your funds",
          body: (
            <p>
              You are solely responsible for the wallets you connect and for any bot
              vault keys you provision. Managed vault keys are stored encrypted
              (AES-256-GCM) so the execution engine can sign transactions you configure,
              but MintDash never takes custody of your assets and cannot recover lost
              keys, reverse transactions, or retrieve funds sent to a wrong address.
              Transactions broadcast to a blockchain are irreversible.
            </p>
          ),
        },
        {
          title: "Acceptable use",
          body: (
            <p>
              You agree to use MintDash only for lawful purposes and in compliance with
              the rules of the networks, marketplaces, and smart contracts you interact
              with. You may not use the service to defraud other users, manipulate
              markets in violation of applicable law, attack or probe the platform's
              infrastructure, or resell access without permission. We may suspend
              accounts that abuse the service or degrade it for others.
            </p>
          ),
        },
        {
          title: "Service provided as-is",
          body: (
            <p>
              MintDash is provided "as is" and "as available" without warranties of any
              kind, express or implied. We do not guarantee uptime, execution speed,
              fill rates, or the accuracy of on-chain data presented. Blockchain
              networks, RPC providers, and marketplace APIs can fail, congest, or change
              without notice; MintDash is not liable for losses arising from those
              failures, from smart-contract bugs, or from your own configuration
              choices, to the maximum extent permitted by law.
            </p>
          ),
        },
        {
          title: "Plans & billing",
          body: (
            <p>
              The FREE plan includes a 7-day trial of the snipe bot starting at signup,
              with published caps on pending orders and wallets per snipe. PRO is $15
              per month, paid in crypto: you send the amount in ETH/native token on a
              supported EVM chain to the payment address shown on the Upgrade page and
              submit the transaction hash. Access is activated manually after the
              payment is confirmed on-chain — usually within hours. Because activation
              is manual and payments are on-chain, payments are non-refundable once
              confirmed; if a claim is rejected your funds remain in your own wallet.
              PRO access expires 30 days after each confirmed payment unless renewed.
            </p>
          ),
        },
        {
          title: "Changes & termination",
          body: (
            <p>
              We may update these terms, the feature set, or plan pricing at any time;
              material changes will be posted on this page with a new "last updated"
              date. You may stop using MintDash at any time — revoking permissions and
              deleting your vault keys is self-serve from the dashboard. Continued use
              after an update constitutes acceptance of the new terms.
            </p>
          ),
        },
      ]}
    />
  );
}
