import LegalDoc from "./LegalDoc";

/** Risk Disclosure — NFT/EVM execution risks, terminal style. */
export default function Risk() {
  return (
    <LegalDoc
      eyebrow="LEGAL / RISK"
      title="Risk Disclosure"
      updated="September 2026"
      intro="Using MintDash to mint, buy, sell, or copy-trade NFTs and other crypto assets on EVM chains involves significant risk. Read this disclosure carefully and never commit funds you cannot afford to lose."
      sections={[
        {
          title: "NFT & crypto-asset volatility",
          body: (
            <p>
              NFT prices are extremely volatile and can go to zero. Floor prices can gap
              down in minutes, liquidity can disappear entirely, and there may be no
              buyer at any price when you want to sell. Royalties, marketplace policy
              changes, and collection-level events (reveals, delistings, team
              abandonment) can materially affect value without warning.
            </p>
          ),
        },
        {
          title: "Smart-contract risk",
          body: (
            <p>
              You interact with third-party smart contracts that MintDash does not
              control and cannot audit exhaustively. Contracts may contain bugs,
              honeypots, trading blocks, upgradeable proxies, or malicious logic.
              Automated screening (such as the Anti-Rug Shield) reduces but cannot
              eliminate this risk — a "passing" score is not a guarantee of safety.
            </p>
          ),
        },
        {
          title: "Live execution risk",
          body: (
            <p>
              MintDash executes real on-chain transactions only — there is no paper
              mode. Armed tasks and copy-trading rules will spend real funds from your
              bot vault the moment their trigger conditions fire, whether or not you are
              online. Misconfigured gas limits, mint prices, caps, or target contracts
              can cause unintended purchases. Transactions are irreversible once
              confirmed.
            </p>
          ),
        },
        {
          title: "Slippage, gas & failed transactions",
          body: (
            <p>
              Competitive mints and fast-moving floors mean the price you target is not
              always the price you get. Gas fees are paid on every transaction —
              including failed ones — and can spike sharply during congestion. A task
              can spend its full retry budget in gas without ever landing a fill.
            </p>
          ),
        },
        {
          title: "Infrastructure & chain failures",
          body: (
            <p>
              Execution depends on public RPC endpoints, block explorers, marketplace
              APIs, and the underlying EVM networks themselves. Any of these can
              degrade, rate-limit, reorganize, or halt. During such events tasks may
              fire late, miss triggers, or report stale data. MintDash is not
              responsible for losses caused by third-party infrastructure failures.
            </p>
          ),
        },
        {
          title: "Copy trading is not advice",
          body: (
            <p>
              Leaderboards and sniper profiles describe what other wallets did in the
              past. Copying a historically profitable wallet can still lose money —
              strategies decay, wallets change hands, and visible history can be
              manufactured. Performance-fee arrangements do not align outcomes: you
              bear 100% of any loss.
            </p>
          ),
        },
        {
          title: "Key security",
          body: (
            <p>
              Anyone with your vault's private key controls its funds. Keep account
              credentials secret, fund bot vaults only with what a strategy requires,
              and rotate or revoke keys you believe are exposed. MintDash will never
              ask for your seed phrase.
            </p>
          ),
        },
      ]}
    />
  );
}
