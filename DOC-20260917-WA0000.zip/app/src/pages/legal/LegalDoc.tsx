import type { ReactNode } from "react";
import { Link } from "react-router";

export type LegalSection = {
  title: string;
  body: ReactNode;
};

/**
 * Shared legal-document shell — terminal design language: hairline card,
 * mono section markers, max-w-3xl prose column.
 */
export default function LegalDoc({
  eyebrow,
  title,
  updated,
  intro,
  sections,
}: {
  eyebrow: string;
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
}) {
  return (
    <div className="container-x py-16 md:py-24">
      <div className="mx-auto max-w-3xl">
        <p className="eyebrow eyebrow-green">[ {eyebrow} ]</p>
        <h1 className="mt-4 text-[30px] font-bold leading-[1.1] tracking-[-0.025em] text-tpri md:text-[40px]">
          {title}
        </h1>
        <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.18em] text-tmut">
          Last updated: {updated}
        </p>
        <p className="mt-6 text-[15px] leading-relaxed text-tsec">{intro}</p>

        <div className="card-base mt-10 flex flex-col gap-8 p-6 md:p-8">
          {sections.map((s, i) => (
            <section key={s.title}>
              <h2 className="flex items-baseline gap-3 font-display text-[17px] font-semibold text-tpri">
                <span className="font-mono text-[11px] text-violet">
                  {String(i + 1).padStart(2, "0")}
                </span>
                {s.title}
              </h2>
              <div className="mt-3 text-[14px] leading-relaxed text-tsec">{s.body}</div>
            </section>
          ))}
        </div>

        <p className="mt-8 flex flex-wrap items-center gap-4 font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
          <Link to="/terms" className="transition-colors hover:text-tpri">
            Terms of Service
          </Link>
          <span>·</span>
          <Link to="/risk" className="transition-colors hover:text-tpri">
            Risk Disclosure
          </Link>
          <span>·</span>
          <Link to="/privacy" className="transition-colors hover:text-tpri">
            Privacy Policy
          </Link>
        </p>
      </div>
    </div>
  );
}
