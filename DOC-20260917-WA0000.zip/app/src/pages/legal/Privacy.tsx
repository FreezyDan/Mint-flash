import LegalDoc from "./LegalDoc";

/** Privacy Policy — what's stored, what's not, terminal style. */
export default function Privacy() {
  return (
    <LegalDoc
      eyebrow="LEGAL / PRIVACY"
      title="Privacy Policy"
      updated="September 2026"
      intro="This policy explains what MintDash stores about you, why, and — just as importantly — what we never store. The short version: we keep the minimum needed to run your account and your bot."
      sections={[
        {
          title: "Account data we store",
          body: (
            <ul className="list-disc space-y-1.5 pl-5">
              <li>Your email address and display name.</li>
              <li>
                Your password as a salted scrypt hash — never in plaintext, and we
                cannot recover it, only reset it.
              </li>
              <li>
                Your plan status, plan expiry, and payment claims (EVM chain id and
                transaction hash you submit on the Upgrade page).
              </li>
              <li>
                Product configuration you create: mint tasks, sweep rules, copy-trading
                settings, watched wallets, and activity logs.
              </li>
            </ul>
          ),
        },
        {
          title: "Bot vault keys",
          body: (
            <p>
              Managed bot-vault private keys are encrypted with AES-256-GCM before they
              touch the database; only the execution engine can decrypt them, in memory,
              at the moment a transaction you configured is signed. Manually added
              wallets store public addresses only — their keys never reach our
              database at all.
            </p>
          ),
        },
        {
          title: "On-chain public data",
          body: (
            <p>
              Blockchains are public. Wallet addresses, transactions, mints, and trades
              you make are visible to anyone and are indexed by MintDash and by third
              parties (explorers, marketplaces, analytics providers) independently of
              us. Data written to a blockchain cannot be deleted; this policy cannot
              and does not restrict information that is public by design.
            </p>
          ),
        },
        {
          title: "What we never store",
          body: (
            <ul className="list-disc space-y-1.5 pl-5">
              <li>Plaintext private keys.</li>
              <li>Seed phrases / recovery phrases — never ask us to store one, and never share one with anyone claiming to be MintDash.</li>
              <li>Plaintext passwords.</li>
              <li>Payment card or bank details — all plan payments are made on-chain from your own wallet.</li>
            </ul>
          ),
        },
        {
          title: "How we use data",
          body: (
            <p>
              Account and configuration data is used solely to operate the service:
              authenticating you, running your tasks, reviewing payment claims, and
              showing your own activity back to you. We do not sell personal data and
              do not share it with advertisers. Service providers that help run the
              infrastructure (hosting, database) process data only as needed to provide
              the service.
            </p>
          ),
        },
        {
          title: "Retention & deletion",
          body: (
            <p>
              You can delete bot wallets, tasks, and rules from the dashboard at any
              time; encrypted vault keys are destroyed with the wallet row. To delete
              your account and remaining personal data, contact the admin from your
              registered email. Activity logs may be retained briefly for security and
              debugging, then purged. On-chain data is permanent and outside our
              control.
            </p>
          ),
        },
        {
          title: "Changes",
          body: (
            <p>
              If this policy changes, the updated version will be posted on this page
              with a new "last updated" date. Continued use of MintDash after a change
              constitutes acceptance.
            </p>
          ),
        },
      ]}
    />
  );
}
