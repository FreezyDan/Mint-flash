import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/providers/trpc";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

const inputCls =
  "w-full rounded-lg border border-hairline bg-void px-3 py-2.5 font-mono text-[13px] text-tpri placeholder:text-tmut focus:border-violet/60 focus:outline-none focus:ring-1 focus:ring-violet/40 transition-colors";

const labelCls = "mb-1.5 block font-mono text-[11px] uppercase tracking-[0.16em] text-tmut";

export default function Login() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();

  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);

  const onSuccess = async () => {
    setError(null);
    await utils.invalidate();
    navigate("/app");
  };
  const onError = (e: { message: string }) => setError(e.message);

  const login = trpc.creds.login.useMutation({ onSuccess, onError });
  const register = trpc.creds.register.useMutation({ onSuccess, onError });
  const pending = login.isPending || register.isPending;

  const submit = () => {
    setError(null);
    if (mode === "login") {
      login.mutate({ email, password });
    } else {
      register.mutate({ email, password, ...(name.trim() ? { name: name.trim() } : {}) });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-void px-4">
      <Card className="w-full max-w-sm border-hairline bg-panel">
        <CardHeader className="text-center">
          <CardTitle className="font-mono text-tpri">Welcome</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-5">
          {/* Kimi OAuth — unchanged flow */}
          <Button
            className="w-full"
            size="lg"
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
          >
            Sign in with Kimi
          </Button>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <span className="h-px flex-1 bg-hairline" />
            <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
              or continue with email
            </span>
            <span className="h-px flex-1 bg-hairline" />
          </div>

          {/* Email + password form */}
          <form
            className="flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
          >
            {mode === "register" && (
              <div>
                <label className={labelCls}>Name (optional)</label>
                <input
                  className={inputCls}
                  placeholder="sniper"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
              </div>
            )}
            <div>
              <label className={labelCls}>Email</label>
              <input
                className={inputCls}
                type="email"
                required
                placeholder="you@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
              />
            </div>
            <div>
              <label className={labelCls}>Password</label>
              <input
                className={inputCls}
                type="password"
                required
                minLength={mode === "register" ? 8 : 1}
                placeholder={mode === "register" ? "8+ characters" : "••••••••"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={mode === "register" ? "new-password" : "current-password"}
              />
            </div>

            {error && (
              <p className="rounded-lg border border-alarm/40 bg-alarm/10 px-3 py-2 font-mono text-xs leading-relaxed text-alarm">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={pending}
              className="mt-1 w-full rounded-lg bg-g-brand px-4 py-2.5 text-[13px] font-semibold text-white transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-40"
            >
              {pending
                ? "Working…"
                : mode === "login"
                  ? "Sign in"
                  : "Create account"}
            </button>
          </form>

          {/* Mode toggle */}
          <p className="text-center font-mono text-[11px] text-tmut">
            {mode === "login" ? "No account yet?" : "Already registered?"}{" "}
            <button
              type="button"
              onClick={() => {
                setMode(mode === "login" ? "register" : "login");
                setError(null);
              }}
              className="text-violet transition-colors hover:text-tpri"
            >
              {mode === "login" ? "Create account" : "Sign in"}
            </button>
          </p>

          {/* Legal links */}
          <p className="flex items-center justify-center gap-3 font-mono text-[10px] uppercase tracking-[0.18em] text-tmut">
            <Link to="/terms" className="transition-colors hover:text-tpri">
              Terms
            </Link>
            <span>·</span>
            <Link to="/risk" className="transition-colors hover:text-tpri">
              Risk
            </Link>
            <span>·</span>
            <Link to="/privacy" className="transition-colors hover:text-tpri">
              Privacy
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
