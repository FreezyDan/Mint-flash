import { useState } from "react";
import { motion } from "framer-motion";
import PlanCards, { BillingToggle } from "@/components/pricing/PlanCards";
import type { Billing } from "@/components/pricing/PlanCards";
import FeeCalculator from "@/components/pricing/FeeCalculator";
import ComparisonTable from "@/components/pricing/ComparisonTable";
import PricingFAQ from "@/components/pricing/PricingFAQ";
import PricingCTA from "@/components/pricing/PricingCTA";

const headerItem = (i: number) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay: i * 0.09, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
});

/** `/pricing` — 3-tier plans, fee calculator, comparison table, FAQ, CTA. */
export default function Pricing() {
  const [billing, setBilling] = useState<Billing>("monthly");

  return (
    <>
      {/* S1 — header */}
      <section className="container-x pb-14 pt-36 text-center">
        <motion.p {...headerItem(0)} className="eyebrow eyebrow-green">
          [ PRICING ]
        </motion.p>
        <motion.h1
          {...headerItem(1)}
          className="mx-auto mt-6 max-w-3xl text-[40px] font-bold leading-[1.05] tracking-[-0.03em] md:text-[56px]"
        >
          Pay for speed. <span className="text-gradient-profit">Keep the alpha.</span>
        </motion.h1>
        <motion.p {...headerItem(2)} className="mx-auto mt-4 max-w-xl text-[17px] text-tsec">
          Every plan is non-custodial and cancel-anytime. Failed mints never cost
          you a fee.
        </motion.p>
        <motion.div {...headerItem(3)} className="mt-8">
          <BillingToggle billing={billing} onChange={setBilling} />
        </motion.div>
      </section>

      {/* S2 — plan cards */}
      <PlanCards billing={billing} />

      {/* S3 — fee calculator */}
      <FeeCalculator />

      {/* S4 — comparison table */}
      <ComparisonTable />

      {/* S5 — FAQ */}
      <PricingFAQ />

      {/* S6 — CTA variant */}
      <PricingCTA />
    </>
  );
}
