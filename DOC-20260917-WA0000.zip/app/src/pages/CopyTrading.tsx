import { motion } from "framer-motion";
import LivePulseDot from "@/components/LivePulseDot";
import TickerStrip from "@/components/TickerStrip";
import { ButtonLink } from "@/components/Button";
import HowItMirrors from "@/components/copytrading/HowItMirrors";
import SniperShowcase from "@/components/copytrading/SniperShowcase";
import CopySettings from "@/components/copytrading/CopySettings";
import RiskControls from "@/components/copytrading/RiskControls";
import MirroredFeed from "@/components/copytrading/MirroredFeed";
import { trpc } from "@/providers/trpc";

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

/** Real scan-coverage chips from the on-chain scanner — no fabricated stats. */
function ScanStatChips() {
  const stats = trpc.public.scanStats.useQuery(undefined, {
    refetchInterval: 60_000,
    retry: false,
  });
  const d = stats.data;
  if (!d) return null;
  const chips = [
    `${d.chainsScanned} chains scanned`,
    `${d.tradersScanned.toLocaleString()} profitable traders found on-chain`,
    d.lastScannedAt
      ? `last scan ${new Date(d.lastScannedAt).toLocaleString()}`
      : null,
  ].filter((c): c is string => c != null);
  return (
    <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
      {chips.map((s) => (
        <span
          key={s}
          className="tnum rounded-full border border-hairline px-3.5 py-1.5 font-mono text-xs text-tsec"
        >
          {s}
        </span>
      ))}
    </div>
  );
}

/** Marching dashed light-trail overlay for the hero flow image (16s loop). */
function TrailOverlay() {
  const trails = [
    { d: "M 330 150 C 640 150, 780 392, 1010 392", stroke: "#7C5CFF" },
    { d: "M 330 392 L 1010 392", stroke: "#39FF8E" },
    { d: "M 330 634 C 640 634, 780 392, 1010 392", stroke: "#41E6E0" },
  ];
  return (
    <svg
      viewBox="0 0 1400 800"
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
    >
      {trails.map((t, i) => (
        <motion.path
          key={i}
          d={t.d}
          fill="none"
          stroke={t.stroke}
          strokeWidth="2"
          strokeDasharray="10 10"
          opacity="0.85"
          animate={{ strokeDashoffset: [0, -400] }}
          transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
        />
      ))}
    </svg>
  );
}

function Stagger({
  children,
  i,
  className,
}: {
  children: React.ReactNode;
  i: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: i * 0.09, ease: EASE }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/**
 * `/copy-trading` — the copy-trade product page.
 * CTA band + footer come from the marketing Layout.
 */
export default function CopyTrading() {
  return (
    <>
      {/* S1 — Hero */}
      <section className="relative overflow-hidden pt-36">
        <div className="pointer-events-none absolute inset-0 bg-g-hero-glow" aria-hidden />
        <div className="container-x relative text-center">
          <Stagger i={0}>
            <p className="eyebrow eyebrow-violet">
              <LivePulseDot />
              [ COPY TRADING ENGINE ]
            </p>
          </Stagger>
          <Stagger i={1}>
            <h1 className="mx-auto mt-6 max-w-3xl text-[40px] font-bold leading-[1.05] tracking-[-0.03em] md:text-[60px]">
              Their alpha. <span className="text-gradient-profit">Your wallet.</span>
            </h1>
          </Stagger>
          <Stagger i={2}>
            <p className="mx-auto mt-5 max-w-2xl text-[17px] text-tsec">
              MintDash ranks thousands of sniper wallets by verified on-chain
              profit. Choose who to mirror, set your limits, and every mint they
              make fires from your wallet in ~412ms — automatically.
            </p>
          </Stagger>
          <Stagger i={3}>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <ButtonLink to="/app">Start Copying</ButtonLink>
              <ButtonLink to="/leaderboard" variant="ghost">
                Browse leaderboard
              </ButtonLink>
            </div>
          </Stagger>
          <Stagger i={4}>
            <ScanStatChips />
          </Stagger>

          {/* Flow illustration with violet glow bloom + marching trail overlay */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.35, ease: EASE }}
            className="relative mx-auto mt-14 max-w-[1000px]"
          >
            <div
              className="pointer-events-none absolute -inset-10 bg-g-hero-glow"
              aria-hidden
            />
            <img
              src="/copy-flow.png"
              alt="Leader wallets mirroring into a user wallet automatically"
              className="relative block w-full"
            />
            <TrailOverlay />
          </motion.div>
        </div>
      </section>

      {/* Shared live mint ticker (global design: home + copy-trading) */}
      <div className="mt-16">
        <TickerStrip />
      </div>

      {/* S2 — How mirroring works */}
      <HowItMirrors />

      {/* S3 — Top snipers */}
      <SniperShowcase />

      {/* S4 — Copy settings walkthrough */}
      <CopySettings />

      {/* S5 — Risk controls */}
      <RiskControls />

      {/* S6 — Live mirrored-mints feed */}
      <MirroredFeed />
    </>
  );
}
