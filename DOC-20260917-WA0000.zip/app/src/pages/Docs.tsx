import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router";
import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { ArrowRight, Search } from "lucide-react";
import Reveal from "@/components/Reveal";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import CodeBlock, { type CodeLine } from "@/components/docs/CodeBlock";
import MiniFeed from "@/components/docs/MiniFeed";
import { cn } from "@/lib/utils";
import { CHANGELOG, DOCS_NAV, DOCS_SECTIONS, FAQS, GUIDES } from "@/data/docs";

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

function scrollToAnchor(anchor: string) {
  document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ------------------------------------------------------------------ */
/* Docs sidebar                                                        */
/* ------------------------------------------------------------------ */

function DocsSidebar({
  active,
  onSelect,
}: {
  active: string;
  onSelect: (anchor: string) => void;
}) {
  return (
    <>
      {/* Desktop: sticky two-pane sidebar */}
      <aside className="sticky top-24 hidden w-56 shrink-0 self-start lg:block">
        <nav className="flex flex-col gap-6">
          {DOCS_NAV.map((g) => (
            <div key={g.group}>
              <p className="mb-2 font-mono text-[10px] uppercase tracking-[0.2em] text-tmut">
                {g.group}
              </p>
              <ul className="flex flex-col">
                {g.items.map((item) => {
                  const isActive = active === item.anchor;
                  return (
                    <li key={item.label}>
                      <button
                        onClick={() => onSelect(item.anchor)}
                        className={cn(
                          "relative w-full border-l-2 py-1.5 pl-3 text-left text-sm font-medium transition-colors",
                          isActive
                            ? "border-violet text-tpri"
                            : "border-transparent text-tmut hover:text-tpri",
                        )}
                      >
                        {item.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>
      </aside>

      {/* Mobile: horizontal chip row */}
      <div className="mb-8 flex gap-2 overflow-x-auto pb-2 lg:hidden">
        {[
          { anchor: "quickstart", label: "Quickstart" },
          { anchor: "guides", label: "Guides" },
          { anchor: "api", label: "API" },
          { anchor: "changelog", label: "Changelog" },
          { anchor: "faq", label: "FAQ" },
        ].map(({ anchor: a, label }) => (
          <button
            key={a}
            onClick={() => onSelect(a)}
            className={cn(
              "shrink-0 rounded-full border px-3.5 py-1.5 font-mono text-xs transition-colors",
              active === a
                ? "border-violet/60 bg-violet/10 text-tpri"
                : "border-hairline bg-panel text-tmut",
            )}
          >
            {label}
          </button>
        ))}
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Quickstart                                                          */
/* ------------------------------------------------------------------ */

const STEP_CODE: CodeLine[][] = [
  [
    { text: "connect 0xdegen…42Ff", tone: "prompt" },
    { text: "✓ session scoped: mint-only", tone: "success" },
  ],
  [
    { text: "task create --contract 0x3f2a…c81d --wallets 3 --gas degen", tone: "prompt" },
    { text: "✓ contract verified · ERC-721 · supply 8,888", tone: "success" },
    { text: "✓ risk score 12/100 — clean", tone: "success" },
    { text: "task #0471 armed", tone: "out" },
  ],
  [
    { text: "copy 0x7a3F…9e2B --size 0.1eth --cap 1.5eth/day --stop-loss -20%", tone: "prompt" },
    { text: "✓ mirroring live · median delay 412ms", tone: "success" },
  ],
];

const STEPS = [
  {
    id: "qs-step-1",
    title: "Connect your wallet",
    body: "MintDash never takes custody. You sign a scoped session that can only execute tasks you explicitly arm — revoke it on-chain at any time.",
    code: STEP_CODE[0],
  },
  {
    id: "qs-step-2",
    title: "Create your first task",
    body: "Point a task at a contract, pick your wallets and a gas preset. The engine verifies the contract, scans it with the Anti-Rug Shield, then waits for your go-live trigger.",
    code: STEP_CODE[1],
  },
  {
    id: "qs-step-3",
    title: "Or copy a sniper",
    body: "Rather ride someone else's alpha? Watch any profitable wallet and mirror its mints and buys into your own — with per-trade size, daily caps and a stop-loss on top.",
    code: STEP_CODE[2],
  },
  {
    id: "qs-step-4",
    title: "Watch the fills",
    body: "Every confirmed mint, fired task and mirrored copy lands in the dashboard's live activity feed in real time. This is what it looks like:",
    code: null,
  },
] as const;

function Quickstart() {
  return (
    <section id="quickstart" className="scroll-mt-24">
      <Reveal>
        <h2 className="font-display text-[32px] font-semibold leading-tight tracking-[-0.025em] text-tpri">
          Quickstart
        </h2>
        <p className="mt-2 text-[16px] text-tsec">
          Four steps between you and your first sniped mint. Everything below also works from the
          dashboard UI — the commands are just shorthand.
        </p>
      </Reveal>
      <div className="mt-8 flex flex-col gap-5">
        {STEPS.map((s, i) => (
          <Reveal key={s.id} delay={0.05 * i}>
            <div id={s.id} className="card-base scroll-mt-24 p-5">
              <div className="flex items-baseline gap-3">
                <span className="font-mono text-xs text-violet">0{i + 1}</span>
                <h3 className="font-display text-[19px] font-semibold text-tpri">{s.title}</h3>
              </div>
              <p className="mt-2 text-[14px] leading-relaxed text-tsec">{s.body}</p>
              <div className="mt-4">
                {s.code ? <CodeBlock lines={s.code as CodeLine[]} typing /> : <MiniFeed />}
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Guides grid                                                         */
/* ------------------------------------------------------------------ */

const CATEGORY_CLS: Record<string, string> = {
  Tasks: "border-violet/40 text-violet",
  "Copy trading": "border-cyan/40 text-cyan",
  Safety: "border-neon/40 text-neon",
};

function Guides({ query }: { query: string }) {
  const q = query.trim().toLowerCase();
  const matches = (g: (typeof GUIDES)[number]) =>
    !q ||
    g.title.toLowerCase().includes(q) ||
    g.summary.toLowerCase().includes(q) ||
    g.category.toLowerCase().includes(q);
  const visible = GUIDES.filter(matches);

  return (
    <section id="guides" className="mt-20 scroll-mt-24">
      <Reveal>
        <h2 className="font-display text-[32px] font-semibold leading-tight tracking-[-0.025em] text-tpri">
          Guides
        </h2>
        <p className="mt-2 text-[16px] text-tsec">
          Deeper dives on gas, rotation, sniper selection and safety.
          {q && (
            <span className="ml-2 font-mono text-xs text-violet">
              {visible.length} match{visible.length === 1 ? "" : "es"} for “{query.trim()}”
            </span>
          )}
        </p>
      </Reveal>
      <motion.div layout className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <AnimatePresence mode="popLayout">
          {visible.map((g, i) => (
            <motion.article
              layout
              key={g.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, height: 0, marginBottom: -16, overflow: "hidden" }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.35, delay: 0.05 * (i % 4), ease: EASE }}
              className="card-base card-hover group cursor-pointer p-5"
            >
              <span
                className={cn(
                  "inline-block rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.14em]",
                  CATEGORY_CLS[g.category],
                )}
              >
                {g.category}
              </span>
              <h3 className="mt-3 font-display text-[17px] font-semibold leading-snug text-tpri">
                {g.title}
              </h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-tsec">{g.summary}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="font-mono text-[11px] text-tmut">{g.minutes} min read</span>
                <ArrowRight className="h-4 w-4 text-tmut transition-all duration-200 group-hover:translate-x-1 group-hover:text-violet" />
              </div>
            </motion.article>
          ))}
        </AnimatePresence>
      </motion.div>
      {visible.length === 0 && (
        <p className="mt-6 rounded-lg border border-dashed border-hairline px-4 py-8 text-center font-mono text-xs text-tmut">
          no guides match “{query.trim()}” — try “gas”, “stop-loss” or “sniper”
        </p>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* API teaser                                                          */
/* ------------------------------------------------------------------ */

function ApiTeaser() {
  return (
    <section id="api" className="mt-20 scroll-mt-24">
      <div className="grid grid-cols-1 items-center gap-8 lg:grid-cols-2">
        <Reveal>
          <p className="eyebrow eyebrow-violet">[ API ]</p>
          <h2 className="mt-4 font-display text-[32px] font-semibold leading-tight tracking-[-0.025em] text-tpri">
            Build on the bot.
          </h2>
          <p className="mt-3 text-[16px] leading-relaxed text-tsec">
            Everything the dashboard does is available over REST and WebSocket — arm tasks, stream
            fills, manage copies. Whale plans include a dedicated key with 120 req/s.
          </p>
          <a
            href="#api"
            onClick={(e) => e.preventDefault()}
            className="mt-4 inline-block font-mono text-sm text-cyan hover:underline"
          >
            Full API reference →
          </a>
        </Reveal>
        <motion.div
          initial={{ opacity: 0, x: 32 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.45, ease: EASE }}
          className="relative"
        >
          <div className="rounded-xl border border-hairline bg-panel p-5 font-mono text-[12.5px] leading-relaxed">
            <p className="text-tmut">
              <span className="text-violet">POST</span> /v1/tasks
            </p>
            <pre className="mt-2 whitespace-pre-wrap text-tsec">
{`{
  `}<span className="text-violet">"contract"</span>{`: `}<span className="text-neon">"0x3f2a…c81d"</span>{`,
  `}<span className="text-violet">"wallets"</span>{`: `}<span className="text-amber">3</span>{`,
  `}<span className="text-violet">"gas"</span>{`: `}<span className="text-neon">"degen"</span>{`,
  `}<span className="text-violet">"trigger"</span>{`: `}<span className="text-neon">"goLive"</span>{`
}`}
            </pre>
            <div className="mt-4 flex items-center gap-3 border-t border-hairline pt-4">
              <motion.span
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3, type: "spring", stiffness: 380, damping: 14 }}
                className="rounded-full border border-neon/40 bg-neon/10 px-2.5 py-0.5 font-mono text-[11px] font-bold text-neon"
              >
                201
              </motion.span>
              <code className="text-tsec">
                {`{`}<span className="text-violet">"task_id"</span>{`:`}<span className="text-neon">"0472"</span>{`,`}{" "}
                <span className="text-violet">"status"</span>{`:`}<span className="text-neon">"armed"</span>{`}`}
              </code>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Changelog — scroll-scrubbed timeline                                */
/* ------------------------------------------------------------------ */

function Changelog() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.8", "end 0.55"],
  });
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 26, mass: 0.4 });

  return (
    <section id="changelog" className="mt-20 scroll-mt-24">
      <Reveal>
        <h2 className="font-display text-[32px] font-semibold leading-tight tracking-[-0.025em] text-tpri">
          Changelog
        </h2>
      </Reveal>
      <div ref={ref} className="relative mt-8 pl-8">
        {/* Track */}
        <div className="absolute bottom-2 left-[5px] top-2 w-0.5 bg-hairline" />
        <motion.div
          style={{ scaleY }}
          className="absolute bottom-2 left-[5px] top-2 w-0.5 origin-top bg-neon"
        />
        <ol className="flex flex-col gap-8">
          {CHANGELOG.map((c, i) => (
            <motion.li
              key={c.version}
              initial={{ opacity: 0, x: 16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.4, delay: 0.08 * i, ease: EASE }}
              className="relative"
            >
              <motion.span
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ type: "spring", stiffness: 420, damping: 15, delay: 0.08 * i }}
                className="absolute -left-8 top-1.5 h-3 w-3 rounded-full border-2 border-neon bg-void"
              />
              <div className="flex flex-wrap items-center gap-3">
                <span className="tnum font-mono text-xs text-tmut">{c.date}</span>
                <span className="rounded-full border border-violet/50 px-2 py-0.5 font-mono text-[10px] font-medium text-violet">
                  {c.version}
                </span>
                <h3 className="font-display text-[16px] font-semibold text-tpri">{c.title}</h3>
              </div>
              <ul className="mt-1.5 flex flex-col gap-0.5">
                {c.bullets.map((b) => (
                  <li key={b} className="font-mono text-[12px] text-tsec">
                    {b}
                  </li>
                ))}
              </ul>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* FAQ + CTA                                                           */
/* ------------------------------------------------------------------ */

function Faq() {
  return (
    <section id="faq" className="mt-20 scroll-mt-24">
      <Reveal>
        <h2 className="font-display text-[32px] font-semibold leading-tight tracking-[-0.025em] text-tpri">
          FAQ
        </h2>
      </Reveal>
      <Reveal delay={0.08}>
        <Accordion type="single" collapsible className="mt-6 rounded-xl border border-hairline bg-panel px-5">
          {FAQS.map((f, i) => (
            <AccordionItem key={f.q} value={`faq-${i}`} className="border-hairline">
              <AccordionTrigger className="text-[15px] font-medium text-tpri hover:no-underline">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="text-[14px] leading-relaxed text-tsec">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </Reveal>
    </section>
  );
}

function DocsCta() {
  return (
    <section className="relative mt-24 overflow-hidden rounded-2xl border border-hairline bg-panel px-6 py-16 text-center">
      <div className="bg-g-hero-glow pointer-events-none absolute inset-0" aria-hidden />
      <Reveal className="relative">
        <h2 className="font-display text-3xl font-bold tracking-[-0.025em] text-tpri md:text-4xl">
          Arm your first task.
        </h2>
        <p className="mx-auto mt-3 max-w-md text-[15px] text-tsec">
          The quickstart takes five minutes. The first snipe takes about 400 milliseconds.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <Link
            to="/app"
            className="rounded-lg bg-g-brand px-6 py-3 text-[15px] font-semibold text-white transition-all duration-150 hover:shadow-glow-violet hover:brightness-110 active:scale-[0.97]"
          >
            Launch the App
          </Link>
          <button
            onClick={() => scrollToAnchor("quickstart")}
            className="rounded-lg border border-hairline px-6 py-3 text-[15px] font-semibold text-tpri transition-colors hover:border-violet/45 hover:bg-white/5"
          >
            Read the quickstart
          </button>
        </div>
      </Reveal>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function Docs() {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [active, setActive] = useState<string>("quickstart");
  const searchRef = useRef<HTMLInputElement>(null);

  // 150ms debounce for live guide filtering.
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 150);
    return () => clearTimeout(t);
  }, [query]);

  // ⌘K focuses search.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Track active section on scroll.
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive(e.target.id);
        }
      },
      { rootMargin: "-30% 0px -55% 0px" },
    );
    DOCS_SECTIONS.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  const navActive = useMemo(
    () => (active.startsWith("qs-step") ? "quickstart" : active),
    [active],
  );

  return (
    <div className="container-x pb-24 pt-12">
      {/* S1. Header */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="relative"
      >
        <div className="bg-g-hero-glow pointer-events-none absolute -inset-8 opacity-60" aria-hidden />
        <img
          src="/docs-hero.png"
          alt="MintDash documentation"
          className="relative h-56 w-full rounded-xl border border-hairline object-cover"
        />
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.5, ease: EASE }}
        className="mt-10"
      >
        <p className="eyebrow eyebrow-green">[ DOCUMENTATION ]</p>
        <h1 className="mt-5 max-w-2xl font-display text-[34px] font-bold leading-[1.08] tracking-[-0.03em] text-tpri md:text-[44px]">
          Zero to first snipe in five minutes.
        </h1>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.28, duration: 0.4, ease: EASE }}
        className="relative mt-7 max-w-2xl"
      >
        <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-tmut" />
        <input
          ref={searchRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search the docs…"
          className="w-full rounded-lg border border-hairline bg-panel py-3.5 pl-11 pr-16 font-mono text-sm text-tpri placeholder:text-tmut focus:border-violet/60 focus:outline-none focus:ring-1 focus:ring-violet/40"
        />
        <kbd className="absolute right-4 top-1/2 -translate-y-1/2 rounded border border-hairline bg-panel2 px-1.5 py-0.5 font-mono text-[10px] text-tmut">
          ⌘K
        </kbd>
      </motion.div>

      {/* S2. Two-pane shell */}
      <div className="mt-14 flex gap-10">
        <DocsSidebar
          active={navActive}
          onSelect={(a) => {
            setActive(a);
            scrollToAnchor(a);
          }}
        />
        <div className="min-w-0 max-w-3xl flex-1">
          <Quickstart />
          <Guides query={debounced} />
          <ApiTeaser />
          <Changelog />
          <Faq />
        </div>
      </div>

      <DocsCta />
    </div>
  );
}
