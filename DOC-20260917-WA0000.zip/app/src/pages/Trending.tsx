import { motion } from "framer-motion";
import CTABand from "@/components/CTABand";
import LivePulseDot from "@/components/LivePulseDot";
import { chainMetaById, truncateAddress } from "@/lib/chains";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";

const headerItem = (i: number) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
});

function lastMintLabel(ts: number): string {
  const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 5) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

/** Velocity cell — m1 flashes neon while mints are landing right now. */
function VelocityCell({ value, hot }: { value: number; hot?: boolean }) {
  return (
    <td className="tnum px-4 py-3 font-mono text-sm">
      <span
        className={cn(
          "rounded px-1.5 py-0.5",
          hot && value > 0
            ? "animate-pulse bg-neon/15 font-semibold text-neon"
            : value > 0
              ? "text-tsec"
              : "text-tmut/60",
        )}
      >
        {value}
      </span>
    </td>
  );
}

/**
 * `/trending` — live "Minting Now" feed: contracts ranked by mint velocity
 * from the seven-chain watcher snapshot (10s poll).
 */
export default function Trending() {
  const query = trpc.public.trendingMints.useQuery(undefined, { refetchInterval: 10_000 });
  const rows = query.data ?? [];

  return (
    <>
      {/* S1 — page header */}
      <section className="container-x pb-10 pt-32">
        <motion.p {...headerItem(0)} className="eyebrow eyebrow-green">
          [ MINTING NOW ]
          <LivePulseDot />
        </motion.p>
        <motion.h1
          {...headerItem(1)}
          className="mt-6 max-w-3xl text-[40px] font-bold leading-[1.05] tracking-[-0.03em] md:text-5xl"
        >
          Live mint velocity, seven chains.
        </motion.h1>
        <motion.p {...headerItem(2)} className="mt-4 max-w-xl text-[17px] text-tsec">
          The MintDash watcher tails ERC-721 mint logs across Ethereum, Base,
          Arbitrum, Polygon, Robinhood, Ink and Arc — ranking the collections
          degens are minting right now. Straight from the chain, no API keys.
        </motion.p>
        <motion.div
          {...headerItem(3)}
          className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-xs text-tmut"
        >
          <span>7 chains watched</span>
          <span aria-hidden>·</span>
          <span>{rows.length} collections minting</span>
          <span aria-hidden>·</span>
          <span>refreshes every 10s</span>
        </motion.div>
      </section>

      {/* S2 — live table */}
      <section className="container-x pt-2">
        <div className="card-base p-0">
          {query.isLoading ? (
            <div className="flex flex-col gap-2 p-6">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="h-12 animate-pulse rounded-lg bg-panel2" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] text-left">
                <thead>
                  <tr className="border-b border-hairline font-mono text-[11px] uppercase tracking-[0.14em] text-tmut">
                    <th className="py-3 pl-6 pr-4 font-medium">Rank</th>
                    <th className="px-4 py-3 font-medium">Chain</th>
                    <th className="px-4 py-3 font-medium">Collection</th>
                    <th className="px-4 py-3 font-medium">1m</th>
                    <th className="px-4 py-3 font-medium">5m</th>
                    <th className="px-4 py-3 font-medium">15m</th>
                    <th className="px-4 py-3 font-medium">1h</th>
                    <th className="px-4 py-3 font-medium">Minters 15m</th>
                    <th className="py-3 pl-4 pr-6 font-medium">Last mint</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r, i) => {
                    const chain = chainMetaById(r.chainId);
                    return (
                      <motion.tr
                        key={`${r.chainId}-${r.contract}`}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{
                          duration: 0.3,
                          delay: Math.min(i, 12) * 0.035,
                          ease: [0.16, 1, 0.3, 1],
                        }}
                        className="h-14 border-b border-hairline/60 transition-colors last:border-0 hover:bg-panel2"
                      >
                        {/* Rank */}
                        <td className="pl-6 pr-4">
                          <span
                            className={cn(
                              "tnum inline-flex min-w-9 items-center justify-center rounded-md border px-1.5 py-0.5 font-mono text-xs font-bold",
                              i === 0
                                ? "border-neon/30 bg-neon/10 text-neon"
                                : i < 3
                                  ? "border-amber/30 bg-amber/10 text-amber"
                                  : "border-transparent text-tmut",
                            )}
                          >
                            #{i + 1}
                          </span>
                        </td>
                        {/* Chain */}
                        <td className="px-4 py-3">
                          {chain && (
                            <span className="flex items-center gap-1.5">
                              <img
                                src={chain.badge}
                                alt={chain.name}
                                title={chain.name}
                                className="h-4 w-4 opacity-80"
                                loading="lazy"
                              />
                              <span className="font-mono text-xs text-tmut">{chain.name}</span>
                            </span>
                          )}
                        </td>
                        {/* Collection */}
                        <td className="px-4 py-3">
                          <span className="flex flex-col">
                            <span className="text-sm font-medium text-tpri">
                              {r.name ?? truncateAddress(r.contract)}
                            </span>
                            <span className="font-mono text-[11px] text-tmut">
                              {r.name
                                ? `${r.symbol ? `${r.symbol} · ` : ""}${truncateAddress(r.contract)}`
                                : (r.symbol ?? "")}
                            </span>
                          </span>
                        </td>
                        {/* Velocity windows — m1 flashes neon while hot */}
                        <VelocityCell value={r.m1} hot />
                        <VelocityCell value={r.m5} />
                        <VelocityCell value={r.m15} />
                        <VelocityCell value={r.h1} />
                        {/* Unique minters */}
                        <td className="tnum px-4 py-3 font-mono text-sm text-cyan">
                          {r.uniqueMinters15m}
                        </td>
                        {/* Last mint */}
                        <td className="py-3 pl-4 pr-6">
                          <span className="font-mono text-xs text-tmut">
                            {lastMintLabel(r.lastMintTs)}
                          </span>
                        </td>
                      </motion.tr>
                    );
                  })}
                  {rows.length === 0 && (
                    <tr>
                      <td colSpan={9} className="px-6 py-16 text-center">
                        <p className="font-mono text-sm text-tmut">
                          Watcher is warming up — live mint activity across 6 EVM
                          chains appears here within a minute.
                        </p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* S3 — shared CTA band (Layout only auto-renders it for other routes) */}
      <CTABand />
    </>
  );
}
