/** Local content for the Docs hub — no backend required. */

export interface DocsNavGroup {
  group: string;
  items: { label: string; anchor: string }[];
}

export const DOCS_NAV: DocsNavGroup[] = [
  {
    group: "Getting started",
    items: [
      { label: "Quickstart", anchor: "quickstart" },
      { label: "Connecting wallets", anchor: "qs-step-1" },
      { label: "Funding & vaults", anchor: "qs-step-4" },
    ],
  },
  {
    group: "Tasks",
    items: [
      { label: "Creating a task", anchor: "qs-step-2" },
      { label: "Gas strategies", anchor: "guides" },
      { label: "Multi-wallet setup", anchor: "guides" },
    ],
  },
  {
    group: "Copy trading",
    items: [
      { label: "Choosing snipers", anchor: "qs-step-3" },
      { label: "Limits & stop-loss", anchor: "guides" },
      { label: "Mirror sells", anchor: "changelog" },
    ],
  },
  {
    group: "Safety",
    items: [
      { label: "Anti-Rug Shield", anchor: "guides" },
      { label: "Permissions model", anchor: "faq" },
      { label: "Revoking access", anchor: "faq" },
    ],
  },
  {
    group: "API",
    items: [
      { label: "Authentication", anchor: "api" },
      { label: "REST endpoints", anchor: "api" },
      { label: "WebSockets", anchor: "api" },
    ],
  },
];

/** Main anchors observed for sidebar active state. */
export const DOCS_SECTIONS = ["quickstart", "guides", "api", "changelog", "faq"] as const;

export interface DocsGuide {
  title: string;
  category: "Tasks" | "Copy trading" | "Safety";
  summary: string;
  minutes: number;
}

export const GUIDES: DocsGuide[] = [
  {
    title: "Gas strategies explained",
    category: "Tasks",
    summary: "When to Chill, when to go God-mode, and what it costs.",
    minutes: 8,
  },
  {
    title: "Bypassing per-wallet limits",
    category: "Tasks",
    summary: "Multi-wallet rotation without getting sybil-flagged.",
    minutes: 6,
  },
  {
    title: "Reading the leaderboard",
    category: "Copy trading",
    summary: "Win rate vs PnL: which stats actually predict future alpha.",
    minutes: 7,
  },
  {
    title: "Setting a sane stop-loss",
    category: "Copy trading",
    summary: "Auto-unfollow rules that protect your stack.",
    minutes: 5,
  },
  {
    title: "How the Anti-Rug Shield scores contracts",
    category: "Safety",
    summary: "What we scan, what we miss, and how to read a report.",
    minutes: 9,
  },
  {
    title: "Revoking MintDash permissions",
    category: "Safety",
    summary: "One click, on-chain, immediate.",
    minutes: 3,
  },
];

export interface ChangelogEntry {
  date: string;
  version: string;
  title: string;
  bullets: string[];
}

export const CHANGELOG: ChangelogEntry[] = [
  {
    date: "2025-06-02",
    version: "v2.4",
    title: "Base chain support live",
    bullets: ["+ chain badge filters", "+ 40ms faster block subscription"],
  },
  {
    date: "2025-05-18",
    version: "v2.3",
    title: "Mirror sells",
    bullets: ["copy sells with trailing floor", "+ auto-list on detected flips"],
  },
  {
    date: "2025-05-02",
    version: "v2.2",
    title: "Anti-Rug Shield v2",
    bullets: ["proxy-trap detection", "dev-concentration scoring"],
  },
  {
    date: "2025-04-11",
    version: "v2.1",
    title: "Failed-gas reimbursement for Pro",
    bullets: ["gas refunded on sold-out fires", "+ per-task retry budgets"],
  },
];

export const FAQS: { q: string; a: string }[] = [
  {
    q: "Do I need to code?",
    a: "No — everything works from the dashboard. Tasks, copy-trading, wallets and settings are all point-and-click. The API is optional and aimed at Whale-plan power users.",
  },
  {
    q: "Where do tasks run?",
    a: "On MintDash infrastructure. Armed tasks execute from our low-latency runners next to block builders — closing your laptop doesn't stop anything.",
  },
  {
    q: "What wallets are supported?",
    a: "Any EVM wallet for signing in and funding. Bot execution wallets are provisioned per account; private keys live only in the server environment, never in the browser or database.",
  },
  {
    q: "How do I pay for PRO?",
    a: "With crypto, directly on-chain. Send $15 worth of ETH/native token to the payment address shown on the Upgrade page — any supported EVM chain works (Ethereum, Base, Arbitrum, Polygon, Robinhood, Ink, Arc) — then paste the transaction hash into the claim form. The admin confirms the payment on-chain and activates PRO for 30 days, usually within hours. There is no card checkout and no payment processor involved.",
  },
  {
    q: "Which chains does MintDash support?",
    a: "EVM chains only: Ethereum, Base, Arbitrum, Polygon, Robinhood, Ink, and Arc. Sniping, copy trading, floor sweeping, and PRO payments all run on these seven EVM networks — Arc included (OpenSea and Seaport have been live on Arc since mainnet day one; prices there are USDC-denominated).",
  },
  {
    q: "Is there a testnet mode?",
    a: "No — MintDash executes real on-chain transactions only. Every task fires from your bot vault with real funds, so size your caps accordingly. Nothing is ever paper-traded or faked.",
  },
];
