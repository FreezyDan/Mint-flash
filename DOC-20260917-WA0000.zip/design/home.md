# Home Page (`/`) — Landing

The flagship page. Goal: instantly communicate "this is a serious, live, money-making machine" — dense live data, terminal aesthetics, and a cinematic scroll story. ~10 sections.

**Global page behavior**: Lenis smooth scroll. Grid + noise background layer. One pinned ScrollTrigger sequence (How It Works). Hero uses the site's only Three.js scene.

---

## S1. Hero — "The Minting Terminal"

**Layout**: Full viewport height (min-h-screen), split layout — left 55% copy, right 45% visual. Behind everything: a Three.js particle field of ~1200 tiny points forming a slowly rotating torus/grid hybrid, colored in violet with sparse green points, reacting subtly to cursor (parallax tilt ±8°). Radial `g-hero-glow` behind. CSS fallback: static radial gradient + grid texture.

**Content (left)**:
- Eyebrow: `[ LIVE ON ETH · SOL · BASE · POLYGON ]` with live pulse dot (mono 12px, green).
- H1 (Space Grotesk 700, 76px): "Mint first. **Ask never.**" — "Mint first." in `text-primary`, "Ask never." in gradient green→cyan. Character-level split animation on load.
- Subhead (Inter 17px, `text-secondary`, max-w-md): "MintDash is the auto-mint bot that fires your transaction the millisecond a drop goes live — and copies the wallets of the most profitable NFT snipers on-chain, automatically."
- CTA row: Primary button "Launch the Bot" (g-brand) + ghost button "See live snipers ↗". Both with tap-scale micro-interactions.
- Trust strip (mono 12px, `text-muted`, separated by `·`): `142,908 mints executed` · `0 failed-tx protection` · `avg 412ms to block inclusion`.

**Content (right)**: Terminal card (`hero-terminal.png` fallback; ideally built as live HTML):
- Chrome bar: three dots (red/amber/green) + `mintdash — task #0471` mono 12px.
- Body (JetBrains Mono 13px, syntax colored): lines like
  `▸ watching  0x3f2a…c81d  [Degen Apes S2]`
  `▸ goLive detected — block 21,447,902`
  `✓ MINT CONFIRMED  +3 NFTs  gas 0.0021 ETH  398ms` (green)
  `▸ copying wallet 0x7a3F…9e2B (30d PnL +84.2 ETH)` (cyan)
- New lines append every ~2s (typewriter, 18ms/char), old lines scroll up; capped at 8 visible lines. A blinking block cursor at the bottom.

**Animation**:
- On load: particle field fades in (opacity 0→1, 800ms) → H1 chars stagger in (24ms each, y 0.6em→0, rotate 4°→0, 500ms `power3.out`) → subhead + CTAs fade up (y 20px, stagger 100ms) → terminal card slides in from right (x 60px→0, 600ms, 300ms delay) → first terminal line types at 700ms.
- Scroll: hero content parallaxes up at 0.6× scroll speed, particle field at 0.3×; whole hero fades to 40% opacity by 80% scroll-out.

---

## S2. Live Mint Ticker

**Layout**: Full-bleed strip, h-14, top+bottom hairlines, `bg-panel`. Marquee of ~20 recent mints looping infinitely.

**Content per item**: `nft-mint-*.png` thumbnail (24px, rounded) + collection name (Inter 500 13px) + PnL chip (`+0.84 ETH`, mono 12px, green bg 10% + green text) + truncated wallet (mono, `text-muted`) + `2s ago`.

**Animation**: CSS marquee translateX 0→−50%, 40s linear infinite; pause on hover; edges masked with 80px fade gradients. Every ~4s one item's PnL chip flashes (background opacity 10%→30%→10%, 600ms) to feel alive.

---

## S3. Stats Band

**Layout**: 4-column grid (2×2 on mobile), each cell `bg-panel` hairline card with big mono number + label + tiny sparkline (SVG, green or violet, 60×20px).

**Content**:
- `142,908` — mints executed all-time
- `+2,431 ETH` — tracked sniper profit (30d)
- `412ms` — median time-to-block
- `98.7%` — mint success rate

**Animation**: On viewport entry (70%): numbers count up from 0 over 1.4s (`power2.out`, tabular-nums so no jitter); cards stagger in 90ms apart (y 24px, fade); sparklines draw via stroke-dashoffset 0→full over 1s.

---

## S4. How It Works — Pinned Scroll Sequence

**Layout**: Section pinned for 200vh. Left: sticky step list (3 steps, vertical). Right: a device-frame panel whose content crossfades per step. Progress line on far left: 2px vertical track, green fill grows with scroll progress.

**Steps**:
1. **Point** — "Paste any contract or drop link." Panel: input UI mock with a contract address, chain selector chips (ETH/SOL/Base), "Watch drop" button.
2. **Arm** — "Set gas strategy, wallets, and max spend. Or pick a sniper to copy." Panel: gas preset toggle (Chill/Degen/God-mode slider), wallet count stepper, copy-trader card preview.
3. **Snipe** — "The bot fires the instant minting goes live. You watch the fills roll in." Panel: the live terminal again, now showing `✓ MINT CONFIRMED` lines stacking.

**Animation**: ScrollTrigger pin. Step activation at 33%/66%/100% progress: inactive steps at 40% opacity, active step gets green left-border + mono step number `01/02/03` lights up; right panel crossfades (opacity + y 12px, 350ms) at each threshold. Progress line fill synced to scroll progress (scrub: true).

---

## S5. Copy Trading Spotlight

**Layout**: Two-column — left copy, right a stacked "sniper card" cluster (3 cards overlapping with -20px offsets, slight rotate ±2°).

**Content**:
- Eyebrow: `[ COPY TRADING ENGINE ]` violet.
- H2: "Ride the wallets that never miss."
- Body: "Every sniper on MintDash is ranked by verified on-chain PnL. Pick one, set your size, and every mint they make fires from your wallet in under half a second — with your own risk limits on top."
- Checklist (green check icons, Inter 15px): Verified on-chain track record · Per-copy max spend & daily caps · Stop-loss auto-unfollow · Mirror sells too (optional).
- Link: "Explore the leaderboard →" (cyan, arrow slides on hover).

**Sniper cards** (each): avatar (`sniper-avatar-*.png`), name `0x7a3F…9e2B`, rank chip `#1`, 30d PnL `+84.2 ETH` (green mono XL), win rate `71%`, followers `1,204`, mini sparkline, green "Copy" button.

**Animation**: Cards reveal with stagger (120ms) — rotate from 6°→final, y 40px→0, opacity 0→1, `back.out(1.4)`. On hover each card lifts to front (z-index + scale 1.04). Copy button: hover fills black→green with 150ms sweep.

---

## S6. Feature Grid

**Layout**: Bento grid — 6 cells (2 large 2×1, 4 standard), gap-4.

**Cells** (H3 + 2-line description + small visual):
1. (Large) **Mempool Sniping** — "Reads pending transactions and contract state directly. Fires before the public mint button even renders." Visual: mini terminal with latency bars (12ms / 38ms / 412ms).
2. **Gas Warfare** — "Dynamic priority fees tuned per drop. Win the block, not the bidding war." Visual: gas gauge dial.
3. **Anti-Rug Shield** — "Every watched contract is scanned for honeypots, proxy traps, and hidden mint functions." Visual: shield icon + score chip `12/100 RISK`.
4. **Multi-Wallet Rotation** — "Spin up to 50 wallets per task to bypass per-wallet mint limits." Visual: stacked wallet chips.
5. (Large) **Copy Trading** — "Mirror top snipers mint-for-mint, with your own caps and stop-loss." Visual: `copy-flow.png`-style mini diagram (two nodes + arrow).
6. **Instant Sell-Down** — "Optional auto-list on marketplaces the moment your mint confirms." Visual: arrow to marketplace icon + `listed @ 0.42 ETH`.

**Animation**: Grid reveals with 80ms stagger (y 28px, fade, 450ms). Hover per card: border violet + internal visual scales 1.03 + H3 gets green underline sweep.

---

## S7. Leaderboard Preview

**Layout**: Header row (H2 "The sharpest wallets on-chain" + link "Full leaderboard →") above a 5-row table.

**Table columns**: Rank (mono, #1 gold-tinted amber, #2/#3 violet) · Sniper (avatar + truncated address) · Chain badges · 30d PnL (green mono) · Win rate · Mints · Sparkline · Copy button.

**Animation**: Rows slide in from right (x 32px, stagger 80ms, 350ms). Every 3s a random row's PnL ticks up with green flash (simulated live data). Row hover: bg `bg-panel-2`, Copy button fades in.

---

## S8. Testimonials

**Layout**: 3 cards horizontally (stack on mobile). Quote (Inter 17px, `text-primary`) + author row (sniper avatar, alias, "Copies since Mar 2024 · +31.7 ETH" mono caption).

**Sample quotes**:
- "I copied 0x7a3F for one month and stopped staring at Discord mint channels forever. The bot just fills my wallet." — `degenfiend.eth`
- "412ms to inclusion. My old setup was 4 seconds and a prayer." — `0xMira`
- "The anti-rug shield saved me from two honeypots in a single week." — `snipegod.sol`

**Animation**: Cards fade up stagger 120ms; quote marks (oversized `"` in violet, 80px) animate in with scale 0.6→1, `back.out`.

---

## S9. Pricing Teaser

**Layout**: Compact 3-plan strip (Free / Pro / Whale), middle card elevated with violet border + "MOST POPULAR" chip. Each: name, price (mono XL), 3 key lines, button. Link below: "Full comparison & fee calculator →" to `/pricing`.

**Content**: Free `$0` — 1 task, 3 wallets, community snipers. Pro `$99/mo` — unlimited tasks, 25 wallets, copy any sniper, anti-rug shield. Whale `0.5 ETH/qtr` — god-mode gas, 50 wallets, private mempool routing, dedicated RPC.

**Animation**: Cards stagger up 100ms; Whale/Pro card glows pulse subtly (box-shadow opacity oscillates 10%→18%, 3s).

---

## S10. FAQ + CTA Band + Footer

**FAQ**: Accordion (shadcn), 6 questions, `bg-panel` rows with hairline dividers. Chevron rotates 180° on open; content expands with height animation (250ms `easeOut`).
Questions: Is MintDash custodial? (No — keys stay in your wallet/client-side session.) · Which chains are supported? · What does copy trading cost? · What happens if a mint fails? (No-fill, no-fee; failed gas reimbursed on Pro+.) · Can I get banned from drops for botting? · Do I need to keep my browser open? (No — tasks run on MintDash infra.)

**CTA band**: Shared component — H2 "Stop clicking. Start sniping.", Launch App button, violet radial glow.

**Animation**: FAQ rows reveal staggered 60ms; CTA band content scales 0.96→1 + fades on entry.

**Footer**: Shared global footer.

---

## Assets used

`logo.svg`, `hero-terminal.png`, `og-grid-texture.svg`, `sniper-avatar-1..8.png`, `nft-mint-1..6.png`, `copy-flow.png` (mini), chain SVG badges.
