# Copy Trading Page (`/copy-trading`)

The page for the product's headline differentiator: mirroring profitable NFT snipers. Structure: hero with flow visual, "how mirroring works" 3-step, top sniper cards, copy-settings walkthrough, risk controls, live mirrored-mints feed, CTA.

---

## S1. Hero — "Copy the wallets that never miss"

**Layout**: Centered header (pt-36) over `copy-flow.png` as a wide illustration below the copy (1400×800, contained, violet glow behind).
- Eyebrow: `[ COPY TRADING ENGINE ]` violet, with live pulse dot.
- H1 (60px): "Their alpha. **Your wallet.**" — green→cyan gradient on "Your wallet."
- Subhead: "MintDash ranks thousands of sniper wallets by verified on-chain profit. Choose who to mirror, set your limits, and every mint they make fires from your wallet in ~412ms — automatically."
- CTA row: primary "Start Copying" + ghost "Browse leaderboard".
- Stat chips row (mono 12px): `2,847 verified snipers` · `+2,431 ETH tracked profit` · `412ms median mirror`.

**Animation**: Copy staggers up on load (90ms, y 24px). `copy-flow.png` scales 0.94→1 + fades in over 700ms with a violet glow bloom; light-trail arrows in the image get an HTML dashed-line overlay animating `stroke-dashoffset` (marching, 16s loop) to imply motion.

---

## S2. How Mirroring Works — 3 Steps

**Layout**: 3-column card row with connecting dashed line running behind (desktop only).

**Steps** (numbered mono `01/02/03`, green):
1. **Pick a sniper** — "Filter by chain, PnL, win rate, and style. Every stat is computed from public chain data — no screenshots, no self-reported nonsense."
2. **Set your rules** — "Copy size per mint, daily ETH cap, chains to mirror, stop-loss. Your rules override everything — the sniper never touches your limits."
3. **Mirror in milliseconds** — "When they mint, you mint. When they dump, you can auto-dump. Fills, fees, and PnL stream into your dashboard live."

**Animation**: Cards stagger up 100ms; the connecting dashed line draws left→right (stroke-dashoffset, 1.2s) as cards land. On scroll-through, each card's number chip gets a one-time green glow pulse.

---

## S3. Top Snipers — Featured Cards

**Layout**: Header ("This week's sharpest") + 3 large cards horizontally (stack mobile). Each card is a rich profile:
- Rank chip `#1` (amber-tinted for #1, violet for #2–3), avatar (`sniper-avatar-*.png`), alias + truncated address with copy icon.
- Big mono PnL: `+84.2 ETH` 30d (green, 36px), plus `7d +12.9 ETH` secondary.
- Stats grid 2×2: Win rate `71%` · Mints `312` · Followers `1,204` · Avg hold `2.4d`.
- Sparkline (90-day equity curve, green SVG, 8px gradient fill below).
- Footer row: chain badges + green "Copy" button (fills card width, black text).

**Sample snipers**: `0x7a3F…9e2B` "goblinmode" · `0xB91c…44aA` "waifusniper" · `So1ana…xQ9p` "matcha.sol".

**Animation**: Cards rotate in (rotate 3°→0, y 36px, stagger 140ms, `back.out(1.3)`). Sparklines draw (dashoffset, 1.2s). Copy buttons: on hover a green sheen sweeps left→right (300ms); on click, button morphs to "Copying ✓" with checkmark pop (scale 0.5→1, `back.out`).

---

## S4. Copy Settings Walkthrough

**Layout**: Two columns — left: a live interactive settings panel (the star of the page); right: explanatory copy with anchored bullets that highlight as you interact.

**Interactive panel** (`bg-panel`, hairline, radius 12px, p-6):
- "Copy size per mint" — ETH amount stepper (0.05 / 0.1 / 0.25 / custom input), mono readout.
- "Daily cap" — slider 0–5 ETH with live readout `1.50 ETH/day`.
- "Mirror sells" — toggle (green when on).
- "Stop-loss" — toggle + `-20% PnL → auto-unfollow` caption when enabled.
- "Chains to mirror" — chip multi-select (ETH/SOL/Base/Polygon, selected = violet fill).
- Bottom summary bar updates live: `Max daily exposure: 1.50 ETH · est. 6–14 mints` (mono 12px, cyan).

**Right copy**: 4 bullets; each highlights (border-left green + text brightens) when the corresponding control is hovered/changed.

**Animation**: Panel slides in from left (x −40px, 500ms); controls have springy micro-feedback (toggle snap 150ms, slider thumb scale 1.1 while dragging, stepper ticks with 80ms haptic-style scale pulse). Bullet highlight transitions 200ms.

---

## S5. Risk Controls — Dark Warning Section

**Layout**: Full-width section with subtle red-tinted radial glow (rgba(255,77,106,0.06)) — the only red-accented section. H2: "Copy trading without the clown risks." 3 cards:
1. **Verified-only leaderboard** — "PnL is computed from chain data. No wallet gets listed without 30+ days of history and 50+ mints."
2. **Your keys, your rules** — "Non-custodial. MintDash can only execute the exact task scope you sign. Revoke anytime in one click."
3. **Automatic circuit breakers** — "Sniper's 7d PnL goes negative past your stop-loss? Auto-unfollow, funds never leave your wallet."

**Animation**: Cards fade up stagger 100ms; each card's icon (shield / key / breaker, inline SVG, red→green duotone) draws in via stroke animation on entry.

---

## S6. Live Mirrored-Mints Feed

**Layout**: Two-part: header with live pulse + "Right now, on MintDash" H2; below, a 6-row live feed panel (`bg-panel`, mono rows).

**Row format**: `nft-mint-*.png` thumb · collection + token ID · `mirrored from 0x7a3F…9e2B` (cyan, truncated) · PnL chip green · latency `388ms` · time `now/4s/11s…`.

**Animation**: Simulated live — every 2–3s a new row slides in from right (x 24px, 300ms) with green background flash fading over 500ms; oldest row fades out and collapses (height 0, 250ms). Times tick upward each second. Pause simulation when tab hidden.

---

## S7. CTA Band + Footer

Shared CTA band, copy variant: H2 "Pick your first sniper." + primary "Browse the leaderboard" (links `/leaderboard`) + ghost "Launch App". Standard footer.

---

## Assets used
`copy-flow.png`, `sniper-avatar-1..8.png`, `nft-mint-1..6.png`, `chain-*.svg`. Settings panel and feed are live HTML.
