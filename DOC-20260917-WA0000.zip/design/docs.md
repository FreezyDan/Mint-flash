# Docs Page (`/docs`)

Documentation hub. Two-pane app-like layout (docs sidebar + content) rather than a marketing page. Goal: make the bot feel real and approachable — a working quickstart in under 5 minutes.

---

## S1. Docs Header

**Layout**: pt-28 pb-10, left-aligned, with `docs-hero.png` as a wide banner above the title (1400×700, h-56 object-cover, rounded 12px, hairline border, violet glow faint behind).
- Eyebrow: `[ DOCUMENTATION ]` green.
- H1 (44px): "Zero to first snipe in five minutes."
- Search bar: wide mono input (`Search the docs…  ⌘K`), `bg-panel`, hairline, violet focus ring; placeholder blinking caret. Typing filters the guides grid (S3) live with 150ms debounce.

**Animation**: Banner fades + scales 0.98→1 (600ms); title staggers up; search bar slides up last (y 16px, 400ms).

---

## S2. Layout Shell

**Two-pane** below header: left docs sidebar (w-56, sticky top-24, self-start), right content (max-w-3xl). Mobile: sidebar becomes a horizontal scroll chip row.

**Sidebar nav** (Inter 500 14px, grouped):
- **Getting started**: Quickstart (active) · Connecting wallets · Funding & vaults
- **Tasks**: Creating a task · Gas strategies · Multi-wallet setup
- **Copy trading**: Choosing snipers · Limits & stop-loss · Mirror sells
- **Safety**: Anti-Rug Shield · Permissions model · Revoking access
- **API**: Authentication · REST endpoints · WebSockets

Active item: violet left bar + white text; others `text-muted`, hover `text-primary`. Clicking a group item smooth-scrolls to the matching anchor section (Lenis `scrollTo`) and updates active state on scroll (IntersectionObserver).

---

## S3. Quickstart Guide (main content, anchor `#quickstart`)

**Layout**: Article-style, prose width. H2 + intro line, then 4 numbered steps. Each step = card with mono step number, H3, body, and a code/terminal block.

**Steps**:
1. **Connect your wallet** — "MintDash never takes custody. You sign a scoped session that can only execute tasks you explicitly arm." Code block: mono `connect 0xdegen…42Ff  ✓ session scoped: mint-only` on dark terminal card (green ✓).
2. **Create your first task** — body + terminal block: `task create --contract 0x3f2a…c81d --wallets 3 --gas degen` → output lines `✓ contract verified · ERC-721 · supply 8,888` `✓ risk score 12/100 — clean` `task #0471 armed`.
3. **Or copy a sniper** — body + block: `copy 0x7a3F…9e2B --size 0.1eth --cap 1.5eth/day --stop-loss -20%` → `✓ mirroring live · median delay 412ms`.
4. **Watch the fills** — body pointing to dashboard + a mini 3-row live feed embedded inline (same insert animation as other feeds).

**Code block styling**: `bg-void` inner panel, 1px hairline, radius 8px, mono 13px, `$` prompts in violet, output in `text-secondary`, success lines green. Copy button top-right (icon, appears on hover, click → "copied" tooltip 1.2s).

**Animation**: Step cards stagger in 100ms on scroll; terminal lines type when 60% visible (15ms/char, once); copy buttons have scale-tap feedback.

---

## S4. Guides Grid (anchor `#guides`)

**Layout**: H2 "Guides" + 3×2 card grid. Each card: mono category tag, H3 title, 2-line summary, `8 min read` caption, arrow icon that slides right 4px on hover.
1. Gas strategies explained — *Tasks* — "When to Chill, when to go God-mode, and what it costs."
2. Bypassing per-wallet limits — *Tasks* — "Multi-wallet rotation without getting sybil-flagged."
3. Reading the leaderboard — *Copy trading* — "Win rate vs PnL: which stats actually predict future alpha."
4. Setting a sane stop-loss — *Copy trading* — "Auto-unfollow rules that protect your stack."
5. How the Anti-Rug Shield scores contracts — *Safety* — "What we scan, what we miss, and how to read a report."
6. Revoking MintDash permissions — *Safety* — "One click, on-chain, immediate."

**Animation**: Cards stagger 80ms (y 24px, fade); hover lifts (translateY −3px, border violet). Live-filtering from the search bar: non-matching cards collapse (height+opacity, 250ms).

---

## S5. API Reference Teaser (anchor `#api`)

**Layout**: Two-column — left copy, right code block.
- H2 "Build on the bot." + body: "Everything the dashboard does is available over REST and WebSocket — arm tasks, stream fills, manage copies. Whale plans include a dedicated key with 120 req/s."
- Link: "Full API reference →" (cyan).
- Right: terminal card with sample:
  `POST /v1/tasks` request JSON (mono, syntax tinted: keys violet, strings green) and a `201` response `{"task_id":"0472","status":"armed"}`.

**Animation**: Code block slides in from right (x 32px, 450ms); a green `201` status chip pops (`back.out`) 300ms later.

---

## S6. Changelog (anchor `#changelog`)

**Layout**: H2 "Changelog" + vertical timeline — 2px hairline track left, green dots per entry. 4 entries, each: mono date + version chip (violet border) + title + 2 bullet lines:
- `2025-06-02` `v2.4` — "Base chain support live" · `+ chain badge filters` · `+ 40ms faster block subscription`
- `2025-05-18` `v2.3` — "Mirror sells" · copy sells with trailing floor
- `2025-05-02` `v2.2` — "Anti-Rug Shield v2" · proxy-trap detection, dev-concentration scoring
- `2025-04-11` `v2.1` — "Failed-gas reimbursement for Pro"

**Animation**: Timeline track draws top→bottom (scaleY, scrubbed by scroll within the section); dots pop as track reaches them (scale 0→1, `back.out`); entries fade-slide in staggered 80ms.

---

## S7. Docs FAQ + CTA + Footer

**FAQ** (4 items, same accordion): Do I need to code? (No — everything works from the dashboard; API is optional.) · Where do tasks run? (MintDash infra — closing your laptop doesn't stop armed tasks.) · What wallets are supported? · Is there a testnet mode? (Yes — Sepolia + Devnet paper-trading.)

**CTA band**: variant — H2 "Arm your first task." + primary "Launch the App" + ghost "Read the quickstart" (scrolls to top). Global footer.

---

## Assets used
`docs-hero.png`, `og-grid-texture.svg`, `logo.svg`. Code blocks, timeline, feeds are live HTML.
