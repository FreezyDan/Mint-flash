# MintDash — Global Design Document

**Product**: MintDash — a web-based NFT auto-mint bot with copy-trading. Users deploy mint "tasks" that snipe drops in milliseconds, and can one-click copy the minting activity of the most profitable NFT snipers/traders on-chain.

**Concept mood**: A trading terminal for NFT degens. Think Bloomberg terminal × cyberpunk neon × crypto-native culture. Dark, dense, data-rich, glowing. Everything feels *live* — tickers, feeds, counters, pulse indicators.

---

## 1. Visual Direction

- **Aesthetic**: Dark-mode "quant terminal" UI. Deep near-black surfaces, neon green (profit/success) + electric violet (brand) accents, hairline borders, glassmorphic panels, subtle scanline/grid textures.
- **Texture language**: Fine 1px grid overlays, dotted halftone noise at 3–5% opacity, glowing radial gradients behind key moments. No photos of people — the imagery is abstract 3D, data-viz, and terminal UI.
- **Motion language**: Fast, precise, mechanical. Data "ticks in" rather than floats. Numbers count up, feed rows slide in from the right with a green flash (like a filled order), pulses on live dots. Scroll reveals are snappy (300–500ms), never dreamy.
- **Signature motifs**:
  1. **Live pulse dot** — 8px green dot with expanding ring animation, used next to everything "live".
  2. **Terminal card** — a panel styled like a code terminal (traffic-light dots, mono font, syntax-colored output) used in hero and feature sections.
  3. **PnL chips** — pill badges showing `+4.2 ETH` in green or `-0.3 ETH` in red.
  4. **Hex/wallet truncation** — addresses shown as `0x7a3F…9e2B` in JetBrains Mono with a copy icon on hover.

---

## 2. Color Palette

| Token | Hex | Usage |
|---|---|---|
| `bg-void` | `#07080D` | Page background |
| `bg-panel` | `#0D0F16` | Cards, panels |
| `bg-panel-2` | `#12141E` | Elevated cards, hover states |
| `border-hairline` | `#1E2230` | 1px borders everywhere |
| `brand-violet` | `#7C5CFF` | Primary brand, CTAs, glows |
| `brand-violet-deep` | `#4A2EDB` | Gradient partner for violet |
| `neon-green` | `#39FF8E` | Profit, success, live indicators, "mint" actions |
| `neon-green-dim` | `#1A3A2A` | Green tint backgrounds |
| `alarm-red` | `#FF4D6A` | Loss, risk, anti-rug warnings |
| `amber` | `#FFB224` | Warnings, pending states |
| `text-primary` | `#F2F4F8` | Headings, key numbers |
| `text-secondary` | `#9BA3B4` | Body text |
| `text-muted` | `#5A6274` | Captions, labels |
| `cyan` | `#41E6E0` | Secondary data accent (charts, links in feeds) |

**Gradients**:
- `g-brand`: `linear-gradient(135deg, #7C5CFF 0%, #4A2EDB 100%)`
- `g-profit`: `linear-gradient(135deg, #39FF8E 0%, #14B8A6 100%)`
- `g-hero-glow`: radial `rgba(124,92,255,0.22)` → transparent, behind hero
- `g-green-glow`: radial `rgba(57,255,142,0.14)` → transparent, behind live sections

**Rule**: Green = money/success only. Violet = brand/CTA only. Never mix the two in a single element.

---

## 3. Typography

Google Fonts (all loaded via `fonts.googleapis.com`):

| Role | Font | Weights | Notes |
|---|---|---|---|
| Display / Headlines | **Space Grotesk** | 500, 600, 700 | Tight tracking `-0.03em`; uppercase for eyebrow labels with `+0.18em` tracking |
| Body / UI | **Inter** | 400, 500, 600 | 16px base, line-height 1.6 |
| Data / Mono | **JetBrains Mono** | 400, 500, 700 | All numbers, addresses, prices, terminal text, table data, tickers. Enables tabular numerals (`font-variant-numeric: tabular-nums`) |

**Scale** (desktop):
- Hero H1: 76px / 1.02 / -0.035em / Space Grotesk 700
- Page H1: 60px / 1.05 / -0.03em
- Section H2: 44px / 1.1 / -0.025em
- Card H3: 22px / 1.25 / Space Grotesk 600
- Body: 16–17px Inter 400, `text-secondary`
- Eyebrow: 12px JetBrains Mono 500, uppercase, `+0.2em`, `neon-green` or `brand-violet`
- Data XL (stats): 48px JetBrains Mono 700, `text-primary`
- Caption/label: 12–13px Inter 500, `text-muted`

**Mobile scale-down**: H1 hero → 40px, H2 → 30px, stats → 32px.

---

## 4. Spacing, Layout & Components

- **Container**: max-width `1200px`, `px-6`. Full-bleed sections for hero glows and tickers.
- **Section rhythm**: `py-24` desktop / `py-16` mobile. Dense dashboard sections use `py-12`.
- **Radius**: `12px` cards, `8px` inner elements, `999px` chips/badges.
- **Borders**: 1px `border-hairline` on all cards; hover state lifts border to `rgba(124,92,255,0.45)` + subtle translateY(-2px).
- **Shadows/glows**: `0 0 40px rgba(124,92,255,0.15)` on primary CTA hover; `0 0 24px rgba(57,255,142,0.12)` on live panels.
- **Grid overlay**: fixed background layer — 64px grid lines at `rgba(255,255,255,0.025)`, plus noise (SVG `feTurbulence` data-URI) at 4% opacity. Global, behind everything.

### Shared components

**Navbar** (fixed, h-16, backdrop-blur, `bg-void/80`, 1px bottom hairline):
- Left: logo mark (SVG lightning-diamond, `logo.svg`) + "MINTDASH" in Space Grotesk 700, letterspaced.
- Center: links — Features, Copy Trading, Leaderboard, Pricing, Docs. Inter 500, 14px, `text-secondary` → white on hover with a 2px violet underline that slides in (200ms).
- Right: "Live: 12,842 wallets tracked" mini pulse indicator (mono 12px, hidden on mobile) + **Launch App** button (g-brand, white text, radius 8px, glow on hover).
- Mobile: hamburger → full-screen overlay menu, links stagger in (60ms apart, slide up 20px + fade).

**Footer** (`bg-panel`, top hairline):
- 4 columns: Brand blurb + socials (X/Twitter, Discord, Telegram, GitHub icons as inline SVG) / Product links / Resources / Legal.
- Bottom bar: mono 11px "© 2025 MintDash Labs — Not financial advice. NFT trading involves risk." + a "Systems Operational" green pulse chip.
- Above footer on every marketing page: **CTA band** (see below).

**CTA band** (shared): full-width panel with violet radial glow, H2 "Stop clicking. Start sniping.", sub-copy, Launch App button + "View docs" ghost link. Used at the bottom of home, features, copy-trading, pricing.

**Buttons**:
- Primary: g-brand background, white, Inter 600 15px, px-6 py-3, radius 8px. Hover: brightness +10%, glow shadow, scale 1.02. Active: scale 0.98.
- Success/Mint: solid `neon-green`, black text (`#07080D`), same sizing — used for mint/copy actions.
- Ghost: 1px `border-hairline`, `text-primary`, hover border-violet + bg white/5.
- All buttons get a Framer Motion tap animation (scale 0.97, 120ms spring).

**Cards**: `bg-panel`, hairline border, radius 12px, p-6. Hover (interactive cards): border violet, translateY(-2px), 200ms ease-out.

**Ticker strip** (shared, used on home + copy-trading): infinite horizontal marquee of recent mints: `+0.84 ETH  Azuki #8841  0x7a3F…9e2B  2s ago` — mono 13px, alternating green profit chips. CSS keyframes marquee, 40s loop, pause on hover. Edges fade with mask-gradient.

**Live pulse dot**: 8px `neon-green` circle + absolutely positioned ring animating scale 1→2.2, opacity 0.8→0, 1.6s infinite.

**Section eyebrow**: mono uppercase chip — e.g. `[ COPY TRADING ENGINE ]` with green or violet text and matching 1px border at 30% opacity.

---

## 5. Animation System

- **Libraries**: GSAP + ScrollTrigger (scroll storytelling, pinned sequences), Framer Motion (micro-interactions, page transitions, lists), Lenis (smooth scroll sitewide), Three.js/R3F (hero background only — see home.md).
- **Global scroll**: Lenis with `lerp: 0.09`, wheel multiplier 1.0. Reduced-motion: disable Lenis + pinned sections, swap all reveals to simple opacity fades.
- **Default reveal pattern** (`.reveal`): opacity 0→1, y 28px→0, 500ms, ease `power3.out`, trigger at 80% viewport. Stagger groups: 80–100ms per child.
- **Number counters**: GSAP ticker — count from 0 to target over 1.4s with `power2.out`, mono font, triggered on viewport entry. Only animate integers/short decimals.
- **Feed row insertion** (live feeds): new rows slide in from right (x: 24→0, 350ms) with a 400ms green background flash that fades — like an order fill.
- **Headline treatment**: character-level split (max ~20 chars) for hero H1 via GSAP SplitText-style stagger (24ms/char, y 0.6em→0, rotate 4°→0). Subheads: word-level. Body: block-level.
- **Page transitions**: Framer Motion — outgoing fades + y -12px (180ms), incoming y 16px→0 + fade (280ms).
- **Cursor**: default cursor globally EXCEPT hero on home, which uses a custom crosshair cursor (SVG) over the 3D canvas; interactive elements keep pointer.
- **Performance budget**: max one pinned ScrollTrigger sequence per page; hero 3D particle field capped at ~1200 particles; tickers/feeds use CSS transforms only (no layout thrash); live feed simulations throttle to 1 row / 1.5–3s.

---

## 6. Page List

| File | Route | Description |
|---|---|---|
| `home.md` | `/` | Landing: 3D hero with terminal card, live mint ticker, stats band, how-it-works pinned sequence, copy-trading spotlight, sniper leaderboard preview, feature grid, pricing teaser, testimonials, FAQ, CTA. |
| `features.md` | `/features` | Deep dive: mint engine, mempool sniping, gas wars, anti-rug shield, wallet tracking, multi-chain support — alternating showcase sections with terminal/mini-UI illustrations. |
| `copy-trading.md` | `/copy-trading` | The copy-trade product: how mirroring works, top sniper cards with PnL charts, copy settings UI walkthrough, risk controls, live mirrored-mints feed. |
| `leaderboard.md` | `/leaderboard` | Full sortable/filterable leaderboard of profitable snipers — rank table with sparklines, filters by chain/timeframe/win-rate, trader profile drawer. |
| `dashboard.md` | `/app` | The actual bot web-app UI: sidebar, task creation wizard (contract, gas, wallets), live task cards, activity feed, PnL overview, copy-trade module, settings. |
| `pricing.md` | `/pricing` | Plans (Free/Pro/Whale) with feature matrix, fee calculator, comparison table, FAQ, CTA. |
| `docs.md` | `/docs` | Documentation hub: quickstart guide with code steps, guides grid, API reference teaser, changelog, FAQ accordion. |

---

## 7. Dependencies (for implementation team)

- `react`, `react-dom`, `react-router-dom` (pages above)
- `tailwindcss` v3.4, `shadcn/ui` primitives (accordion, tabs, dialog/drawer, table, toggle, slider, badge)
- `gsap` (+ ScrollTrigger), `framer-motion`, `lenis`
- `three`, `@react-three/fiber`, `@react-three/drei` (hero only)
- `recharts` or lightweight custom SVG sparklines for PnL charts (prefer custom SVG sparklines for table density)
- Google Fonts: Space Grotesk, Inter, JetBrains Mono

---

## 8. Assets

All imagery is abstract/terminal/3D — no photography of people.

| Filename | Description | Location | Dimensions | Type |
|---|---|---|---|---|
| `logo.svg` | Geometric logo mark: a diamond/hexagon shape fused with a lightning bolt, two-tone — neon green (#39FF8E) bolt over violet (#7C5CFF) diamond outline, flat vector, works at 24px | Navbar, footer, favicon | 64×64 1:1 | SVG |
| `hero-terminal.png` | Dark terminal/UI screenshot-style illustration: a mint bot console showing green "MINT CONFIRMED" lines, gas values, wallet addresses in mono type on near-black panel with violet border glow. Pixel-crisp UI mock, slight perspective tilt | Home hero (right side) | 1200×900 4:3 | Image |
| `og-grid-texture.svg` | Fine 64px grid line pattern, white at 2.5% opacity, tileable | Global background layer | 128×128 tile | SVG |
| `sniper-avatar-1..8.png` (8 files) | Abstract trader avatars: generative geometric identicons — each a unique arrangement of 3–5 glowing shapes (triangles, rings, arcs) on dark backgrounds, one accent color each (violet, green, cyan, amber, red variations). No faces. | Leaderboard cards, testimonials, dashboard | 256×256 1:1 | Image |
| `nft-mint-1..6.png` (6 files) | Small square NFT artwork thumbnails for the live mint feed: varied generative-art styles (pixel punk, chromatic gradient blob, glitch skull, vaporwave grid, line-art ape, neon kanji poster), each clearly distinct, dark backgrounds | Live ticker + feeds (home, copy-trading, dashboard) | 128×128 1:1 | Image |
| `chain-eth.svg`, `chain-sol.svg`, `chain-base.svg`, `chain-poly.svg` | Minimal monochrome chain badge icons (Ethereum diamond, Solana stripes, Base circle, Polygon hex) in `#9BA3B4`, single-color flat | Multi-chain section (features), dashboard, filters | 48×48 1:1 | SVG |
| `features-anti-rug.png` | UI illustration: a "risk scan" panel showing a contract audit checklist — green checkmarks, one red warning row, a circular risk score gauge at 12/100, dark terminal styling with red/green accents | Features — anti-rug section | 1000×800 5:4 | Image |
| `copy-flow.png` | Diagram-style illustration: three glowing wallet nodes on the left connected by animated-looking light trails to one user wallet node on the right, arrows labeled with mono-type "mirror in 412ms", dark background with violet/green glow | Copy-trading page hero | 1400×800 7:4 | Image |
| `pricing-whale-bg.png` | Abstract background for the "Whale" plan card: flowing dark liquid metal with violet and green iridescent highlights, subtle, premium feel | Pricing page | 800×1000 4:5 | Image |
| `docs-hero.png` | Isometric illustration of stacked documentation/terminal panels floating in dark space, violet rim lighting, mono text fragments visible on screens | Docs page header | 1400×700 2:1 | Image |
