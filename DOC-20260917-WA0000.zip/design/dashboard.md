# Dashboard / App Page (`/app`)

The actual bot web-app. This is a product UI, not marketing — denser, utility-first, but keeps the terminal aesthetic. Replaces the marketing navbar with an app shell. Structure: sidebar + topbar + main canvas with 6 zones. This page should feel fully functional: create tasks, toggle bots, watch feeds.

---

## App Shell

**Sidebar** (fixed left, w-60, `bg-panel`, right hairline, full height):
- Top: logo + "MINTDASH" (smaller than marketing nav).
- Nav items (icon + label, Inter 500 14px): **Overview** (active default), **Tasks**, **Copy Trading**, **Wallets**, **Activity**, **Settings**. Active item: violet 2px left bar + `bg-panel-2` + white text; inactive `text-muted`, hover bg.
- Bottom: plan chip `PRO` (violet border) + usage meter `Tasks 7/∞ · Wallets 18/25` (hairline progress bar, green fill 72%) + user row (avatar, `0xdegen…42Ff`, disconnect icon).

**Topbar** (h-14, `bg-void/80` backdrop-blur, bottom hairline): page title (Space Grotesk 600, 18px) · right side: network status `ETH block 21,447,902` (mono 12px, ticks +1 every ~12s) · gas readout `12 gwei` (mono, color-coded green<20/amber<60/red>60) · bell icon with green dot · "New Task" primary button (compact).

**Animation**: Shell fades in on load (300ms); sidebar items stagger 40ms from top; main content y 16px→0 fade 400ms. Sidebar collapses to icon rail on <1024px (Framer Motion width spring, labels fade).

---

## Z1. Overview Stat Cards (row of 4)

Cards (`bg-panel`, p-5): label (mono 11px uppercase muted) + big mono value + delta chip + sparkline.
- **Total PnL** `+12.84 ETH` · `+2.1 today` green · green sparkline
- **Active tasks** `7` · `2 armed` amber · flat line
- **Copying** `3 snipers` · `+0.9 ETH today` green · green sparkline
- **Success rate** `97.2%` · `last 100 mints` · violet sparkline

**Animation**: Stagger 80ms up; values count up 1.2s on first load; every ~6s "Total PnL" ticks up +0.01–0.08 with green flash (live simulation).

---

## Z2. Active Tasks (main left column, 2/3 width)

**Task cards** (stacked, `bg-panel`, p-5). Each card:
- Header: status pill (`ARMED` amber pulsing / `LIVE-FIRING` green pulsing / `PAUSED` gray) · collection name (Space Grotesk 600) + contract (mono 12px truncated, copy icon) · chain badge.
- Body row: countdown or state readout (`go-live in 02:14:33`, mono, tabular, ticking every second) · `wallets 12/12 funded` · `max 3 NFT/wallet` · gas preset chip `DEGEN`.
- Footer: hairline top, actions — pause/resume icon toggle, edit, duplicate, delete (icon buttons, muted → white on hover; delete → red).
- Progress: thin 3px bar under header when firing (green fill animating to simulated %).

**Content**: 4 sample tasks — "Degen Apes S2" (ARMED, countdown), "PixelWraiths" (LIVE-FIRING, 61% minted progress), "matcha cows ep.2" (PAUSED), "BasePunks Deriv" (ARMED, awaiting go-live signal).

**Animation**: Cards stagger in 90ms. Countdown ticks live. The LIVE-FIRING card periodically (every 4–7s) flashes a new fill: a row slides into its mini-feed `✓ wallet 0x88…f1 minted #4412 · 0.08 ETH` (x 16px, green flash). Pause toggle: pill crossfades color + label with 200ms.

---

## Z3. New Task Wizard (modal)

**Trigger**: "New Task" button (topbar) or empty-state CTA. Modal (shadcn Dialog, max-w-lg, `bg-panel`, scale 0.95→1 + fade 220ms, backdrop `bg-void/80`).

**3 steps** (stepper header: mono `STEP 1/3`, progress bar violet):
1. **Target** — contract address or drop URL input (mono, with validation state: green check + `ERC-721 detected · supply 8,888` on valid paste), chain select chips.
2. **Strategy** — gas preset cards (Chill/Degen/God), wallets slider 1–25, max spend per wallet input, optional "Copy a sniper instead" toggle that swaps step 2 to a sniper-picker (search + 3 suggested sniper cards).
3. **Review & Arm** — summary list (mono key/value rows), estimated cost card (`est. max cost 2.4 ETH + gas ≤ 0.06 ETH`, cyan), big green "Arm Task" button → success state: checkmark pop + `Task #0472 armed` + "View in tasks" link.

**Animation**: Step transitions slide horizontally (x 40px→0 incoming, −40px outgoing, 280ms). Validation check pops (`back.out`). Progress bar animates width per step (300ms).

---

## Z4. Copy Trading Module (right column, 1/3 width)

**Panel** (`bg-panel`): header "Copying" + manage link → `/copy-trading`.
- 3 rows of active copies: avatar + alias · `size 0.1 ETH/mint` mono caption · PnL chip `+0.42 ETH` green · toggle (green on) to pause copying.
- Below: "Suggested" section — 2 sniper mini-cards (avatar, alias, `30d +21.4 ETH`, sparkline, "Copy" ghost button).
- Toggling a copy off: row dims to 50% opacity, toggle snaps, toast slides up from bottom: `Paused copying goblinmode` (mono 12px, auto-dismiss 3s).

**Animation**: Rows stagger 80ms; toggles spring 150ms; toast y 24px→0 + fade, dismiss reverses.

---

## Z5. Activity Feed (right column, below Z4)

**Panel**: header "Activity" + live pulse dot. Mono 12.5px rows, icon per type:
- ✓ green — `MINT CONFIRMED  PixelWraiths #4412  0.08 ETH`
- ⚡ violet — `TASK FIRED  BasePunks Deriv  12 wallets`
- ⚠ amber — `GAS SPIKE  48 gwei — task #0471 waiting`
- ✕ red — `MINT FAILED  sold out block 21,447,118  gas refunded`
- ⧉ cyan — `COPIED  goblinmode → Azuki #8841  +0.84 ETH est.`

20 initial rows; new rows insert every 2–4s (same slide-in + green/red flash pattern as home feed). Timestamps relative, ticking. Scrollable (max-h-96, thin scrollbar styled `border-hairline`).

**Animation**: Insert animation per row (x 20px→0, 280ms, bg flash 400ms). Row hover reveals a "view tx ↗" mono link (cyan).

---

## Z6. Wallets Strip (bottom, full main width)

**Panel**: header "Wallets" + "18 connected" caption + ghost "Manage".
- Horizontal scroll row of wallet chips (mono address, avatar dot, balance `0.42 ETH`, funded=green dot / low=amber). First chip is "Vault" (violet border, `12.84 ETH`).
- Hover chip: tooltip card (bg-panel-2, hairline) with full address + copy button + `sweeps to vault: on`.

**Animation**: Chips stagger in 40ms; horizontal scroll with edge fade masks; tooltip fades/scales 0.95→1 (150ms).

---

## Assets used
`sniper-avatar-*.png` (copies + suggested), `nft-mint-*.png` (fill rows), `chain-*.svg` (badges), `logo.svg`. All panels/feeds/wizard are live HTML.
