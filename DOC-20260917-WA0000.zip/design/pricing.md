# Pricing Page (`/pricing`)

Conversion-focused: 3-tier plans, fee calculator, full comparison table, FAQ, CTA. Dark terminal aesthetic with one premium visual moment (Whale card background).

---

## S1. Page Header

**Layout**: Centered, pt-36 pb-14.
- Eyebrow: `[ PRICING ]` green.
- H1 (56px): "Pay for speed. **Keep the alpha.**"
- Subhead: "Every plan is non-custodial and cancel-anytime. Failed mints never cost you a fee."
- Billing toggle: `Monthly / Quarterly (−20%)` — pill toggle with sliding indicator (Framer Motion `layoutId`, 250ms spring); prices animate when toggled (digits roll, 300ms).

**Animation**: Header staggers up 90ms; toggle fades in last.

---

## S2. Plan Cards

**Layout**: 3 cards, gap-6, middle elevated (scale 1.03, violet border + "MOST POPULAR" chip above). Cards `bg-panel`, p-8, radius 12px.

**Free — "Scout"** `$0` forever
- 1 active task · 3 wallets · community snipers only · public RPC speed · basic risk scan
- Ghost button "Start free"

**Pro — "Sniper"** `$99/mo` (`$79/mo` quarterly) — MOST POPULAR
- Unlimited tasks · 25 wallets · copy any sniper · Anti-Rug Shield full scans · dynamic gas warfare · failed-gas reimbursement · priority support
- Primary (g-brand) button "Go Pro"

**Whale — "God Mode"** `0.5 ETH/quarter` — card uses `pricing-whale-bg.png` as background (dark, 25% opacity behind content, content stays readable)
- Everything in Pro · 50 wallets/task · private mempool routing + builder bundles · god-mode gas · dedicated RPC node · 1-on-1 strategy onboarding · API access
- Green "Mint" button "Go Whale" (black text)

**Card anatomy**: plan name (mono eyebrow) → price (mono 44px + `/mo` muted) → one-line pitch → hairline → feature list (green checks, Inter 14.5px, gap-2.5) → button full-width.

**Animation**: Cards stagger up 120ms (middle lands last for emphasis, 1.03 scale settles with spring). Whale card background slowly pans (background-position 0→20px, 12s alternate loop). Popular chip pulses (opacity 0.75→1, 2s). Quarterly toggle: prices roll with odometer digits.

---

## S3. Fee Calculator

**Layout**: Two-column panel (`bg-panel`, violet radial glow faint): left controls, right live readout.

**Controls**:
- "Mints per month" slider 1–200 (mono readout `48`)
- "Avg mint price" slider 0.01–1 ETH (`0.08 ETH`)
- "Copies active" stepper 0–10
- Plan toggle chips (Scout/Sniper/Whale)

**Readout** (right, mono, updating live with 200ms digit-roll on change):
- `Est. monthly volume` `3.84 ETH`
- `MintDash cost` `$99 · ≈ 2.6% of volume` (green when < 5%)
- `Failed-mint protection` `saves est. 0.11 ETH/mo` (green)
- Verdict line: "Pro pays for itself if you win **one** contested mint." (Inter 15px, `text-primary`)

**Animation**: Panel slides up on entry; sliders have spring thumbs; readout values roll on any input change.

---

## S4. Comparison Table

**Layout**: Full-width table, 4 columns (Feature / Scout / Sniper / Whale). Sticky column header. Feature names Inter 14px `text-secondary`; values mono — checks (green ✓), dashes (muted —), or values (`3` / `25` / `50`).

**Rows** (grouped with mono group labels):
- Execution: Active tasks · Wallets per task · Gas warfare · Private mempool routing · Builder bundles
- Copy trading: Community snipers · Any verified sniper · Mirror sells · Stop-loss auto-unfollow
- Safety: Basic risk scan · Full Anti-Rug Shield · Failed-gas reimbursement
- Platform: API access · Dedicated RPC · Support (community / priority / 1-on-1)

**Animation**: Rows reveal in staggered groups (60ms, y 16px) on scroll. Row hover highlights entire row (`bg-panel-2`) and the Sniper column cells get a persistent 5% violet tint to guide the eye.

---

## S5. Pricing FAQ

Accordion (same component as home), 5 questions:
- Is there a per-mint fee? (No on Pro/Whale; Scout takes 2% of mint price.)
- What does "failed-gas reimbursement" mean? · Can I pay in crypto? (ETH, SOL, USDC.) · Can I cancel anytime? · What happens to my tasks if I downgrade?

**Animation**: Same accordion behavior as home (chevron rotate, height spring 250ms); rows stagger 60ms on entry.

---

## S6. CTA Band + Footer

Shared CTA band, variant copy: H2 "Your first snipe is free." + primary "Start with Scout" + ghost "Compare plans" (scrolls to table). Global footer.

---

## Assets used
`pricing-whale-bg.png`, `og-grid-texture.svg`. Calculator/table all live HTML.
