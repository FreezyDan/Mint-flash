# Leaderboard Page (`/leaderboard`)

A dense, data-first page: the full ranked table of profitable NFT snipers. Feels like a trading screener. Structure: header, filter toolbar, ranked table (25 rows) with trader profile drawer, "get listed" band, CTA.

---

## S1. Page Header

**Layout**: Compact (pt-32 pb-10), left-aligned.
- Eyebrow: `[ SNIPER LEADERBOARD ]` green + live pulse dot.
- H1 (48px): "The sharpest wallets on-chain."
- Subhead: "Every wallet below is verified against public chain data. Rankings recompute every 15 minutes. No self-reporting, no screenshots."
- Meta row (mono 12px, `text-muted`): `Last recompute: 3 min ago` · `2,847 tracked wallets` · `min. 50 mints & 30d history to list`.

**Animation**: Header staggers up on load (80ms apart). Meta row's "3 min ago" ticks live each minute.

---

## S2. Filter Toolbar

**Layout**: Sticky under navbar (top-16, `bg-void/90` backdrop-blur, bottom hairline). Left→right:
- **Timeframe tabs**: `24H / 7D / 30D / 90D / ALL` — pill tabs, active = violet fill, sliding indicator (Framer Motion `layoutId` underline-pill, 250ms spring).
- **Chain filter chips**: All / ETH / SOL / Base / Polygon (with chain SVG badges), multi-toggle.
- **Min win-rate slider**: 0–100%, readout mono `≥ 55%`.
- **Search**: mono input "address or alias…", 220px wide, focus ring violet.
- Right end: result count `248 snipers` (mono, updates on filter change with a 200ms number-roll).

**Animation**: Toolbar fades in after header (300ms delay). Tab switch animates the indicator and crossfades table rows (out: y −8px fade 150ms; in: stagger 40ms, y 12px→0, 250ms).

---

## S3. Ranked Table

**Layout**: Full-width table, hairline row dividers, header row mono 11px uppercase `text-muted`, sortable columns (sort arrow flips 180° on click, toggles asc/desc). Rows h-16, hover `bg-panel-2`.

**Columns**:
1. **Rank** — mono; `#1` amber chip, `#2` silver-ish (`#C7CCDA`), `#3` bronze-ish (`#C98A4B`), rest `text-muted`.
2. **Sniper** — 32px avatar (`sniper-avatar-*.png` cycling) + alias (Inter 600) + truncated address (mono 12px, `text-muted`, copy icon on hover).
3. **Chains** — up to 3 chain badge SVGs.
4. **PnL (selected timeframe)** — mono 15px; green `+84.2 ETH` / red `−3.1 ETH`. Sortable (default sort desc).
5. **Win rate** — mono + tiny 24px horizontal bar (green fill vs hairline track). Sortable.
6. **Mints** — mono. Sortable.
7. **Followers** — mono. Sortable.
8. **90d sparkline** — 80×24 SVG, green if net positive, red if negative.
9. **Action** — green "Copy" button (compact, appears solid on hover else outline) + chevron to open profile drawer.

**Data**: 25 rows of realistic mock data (aliases like `goblinmode`, `waifusniper`, `matcha.sol`, `0xMira`, `snipegod`, `floorflipper`, `gasgoblin`, `mintqueen`…), PnL ranging `+84.2` down to `+2.1 ETH` with a few red negatives at the bottom of ALL timeframe.

**Animation**: Initial load: rows stagger in from right (x 24px, 35ms stagger, 300ms). Sort: rows FLIP-animate to new positions (Framer Motion layout, 350ms spring). Every ~4s one random visible row's PnL ticks up with a green flash (live simulation).

---

## S4. Trader Profile Drawer

**Trigger**: Clicking a row (or its chevron) opens a right-side drawer (480px, `bg-panel`, left hairline, Framer Motion x 480→0, 350ms spring; backdrop `bg-void/70` fade 200ms; ESC/backdrop closes).

**Content** (top→bottom):
- Header: 56px avatar, alias + full address with copy button, rank chip, "Copy this sniper" green button (full width).
- Equity curve: 90d area chart (SVG, green gradient fill, grid lines, hover crosshair with mono tooltip `Apr 12 · +61.4 ETH`).
- Stats grid 3×2: Total PnL · Win rate · Mints · Avg ROI/mint · Median hold · Followers.
- "Recent mints" mini-list (5 rows): NFT thumb, collection, date, PnL chip.
- Copy defaults preview: what your copy settings would be (links to `/copy-trading` settings section).

**Animation**: Drawer content staggers in after slide (60ms apart). Chart draws (dashoffset, 1s). Hover crosshair: vertical hairline + dot snap to nearest point, tooltip follows (transform only).

---

## S5. "Get Listed" Band

**Layout**: Two-column panel (`bg-panel`, violet radial glow left): copy left, CTA right.
- H3: "Think your wallet belongs here?"
- Body: "Connect read-only and MintDash will verify your on-chain track record automatically. 30 days of history, 50+ mints, positive expectancy — you're in."
- Ghost button "Verify my wallet" + mono caption `read-only · revocable · no signing of txs`.

**Animation**: Panel scales 0.97→1 + fade on entry; violet glow blooms (opacity 0→1, 800ms).

---

## S6. CTA Band + Footer

Shared CTA band + footer. Standard animations.

---

## Assets used
`sniper-avatar-1..8.png`, `chain-*.svg`, `nft-mint-1..6.png` (recent mints in drawer). Table, charts, drawer all live HTML/SVG.
