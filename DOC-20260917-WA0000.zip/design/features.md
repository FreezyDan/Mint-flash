# Features Page (`/features`)

Deep-dive product page. Structure: page header, 6 alternating showcase sections (each pairing copy with a UI/terminal illustration), a multi-chain strip, and the shared CTA band. No pinned scroll here — instead each showcase uses scroll-scrubbed internal animations.

---

## S1. Page Header

**Layout**: Centered, pt-40 pb-20, violet radial glow behind.
- Eyebrow: `[ THE ENGINE ]` green.
- H1 (60px): "Built for the first block. **Every block.**" — gradient green→cyan on second phrase, word-level split.
- Subhead: "Six systems working in parallel so your transaction lands before the crowd knows the mint is live."
- Scroll hint: mono 11px `scroll ↓` with bouncing chevron (translateY 0→6px, 1s loop).

**Animation**: Header content staggers up on load (eyebrow → H1 → sub, 100ms apart, y 24px, 500ms). Glow fades in 800ms.

---

## S2. Showcase 01 — Auto-Mint Engine

**Layout**: Alternating row — copy left (45%), visual right (55%). Visual = live HTML terminal card (larger version of hero's): full task lifecycle typing loop — `watch → goLive → simulate → fire → confirm`, with timing annotations appearing next to each line in cyan mono.

**Copy**:
- Mono index `01` + H3 32px: "The Auto-Mint Engine"
- Body: "Point MintDash at any ERC-721/1155, Candy Machine, or fair-launch contract. We read mint state directly from the chain — not the project's website — and pre-build your transaction so it's signed, simulated, and ready to fire."
- Spec chips row (mono 12px, hairline chips): `pre-signed tx` · `block-subscription` · `auto-retry 3×` · `reorg detection`.

**Animation**: Copy slides in from left (x −32px, 500ms). Terminal starts typing only when 50% visible; each line types 15ms/char, with a green flash on the `✓ CONFIRMED` line; loops continuously while in view.

---

## S3. Showcase 02 — Mempool Sniping (reversed)

**Layout**: Visual left, copy right. Visual = "latency race" bar chart built in HTML: 5 horizontal bars comparing `MintDash 412ms` (green, glowing) vs `Browser mint 4.2s`, `Mobile wallet 6.8s`, `Discord alert 12s`, `Email lol ∞` (grays, progressively dimmer). Bars animate width on scroll.

**Copy**:
- `02` + H3: "Mempool Sniping"
- Body: "MintDash subscribes to pending blocks and contract events across private relay networks. When a mint function flips active — a timestamp, a block number, an owner transaction — your tx is already in flight. Frontends are for collectors. You're a sniper."
- Spec chips: `private relays` · `mempool watch` · `event triggers` · `flashbots-style bundles`.

**Animation**: Bars grow from 0→final width on entry (800ms, `power3.out`, stagger 80ms); MintDash bar gets a trailing glow pulse after landing. Copy slides from right (x 32px).

---

## S4. Showcase 03 — Gas Warfare

**Layout**: Copy left, visual right. Visual = interactive gas strategy dial: three preset cards (Chill / Degen / God-mode) with a live "estimated inclusion" readout that changes as you hover each preset (`~12 blocks` / `~1 block` / `next block — 99.1%`), plus a priority-fee slider that updates a mono fee readout `maxFee 84 gwei · priority 12 gwei`.

**Copy**: `03` + H3 "Gas Warfare, Automated". Body: "Stop guessing gwei. MintDash models each drop's competition in real time and sets just enough priority fee to win inclusion without overpaying. God-mode routes through builder bundles when the block is contested." Chips: `dynamic priority` · `bundle routing` · `overpay guard` · `per-drop profiles`.

**Animation**: Dial cards stagger in (100ms, y 24px). Hovering a preset: card lifts, readout digits roll (odometer-style, 300ms). Slider thumb has friction feel (Framer Motion drag with snap).

---

## S5. Showcase 04 — Anti-Rug Shield (reversed)

**Layout**: Visual left — `features-anti-rug.png` inside a device-frame panel with scanline overlay; copy right.

**Copy**: `04` + H3 "Anti-Rug Shield". Body: "Before a single wei moves, every watched contract is decompiled and scored: hidden mint functions, proxy upgrade traps, honeypot transfer logic, dev wallet concentration. Score above your threshold and the task auto-aborts — with a full report." Chips: `honeypot detect` · `proxy trap scan` · `dev concentration` · `auto-abort`.

**Animation**: On entry the risk-gauge in the image gets an HTML overlay arc that sweeps 0→12 (score) over 1.2s; checklist rows (HTML overlay, green checks) stagger in 90ms; the one red warning row pulses (opacity 0.6→1, 1.4s, 2 loops).

---

## S6. Showcase 05 — Multi-Wallet Rotation

**Layout**: Copy left, visual right. Visual = a fanned stack of 8 wallet chips (mono addresses, avatar dots) that on hover spread into a grid; a counter chip reads `50 wallets · 1 task`.

**Copy**: `05` + H3 "Multi-Wallet Rotation". Body: "Per-wallet mint limits are a suggestion, not a rule. Spin up to 50 funded wallets per task; MintDash distributes mints, randomizes timing within your window, and consolidates proceeds back to your vault wallet automatically." Chips: `50 wallets/task` · `timing jitter` · `auto-consolidate` · `vault sweep`.

**Animation**: Wallet chips deal in like cards (rotate from −8°, y 30px, stagger 60ms, `back.out(1.6)`). Hover spreads the fan over 350ms spring.

---

## S7. Showcase 06 — Instant Sell-Down (reversed)

**Layout**: Visual left — flow diagram: `MINTED` (green chip) → arrow → `LISTED @ 0.42 ETH` (violet chip) → arrow → `SOLD +0.31 ETH` (green), with an animated dashed line marching along the arrows; copy right.

**Copy**: `06` + H3 "Instant Sell-Down". Body: "Minting is half the trade. Optionally auto-list your fills on major marketplaces at your target multiple or trailing floor, the same block they confirm. Take profit while everyone else is still refreshing metadata." Chips: `auto-list` · `target multiple` · `trailing floor` · `same-block`.

**Animation**: Dashed arrow lines animate `stroke-dashoffset` continuously (marching ants, 20s loop). Stage chips pop in sequence on entry (scale 0.8→1, stagger 200ms, `back.out`).

---

## S8. Multi-Chain Strip

**Layout**: Full-width panel, `bg-panel`, centered. H3 "One terminal. Every chain." + row of 4 chain cards (SVG badge, name, mono stat):
- Ethereum — `2,841 tasks live`
- Solana — `1,204 tasks live`
- Base — `986 tasks live`
- Polygon — `412 tasks live`

**Animation**: Cards stagger up 90ms; task counters tick +1 every ~5s with green flash (simulated).

---

## S9. CTA Band + Footer

Shared CTA band ("Stop clicking. Start sniping.") + global footer. Standard reveal animations.

---

## Assets used
`features-anti-rug.png`, `chain-*.svg` (4), `og-grid-texture.svg`. Terminal/dial/flow visuals are built in HTML/CSS, not images.
